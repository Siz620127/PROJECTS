package sy_my ;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Scanner;
import org.json.simple.JSONObject;
import org.json.simple.JSONArray;
import org.json.simple.JSONValue;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

// import java.time.*;

// -------

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import java.sql.* ;

// import java.sql.Connection;
// import java.sql.Date;
// import java.sql.DriverManager;
// import java.sql.PreparedStatement;
// import java.sql.SQLException;

import java.text.SimpleDateFormat;


public class Queries_SAL {



    // TEST START
    public static HttpURLConnection TestQuery(ReadConf conf) throws Exception {
        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals("185.158.177.241");

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end


             // URL url             = new URL( conf.getUrl_sy() );
             URL url                = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", "185.158.177.241"  );
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", "f1bc5219-b382-472e-adc9-ff0926ecbbb0" );



     	     String json = "{\n";
     		 json += "\"Username\": "     +  "\"ADMIN\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"\" "       + ",\n";
		     json += "\"ForceRelogin\": " +  true          + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( response );

   			     return con ;  // response


                 /*
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parse    = new JSONParser();
                 JSONObject data_obj = (JSONObject) parse.parse( json );  // inline
                 //Get the required object from the above created object
                 JSONObject obj = (JSONObject) data_obj.get("Globale");
                 //Get the required data using its key
                 System.out.println(obj.get("TotalRecovered"));
                 JSONArray arr = (JSONArray) data_obj.get("Countries");
                 for (int i = 0; i < arr.size(); i++) {
                      JSONObject new_obj = (JSONObject) arr.get(i);
                      if (new_obj.get("Slug").equals("albania")) {
                         System.out.println("Total Recovered: " + new_obj.get("TotalRecovered"));
                         break;
                      }
                 }
               */

                }


        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() );
        }
        // return con;
    }

    // TEST END





    public static String getCustomerOrderInvoices(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/CustomerOrderInvoices?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".customerorderinvoice  where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".customerorderinvoice (tenant_id , id , " +
                          " Version , " +
                          " ActiveDeliveryAddressCustomerId , " +
                          " ActiveDeliveryAddressSupplierId , " +
                          " ActiveDeliveryAddressCompanyId , " +
                          " SourceOfAlternativeDeliveryAddresses , " +
                          " Status , " +
                          " ConsigneeReferenceId , " +
                          " ProformaStatus , " +
                          " ProjectId , " +
                          " DeliveryAddressId , " +
                          " InvoiceAddressId , " +
                          " OurReferenceId , " +
                          " OurReferenceName , " +
                          " BusinessContactReferenceName , " +
                          " GoodsLabel , " +
                          " InvoiceStatusPending , " +
                          " ComprehensiveInvoiceGroupingMode , " +
                          " IsConverted , " +
                          " BusinessContactReferenceId , " +
                          " HasInvoicingCharge , " +
                          " IsFreeDeliveryMonth , " +
                          " GoodsAddressNumber , " +
                          " VatNumber , " +
                          " Dock , " +
                          " DeliveryInstruction , " +
                          " UsePackageSpecification , " +
                          " InvoicePrintoutMethod , " +
                          " PrintProformaInvoiceVia , " +
                          " EInvoiceExportMode , " +
                          " Priority , " +
                          " DirectlyRegistered , " +
                          " PartialInvoiceType , " +
                          " FormReportConfigurationId , " +
                          " DeliveryNoteNumber , " +
                          " DeliveryNoteCreationDate , " +
                          " ExcludeFromEdi , " +
                          " DeliveryIndex , " +
                          " OrderDeliveryNumber , " +
                          " SellerId , " +
                          " PickingListId , " +
                          " ShippingInformationId , " +
                          " ProformaNumber , " +
                          " ProformaDate , " +
                          " DestinationForDeliveryTerm , " +
                          " CandidateDebitInvoiceId , " +
                          " ConsigneeReferenceName , " +
                          " LedgerId , " +
                          " BusinessContactOrderId , " +
                          " InvoiceBusinessContactId , " +
                          " AccountGroupId , " +
                          " WarehouseId , " +
                          " VatGroupId , " +
                          " PaymentTermId , " +
                          " PaymentTermDescription , " +
                          " GracePeriodInDays , " +
                          " DeliveryMethodId , " +
                          " DeliveryTermId , " +
                          " DeliveryTermDescription , " +
                          " DeliveryMethodDescription , " +
                          " ShipmentPayer , " +
                          " MalaysianTaxExemptionId , " +
                          " Storage , " +
                          " SplitPayment , " +
                          " ActiveDeliveryAddressDeliveryAddressId , " +
                          " ExternalDeliveryNoteNumber , " +

                          " IsPartOfComprehensiveInvoice   " +

                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                           "\"" + ((rec_obj.get("Version") == null)                                         ? 0 : rec_obj.get("Version")  )                                                    + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ActiveDeliveryAddressCustomerId") == null)                 ? 0 : rec_obj.get("ActiveDeliveryAddressCustomerId")  )                            + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ActiveDeliveryAddressSupplierId") == null)                 ? 0 : rec_obj.get("ActiveDeliveryAddressSupplierId")  )                            + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ActiveDeliveryAddressCompanyId") == null)                  ? 0 : rec_obj.get("ActiveDeliveryAddressCompanyId")  )                             + "\" "    + ", " +
                           "\"" + ((rec_obj.get("SourceOfAlternativeDeliveryAddresses") == null)            ? 0 : rec_obj.get("SourceOfAlternativeDeliveryAddresses")  )                       + "\" "    + ", " +
                           "\"" + ((rec_obj.get("Status") == null)                                          ? 0 : rec_obj.get("Status")  )                                                     + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ConsigneeReferenceId") == null)                            ? 0 : rec_obj.get("ConsigneeReferenceId")  )                                       + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ProformaStatus") == null)                                  ? 0 : rec_obj.get("ProformaStatus")  )                                             + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ProjectId") == null)                                       ? 0 : rec_obj.get("ProjectId")  )                                                  + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DeliveryAddressId") == null)                               ? 0 : rec_obj.get("DeliveryAddressId")  )                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("InvoiceAddressId") == null)                                ? 0 : rec_obj.get("InvoiceAddressId")  )                                           + "\" "    + ", " +
                           "\"" + ((rec_obj.get("OurReferenceId") == null)                                  ? 0 : rec_obj.get("OurReferenceId")  )                                             + "\" "    + ", " +
                           "\"" + ((rec_obj.get("OurReferenceName") == null)                                ? 0 : rec_obj.get("OurReferenceName")  )                                           + "\" "    + ", " +
                           "\"" + ((rec_obj.get("BusinessContactReferenceName") == null)                    ? 0 : rec_obj.get("BusinessContactReferenceName")  )                               + "\" "    + ", " +
                           "\"" + ((rec_obj.get("GoodsLabel") == null)                                      ? 0 : rec_obj.get("GoodsLabel")  )                                                 + "\" "    + ", " +
                           "\"" + ((rec_obj.get("InvoiceStatusPending") == "false")                         ? 0 : 1 )                                                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ComprehensiveInvoiceGroupingMode") == null)                ? 0 : rec_obj.get("ComprehensiveInvoiceGroupingMode")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsConverted") == "false")                                  ? 0 : 1 )                                                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("BusinessContactReferenceId") == null)                      ? 0 : rec_obj.get("BusinessContactReferenceId")  )                                 + "\" "    + ", " +
                           "\"" + ((rec_obj.get("HasInvoicingCharge") == "false")                           ? 0 : 1 )                                                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("IsFreeDeliveryMonth") == "false")                          ? 0 : 1 )                                                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("GoodsAddressNumber") == null)                              ? 0 : rec_obj.get("GoodsAddressNumber")  )                                         + "\" "    + ", " +
                           "\"" + ((rec_obj.get("VatNumber") == null)                                       ? 0 : rec_obj.get("VatNumber")  )                                                  + "\" "    + ", " +
                           "\"" + ((rec_obj.get("Dock") == null)                                            ? 0 : rec_obj.get("Dock")  )                                                       + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DeliveryInstruction") == null)                             ? 0 : rec_obj.get("DeliveryInstruction")  )                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("UsePackageSpecification") == "false")                      ? 0 : 1 )                                                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("InvoicePrintoutMethod") == null)                           ? 0 : rec_obj.get("InvoicePrintoutMethod")  )                                      + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PrintProformaInvoiceVia") == null)                         ? 0 : rec_obj.get("PrintProformaInvoiceVia")  )                                    + "\" "    + ", " +
                           "\"" + ((rec_obj.get("EInvoiceExportMode") == null)                              ? 0 : rec_obj.get("EInvoiceExportMode")  )                                         + "\" "    + ", " +
                           "\"" + ((rec_obj.get("Priority") == null)                                        ? 0 : rec_obj.get("Priority")  )                                                   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DirectlyRegistered") == "false")                           ? 0 : 1 )                                                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PartialInvoiceType") == null)                              ? 0 : rec_obj.get("PartialInvoiceType")  )                                         + "\" "    + ", " +
                           "\"" + ((rec_obj.get("FormReportConfigurationId") == null)                       ? 0 : rec_obj.get("FormReportConfigurationId")  )                                  + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DeliveryNoteNumber") == null)                              ? 0 : rec_obj.get("DeliveryNoteNumber")  )                                         + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DeliveryNoteCreationDate") == null || rec_obj.get("DeliveryNoteCreationDate").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("DeliveryNoteCreationDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                           "\"" + ((rec_obj.get("ExcludeFromEdi") == "false")                               ? 0 : 1 )                                                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DeliveryIndex") == null)                                   ? 0 : rec_obj.get("DeliveryIndex")  )                                              + "\" "    + ", " +
                           "\"" + ((rec_obj.get("OrderDeliveryNumber") == null)                             ? 0 : rec_obj.get("OrderDeliveryNumber")  )                                        + "\" "    + ", " +
                           "\"" + ((rec_obj.get("SellerId") == null)                                        ? 0 : rec_obj.get("SellerId")  )                                                   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PickingListId") == null)                                   ? 0 : rec_obj.get("PickingListId")  )                                              + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ShippingInformationId") == null)                           ? 0 : rec_obj.get("ShippingInformationId")  )                                      + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ProformaNumber") == null)                                  ? 0 : rec_obj.get("ProformaNumber")  )                                             + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ProformaDate") == null || rec_obj.get("ProformaDate").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("ProformaDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                           "\"" + ((rec_obj.get("DestinationForDeliveryTerm") == null)                      ? 0 : rec_obj.get("DestinationForDeliveryTerm")  )                                 + "\" "    + ", " +
                           "\"" + ((rec_obj.get("CandidateDebitInvoiceId") == null)                         ? 0 : rec_obj.get("CandidateDebitInvoiceId")  )                                    + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ConsigneeReferenceName") == null)                          ? 0 : rec_obj.get("ConsigneeReferenceName")  )                                     + "\" "    + ", " +
                           "\"" + ((rec_obj.get("LedgerId") == null)                                        ? 0 : rec_obj.get("LedgerId")  )                                                   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("BusinessContactOrderId") == null)                          ? 0 : rec_obj.get("BusinessContactOrderId")  )                                     + "\" "    + ", " +
                           "\"" + ((rec_obj.get("InvoiceBusinessContactId") == null)                        ? 0 : rec_obj.get("InvoiceBusinessContactId")  )                                   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("AccountGroupId") == null)                                  ? 0 : rec_obj.get("AccountGroupId")  )                                             + "\" "    + ", " +
                           "\"" + ((rec_obj.get("WarehouseId") == null)                                     ? 0 : rec_obj.get("WarehouseId")  )                                                + "\" "    + ", " +
                           "\"" + ((rec_obj.get("VatGroupId") == null)                                      ? 0 : rec_obj.get("VatGroupId")  )                                                 + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PaymentTermId") == null)                                   ? 0 : rec_obj.get("PaymentTermId")  )                                              + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PaymentTermDescription") == null)                          ? 0 : rec_obj.get("PaymentTermDescription")  )                                     + "\" "    + ", " +
                           "\"" + ((rec_obj.get("GracePeriodInDays") == null)                               ? 0 : rec_obj.get("GracePeriodInDays")  )                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DeliveryMethodId") == null)                                ? 0 : rec_obj.get("DeliveryMethodId")  )                                           + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DeliveryTermId") == null)                                  ? 0 : rec_obj.get("DeliveryTermId")  )                                             + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DeliveryTermDescription") == null)                         ? 0 : rec_obj.get("DeliveryTermDescription")  )                                    + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DeliveryMethodDescription") == null)                       ? 0 : rec_obj.get("DeliveryMethodDescription")  )                                  + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ShipmentPayer") == null)                                   ? 0 : rec_obj.get("ShipmentPayer")  )                                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("MalaysianTaxExemptionId") == null)                         ? 0 : rec_obj.get("MalaysianTaxExemptionId")  )                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Storage") == null)                                         ? 0 : rec_obj.get("Storage")  )                                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SplitPayment") == "false")                                 ? 0 : 1 )                                                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ActiveDeliveryAddressDeliveryAddressId") == null)          ? 0 : rec_obj.get("ActiveDeliveryAddressDeliveryAddressId")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ExternalDeliveryNoteNumber") == null)                      ? 0 : rec_obj.get("ExternalDeliveryNoteNumber")  )                                 + "\" "    + ", " +

                          "\"" + ((rec_obj.get("IsPartOfComprehensiveInvoice") == "false")                 ? 0 : 1 )                                                                          + "\" "    + "  " +

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "CustomerOrderInvoice was imported from Monitor API to MySql. " + rs_count + " records "  , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getCustomerOrderInvoices





    public static String getCustomerOrders(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrders" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/CustomerOrders?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".customerorder  where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".customerorder (tenant_id , id , " +
                          " Version , " +
                          " IsStockOrder , " +
                          " EdiOrderType , " +
                          " ExcludeFromEdi , " +
                          " SellerId , " +
                          " IncludeInDeliveryAnalysis , " +
                          " PartialDeliveryType , " +
                          " UsePackageSpecification , " +
                          " UseBundling , " +
                          " DeliveryHorizon , " +
                          " DeliveryNoteNumberWhenDeliveryPlanning , " +
                          " PreliminaryPickingList , " +
                          " ShowPriceInAcknowledgement , " +
                          " ShowTotalInAcknowledgement , " +
                          " ThirdPartyTrading , " +
                          " DeliveryInstruction , " +
                          " ActiveDeliveryAddressCustomerId , " +
                          " ActiveDeliveryAddressSupplierId , " +
                          " ActiveDeliveryAddressCompanyId , " +
                          " SourceOfAlternativeDeliveryAddresses , " +
                          " IsCredit , " +
                          " InvoiceType , " +
                          " PaymentMethodId , " +
                          " ReasonCodeDebitNoteId , " +
                          " ConsigneeReferenceId , " +
                          " ImportInformationId , " +
                          " Preliminary , " +
                          " InvoiceAddressId , " +
                          " InvoiceStatusPending , " +
                          " ComprehensiveInvoiceGroupingMode , " +
                          " HasInvoicingCharge , " +
                          " IsFreeDeliveryMonth , " +
                          " GoodsAddressNumber , " +
                          " DestinationForDeliveryTerm , " +
                          " VatNumber , " +
                          " Dock , " +
                          " FromQuoteNumber , " +
                          " AftermarketProductRecordId , " +
                          " PurchaseOrderId , " +
                          " PaymentPlanTemplateId , " +
                          " PaymentPlanConvertedFromG4 , " +
                          " UnpaidAdvanceWarningType , " +
                          " CreatedFrom , " +
                          " ShippingInformationId , " +
                          " Status , " +
                          " UseForwardRate , " +
                          " ExcludeFromPaymentPlanReconciliation , " +
                          " ResetPaymentPlanDifferenceAmount , " +
                          " ResetPaymentPlanDifferenceAmountCurrencyId , " +
                          " ConsigneeReferenceName , " +
                          " PrintProformaInvoiceVia , " +
                          " TransferStatus , " +
                          " CustomerOrderTransferOrderIdentifier , " +
                          " CreatedInCompanyWithRole , " +
                          " BusinessContactId , " +
                          " InvoiceBusinessContactId , " +
                          " OrderTypeId , " +
                          " AccountGroupId , " +
                          " CategoryString , " +
                          " BusinessContactReferenceId , " +
                          " DeliveryAddressId , " +
                          " OrderNumber , " +
                          " OrderDate , " +
                          " BusinessContactOrderNumber , " +
                          " OurReferenceId , " +
                          " OurReferenceName , " +
                          " BusinessContactReferenceName , " +
                          " GoodsLabel , " +
                          " CurrencyId , " +
                          " VatGroupId , " +
                          " WarehouseId , " +
                          " Priority , " +
                          " ProjectId , " +
                          " MailingAddressId , " +
                          " SendMethod , " +
                          " InvoicePrintoutMethod , " +
                          " InternalCommentId , " +
                          " ExternalCommentId , " +
                          " TransportTime , " +
                          " LifeCycleState , " +
                          " ExchangeRate , " +
                          " PaymentTermId , " +
                          " PaymentTermDescription , " +
                          " GracePeriodInDays , " +
                          " DeliveryMethodId , " +
                          " DeliveryTermId , " +
                          " DeliveryTermDescription , " +
                          " DeliveryMethodDescription , " +
                          " ShipmentPayer , " +
                          " FreightPayerAddressId , " +
                          " FreightPayerAddressActive , " +
                          " MalaysianTaxExemptionId , " +
                          " SplitPayment , " +
                          " ReasonCodeCorrectionInvoiceId , " +
                          " ReasonCodeCorrectionInvoiceText , " +
                          " ActiveDeliveryAddressDeliveryAddressId , " +
                          " PolishVatInfo ,  " +

                          " CustomerId , "  +
                          " InvoiceCustomerId ,  "  +
                          " IsPartOfComprehensiveInvoice  " +

                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                           "\"" + ((rec_obj.get("Version") == null)                                         ? 0 : rec_obj.get("Version")  )                                                    + "\" "    + ", " +
                           "\"" + ((rec_obj.get("IsStockOrder") == "false")                                 ? 0 : 1 )                                                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("EdiOrderType") == null)                                    ? 0 : rec_obj.get("EdiOrderType")  )                                               + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ExcludeFromEdi") == "false")                               ? 0 : 1 )                                                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("SellerId") == null)                                        ? 0 : rec_obj.get("SellerId")  )                                                   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("IncludeInDeliveryAnalysis") == "false")                    ? 0 : 1 )                                                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PartialDeliveryType") == null)                             ? 0 : rec_obj.get("PartialDeliveryType")  )                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("UsePackageSpecification") == "false")                      ? 0 : 1 )                                                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("UseBundling") == "false")                                  ? 0 : 1 )                                                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DeliveryHorizon") == null)                                 ? 0 : rec_obj.get("PartialDeliveryType")  )                                        + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DeliveryNoteNumberWhenDeliveryPlanning") == "false")       ? 0 : 1 )                                                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PreliminaryPickingList") == "false")                       ? 0 : 1 )                                                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ShowPriceInAcknowledgement") == "false")                   ? 0 : 1 )                                                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ShowTotalInAcknowledgement") == "false")                   ? 0 : 1 )                                                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ThirdPartyTrading") == "false")                            ? 0 : 1 )                                                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DeliveryInstruction") == null)                             ? 0 : rec_obj.get("DeliveryInstruction")  )                                        + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ActiveDeliveryAddressCustomerId") == null)                 ? 0 : rec_obj.get("ActiveDeliveryAddressCustomerId")  )                            + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ActiveDeliveryAddressSupplierId") == null)                 ? 0 : rec_obj.get("ActiveDeliveryAddressSupplierId")  )                            + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ActiveDeliveryAddressCompanyId") == null)                  ? 0 : rec_obj.get("ActiveDeliveryAddressCompanyId")  )                             + "\" "    + ", " +
                           "\"" + ((rec_obj.get("SourceOfAlternativeDeliveryAddresses") == null)            ? 0 : rec_obj.get("SourceOfAlternativeDeliveryAddresses")  )                       + "\" "    + ", " +
                           "\"" + ((rec_obj.get("IsCredit") == "false")                                     ? 0 : 1 )                                                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("InvoiceType") == null)                                     ? 0 : rec_obj.get("InvoiceType")  )                                                + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PaymentMethodId") == null)                                 ? 0 : rec_obj.get("PaymentMethodId")  )                                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReasonCodeDebitNoteId") == null)                           ? 0 : rec_obj.get("ReasonCodeDebitNoteId")  )                                      + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ConsigneeReferenceId") == null)                            ? 0 : rec_obj.get("ConsigneeReferenceId")  )                                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ImportInformationId") == null)                             ? 0 : rec_obj.get("ImportInformationId")  )                                        + "\" "    + ", " +
                           "\"" + ((rec_obj.get("Preliminary") == "false")                                  ? 0 : 1 )                                                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("InvoiceAddressId") == null)                                ? 0 : rec_obj.get("InvoiceAddressId")  )                                           + "\" "    + ", " +
                           "\"" + ((rec_obj.get("InvoiceStatusPending") == "false")                         ? 0 : 1 )                                                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ComprehensiveInvoiceGroupingMode") == null)                ? 0 : rec_obj.get("ComprehensiveInvoiceGroupingMode")  )                           + "\" "    + ", " +
                           "\"" + ((rec_obj.get("HasInvoicingCharge") == "false")                           ? 0 : 1 )                                                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsFreeDeliveryMonth") == "false")                          ? 0 : 1 )                                                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("GoodsAddressNumber") == null)                              ? 0 : rec_obj.get("GoodsAddressNumber")  )                                         + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DestinationForDeliveryTerm") == null)                      ? 0 : rec_obj.get("DestinationForDeliveryTerm")  )                                 + "\" "    + ", " +
                           "\"" + ((rec_obj.get("VatNumber") == null)                                       ? 0 : rec_obj.get("VatNumber")  )                                                  + "\" "    + ", " +
                           "\"" + ((rec_obj.get("Dock") == null)                                            ? 0 : rec_obj.get("Dock")  )                                                       + "\" "    + ", " +
                           "\"" + ((rec_obj.get("FromQuoteNumber") == null)                                 ? 0 : rec_obj.get("FromQuoteNumber")  )                                            + "\" "    + ", " +
                           "\"" + ((rec_obj.get("AftermarketProductRecordId") == null)                      ? 0 : rec_obj.get("AftermarketProductRecordId")  )                                 + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PurchaseOrderId") == null)                                 ? 0 : rec_obj.get("PurchaseOrderId")  )                                            + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PaymentPlanTemplateId") == null)                           ? 0 : rec_obj.get("PaymentPlanTemplateId")  )                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PaymentPlanConvertedFromG4") == "false")                   ? 0 : 1 )                                                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("UnpaidAdvanceWarningType") == null)                        ? 0 : rec_obj.get("UnpaidAdvanceWarningType")  )                                   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("CreatedFrom") == null)                                     ? 0 : rec_obj.get("CreatedFrom")  )                                                + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ShippingInformationId") == null)                           ? 0 : rec_obj.get("ShippingInformationId")  )                                      + "\" "    + ", " +
                           "\"" + ((rec_obj.get("Status") == null)                                          ? 0 : rec_obj.get("Status")  )                                                     + "\" "    + ", " +
                           "\"" + ((rec_obj.get("UseForwardRate") == "false")                               ? 0 : 1 )                                                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ExcludeFromPaymentPlanReconciliation") == "false")         ? 0 : 1 )                                                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ResetPaymentPlanDifferenceAmount") == null)                ? 0 : rec_obj.get("ResetPaymentPlanDifferenceAmount")  )                           + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ResetPaymentPlanDifferenceAmountCurrencyId") == null)      ? 0 : rec_obj.get("ResetPaymentPlanDifferenceAmountCurrencyId")  )                 + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ConsigneeReferenceName") == null)                          ? 0 : rec_obj.get("ConsigneeReferenceName")  )                                     + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PrintProformaInvoiceVia") == null)                         ? 0 : rec_obj.get("PrintProformaInvoiceVia")  )                                    + "\" "    + ", " +
                           "\"" + ((rec_obj.get("TransferStatus") == null)                                  ? 0 : rec_obj.get("TransferStatus")  )                                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CustomerOrderTransferOrderIdentifier") == null)            ? 0 : rec_obj.get("CustomerOrderTransferOrderIdentifier")  )                       + "\" "    + ", " +
                           "\"" + ((rec_obj.get("CreatedInCompanyWithRole") == null)                        ? 0 : rec_obj.get("CreatedInCompanyWithRole")  )                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BusinessContactId") == null)                               ? 0 : rec_obj.get("BusinessContactId")  )                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InvoiceBusinessContactId") == null)                        ? 0 : rec_obj.get("InvoiceBusinessContactId")  )                                   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("OrderTypeId") == null)                                     ? 0 : rec_obj.get("OrderTypeId")  )                                                + "\" "    + ", " +
                           "\"" + ((rec_obj.get("AccountGroupId") == null)                                  ? 0 : rec_obj.get("AccountGroupId")  )                                             + "\" "    + ", " +
                           "\"" + ((rec_obj.get("CategoryString") == null)                                  ? 0 : rec_obj.get("CategoryString")  )                                             + "\" "    + ", " +
                           "\"" + ((rec_obj.get("BusinessContactReferenceId") == null)                      ? 0 : rec_obj.get("BusinessContactReferenceId")  )                                 + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DeliveryAddressId") == null)                               ? 0 : rec_obj.get("DeliveryAddressId")  )                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("OrderNumber") == null)                                     ? 0 : rec_obj.get("OrderNumber")  )                                                + "\" "    + ", " +
                           "\"" + ((rec_obj.get("OrderDate") == null || rec_obj.get("OrderDate").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("OrderDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                           "\"" + ((rec_obj.get("BusinessContactOrderNumber") == null)                      ? 0 : rec_obj.get("BusinessContactOrderNumber")  )                                 + "\" "    + ", " +
                           "\"" + ((rec_obj.get("OurReferenceId") == null)                                  ? 0 : rec_obj.get("OurReferenceId")  )                                             + "\" "    + ", " +
                           "\"" + ((rec_obj.get("OurReferenceName") == null)                                ? 0 : rec_obj.get("OurReferenceName")  )                                           + "\" "    + ", " +
                           "\"" + ((rec_obj.get("BusinessContactReferenceName") == null)                    ? 0 : rec_obj.get("BusinessContactReferenceName")  )                               + "\" "    + ", " +
                           "\"" + ((rec_obj.get("GoodsLabel") == null)                                      ? 0 : rec_obj.get("GoodsLabel")  )                                                 + "\" "    + ", " +
                           "\"" + ((rec_obj.get("CurrencyId") == null)                                      ? 0 : rec_obj.get("CurrencyId")  )                                                 + "\" "    + ", " +
                           "\"" + ((rec_obj.get("VatGroupId") == null)                                      ? 0 : rec_obj.get("VatGroupId")  )                                                 + "\" "    + ", " +
                           "\"" + ((rec_obj.get("WarehouseId") == null)                                     ? 0 : rec_obj.get("WarehouseId")  )                                                + "\" "    + ", " +
                           "\"" + ((rec_obj.get("Priority") == null)                                        ? 0 : rec_obj.get("Priority")  )                                                   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ProjectId") == null)                                       ? 0 : rec_obj.get("ProjectId")  )                                                  + "\" "    + ", " +
                           "\"" + ((rec_obj.get("MailingAddressId") == null)                                ? 0 : rec_obj.get("MailingAddressId")  )                                           + "\" "    + ", " +
                           "\"" + ((rec_obj.get("SendMethod") == null)                                      ? 0 : rec_obj.get("SendMethod")  )                                                 + "\" "    + ", " +
                           "\"" + ((rec_obj.get("InvoicePrintoutMethod") == null)                           ? 0 : rec_obj.get("InvoicePrintoutMethod")  )                                      + "\" "    + ", " +
                           "\"" + ((rec_obj.get("InternalCommentId") == null)                               ? 0 : rec_obj.get("InternalCommentId")  )                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ExternalCommentId") == null)                               ? 0 : rec_obj.get("ExternalCommentId")  )                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("TransportTime") == null)                                   ? 0 : rec_obj.get("TransportTime")  )                                              + "\" "    + ", " +
                           "\"" + ((rec_obj.get("LifeCycleState") == null)                                  ? 0 : rec_obj.get("LifeCycleState")  )                                             + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ExchangeRate") == null)                                    ? 0 : rec_obj.get("ExchangeRate")  )                                               + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PaymentTermId") == null)                                   ? 0 : rec_obj.get("PaymentTermId")  )                                              + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PaymentTermDescription") == null)                          ? 0 : rec_obj.get("PaymentTermDescription")  )                                     + "\" "    + ", " +
                           "\"" + ((rec_obj.get("GracePeriodInDays") == null)                               ? 0 : rec_obj.get("GracePeriodInDays")  )                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DeliveryMethodId") == null)                                ? 0 : rec_obj.get("DeliveryMethodId")  )                                           + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DeliveryTermId") == null)                                  ? 0 : rec_obj.get("DeliveryTermId")  )                                             + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DeliveryTermDescription") == null)                         ? 0 : rec_obj.get("DeliveryTermDescription")  )                                    + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DeliveryMethodDescription") == null)                       ? 0 : rec_obj.get("DeliveryMethodDescription")  )                                  + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ShipmentPayer") == null)                                   ? 0 : rec_obj.get("ShipmentPayer")  )                                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("FreightPayerAddressId") == null)                           ? 0 : rec_obj.get("FreightPayerAddressId")  )                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("FreightPayerAddressActive") == "false")                    ? 0 : 1 )                                                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("MalaysianTaxExemptionId") == null)                         ? 0 : rec_obj.get("MalaysianTaxExemptionId")  )                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SplitPayment") == "false")                                 ? 0 : 1 )                                                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReasonCodeCorrectionInvoiceId") == null)                   ? 0 : rec_obj.get("ReasonCodeCorrectionInvoiceId")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReasonCodeCorrectionInvoiceText") == null)                 ? 0 : rec_obj.get("ReasonCodeCorrectionInvoiceText")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ActiveDeliveryAddressDeliveryAddressId") == null)          ? 0 : rec_obj.get("ActiveDeliveryAddressDeliveryAddressId")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PolishVatInfo") == null)                                   ? 0 : rec_obj.get("PolishVatInfo")  )                                              + "\" "    + ", " +

                           "\"" + ((rec_obj.get("CustomerId") == null)                                      ? 0 : rec_obj.get("CustomerId")  )                                                 + "\" "    + ", " +
                           "\"" + ((rec_obj.get("InvoiceCustomerId") == null)                               ? 0 : rec_obj.get("InvoiceCustomerId")  )                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("IsPartOfComprehensiveInvoice") == "false")                 ? 0 : 1 )                                                                          + "\" "    + "  " +

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();


                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "CustomerOrder was imported from Monitor API to MySql. " + rs_count + " records "  , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getCustomerOrders






    public static String getCustomers(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrders" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/Customers" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/Customers?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".customer  where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 com_stmt = "Delete from  " + DbName + ".customerroot where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".customer (tenant_id , id , " +
                          " Version , " +
                          " InvoiceAddressId , " +
                          " UseDeliveryNoteCollectionFormReport , " +
                          " SellerId , " +
                          " UseInvoiceCustomersVatNumber , " +
                          " NumberOfInvoiceCopies , " +
                          " ApplyReminderCharge , " +
                          " UseReminder , " +
                          " InterestType , " +
                          " IsCasualCustomer , " +
                          " InterestInvoiceDays , " +
                          " GracePeriod , " +
                          " ApplyInvoicingCharge , " +
                          " InsuranceCost , " +
                          " ValidityTimeId , " +
                          " RoundOff , " +
                          " PickingListCommentId , " +
                          " LatePaymentFee , " +
                          " ComprehensiveInvoiceGroupingMode , " +
                          " DefaultInvoiceStatusPending , " +
                          " PriceListId , " +
                          " PaymentPlanTemplateId , " +
                          " ConfigurationPriceListId , " +
                          " UseForwardRate , " +
                          " Factoring , " +
                          " AlloyCost , " +
                          " InvoicePrintoutMethod , " +
                          " PrintProformaInvoiceVia , " +
                          " PrintPaymentReminderVia , " +
                          " InvoicePrintoutOccasion , " +
                          " ProformaInvoicePrintoutOccasion , " +
                          " ServiceAgreementId , " +
                          " UseEInvoicing , " +
                          " EInvoiceId , " +
                          " EInvoiceOperatorCode , " +
                          " EInvoiceElectronicAddressIdentifier , " +
                          " BlockedStatus , " +
                          " AttachDatafileWithOrder , " +
                          " AttachDatafileWithInvoice , " +
                          " AttachDatafileWithPart , " +
                          " AttachDatafileWithDispatchAdvice , " +
                          " IncomingPaymentsAccountId , " +
                          " IncludeInDeliveryAnalysis , " +
                          " PartialDeliveryType , " +
                          " UsePackageSpecification , " +
                          " UseBundling , " +
                          " DeliveryHorizon , " +
                          " DeliveryNoteNumberWhenDeliveryPlanning , " +
                          " PreliminaryPickingList , " +
                          " ActiveDeliveryAddressAccountGroupId , " +
                          " AccountManagerId , " +
                          " ShowPartStatisticalGoodsCodeAndCountryOfOriginInForms , " +
                          " ShowPartWeightInForms , " +
                          " QuoteFormReportConfigurationId , " +
                          " AcknowledgementFormReportConfigurationId , " +
                          " InvoiceFormReportConfigurationId , " +
                          " ComprehensiveInvoiceFormReportConfigurationId , " +
                          " DeliveryNoteDeliveredFormReportConfigurationId , " +
                          " DeliveryNoteFormReportConfigurationId , " +
                          " DeliveryNoteCollectionFormReportConfigurationId , " +
                          " TransportLabelA4FormReportConfigurationId , " +
                          " TransportLabelA5FormReportConfigurationId , " +
                          " TransportLabelSmallFormReportConfigurationId , " +
                          " ProformaInvoiceFormReportConfigurationId , " +
                          " ComprehensiveProformaInvoiceFormReportConfigurationId , " +
                          " ActualCustomerProbabilityId , " +
                          " ResellerId , " +
                          " HideDiscountOnProformaInvoice , " +
                          " TagContainerId , " +
                          " StatusId , " +
                          " TypeId , " +
                          " DistrictId , " +
                          " DateForTransitionToActualContact , " +
                          " RootId , " +
                          " VisitingAddressId , " +
                          " DefaultReferenceId , " +
                          " PaymentTermId , " +
                          " ApplyBankCharge , " +
                          " BankChargeAmount , " +
                          " BankGiroNo , " +
                          " DateDisplayFormat , " +
                          " DecimalSymbol , " +
                          " TimeZone , " +
                          " CategoryString , " +
                          " CreditLimit , " +
                          " DefaultOrderPrintoutVia , " +
                          " PalletRegistrationNo , " +
                          " PlusGiroNo , " +
                          " Discount , " +
                          " BlockedFromDate , " +
                          " BlockMessageId , " +
                          " BlockedToDate , " +
                          " BlockedById , " +
                          " LanguageId , " +
                          " CommentId , " +
                          " OurCodeByYou , " +
                          " Url , " +
                          " CurrencyId , " +
                          " DiscountCategoryId , " +
                          " DeliveryInstruction , " +
                          " VatRateId , " +
                          " ToleranceForLateDelivery , " +
                          " ToleranceForEarlyDelivery , " +
                          " Alias , " +
                          " Priority , " +
                          " BlockedContextType , " +
                          " IsInternal , " +
                          " CompanyId , " +
                          " InvoiceCustomerId , " +
                          " ExtendSplitLevel , " +
                          " ModifiedOrderConfirmationFormReportConfigurationId  , " +
                          " SplitPayment  , " +
                          " PolishVatInfo  , " +
                          " PackageListFormReportConfigurationId  , " +
                          " PackageTransportLabelFormReportConfigurationId  , " +
                          " CrediFlowStatus  , " +
                          " CrediFlowInvitationId  , " +
                          " CrediFlowInvitationDate  , " +
                          " CrediFlowPartyId  , " +
                          " EInvoiceDistributionMethod  , " +
                          " DeliveryAddressSelectedOnImport , " +

                          " UseComprehensiveInvoices , " +
                          " ActiveDeliveryAddressId   " +


                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                           "\"" + ((rec_obj.get("Version") == null)                                         ? 0 : rec_obj.get("Version")  )                                                    + "\" "    + ", " +
                           "\"" + ((rec_obj.get("InvoiceAddressId") == null)                                ? 0 : rec_obj.get("InvoiceAddressId")  )                                           + "\" "    + ", " +
                           "\"" + ((rec_obj.get("UseDeliveryNoteCollectionFormReport") == "false")          ? 0 : 1 )                                                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("SellerId") == null)                                        ? 0 : rec_obj.get("SellerId")  )                                                   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("UseInvoiceCustomersVatNumber") == "false")                 ? 0 : 1 )                                                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("NumberOfInvoiceCopies") == null)                           ? 0 : rec_obj.get("NumberOfInvoiceCopies")  )                                      + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ApplyReminderCharge") == "false")                          ? 0 : 1 )                                                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("UseReminder") == "false")                                  ? 0 : 1 )                                                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("InterestType") == null)                                    ? 0 : rec_obj.get("InterestType")  )                                               + "\" "    + ", " +
                           "\"" + ((rec_obj.get("IsCasualCustomer") == "false")                             ? 0 : 1 )                                                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("InterestInvoiceDays") == null)                             ? 0 : rec_obj.get("InterestInvoiceDays")  )                                        + "\" "    + ", " +
                           "\"" + ((rec_obj.get("GracePeriod") == null)                                     ? 0 : rec_obj.get("GracePeriod")  )                                                + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ApplyInvoicingCharge") == "false")                         ? 0 : 1 )                                                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("InsuranceCost") == null)                                   ? 0 : rec_obj.get("InsuranceCost")  )                                              + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ValidityTimeId") == null)                                  ? 0 : rec_obj.get("ValidityTimeId")  )                                             + "\" "    + ", " +
                           "\"" + ((rec_obj.get("RoundOff") == "false")                                     ? 0 : 1 )                                                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PickingListCommentId") == null)                            ? 0 : rec_obj.get("PickingListCommentId")  )                                       + "\" "    + ", " +
                           "\"" + ((rec_obj.get("LatePaymentFee") == null)                                  ? 0 : rec_obj.get("LatePaymentFee")  )                                             + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ComprehensiveInvoiceGroupingMode") == null)                ? 0 : rec_obj.get("ComprehensiveInvoiceGroupingMode")  )                           + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DefaultInvoiceStatusPending") == "false")                  ? 0 : 1 )                                                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PriceListId") == null)                                     ? 0 : rec_obj.get("PriceListId")  )                                                + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PaymentPlanTemplateId") == null)                           ? 0 : rec_obj.get("PaymentPlanTemplateId")  )                                      + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ConfigurationPriceListId") == null)                        ? 0 : rec_obj.get("ConfigurationPriceListId")  )                                   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("UseForwardRate") == "false")                               ? 0 : 1 )                                                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("Factoring") == "false")                                    ? 0 : 1 )                                                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("AlloyCost") == null)                                       ? 0 : rec_obj.get("AlloyCost")  )                                                  + "\" "    + ", " +
                           "\"" + ((rec_obj.get("InvoicePrintoutMethod") == null)                           ? 0 : rec_obj.get("InvoicePrintoutMethod")  )                                      + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PrintProformaInvoiceVia") == null)                         ? 0 : rec_obj.get("PrintProformaInvoiceVia")  )                                    + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PrintPaymentReminderVia") == null)                         ? 0 : rec_obj.get("PrintPaymentReminderVia")  )                                    + "\" "    + ", " +
                           "\"" + ((rec_obj.get("InvoicePrintoutOccasion") == null)                         ? 0 : rec_obj.get("InvoicePrintoutOccasion")  )                                    + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ProformaInvoicePrintoutOccasion") == null)                 ? 0 : rec_obj.get("ProformaInvoicePrintoutOccasion")  )                            + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ServiceAgreementId") == null)                              ? 0 : rec_obj.get("ServiceAgreementId")  )                                         + "\" "    + ", " +
                           "\"" + ((rec_obj.get("UseEInvoicing") == "false")                                ? 0 : 1 )                                                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("EInvoiceId") == null)                                      ? 0 : rec_obj.get("EInvoiceId")  )                                                 + "\" "    + ", " +
                           "\"" + ((rec_obj.get("EInvoiceOperatorCode") == null)                            ? 0 : rec_obj.get("EInvoiceOperatorCode")  )                                       + "\" "    + ", " +
                           "\"" + ((rec_obj.get("EInvoiceElectronicAddressIdentifier") == null)             ? 0 : rec_obj.get("EInvoiceElectronicAddressIdentifier")  )                        + "\" "    + ", " +
                           "\"" + ((rec_obj.get("BlockedStatus") == null)                                   ? 0 : rec_obj.get("BlockedStatus")  )                                              + "\" "    + ", " +
                           "\"" + ((rec_obj.get("AttachDatafileWithOrder") == "false")                      ? 0 : 1 )                                                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("AttachDatafileWithInvoice") == "false")                    ? 0 : 1 )                                                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("AttachDatafileWithPart") == "false")                       ? 0 : 1 )                                                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("AttachDatafileWithDispatchAdvice") == "false")             ? 0 : 1 )                                                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IncomingPaymentsAccountId") == null)                       ? 0 : rec_obj.get("IncomingPaymentsAccountId")  )                                  + "\" "    + ", " +
                           "\"" + ((rec_obj.get("IncludeInDeliveryAnalysis") == "false")                    ? 0 : 1 )                                                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PartialDeliveryType") == null)                             ? 0 : rec_obj.get("PartialDeliveryType")  )                                        + "\" "    + ", " +
                           "\"" + ((rec_obj.get("UsePackageSpecification") == "false")                      ? 0 : 1 )                                                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("UseBundling") == "false")                                  ? 0 : 1 )                                                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DeliveryHorizon") == null)                                 ? 0 : rec_obj.get("DeliveryHorizon")  )                                            + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DeliveryNoteNumberWhenDeliveryPlanning") == "false")       ? 0 : 1 )                                                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PreliminaryPickingList") == "false")                       ? 0 : 1 )                                                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ActiveDeliveryAddressAccountGroupId") == null)             ? 0 : rec_obj.get("ActiveDeliveryAddressAccountGroupId")  )                        + "\" "    + ", " +
                           "\"" + ((rec_obj.get("AccountManagerId") == null)                                ? 0 : rec_obj.get("AccountManagerId")  )                                           + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ShowPartStatisticalGoodsCodeAndCountryOfOriginInForms") == null)   ? 0 : rec_obj.get("ShowPartStatisticalGoodsCodeAndCountryOfOriginInForms")  )   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ShowPartWeightInForms") == null)                           ? 0 : rec_obj.get("ShowPartWeightInForms")  )                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("QuoteFormReportConfigurationId") == null)                  ? 0 : rec_obj.get("QuoteFormReportConfigurationId")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AcknowledgementFormReportConfigurationId") == null)        ? 0 : rec_obj.get("AcknowledgementFormReportConfigurationId")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InvoiceFormReportConfigurationId") == null)                ? 0 : rec_obj.get("InvoiceFormReportConfigurationId")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ComprehensiveInvoiceFormReportConfigurationId") == null)   ? 0 : rec_obj.get("ComprehensiveInvoiceFormReportConfigurationId")  )              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DeliveryNoteDeliveredFormReportConfigurationId") == null)  ? 0 : rec_obj.get("DeliveryNoteDeliveredFormReportConfigurationId")  )             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DeliveryNoteFormReportConfigurationId") == null)           ? 0 : rec_obj.get("DeliveryNoteFormReportConfigurationId")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DeliveryNoteCollectionFormReportConfigurationId") == null) ? 0 : rec_obj.get("DeliveryNoteCollectionFormReportConfigurationId")  )            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("TransportLabelA4FormReportConfigurationId") == null)       ? 0 : rec_obj.get("TransportLabelA4FormReportConfigurationId")  )                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("TransportLabelA5FormReportConfigurationId") == null)       ? 0 : rec_obj.get("TransportLabelA5FormReportConfigurationId")  )                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("TransportLabelSmallFormReportConfigurationId") == null)    ? 0 : rec_obj.get("TransportLabelSmallFormReportConfigurationId")  )               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ProformaInvoiceFormReportConfigurationId") == null)        ? 0 : rec_obj.get("ProformaInvoiceFormReportConfigurationId")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ComprehensiveProformaInvoiceFormReportConfigurationId") == null)  ? 0 : rec_obj.get("ComprehensiveProformaInvoiceFormReportConfigurationId")  )  + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ActualCustomerProbabilityId") == null)                     ? 0 : rec_obj.get("ActualCustomerProbabilityId")  )                                + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ResellerId") == null)                                      ? 0 : rec_obj.get("ResellerId")  )                                                 + "\" "    + ", " +
                           "\"" + ((rec_obj.get("HideDiscountOnProformaInvoice") == "false")                ? 0 : 1 )                                                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("TagContainerId") == null)                                  ? 0 : rec_obj.get("TagContainerId")  )                                             + "\" "    + ", " +
                           "\"" + ((rec_obj.get("StatusId") == null)                                        ? 0 : rec_obj.get("StatusId")  )                                                   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("TypeId") == null)                                          ? 0 : rec_obj.get("TypeId")  )                                                     + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DistrictId") == null)                                      ? 0 : rec_obj.get("DistrictId")  )                                                 + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DateForTransitionToActualContact") == null || rec_obj.get("DateForTransitionToActualContact").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("DateForTransitionToActualContact").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                          "\"" + ((rec_obj.get("RootId") == null)                                          ? Id : rec_obj.get("RootId")  )                                                     + "\" "    + ", " +
                           "\"" + ((rec_obj.get("VisitingAddressId") == null)                               ? 0 : rec_obj.get("VisitingAddressId")  )                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DefaultReferenceId") == null)                              ? 0 : rec_obj.get("DefaultReferenceId")  )                                         + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PaymentTermId") == null)                                   ? 0 : rec_obj.get("PaymentTermId")  )                                              + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ApplyBankCharge") == "false")                              ? 0 : 1 )                                                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("BankChargeAmount") == null)                                ? 0 : rec_obj.get("BankChargeAmount")  )                                           + "\" "    + ", " +
                           "\"" + ((rec_obj.get("BankGiroNo") == null)                                      ? 0 : rec_obj.get("BankGiroNo")  )                                                 + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DateDisplayFormat") == null)                               ? 0 : rec_obj.get("DateDisplayFormat")  )                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DecimalSymbol") == null)                                   ? 0 : rec_obj.get("DecimalSymbol")  )                                              + "\" "    + ", " +
                           "\"" + ((rec_obj.get("TimeZone") == null)                                        ? 0 : rec_obj.get("TimeZone")  )                                                   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("CategoryString") == null)                                  ? 0 : rec_obj.get("CategoryString")  )                                             + "\" "    + ", " +
                           "\"" + ((rec_obj.get("CreditLimit") == null)                                     ? 0 : rec_obj.get("CreditLimit")  )                                                + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DefaultOrderPrintoutVia") == null)                         ? 0 : rec_obj.get("DefaultOrderPrintoutVia")  )                                    + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PalletRegistrationNo") == null)                            ? 0 : rec_obj.get("PalletRegistrationNo")  )                                       + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PlusGiroNo") == null)                                      ? 0 : rec_obj.get("PlusGiroNo")  )                                                 + "\" "    + ", " +
                           "\"" + ((rec_obj.get("Discount") == null)                                        ? 0 : rec_obj.get("Discount")  )                                                   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("BlockedFromDate") == null || rec_obj.get("BlockedFromDate").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("BlockedFromDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                           "\"" + ((rec_obj.get("BlockMessageId") == null)                                  ? 0 : rec_obj.get("BlockMessageId")  )                                             + "\" "    + ", " +
                           "\"" + ((rec_obj.get("BlockedToDate") == null || rec_obj.get("BlockedToDate").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("BlockedToDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                           "\"" + ((rec_obj.get("BlockedById") == null)                                     ? 0 : rec_obj.get("BlockedById")  )                                                + "\" "    + ", " +
                           "\"" + ((rec_obj.get("LanguageId") == null)                                      ? 0 : rec_obj.get("LanguageId")  )                                                 + "\" "    + ", " +
                           "\"" + ((rec_obj.get("CommentId") == null)                                       ? 0 : rec_obj.get("CommentId")  )                                                  + "\" "    + ", " +
                           "\"" + ((rec_obj.get("OurCodeByYou") == null)                                    ? 0 : rec_obj.get("OurCodeByYou")  )                                               + "\" "    + ", " +
                           "\"" + ((rec_obj.get("Url") == null)                                             ? 0 : rec_obj.get("Url")  )                                                        + "\" "    + ", " +
                           "\"" + ((rec_obj.get("CurrencyId") == null)                                      ? 0 : rec_obj.get("CurrencyId")  )                                                 + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DiscountCategoryId") == null)                              ? 0 : rec_obj.get("DiscountCategoryId")  )                                         + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DeliveryInstruction") == null)                             ? 0 : rec_obj.get("DeliveryInstruction")  )                                        + "\" "    + ", " +
                           "\"" + ((rec_obj.get("VatRateId") == null)                                       ? 0 : rec_obj.get("VatRateId")  )                                                  + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ToleranceForLateDelivery") == null)                        ? 0 : rec_obj.get("ToleranceForLateDelivery")  )                                   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ToleranceForEarlyDelivery") == null)                       ? 0 : rec_obj.get("ToleranceForEarlyDelivery")  )                                  + "\" "    + ", " +
                           "\"" + ((rec_obj.get("Alias") == null)                                           ? 0 : rec_obj.get("Alias")  )                                                      + "\" "    + ", " +
                           "\"" + ((rec_obj.get("Priority") == null)                                        ? 0 : rec_obj.get("Priority")  )                                                   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("BlockedContextType") == null)                              ? 0 : rec_obj.get("BlockedContextType")  )                                         + "\" "    + ", " +
                           "\"" + ((rec_obj.get("IsInternal") == "false")                                   ? 0 : 1 )                                                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("CompanyId") == null)                                       ? 0 : rec_obj.get("CompanyId")  )                                                  + "\" "    + ", " +
                           "\"" + ((rec_obj.get("InvoiceCustomerId") == null)                               ? 0 : rec_obj.get("InvoiceCustomerId")  )                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ExtendSplitLevel") == null)                                ? 0 : rec_obj.get("ExtendSplitLevel")  )                                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ModifiedOrderConfirmationFormReportConfigurationId") == null) ? 0 : rec_obj.get("ModifiedOrderConfirmationFormReportConfigurationId")  )      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SplitPayment") == "false")                                 ? 0 : 1 )                                                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PolishVatInfo") == null)                                   ? 0 : rec_obj.get("PolishVatInfo")  )                                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PackageListFormReportConfigurationId") == null)            ? 0 : rec_obj.get("PackageListFormReportConfigurationId")  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PackageTransportLabelFormReportConfigurationId") == null)  ? 0 : rec_obj.get("PackageTransportLabelFormReportConfigurationId")  )             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CrediFlowStatus") == null)                                 ? 0 : rec_obj.get("CrediFlowStatus")  )                                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CrediFlowInvitationId") == null)                           ? 0 : rec_obj.get("CrediFlowInvitationId")  )                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CrediFlowInvitationDate") == null || rec_obj.get("CrediFlowInvitationDate").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("CrediFlowInvitationDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                          "\"" + ((rec_obj.get("CrediFlowPartyId") == null)                                ? 0 : rec_obj.get("CrediFlowPartyId")  )                                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("EInvoiceDistributionMethod") == null)                      ? 0 : rec_obj.get("EInvoiceDistributionMethod")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DeliveryAddressSelectedOnImport") == null)                 ? 0 : rec_obj.get("DeliveryAddressSelectedOnImport")  )                            + "\" "    + ", " +

                          "\"" + ((rec_obj.get("UseComprehensiveInvoices") == "false")                     ? 0 : 1 )                                                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ActiveDeliveryAddressId") == null)                         ? 0 : rec_obj.get("ActiveDeliveryAddressId")  )                                    + "\" "    + "  " +

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();


                         // 2 UPDATE

                         com_stmt =
                          "Insert into " + DbName + ".customerroot (tenant_id , id , " +
                          " CustomerCode , " +
                          " IsPrivateCustomer , " +
                          " PersonalNumber , " +
                          " Name , " +
                          " AlternativeName , " +
                          " MailingAddressId , " +
                          " CorporationIdentificationNumber , " +
                          " VatNumber , " +
                          " ServiceTaxNumber   " +

                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                           "\"" + ((rec_obj.get("Code") == null)                                              ? 0 : rec_obj.get("Code")  )                                                       + "\" "    + ", " +
                           "\"" + ((rec_obj.get("IsPrivateCustomer") == "false")                              ? 0 : 1 )                                                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PersonalNumber") == null)                                    ? 0 : rec_obj.get("PersonalNumber")  )                                             + "\" "    + ", " +
                           "\"" + ((rec_obj.get("Name") == null)                                              ? 0 : rec_obj.get("Name").toString().replaceAll("\"", " ").replaceAll("\\p{Cc}", " ").replaceAll("\\s{2,}", " ")  )              + "\" "    + ", " +
                           "\"" + ((rec_obj.get("AlternativeName") == null)                                   ? 0 : rec_obj.get("AlternativeName").toString().replaceAll("\"", " ").replaceAll("\\p{Cc}", " ").replaceAll("\\s{2,}", " ")  )   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("MailingAddressId") == null)                                  ? 0 : rec_obj.get("MailingAddressId")  )                                           + "\" "    + ", " +
                           "\"" + ((rec_obj.get("CorporationIdentificationNumber") == null)                   ? 0 : rec_obj.get("CorporationIdentificationNumber")  )                            + "\" "    + ", " +
                           "\"" + ((rec_obj.get("VatNumber") == null)                                         ? 0 : rec_obj.get("VatNumber")  )                                                  + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ServiceTaxNumber") == null)                                  ? 0 : rec_obj.get("ServiceTaxNumber")  )                                           + "\" "    + "  " +

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();


                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Customer was imported from Monitor API to MySql. " + rs_count + " records "  , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getCustomers







    public static String getQuotes(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrders" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/Customers" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/Quotes" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/Quotes?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".quote  where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".quote (tenant_id , id , " +
                          " Version , " +
                          " FormReportConfigurationId , " +
                          " Status , " +
                          " SellerId , " +
                          " ShowPriceInDocument , " +
                          " ShowTotalInDocument , " +
                          " VatNumber , " +
                          " ActiveDeliveryAddressCustomerId , " +
                          " ActiveDeliveryAddressSupplierId , " +
                          " ActiveDeliveryAddressCompanyId , " +
                          " SourceOfAlternativeDeliveryAddresses , " +
                          " QuoteDescription , " +
                          " RequestForQuoteDate , " +
                          " QuoteDate , " +
                          " ValidThroughDate , " +
                          " ValidityTimeId , " +
                          " ValidityTimeDescription , " +
                          " ValidityTimeInDays , " +
                          " DeliveryTimeId , " +
                          " DeliveryTimeDescription , " +
                          " DeliveryTimeInDays , " +
                          " Preliminary , " +
                          " LatestContactDate , " +
                          " ProbabilityId , " +
                          " RelatedQuotesId , " +
                          " ReasonCodeLostQuoteId , " +
                          " ReasonLostCommentId , " +
                          " BusinessContactId , " +
                          " OrderTypeId , " +
                          " AccountGroupId , " +
                          " CategoryString , " +
                          " BusinessContactReferenceId , " +
                          " DeliveryAddressId , " +
                          " OrderNumber , " +
                          " OrderDate , " +
                          " BusinessContactOrderNumber , " +
                          " OurReferenceId , " +
                          " OurReferenceName , " +
                          " BusinessContactReferenceName , " +
                          " GoodsLabel , " +
                          " CurrencyId , " +
                          " VatGroupId , " +
                          " WarehouseId , " +
                          " Priority , " +
                          " ProjectId , " +
                          " MailingAddressId , " +
                          " SendMethod , " +
                          " InvoicePrintoutMethod , " +
                          " InternalCommentId , " +
                          " ExternalCommentId , " +
                          " TransportTime , " +
                          " LifeCycleState , " +
                          " UseForwardRate , " +
                          " ExchangeRate , " +
                          " PaymentTermId , " +
                          " PaymentTermDescription , " +
                          " GracePeriodInDays , " +
                          " DeliveryMethodId , " +
                          " DeliveryTermId , " +
                          " DeliveryTermDescription , " +
                          " DeliveryMethodDescription , " +
                          " ShipmentPayer , " +
                          " MalaysianTaxExemptionId , " +
                          " ActiveDeliveryAddressDeliveryAddressId , " +

                          " CustomerId   "  +

                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                           "\"" + ((rec_obj.get("Version") == null)                                         ? 0 : rec_obj.get("Version")  )                                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("FormReportConfigurationId") == null)                       ? 0 : rec_obj.get("FormReportConfigurationId")  )                                  + "\" "    + ", " +
                           "\"" + ((rec_obj.get("Status") == null)                                          ? 0 : rec_obj.get("Status")  )                                                     + "\" "    + ", " +
                           "\"" + ((rec_obj.get("SellerId") == null)                                        ? 0 : rec_obj.get("SellerId")  )                                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ShowPriceInDocument") == "false")                          ? 0 : 1 )                                                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ShowTotalInDocument") == "false")                          ? 0 : 1 )                                                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("VatNumber") == null)                                       ? 0 : rec_obj.get("VatNumber")  )                                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ActiveDeliveryAddressCustomerId") == null)                 ? 0 : rec_obj.get("ActiveDeliveryAddressCustomerId")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ActiveDeliveryAddressSupplierId") == null)                 ? 0 : rec_obj.get("ActiveDeliveryAddressSupplierId")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ActiveDeliveryAddressCompanyId") == null)                  ? 0 : rec_obj.get("ActiveDeliveryAddressCompanyId")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SourceOfAlternativeDeliveryAddresses") == null)            ? 0 : rec_obj.get("SourceOfAlternativeDeliveryAddresses")  )                       + "\" "    + ", " +
                           "\"" + ((rec_obj.get("QuoteDescription") == null)                                ? 0 : rec_obj.get("QuoteDescription")  )                                           + "\" "    + ", " +
                           "\"" + ((rec_obj.get("RequestForQuoteDate") == null || rec_obj.get("RequestForQuoteDate").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("RequestForQuoteDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                           "\"" + ((rec_obj.get("QuoteDate") == null || rec_obj.get("QuoteDate").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("QuoteDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                           "\"" + ((rec_obj.get("ValidThroughDate") == null || rec_obj.get("ValidThroughDate").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("ValidThroughDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                           "\"" + ((rec_obj.get("ValidityTimeId") == null)                                  ? 0 : rec_obj.get("ValidityTimeId")  )                                             + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ValidityTimeDescription") == null)                         ? 0 : rec_obj.get("ValidityTimeDescription")  )                                    + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ValidityTimeInDays") == null)                              ? 0 : rec_obj.get("ValidityTimeInDays")  )                                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DeliveryTimeId") == null)                                  ? 0 : rec_obj.get("DeliveryTimeId")  )                                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DeliveryTimeDescription") == null)                         ? 0 : rec_obj.get("DeliveryTimeDescription")  )                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DeliveryTimeInDays") == null)                              ? 0 : rec_obj.get("DeliveryTimeInDays")  )                                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Preliminary") == "false")                                  ? 0 : 1 )                                                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("LatestContactDate") == null || rec_obj.get("LatestContactDate").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("LatestContactDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                           "\"" + ((rec_obj.get("ProbabilityId") == null)                                   ? 0 : rec_obj.get("ProbabilityId")  )                                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RelatedQuotesId") == null)                                 ? 0 : rec_obj.get("RelatedQuotesId")  )                                            + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ReasonCodeLostQuoteId") == null)                           ? 0 : rec_obj.get("ReasonCodeLostQuoteId")  )                                      + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ReasonLostCommentId") == null)                             ? 0 : rec_obj.get("ReasonLostCommentId")  )                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BusinessContactId") == null)                               ? 0 : rec_obj.get("BusinessContactId")  )                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("OrderTypeId") == null)                                     ? 0 : rec_obj.get("OrderTypeId")  )                                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AccountGroupId") == null)                                  ? 0 : rec_obj.get("AccountGroupId")  )                                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CategoryString") == null)                                  ? 0 : rec_obj.get("CategoryString")  )                                             + "\" "    + ", " +
                           "\"" + ((rec_obj.get("BusinessContactReferenceId") == null)                      ? 0 : rec_obj.get("BusinessContactReferenceId")  )                                 + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DeliveryAddressId") == null)                               ? 0 : rec_obj.get("DeliveryAddressId")  )                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("OrderNumber") == null)                                     ? 0 : rec_obj.get("OrderNumber")  )                                                + "\" "    + ", " +
                           "\"" + ((rec_obj.get("OrderDate") == null || rec_obj.get("OrderDate").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("OrderDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                           "\"" + ((rec_obj.get("BusinessContactOrderNumber") == null)                      ? 0 : rec_obj.get("BusinessContactOrderNumber")  )                                 + "\" "    + ", " +
                           "\"" + ((rec_obj.get("OurReferenceId") == null)                                  ? 0 : rec_obj.get("OurReferenceId")  )                                             + "\" "    + ", " +
                           "\"" + ((rec_obj.get("OurReferenceName") == null)                                ? 0 : rec_obj.get("OurReferenceName")  )                                           + "\" "    + ", " +
                           "\"" + ((rec_obj.get("BusinessContactReferenceName") == null)                    ? 0 : rec_obj.get("BusinessContactReferenceName")  )                               + "\" "    + ", " +
                           "\"" + ((rec_obj.get("GoodsLabel") == null)                                      ? 0 : rec_obj.get("GoodsLabel")  )                                                 + "\" "    + ", " +
                           "\"" + ((rec_obj.get("CurrencyId") == null)                                      ? 0 : rec_obj.get("CurrencyId")  )                                                 + "\" "    + ", " +
                           "\"" + ((rec_obj.get("VatGroupId") == null)                                      ? 0 : rec_obj.get("VatGroupId")  )                                                 + "\" "    + ", " +
                           "\"" + ((rec_obj.get("WarehouseId") == null)                                     ? 0 : rec_obj.get("WarehouseId")  )                                                + "\" "    + ", " +
                           "\"" + ((rec_obj.get("Priority") == null)                                        ? 0 : rec_obj.get("Priority")  )                                                   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ProjectId") == null)                                       ? 0 : rec_obj.get("ProjectId")  )                                                  + "\" "    + ", " +
                           "\"" + ((rec_obj.get("MailingAddressId") == null)                                ? 0 : rec_obj.get("MailingAddressId")  )                                           + "\" "    + ", " +
                           "\"" + ((rec_obj.get("SendMethod") == null)                                      ? 0 : rec_obj.get("SendMethod")  )                                                 + "\" "    + ", " +
                           "\"" + ((rec_obj.get("InvoicePrintoutMethod") == null)                           ? 0 : rec_obj.get("InvoicePrintoutMethod")  )                                      + "\" "    + ", " +
                           "\"" + ((rec_obj.get("InternalCommentId") == null)                               ? 0 : rec_obj.get("InternalCommentId")  )                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ExternalCommentId") == null)                               ? 0 : rec_obj.get("ExternalCommentId")  )                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("TransportTime") == null)                                   ? 0 : rec_obj.get("TransportTime")  )                                              + "\" "    + ", " +
                           "\"" + ((rec_obj.get("LifeCycleState") == null)                                  ? 0 : rec_obj.get("LifeCycleState")  )                                             + "\" "    + ", " +
                           "\"" + ((rec_obj.get("UseForwardRate") == "false")                               ? 0 : 1 )                                                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ExchangeRate") == null)                                    ? 0 : rec_obj.get("ExchangeRate")  )                                               + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PaymentTermId") == null)                                   ? 0 : rec_obj.get("PaymentTermId")  )                                              + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PaymentTermDescription") == null)                          ? 0 : rec_obj.get("PaymentTermDescription")  )                                     + "\" "    + ", " +
                           "\"" + ((rec_obj.get("GracePeriodInDays") == null)                               ? 0 : rec_obj.get("GracePeriodInDays")  )                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DeliveryMethodId") == null)                                ? 0 : rec_obj.get("DeliveryMethodId")  )                                           + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DeliveryTermId") == null)                                  ? 0 : rec_obj.get("DeliveryTermId")  )                                             + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DeliveryTermDescription") == null)                         ? 0 : rec_obj.get("DeliveryTermDescription")  )                                    + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DeliveryMethodDescription") == null)                       ? 0 : rec_obj.get("DeliveryMethodDescription")  )                                  + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ShipmentPayer") == null)                                   ? 0 : rec_obj.get("ShipmentPayer")  )                                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("MalaysianTaxExemptionId") == null)                         ? 0 : rec_obj.get("MalaysianTaxExemptionId")  )                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ActiveDeliveryAddressDeliveryAddressId") == null)          ? 0 : rec_obj.get("ActiveDeliveryAddressDeliveryAddressId")  )                     + "\" "    + ", " +

                           "\"" + ((rec_obj.get("CustomerId") == null)                                      ? 0 : rec_obj.get("CustomerId")  )                                                 + "\" "    + "  " +

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Quote was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getQuotes




    public static String getCustomerAccountGroups(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrders" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/Customers" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/Quotes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerAccountGroups" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/CustomerAccountGroups?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".customeraccountgroup  where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".customeraccountgroup (tenant_id , id , " +
                          " Code , " +
                          " IsDefault , " +
                          " Number , " +
                          " DescriptionId , " +
                          " Description   " +

                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Code") == null)                 ? 0 : rec_obj.get("Code")  )              + "\" "    + ", " +
                           "\"" + ((rec_obj.get("IsDefault") == "false")         ? 0 : 1 )                                 + "\" "    + ", " +
                           "\"" + ((rec_obj.get("Number") == null)               ? 0 : rec_obj.get("Number")  )            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)        ? 0 : rec_obj.get("DescriptionId")  )     + "\" "    + ", " +
                           "\"" + ((rec_obj.get("Description") == null)          ? 0 : rec_obj.get("Description")  )       + "\" "    + "  " +

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "CustomerAccountGroup was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getCustomerAccountGroups





    public static String getCustomerDistricts(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrders" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/Customers" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/Quotes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerAccountGroups" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerDistricts" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/CustomerDistricts?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".customerdistrict  where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".customerdistrict (tenant_id , id , " +
                          " Code , " +
                          " DescriptionId , " +
                          " CompanyIds , " +
                          " Description   " +

                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Code") == null)                 ? 0 : rec_obj.get("Code")  )              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)        ? 0 : rec_obj.get("DescriptionId")  )     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CompanyIds") == null)           ? 0 : rec_obj.get("CompanyIds")  )        + "\" "    + ", " +

                          "\"" + ((rec_obj.get("Description") == null)          ? 0 : rec_obj.get("Description")  )       + "\" "    + "  " +

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "CustomerDistrict was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getCustomerDistricts




    public static String getCustomerOrderDeliveryRows(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrders" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/Customers" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/Quotes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerAccountGroups" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerDistricts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderDeliveryRows" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/CustomerOrderDeliveryRows?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".customerorderdeliveryrow  where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".customerorderdeliveryrow (tenant_id , id , " +
                          " QuantityChangeId , " +
                          " BusinessTransactionContextType , " +
                          " CustomerOrderId , " +
                          " CustomerOrderRowId , " +
                          " InvoiceId , " +
                          " ParentInvoiceId , " +
                          " ParentClass , " +
                          " ParentId , " +
                          " IsVia , " +
                          " DeliveryDate , " +
                          " PickListDeliveryDate , " +
                          " InvoiceRowId , " +
                          " AffectStockBalance , " +
                          " FreeTextHtml , " +
                          " FreeText , " +
                          " CorrectionOfRowId , " +
                          " QuantityToPack , " +
                          " ResponsiblePersonId   " +

                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                           "\"" + ((rec_obj.get("QuantityChangeId") == null)                 ? 0 : rec_obj.get("QuantityChangeId")  )                   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("BusinessTransactionContextType") == null)   ? 0 : rec_obj.get("BusinessTransactionContextType")  )     + "\" "    + ", " +
                           "\"" + ((rec_obj.get("CustomerOrderId") == null)                  ? 0 : rec_obj.get("CustomerOrderId")  )                    + "\" "    + ", " +
                           "\"" + ((rec_obj.get("CustomerOrderRowId") == null)               ? 0 : rec_obj.get("CustomerOrderRowId")  )                 + "\" "    + ", " +
                           "\"" + ((rec_obj.get("InvoiceId") == null)                        ? 0 : rec_obj.get("InvoiceId")  )                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ParentInvoiceId") == null)                  ? 0 : rec_obj.get("ParentInvoiceId")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ParentClass") == null)                      ? 0 : rec_obj.get("ParentClass")  )                        + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ParentId") == null)                         ? 0 : rec_obj.get("ParentId")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsVia") == "false")                         ? 0 : 1 )                                                  + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DeliveryDate") == null || rec_obj.get("DeliveryDate").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("DeliveryDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                           "\"" + ((rec_obj.get("PickListDeliveryDate") == null || rec_obj.get("PickListDeliveryDate").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("PickListDeliveryDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                           "\"" + ((rec_obj.get("InvoiceRowId") == null)                     ? 0 : rec_obj.get("InvoiceRowId")  )                       + "\" "    + ", " +
                           "\"" + ((rec_obj.get("AffectStockBalance") == "false")            ? 0 : 1 )                                                  + "\" "    + ", " +
                           "\"" + ((rec_obj.get("FreeTextHtml") == null)                     ? 0 : rec_obj.get("FreeTextHtml").toString().replaceAll("\"", " ").replaceAll("\\p{Cc}", " ").replaceAll("\\s{2,}", " ")  )   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("FreeText") == null)                         ? 0 : rec_obj.get("FreeText").toString().replaceAll("\"", " ").replaceAll("\\p{Cc}", " ").replaceAll("\\s{2,}", " ")  )       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CorrectionOfRowId") == null)                ? 0 : rec_obj.get("CorrectionOfRowId")  )                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("QuantityToPack") == null)                   ? 0 : rec_obj.get("QuantityToPack")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ResponsiblePersonId") == null)              ? 0 : rec_obj.get("ResponsiblePersonId")  )                + "\" "    + "  " +

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "CustomerOrderDeliveryRow was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getCustomerOrderDeliveryRows




    public static String getCustomerOrderInvoiceRows(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrders" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/Customers" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/Quotes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerAccountGroups" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerDistricts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderDeliveryRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoiceRows" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/CustomerOrderInvoiceRows?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".customerorderinvoicerow  where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".customerorderinvoicerow (tenant_id , id , " +
                          " InterestInvoiceBasisId , " +
                          " OverrideStandardPrice , " +
                          " OverrideStandardPriceCurrencyId , " +
                          " Price , " +
                          " PriceCurrencyId , " +
                          " PriceOrigin , " +
                          " PriceOriginPriceListId , " +
                          " PriceLockedFromAutomaticChanges , " +
                          " PriceIsFuturePrice , " +
                          " PriceInCompanyCurrency , " +
                          " PriceInCompanyCurrencyCurrencyId , " +
                          " SetupPrice , " +
                          " SetupPriceCurrencyId , " +
                          " SetupPriceInCompanyCurrency , " +
                          " SetupPriceInCompanyCurrencyCurrencyId , " +
                          " CodingId , " +
                          " VatRateId , " +
                          " Discount , " +
                          " StandardPrice , " +
                          " StandardPriceCurrencyId , " +
                          " LedgerId   " +

                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                           "\"" + ((rec_obj.get("InterestInvoiceBasisId") == null)               ? 0 : rec_obj.get("InterestInvoiceBasisId")  )                   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("OverrideStandardPrice") == null)                ? 0 : rec_obj.get("OverrideStandardPrice")  )                    + "\" "    + ", " +
                           "\"" + ((rec_obj.get("OverrideStandardPriceCurrencyId") == null)      ? 0 : rec_obj.get("OverrideStandardPriceCurrencyId")  )          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("Price") == null)                                ? 0 : rec_obj.get("Price")  )                                    + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PriceCurrencyId") == null)                      ? 0 : rec_obj.get("PriceCurrencyId")  )                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PriceOrigin") == null)                          ? 0 : rec_obj.get("PriceOrigin")  )                              + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PriceOriginPriceListId") == null)               ? 0 : rec_obj.get("PriceOriginPriceListId")  )                   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PriceLockedFromAutomaticChanges") == "false")   ? 0 : 1 )                                                        + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PriceIsFuturePrice") == "false")                ? 0 : 1 )                                                        + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PriceInCompanyCurrency") == null)               ? 0 : rec_obj.get("PriceInCompanyCurrency")  )                   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PriceInCompanyCurrencyCurrencyId") == null)     ? 0 : rec_obj.get("PriceInCompanyCurrencyCurrencyId")  )         + "\" "    + ", " +
                           "\"" + ((rec_obj.get("SetupPrice") == null)                           ? 0 : rec_obj.get("SetupPrice")  )                               + "\" "    + ", " +
                           "\"" + ((rec_obj.get("SetupPriceCurrencyId") == null)                 ? 0 : rec_obj.get("SetupPriceCurrencyId")  )                     + "\" "    + ", " +
                           "\"" + ((rec_obj.get("SetupPriceInCompanyCurrency") == null)          ? 0 : rec_obj.get("SetupPriceInCompanyCurrency")  )              + "\" "    + ", " +
                           "\"" + ((rec_obj.get("SetupPriceInCompanyCurrencyCurrencyId") == null)   ? 0 : rec_obj.get("SetupPriceInCompanyCurrencyCurrencyId")  ) + "\" "    + ", " +
                           "\"" + ((rec_obj.get("CodingId") == null)                             ? 0 : rec_obj.get("CodingId")  )                                 + "\" "    + ", " +
                           "\"" + ((rec_obj.get("VatRateId") == null)                            ? 0 : rec_obj.get("VatRateId")  )                                + "\" "    + ", " +
                           "\"" + ((rec_obj.get("Discount") == null)                             ? 0 : rec_obj.get("Discount")  )                                 + "\" "    + ", " +
                           "\"" + ((rec_obj.get("StandardPrice") == null)                        ? 0 : rec_obj.get("StandardPrice")  )                            + "\" "    + ", " +
                           "\"" + ((rec_obj.get("StandardPriceCurrencyId") == null)              ? 0 : rec_obj.get("StandardPriceCurrencyId")  )                  + "\" "    + ", " +
                           "\"" + ((rec_obj.get("LedgerId") == null)                             ? 0 : rec_obj.get("LedgerId")  )                                 + "\" "    + "  " +

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "CustomerOrderInvoiceRow was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getCustomerOrderInvoiceRows







    public static String getCustomerOrderRows(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrders" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/Customers" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/Quotes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerAccountGroups" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerDistricts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderDeliveryRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoiceRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderRows" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/CustomerOrderRows?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".customerorderrow  where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".customerorderrow (tenant_id , id , " +
                          " CustomerCommitmentLevel , " +
                          " AlternatePreparationCode , " +
                          " CustomerOrderNumber , " +
                          " CustomerOrderRowPosition , " +
                          " Dock , " +
                          " DockName , " +
                          " Storage , " +
                          " KanbanNumber , " +
                          " ReferenceNumberManufacturing , " +
                          " ReferenceNumberDelivery , " +
                          " ShowFreeTextIn , " +
                          " CreateManufacturingOrder , " +
                          " CreatePurchaseOrder , " +
                          " LinkedPurchaseOrderRowId , " +
                          " LinkedManufacturingOrderId , " +
                          " LinkedWithdrawalReservationId , " +
                          " ShowDeliveryDate , " +
                          " OrderRowSerialNumbersId , " +
                          " CreatedFrom , " +
                          " ImportInformationId , " +
                          " FixedAssetId , " +
                          " LinkedStockOrderRowId , " +
                          " NewFinishDate , " +
                          " TransferStatus , " +
                          " TransferProfileId , " +
                          " CustomerOrderTransferRowIdentifier , " +
                          " OrderNumberInRemoteCompany , " +
                          " PositionInRemoteCompany , " +
                          " CodingId , " +
                          " PaymentPlanRowId , " +
                          " IsCreditedPaymentPlanRow , " +
                          " IsIncludedInPaymentPlan , " +
                          " RowStatus , " +
                          " Status , " +
                          " ProformaStatus , " +
                          " ProformaNumber , " +
                          " ProformaDate , " +
                          " RestQuantity , " +
                          " DeliveredQuantity , " +
                          " OrderedQuantity , " +
                          " InitialDeliveryDate , " +
                          " DesiredDeliveryDate , " +
                          " CreationContext , " +
                          " SubPartParentRowId , " +
                          " QuantityRatio , " +
                          " ParentOrderId , " +
                          " Position , " +
                          " OrderRowType , " +
                          " PartId , " +
                          " EntityIdentityString , " +
                          " AdditionalRowDescription , " +
                          " FreeTextHtml , " +
                          " FreeText , " +
                          " RowIndex , " +
                          " ParentRowId , " +
                          " SumRowId , " +
                          " DeliveryDate , " +
                          " RevisionId , " +
                          " Price , " +
                          " PriceCurrencyId , " +
                          " PriceOrigin , " +
                          " PriceOriginPriceListId , " +
                          " PriceLockedFromAutomaticChanges , " +
                          " PriceIsFuturePrice , " +
                          " DiscountIsLockedFromAutomaticChanges , " +
                          " Discount , " +
                          " ToolId , " +
                          " UnitId , " +
                          " VatRateId , " +
                          " WarehouseId , " +
                          " WeightPerUnit , " +
                          " OrderDate , " +
                          " ConversionFactor , " +
                          " SetupPrice , " +
                          " SetupPriceCurrencyId , " +
                          " StatisticalGoodsCodeId , " +
                          " IntrastatTransactionTypeId , " +
                          " TariffAndServiceCodeId , " +
                          " PriceInCompanyCurrency , " +
                          " PriceInCompanyCurrencyCurrencyId , " +
                          " SetupPriceInCompanyCurrency , " +
                          " SetupPriceInCompanyCurrencyCurrencyId , " +
                          " StandardPrice , " +
                          " StandardPriceCurrencyId , " +
                          " ShowPrice , " +
                          " PartRowType , " +
                          " LifeCycleState , " +
                          " PartStatus , " +
                          " PartConfigurationId , " +
                          " RowsGoodsLabel , " +
                          " PreviousOrderedQuantity , " +
                          " PreviousDeliveryDate , " +
                          " PreviousPrice , " +
                          " PreviousSetupPrice , " +
                          " PreviousDiscount , " +
                          " IsAddedSinceLastPrintout , " +
                          " BlanketOrderSalesRowId , " +
                          " BlanketOrderRowQuantity , " +
                          " RemainingBlanketOrderRowQuantity , " +
                          " BlanketOrderRowValidThrough , " +
                          " PolishGtuCodeId , " +
                          " TextRowCreationContext , " +
                          " IsIncludedInForecastDeduction ,  " +

                          " DeliveredQuantityInOrderUnit ,  " +
                          " OrderedQuantityInOrderUnit ,  " +
                          " RestQuantityInOrderUnit   " +

                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                           "\"" + ((rec_obj.get("CustomerCommitmentLevel") == null)               ? 0 : rec_obj.get("CustomerCommitmentLevel")  )                   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("AlternatePreparationCode") == null)              ? 0 : rec_obj.get("AlternatePreparationCode")  )                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CustomerOrderNumber") == null)                   ? 0 : rec_obj.get("CustomerOrderNumber")  )                       + "\" "    + ", " +
                           "\"" + ((rec_obj.get("CustomerOrderRowPosition") == null)              ? 0 : rec_obj.get("CustomerOrderRowPosition")  )                  + "\" "    + ", " +
                           "\"" + ((rec_obj.get("Dock") == null)                                  ? 0 : rec_obj.get("Dock")  )                                      + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DockName") == null)                              ? 0 : rec_obj.get("DockName")  )                                  + "\" "    + ", " +
                           "\"" + ((rec_obj.get("Storage") == null)                               ? 0 : rec_obj.get("Storage")  )                                   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("KanbanNumber") == null)                          ? 0 : rec_obj.get("KanbanNumber")  )                              + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ReferenceNumberManufacturing") == null)          ? 0 : rec_obj.get("ReferenceNumberManufacturing")  )              + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ReferenceNumberDelivery") == null)               ? 0 : rec_obj.get("ReferenceNumberDelivery")  )                   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ShowFreeTextIn") == null)                        ? 0 : rec_obj.get("ShowFreeTextIn")  )                            + "\" "    + ", " +
                           "\"" + ((rec_obj.get("CreateManufacturingOrder") == "false")           ? 0 : 1 )                                                         + "\" "    + ", " +
                           "\"" + ((rec_obj.get("CreatePurchaseOrder") == "false")                ? 0 : 1 )                                                         + "\" "    + ", " +
                           "\"" + ((rec_obj.get("LinkedPurchaseOrderRowId") == null)              ? 0 : rec_obj.get("LinkedPurchaseOrderRowId")  )                  + "\" "    + ", " +
                           "\"" + ((rec_obj.get("LinkedManufacturingOrderId") == null)            ? 0 : rec_obj.get("LinkedManufacturingOrderId")  )                + "\" "    + ", " +
                           "\"" + ((rec_obj.get("LinkedWithdrawalReservationId") == null)         ? 0 : rec_obj.get("LinkedWithdrawalReservationId")  )             + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ShowDeliveryDate") == "false")                   ? 0 : 1 )                                                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OrderRowSerialNumbersId") == null)               ? 0 : rec_obj.get("OrderRowSerialNumbersId")  )                   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("CreatedFrom") == null)                           ? 0 : rec_obj.get("CreatedFrom")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ImportInformationId") == null)                   ? 0 : rec_obj.get("ImportInformationId")  )                       + "\" "    + ", " +
                           "\"" + ((rec_obj.get("FixedAssetId") == null)                          ? 0 : rec_obj.get("FixedAssetId")  )                              + "\" "    + ", " +
                           "\"" + ((rec_obj.get("LinkedStockOrderRowId") == null)                 ? 0 : rec_obj.get("LinkedStockOrderRowId")  )                     + "\" "    + ", " +
                           "\"" + ((rec_obj.get("NewFinishDate") == null || rec_obj.get("NewFinishDate").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("NewFinishDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                           "\"" + ((rec_obj.get("TransferStatus") == null)                        ? 0 : rec_obj.get("TransferStatus")  )                            + "\" "    + ", " +
                           "\"" + ((rec_obj.get("TransferProfileId") == null)                     ? 0 : rec_obj.get("TransferProfileId")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CustomerOrderTransferRowIdentifier") == null)    ? 0 : rec_obj.get("CustomerOrderTransferRowIdentifier")  )        + "\" "    + ", " +
                           "\"" + ((rec_obj.get("OrderNumberInRemoteCompany") == null)            ? 0 : rec_obj.get("OrderNumberInRemoteCompany")  )                + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PositionInRemoteCompany") == null)               ? 0 : rec_obj.get("PositionInRemoteCompany")  )                   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("CodingId") == null)                              ? 0 : rec_obj.get("CodingId")  )                                  + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PaymentPlanRowId") == null)                      ? 0 : rec_obj.get("PaymentPlanRowId")  )                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("IsCreditedPaymentPlanRow") == "false")           ? 0 : 1 )                                                         + "\" "    + ", " +
                           "\"" + ((rec_obj.get("IsIncludedInPaymentPlan") == "false")            ? 0 : 1 )                                                         + "\" "    + ", " +
                           "\"" + ((rec_obj.get("RowStatus") == null)                             ? 0 : rec_obj.get("RowStatus")  )                                 + "\" "    + ", " +
                           "\"" + ((rec_obj.get("Status") == null)                                ? 0 : rec_obj.get("Status")  )                                    + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ProformaStatus") == null)                        ? 0 : rec_obj.get("ProformaStatus")  )                            + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ProformaNumber") == null)                        ? 0 : rec_obj.get("ProformaNumber")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ProformaDate") == null || rec_obj.get("ProformaDate").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("ProformaDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                           "\"" + ((rec_obj.get("RestQuantity") == null)                          ? 0 : rec_obj.get("RestQuantity")  )                              + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DeliveredQuantity") == null)                     ? 0 : rec_obj.get("DeliveredQuantity")  )                         + "\" "    + ", " +
                           "\"" + ((rec_obj.get("OrderedQuantity") == null)                       ? 0 : rec_obj.get("OrderedQuantity")  )                           + "\" "    + ", " +
                           "\"" + ((rec_obj.get("InitialDeliveryDate") == null || rec_obj.get("InitialDeliveryDate").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("InitialDeliveryDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                           "\"" + ((rec_obj.get("DesiredDeliveryDate") == null || rec_obj.get("DesiredDeliveryDate").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("DesiredDeliveryDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                           "\"" + ((rec_obj.get("CreationContext") == null)                       ? 0 : rec_obj.get("CreationContext")  )                           + "\" "    + ", " +
                           "\"" + ((rec_obj.get("SubPartParentRowId") == null)                    ? 0 : rec_obj.get("SubPartParentRowId")  )                        + "\" "    + ", " +
                           "\"" + ((rec_obj.get("QuantityRatio") == null)                         ? 0 : rec_obj.get("QuantityRatio")  )                             + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ParentOrderId") == null)                         ? 0 : rec_obj.get("ParentOrderId")  )                             + "\" "    + ", " +
                           "\"" + ((rec_obj.get("Position") == null)                              ? 0 : rec_obj.get("Position")  )                                  + "\" "    + ", " +
                           "\"" + ((rec_obj.get("OrderRowType") == null)                          ? 0 : rec_obj.get("OrderRowType")  )                              + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PartId") == null)                                ? 0 : rec_obj.get("PartId")  )                                    + "\" "    + ", " +
                           "\"" + ((rec_obj.get("EntityIdentityString") == null)                  ? 0 : rec_obj.get("EntityIdentityString")  )                      + "\" "    + ", " +
                           "\"" + ((rec_obj.get("AdditionalRowDescription") == null)              ? 0 : rec_obj.get("AdditionalRowDescription")  )                  + "\" "    + ", " +
                           "\"" + ((rec_obj.get("FreeTextHtml") == null)                          ? 0 : rec_obj.get("FreeTextHtml").toString().replaceAll("\"", " ").replaceAll("\\p{Cc}", " ").replaceAll("\\s{2,}", " ")  )   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("FreeText") == null)                              ? 0 : rec_obj.get("FreeText").toString().replaceAll("\"", " ").replaceAll("\\p{Cc}", " ").replaceAll("\\s{2,}", " ")  )       + "\" "    + ", " +
                           "\"" + ((rec_obj.get("RowIndex") == null)                              ? 0 : rec_obj.get("RowIndex")  )                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ParentRowId") == null)                           ? 0 : rec_obj.get("ParentRowId")  )                               + "\" "    + ", " +
                           "\"" + ((rec_obj.get("SumRowId") == null)                              ? 0 : rec_obj.get("SumRowId")  )                                  + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DeliveryDate") == null || rec_obj.get("DeliveryDate").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("DeliveryDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                           "\"" + ((rec_obj.get("RevisionId") == null)                            ? 0 : rec_obj.get("RevisionId")  )                                + "\" "    + ", " +
                           "\"" + ((rec_obj.get("Price") == null)                                 ? 0 : rec_obj.get("Price")  )                                     + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PriceCurrencyId") == null)                       ? 0 : rec_obj.get("PriceCurrencyId")  )                           + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PriceOrigin") == null)                           ? 0 : rec_obj.get("PriceOrigin")  )                               + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PriceOriginPriceListId") == null)                ? 0 : rec_obj.get("PriceOriginPriceListId")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PriceLockedFromAutomaticChanges") == "false")    ? 0 : 1 )                                                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PriceIsFuturePrice") == "false")                 ? 0 : 1 )                                                         + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DiscountIsLockedFromAutomaticChanges") == "false") ? 0 : 1 )                                                       + "\" "    + ", " +
                           "\"" + ((rec_obj.get("Discount") == null)                              ? 0 : rec_obj.get("Discount")  )                                  + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ToolId") == null)                                ? 0 : rec_obj.get("ToolId")  )                                    + "\" "    + ", " +
                           "\"" + ((rec_obj.get("UnitId") == null)                                ? 0 : rec_obj.get("UnitId")  )                                    + "\" "    + ", " +
                           "\"" + ((rec_obj.get("VatRateId") == null)                             ? 0 : rec_obj.get("VatRateId")  )                                 + "\" "    + ", " +
                           "\"" + ((rec_obj.get("WarehouseId") == null)                           ? 0 : rec_obj.get("WarehouseId")  )                               + "\" "    + ", " +
                           "\"" + ((rec_obj.get("WeightPerUnit") == null)                         ? 0 : rec_obj.get("WeightPerUnit")  )                             + "\" "    + ", " +
                           "\"" + ((rec_obj.get("OrderDate") == null || rec_obj.get("OrderDate").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("OrderDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                           "\"" + ((rec_obj.get("ConversionFactor") == null)                      ? 0 : rec_obj.get("ConversionFactor")  )                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("SetupPrice") == null)                            ? 0 : rec_obj.get("SetupPrice")  )                                + "\" "    + ", " +
                           "\"" + ((rec_obj.get("SetupPriceCurrencyId") == null)                  ? 0 : rec_obj.get("SetupPriceCurrencyId")  )                      + "\" "    + ", " +
                           "\"" + ((rec_obj.get("StatisticalGoodsCodeId") == null)                ? 0 : rec_obj.get("StatisticalGoodsCodeId")  )                    + "\" "    + ", " +
                           "\"" + ((rec_obj.get("IntrastatTransactionTypeId") == null)            ? 0 : rec_obj.get("IntrastatTransactionTypeId")  )                + "\" "    + ", " +
                           "\"" + ((rec_obj.get("TariffAndServiceCodeId") == null)                ? 0 : rec_obj.get("TariffAndServiceCodeId")  )                    + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PriceInCompanyCurrency") == null)                ? 0 : rec_obj.get("PriceInCompanyCurrency")  )                    + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PriceInCompanyCurrencyCurrencyId") == null)      ? 0 : rec_obj.get("PriceInCompanyCurrencyCurrencyId")  )          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("SetupPriceInCompanyCurrency") == null)           ? 0 : rec_obj.get("SetupPriceInCompanyCurrency")  )               + "\" "    + ", " +
                           "\"" + ((rec_obj.get("SetupPriceInCompanyCurrencyCurrencyId") == null)  ? 0 : rec_obj.get("SetupPriceInCompanyCurrencyCurrencyId")  )    + "\" "    + ", " +
                           "\"" + ((rec_obj.get("StandardPrice") == null)                         ? 0 : rec_obj.get("StandardPrice")  )                             + "\" "    + ", " +
                           "\"" + ((rec_obj.get("StandardPriceCurrencyId") == null)               ? 0 : rec_obj.get("StandardPriceCurrencyId")  )                   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ShowPrice") == "false")                          ? 0 : 1 )                                                         + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PartRowType") == null)                           ? 0 : rec_obj.get("PartRowType")  )                               + "\" "    + ", " +
                           "\"" + ((rec_obj.get("LifeCycleState") == null)                        ? 0 : rec_obj.get("LifeCycleState")  )                            + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PartStatus") == null)                            ? 0 : rec_obj.get("PartStatus")  )                                + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PartConfigurationId") == null)                   ? 0 : rec_obj.get("PartConfigurationId")  )                       + "\" "    + ", " +
                           "\"" + ((rec_obj.get("RowsGoodsLabel") == null)                        ? 0 : rec_obj.get("RowsGoodsLabel")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PreviousOrderedQuantity") == null)               ? 0 : rec_obj.get("PreviousOrderedQuantity")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PreviousDeliveryDate") == null || rec_obj.get("PreviousDeliveryDate").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("PreviousDeliveryDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                          "\"" + ((rec_obj.get("PreviousPrice") == null)                         ? 0 : rec_obj.get("PreviousPrice")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PreviousSetupPrice") == null)                    ? 0 : rec_obj.get("PreviousSetupPrice")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PreviousDiscount") == null)                      ? 0 : rec_obj.get("PreviousDiscount")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsAddedSinceLastPrintout") == "false")           ? 0 : 1 )                                                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BlanketOrderSalesRowId") == null)                ? 0 : rec_obj.get("BlanketOrderSalesRowId")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BlanketOrderRowQuantity") == null)               ? 0 : rec_obj.get("BlanketOrderRowQuantity")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RemainingBlanketOrderRowQuantity") == null)      ? 0 : rec_obj.get("RemainingBlanketOrderRowQuantity")  )          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BlanketOrderRowValidThrough") == null || rec_obj.get("BlanketOrderRowValidThrough").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("BlanketOrderRowValidThrough").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                          "\"" + ((rec_obj.get("PolishGtuCodeId") == null)                       ? 0 : rec_obj.get("PolishGtuCodeId")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("TextRowCreationContext") == null)                ? 0 : rec_obj.get("TextRowCreationContext")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsIncludedInForecastDeduction") == "false")      ? 0 : 1 )                                                         + "\" "    + ", " +

                          "\"" + ((rec_obj.get("DeliveredQuantityInOrderUnit") == null)          ? 0 : rec_obj.get("DeliveredQuantityInOrderUnit")  )              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OrderedQuantityInOrderUnit") == null)            ? 0 : rec_obj.get("OrderedQuantityInOrderUnit")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RestQuantityInOrderUnit") == null)               ? 0 : rec_obj.get("RestQuantityInOrderUnit")  )                   + "\" "    + "  " +

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "CustomerOrderRow was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getCustomerOrderRows







    public static String getCustomerOrderShippingInformationRows(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrders" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/Customers" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/Quotes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerAccountGroups" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerDistricts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderDeliveryRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoiceRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderShippingInformationRows" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/CustomerOrderShippingInformationRows?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".customerordershippinginformationrow  where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".customerordershippinginformationrow (tenant_id , id , " +
                          " Quantity , " +
                          " Weight , " +
                          " Volume , " +
                          " LoadingMeters , " +
                          " Length , " +
                          " Width , " +
                          " Height , " +
                          " PackageTypeId , " +
                          " GoodsTypeId , " +
                          " PackagingPartId , " +
                          " ParentClass , " +
                          " ParentId   " +

                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Quantity") == null)               ? 0 : rec_obj.get("Quantity")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Weight") == null)                 ? 0 : rec_obj.get("Weight")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Volume") == null)                 ? 0 : rec_obj.get("Volume")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("LoadingMeters") == null)          ? 0 : rec_obj.get("LoadingMeters")  )              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Length") == null)                 ? 0 : rec_obj.get("Length")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Width") == null)                  ? 0 : rec_obj.get("Width")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Height") == null)                 ? 0 : rec_obj.get("Height")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PackageTypeId") == null)          ? 0 : rec_obj.get("PackageTypeId")  )              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("GoodsTypeId") == null)            ? 0 : rec_obj.get("GoodsTypeId")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PackagingPartId") == null)        ? 0 : rec_obj.get("PackagingPartId")  )            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ParentClass") == null)            ? 0 : rec_obj.get("ParentClass")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ParentId") == null)               ? 0 : rec_obj.get("ParentId")  )                   + "\" "    + "  " +

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "CustomerOrderShippingInformationRow was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getCustomerOrderShippingInformationRows




    public static String getCustomerOrderTypes(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrders" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/Customers" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/Quotes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerAccountGroups" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerDistricts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderDeliveryRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoiceRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderShippingInformationRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderTypes" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/CustomerOrderTypes?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".customerordertype  where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".customerordertype (tenant_id , id , " +
                          " PriceSetting , " +
                          " PriceListId , " +
                          " PreliminaryPickingList , " +
                          " IncludeInDeliveryAnalysis , " +
                          " IncludeInStatistics , " +
                          " InvoiceType , " +
                          " PaymentTermId , " +
                          " PurchaseOrderAddressStrategy , " +
                          " ConnectedPurchaseOrderTypeId , " +
                          " AutomaticArrivalReportingForStockOrder , " +
                          " TransactionTypeIntrastatExportId , " +
                          " IntrastatValueExport , " +
                          " PriceListIntrastatExportId , " +
                          " IntrastatExportCurrencyExchangeTypeId , " +
                          " Code , " +
                          " BaseType , " +
                          " Preliminary , " +
                          " CodingGroupId , " +
                          " Number , " +
                          " Prefix , " +
                          " DescriptionId , " +
                          " Priority , " +
                          " Visible , " +
                          " IsPreset , " +
                          " CreateInvoiceBasis , " +
                          " CustomerOrderActivityTemplateId , " +
                          " DefaultTransferProfileId   " +

                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("PriceSetting") == null)                                 ? 0 : rec_obj.get("PriceSetting")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PriceListId") == null)                                  ? 0 : rec_obj.get("PriceListId")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PreliminaryPickingList") == "false")                    ? 0 : 1 )                                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IncludeInDeliveryAnalysis") == "false")                 ? 0 : 1 )                                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IncludeInStatistics") == "false")                       ? 0 : 1 )                                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InvoiceType") == null)                                  ? 0 : rec_obj.get("InvoiceType")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PaymentTermId") == null)                                ? 0 : rec_obj.get("PaymentTermId")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PurchaseOrderAddressStrategy") == null)                 ? 0 : rec_obj.get("PurchaseOrderAddressStrategy")  )             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ConnectedPurchaseOrderTypeId") == null)                 ? 0 : rec_obj.get("ConnectedPurchaseOrderTypeId")  )             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AutomaticArrivalReportingForStockOrder") == "false")    ? 0 : 1 )                                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("TransactionTypeIntrastatExportId") == null)             ? 0 : rec_obj.get("TransactionTypeIntrastatExportId")  )         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IntrastatValueExport") == null)                         ? 0 : rec_obj.get("IntrastatValueExport")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PriceListIntrastatExportId") == null)                   ? 0 : rec_obj.get("PriceListIntrastatExportId")  )               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IntrastatExportCurrencyExchangeTypeId") == null)        ? 0 : rec_obj.get("IntrastatExportCurrencyExchangeTypeId")  )    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Code") == null)                                         ? 0 : rec_obj.get("Code")  )                                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BaseType") == null)                                     ? 0 : rec_obj.get("BaseType")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Preliminary") == "false")                               ? 0 : 1 )                                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CodingGroupId") == null)                                ? 0 : rec_obj.get("CodingGroupId")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Number") == null)                                       ? 0 : rec_obj.get("Number")  )                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Prefix") == null)                                       ? 0 : rec_obj.get("Prefix")  )                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                                ? 0 : rec_obj.get("DescriptionId")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Priority") == null)                                     ? 0 : rec_obj.get("Priority")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Visible") == "false")                                   ? 0 : 1 )                                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsPreset") == "false")                                  ? 0 : 1 )                                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CreateInvoiceBasis") == "false")                        ? 0 : 1 )                                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CustomerOrderActivityTemplateId") == null)              ? 0 : rec_obj.get("CustomerOrderActivityTemplateId")  )          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DefaultTransferProfileId") == null)                     ? 0 : rec_obj.get("DefaultTransferProfileId")  )                 + "\" "    + "  " +

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "CustomerOrderType was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getCustomerOrderTypes





    public static String getCustomerPartLinks(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrders" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/Customers" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/Quotes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerAccountGroups" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerDistricts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderDeliveryRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoiceRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderShippingInformationRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerPartLinks" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/CustomerPartLinks?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".customerpartlink  where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".customerpartlink (tenant_id , id , " +
                          " CustomerId , " +
                          " CertificateFormReportConfigurationId , " +
                          " CustomerPartNumber , " +
                          " PackagingPartId , " +
                          " PickingCommentId , " +
                          " Gs1Code , " +
                          " OverrideSalesCommentId , " +
                          " SalesCommentShowInForms , " +
                          " QuantityForLeadTimeToCustomer , " +
                          " UnitId , " +
                          " PartId , " +
                          " PriceCurrencyId , " +
                          " Price , " +
                          " SetupPrice , " +
                          " LeadTime , " +
                          " Discount , " +
                          " PriceValidThrough , " +
                          " FuturePrice , " +
                          " FuturePriceValidThrough , " +
                          " FutureSetupPrice , " +
                          " PriceCommentId , " +
                          " QuantityPerPackage , " +
                          " PackageTransportLabelFormReportConfigurationId , " +

                          " Unit , " +
                          " PriceCurrency , " +
                          " PriceComment  " +

                          " ) " +

                          "values ( " +
                           tenant_id                            + ", " +
                           Id                                     + ", " +
                           "\"" + ((rec_obj.get("CustomerId") == null)                                 ? 0 : rec_obj.get("CustomerId")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CertificateFormReportConfigurationId") == null)       ? 0 : rec_obj.get("CertificateFormReportConfigurationId")  )   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("CustomerPartNumber") == null)                         ? 0 : rec_obj.get("CustomerPartNumber")  )                     + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PackagingPartId") == null)                            ? 0 : rec_obj.get("PackagingPartId")  )                        + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PickingCommentId") == null)                           ? 0 : rec_obj.get("PickingCommentId")  )                       + "\" "    + ", " +
                           "\"" + ((rec_obj.get("Gs1Code") == null)                                    ? 0 : rec_obj.get("Gs1Code")  )                                + "\" "    + ", " +
                           "\"" + ((rec_obj.get("OverrideSalesCommentId") == null)                     ? 0 : rec_obj.get("OverrideSalesCommentId")  )                 + "\" "    + ", " +
                           "\"" + ((rec_obj.get("SalesCommentShowInForms") == null)                    ? 0 : rec_obj.get("SalesCommentShowInForms")  )                + "\" "    + ", " +
                           "\"" + ((rec_obj.get("QuantityForLeadTimeToCustomer") == null)              ? 0 : rec_obj.get("QuantityForLeadTimeToCustomer")  )          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("UnitId") == null)                                     ? 0 : rec_obj.get("UnitId")  )                                 + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PartId") == null)                                     ? 0 : rec_obj.get("PartId")  )                                 + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PriceCurrencyId") == null)                            ? 0 : rec_obj.get("PriceCurrencyId")  )                        + "\" "    + ", " +
                           "\"" + ((rec_obj.get("Price") == null)                                      ? 0 : rec_obj.get("Price")  )                                  + "\" "    + ", " +
                           "\"" + ((rec_obj.get("SetupPrice") == null)                                 ? 0 : rec_obj.get("SetupPrice")  )                             + "\" "    + ", " +
                           "\"" + ((rec_obj.get("LeadTime") == null)                                   ? 0 : rec_obj.get("LeadTime")  )                               + "\" "    + ", " +
                           "\"" + ((rec_obj.get("Discount") == null)                                   ? 0 : rec_obj.get("Discount")  )                               + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PriceValidThrough") == null || rec_obj.get("PriceValidThrough").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("PriceValidThrough").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                           "\"" + ((rec_obj.get("FuturePrice") == null)                                ? 0 : rec_obj.get("FuturePrice")  )                            + "\" "    + ", " +
                           "\"" + ((rec_obj.get("FuturePriceValidThrough") == null || rec_obj.get("FuturePriceValidThrough").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("FuturePriceValidThrough").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                           "\"" + ((rec_obj.get("FutureSetupPrice") == null)                           ? 0 : rec_obj.get("FutureSetupPrice")  )                       + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PriceCommentId") == null)                             ? 0 : rec_obj.get("PriceCommentId")  )                         + "\" "    + ", " +
                           "\"" + ((rec_obj.get("QuantityPerPackage") == null)                         ? 0 : rec_obj.get("QuantityPerPackage")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PackageTransportLabelFormReportConfigurationId") == null)  ? 0 : rec_obj.get("PackageTransportLabelFormReportConfigurationId")  ) + "\" "    + ", " +

                           "\"" + ((rec_obj.get("Unit") == null)                                       ? 0 : rec_obj.get("Unit")  )                                   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PriceCurrency") == null)                              ? 0 : rec_obj.get("PriceCurrency")  )                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PriceComment") == null)                               ? 0 : rec_obj.get("PriceComment")  )                           + "\" "    + "  " +

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "CustomerPartLink was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getCustomerPartLinks





    public static String getCustomerRelationshipActivityTypes(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrders" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/Customers" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/Quotes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerAccountGroups" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerDistricts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderDeliveryRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoiceRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderShippingInformationRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerPartLinks" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerRelationshipActivityTypes" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/CustomerRelationshipActivityTypes?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".customerrelationshipactivitytype  where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".customerrelationshipactivitytype (tenant_id , id , " +
                          " Code , " +
                          " DescriptionId , " +
                          " Description   " +

                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Code") == null)                                    ? 0 : rec_obj.get("Code")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                           ? 0 : rec_obj.get("DescriptionId")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                             ? 0 : rec_obj.get("Description")  )                        + "\" "    + "  " +

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "CustomerRelationshipActivityType was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getCustomerRelationshipActivityTypes





    public static String getCustomerRelationshipManagementActivities(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrders" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/Customers" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/Quotes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerAccountGroups" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerDistricts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderDeliveryRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoiceRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderShippingInformationRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerPartLinks" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerRelationshipActivityTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerRelationshipManagementActivities" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/CustomerRelationshipManagementActivities?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".customerrelationshipmanagementactivity  where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".customerrelationshipmanagementactivity (tenant_id , id , " +
                          " CustomerId , " +
                          " BusinessContactReferenceId , " +
                          " OrderId , " +
                          " ActivityTypeId , " +
                          " CompletedByUserId , " +
                          " ResponsibleUserId , " +
                          " DescriptionId , " +
                          " CommentId , " +
                          " Status , " +
                          " ReminderId , " +
                          " PlannedCompletionDate , " +
                          " CompletionDate , " +
                          " PlannedStartDate , " +
                          " ActualStartDate , " +
                          " CalendarAppointmentId , " +
                          " IsMandatory , " +
                          " IsAdministratorResponsibleUser , " +
                          " AdministratorType , " +
                          " IsAdministratorResponsibleUserRestorable , " +
                          " IsDueDatePlannedCompletionDateRestorable , " +

                          " BusinessContactReference , " +
                          " ActivityType , " +
                          " Description , " +
                          " Comment   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("CustomerId") == null)                                 ? 0 : rec_obj.get("CustomerId")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BusinessContactReferenceId") == null)                 ? 0 : rec_obj.get("BusinessContactReferenceId")  )             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OrderId") == null)                                    ? 0 : rec_obj.get("OrderId")  )                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ActivityTypeId") == null)                             ? 0 : rec_obj.get("ActivityTypeId")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CompletedByUserId") == null)                          ? 0 : rec_obj.get("CompletedByUserId")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ResponsibleUserId") == null)                          ? 0 : rec_obj.get("ResponsibleUserId")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                              ? 0 : rec_obj.get("DescriptionId")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CommentId") == null)                                  ? 0 : rec_obj.get("CommentId")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Status") == null)                                     ? 0 : rec_obj.get("Status")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReminderId") == null)                                 ? 0 : rec_obj.get("ReminderId")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PlannedCompletionDate") == null || rec_obj.get("PlannedCompletionDate").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("PlannedCompletionDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                          "\"" + ((rec_obj.get("CompletionDate") == null        || rec_obj.get("CompletionDate").toString().substring(0,2).equals("00")  )        ? new Date(2021000000) : rec_obj.get("CompletionDate").toString().substring(0,19).replace('T', ' ')  )        + "\" " + ", " +
                          "\"" + ((rec_obj.get("PlannedStartDate") == null      || rec_obj.get("PlannedStartDate").toString().substring(0,2).equals("00")  )      ? new Date(2021000000) : rec_obj.get("PlannedStartDate").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("ActualStartDate") == null       || rec_obj.get("ActualStartDate").toString().substring(0,2).equals("00")  )       ? new Date(2021000000) : rec_obj.get("ActualStartDate").toString().substring(0,19).replace('T', ' ')  )       + "\" " + ", " +
                          "\"" + ((rec_obj.get("CalendarAppointmentId") == null)                      ? 0 : rec_obj.get("CalendarAppointmentId")  )                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsMandatory") == "false")                             ? 0 : 1 )                                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsAdministratorResponsibleUser") == "false")          ? 0 : 1 )                                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AdministratorType") == null)                          ? 0 : rec_obj.get("AdministratorType")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsAdministratorResponsibleUserRestorable") == "false") ? 0 : 1 )                                                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsDueDatePlannedCompletionDateRestorable") == "false") ? 0 : 1 )                                                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BusinessContactReference") == null)                    ? 0 : rec_obj.get("BusinessContactReference")  )              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ActivityType") == null)                                ? 0 : rec_obj.get("ActivityType")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                                 ? 0 : rec_obj.get("Description")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Comment") == null)                                     ? 0 : rec_obj.get("Comment")  )                               + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "CustomerRelationshipManagementActivity was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getCustomerRelationshipManagementActivities



    public static String getCustomerStatuses(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrders" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/Customers" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/Quotes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerAccountGroups" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerDistricts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderDeliveryRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoiceRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderShippingInformationRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerPartLinks" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerRelationshipActivityTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerRelationshipManagementActivities" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerStatuses" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/CustomerStatuses?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".customerstatus where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".customerstatus (tenant_id , id , " +
                          " Code , " +
                          " DescriptionId , " +
                          " Description   " +
                          " ) " +

                          "values ( " +
                          tenant_id                            + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Code") == null)                                   ? 0 : rec_obj.get("Code")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                          ? 0 : rec_obj.get("DescriptionId")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                            ? 0 : rec_obj.get("Description")  )                        + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "CustomerStatus was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getCustomerStatuses



    public static String getCustomerTypes(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrders" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/Customers" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/Quotes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerAccountGroups" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerDistricts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderDeliveryRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoiceRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderShippingInformationRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerPartLinks" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerRelationshipActivityTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerRelationshipManagementActivities" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerStatuses" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerTypes" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/CustomerTypes?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".customertype where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".customertype (tenant_id , id , " +
                          " Code , " +
                          " DescriptionId , " +
                          " Description   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Code") == null)                                   ? 0 : rec_obj.get("Code")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                          ? 0 : rec_obj.get("DescriptionId")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                            ? 0 : rec_obj.get("Description")  )                        + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "CustomerType was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getCustomerTypes



    public static String getInvoiceLogs(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrders" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/Customers" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/Quotes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerAccountGroups" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerDistricts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderDeliveryRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoiceRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderShippingInformationRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerPartLinks" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerRelationshipActivityTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerRelationshipManagementActivities" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerStatuses" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/InvoiceLogs" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/InvoiceLogs?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".invoicelog where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".invoicelog (tenant_id , id , " +
                          " InvoiceId , " +
                          " LoggingTimestamp , " +
                          " InvoiceDate , " +
                          " InvoiceNumber , " +
                          " DeliveryRowId , " +
                          " PartId , " +
                          " PartNumber , " +
                          " PartCategory , " +
                          " PartCode , " +
                          " CustomerId , " +
                          " CustomerCode , " +
                          " CustomerGroup , " +
                          " CustomerOrderId , " +
                          " CustomerOrderNumber , " +
                          " WarehouseId , " +
                          " UserId , " +
                          " Username , " +
                          " Seller , " +
                          " OrderedQuantity , " +
                          " InvoicedQuantity , " +
                          " UnitCode , " +
                          " Discount , " +
                          " Price , " +
                          " SetupPrice , " +
                          " PriceInCompanyCurrency , " +
                          " SetupPriceInCompanyCurrency , " +
                          " StandardPrice , " +
                          " WeightPerUnit , " +
                          " ProductGroupNumber , " +
                          " StatisticalGoodsCode , " +
                          " IntrastatTransactionType , " +
                          " TariffAndServiceCode , " +
                          " CurrencyCode , " +
                          " ExchangeRate , " +
                          " CustomerOrderCategory , " +
                          " BusinessContactOrderNumber , " +
                          " OrderRowType , " +
                          " ConversionFactor , " +
                          " DeliveryIndex , " +
                          " FifoPrice , " +
                          " ServiceType , " +
                          " AccountNumber , " +
                          " DeliveryAddressAddressee , " +
                          " IsExportedToManagementAccounting   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("InvoiceId") == null)                                 ? 0 : rec_obj.get("InvoiceId")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("LoggingTimestamp") == null      || rec_obj.get("LoggingTimestamp").toString().substring(0,2).equals("00")  )      ? new Date(2021000000) : rec_obj.get("LoggingTimestamp").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("InvoiceDate") == null           || rec_obj.get("InvoiceDate").toString().substring(0,2).equals("00")  )           ? new Date(2021000000) : rec_obj.get("InvoiceDate").toString().substring(0,19).replace('T', ' ')  )           + "\" " + ", " +
                          "\"" + ((rec_obj.get("InvoiceNumber") == null)                             ? 0 : rec_obj.get("InvoiceNumber")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DeliveryRowId") == null)                             ? 0 : rec_obj.get("DeliveryRowId")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PartId") == null)                                    ? 0 : rec_obj.get("PartId")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PartNumber") == null)                                ? 0 : rec_obj.get("PartNumber")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PartCategory") == null)                              ? 0 : rec_obj.get("PartCategory")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PartCode") == null)                                  ? 0 : rec_obj.get("PartCode")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CustomerId") == null)                                ? 0 : rec_obj.get("CustomerId")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CustomerCode") == null)                              ? 0 : rec_obj.get("CustomerCode")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CustomerGroup") == null)                             ? 0 : rec_obj.get("CustomerGroup")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CustomerOrderId") == null)                           ? 0 : rec_obj.get("CustomerOrderId")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CustomerOrderNumber") == null)                       ? 0 : rec_obj.get("CustomerOrderNumber")  )                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("WarehouseId") == null)                               ? 0 : rec_obj.get("WarehouseId")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("UserId") == null)                                    ? 0 : rec_obj.get("UserId")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Username") == null)                                  ? 0 : rec_obj.get("Username")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Seller") == null)                                    ? 0 : rec_obj.get("Seller")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OrderedQuantity") == null)                           ? 0 : rec_obj.get("OrderedQuantity")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InvoicedQuantity") == null)                          ? 0 : rec_obj.get("InvoicedQuantity")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("UnitCode") == null)                                  ? 0 : rec_obj.get("UnitCode")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Discount") == null)                                  ? 0 : rec_obj.get("Discount")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Price") == null)                                     ? 0 : rec_obj.get("Price")  )                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SetupPrice") == null)                                ? 0 : rec_obj.get("SetupPrice")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PriceInCompanyCurrency") == null)                    ? 0 : rec_obj.get("PriceInCompanyCurrency")  )               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SetupPriceInCompanyCurrency") == null)               ? 0 : rec_obj.get("SetupPriceInCompanyCurrency")  )          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("StandardPrice") == null)                             ? 0 : rec_obj.get("StandardPrice")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("WeightPerUnit") == null)                             ? 0 : rec_obj.get("WeightPerUnit")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ProductGroupNumber") == null)                        ? 0 : rec_obj.get("ProductGroupNumber")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("StatisticalGoodsCode") == null)                      ? 0 : rec_obj.get("StatisticalGoodsCode")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IntrastatTransactionType") == null)                  ? 0 : rec_obj.get("IntrastatTransactionType")  )             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("TariffAndServiceCode") == null)                      ? 0 : rec_obj.get("TariffAndServiceCode")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CurrencyCode") == null)                              ? 0 : rec_obj.get("CurrencyCode")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ExchangeRate") == null)                              ? 0 : rec_obj.get("ExchangeRate")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CustomerOrderCategory") == null)                     ? 0 : rec_obj.get("CustomerOrderCategory")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BusinessContactOrderNumber") == null)                ? 0 : rec_obj.get("BusinessContactOrderNumber")  )           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OrderRowType") == null)                              ? 0 : rec_obj.get("OrderRowType")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ConversionFactor") == null)                          ? 0 : rec_obj.get("ConversionFactor")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DeliveryIndex") == null)                             ? 0 : rec_obj.get("DeliveryIndex")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("FifoPrice") == null)                                 ? 0 : rec_obj.get("FifoPrice")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ServiceType") == null)                               ? 0 : rec_obj.get("ServiceType")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AccountNumber") == null)                             ? 0 : rec_obj.get("AccountNumber")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DeliveryAddressAddressee") == null)                  ? 0 : rec_obj.get("DeliveryAddressAddressee")  )             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsExportedToManagementAccounting") == "false")       ? 0 : 1 )                                                    + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "InvoiceLog was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getInvoiceLogs




    public static String getOtherCustomerNumbers(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrders" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/Customers" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/Quotes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerAccountGroups" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerDistricts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderDeliveryRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoiceRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderShippingInformationRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerPartLinks" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerRelationshipActivityTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerRelationshipManagementActivities" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerStatuses" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/InvoiceLogs" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/OtherCustomerNumbers" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/OtherCustomerNumbers?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".othercustomernumber where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".othercustomernumber (tenant_id , id , " +
                          " IsDefault , " +
                          " Number , " +
                          " CustomerId   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("IsDefault") == "false")             ? 0 : 1 )                                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Number") == null)                   ? 0 : rec_obj.get("Number")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CustomerId") == null)               ? 0 : rec_obj.get("CustomerId")  )                           + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "OtherCustomerNumber was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getOtherCustomerNumbers



    public static String getQuoteRows(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrders" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/Customers" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/Quotes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerAccountGroups" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerDistricts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderDeliveryRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoiceRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderShippingInformationRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerPartLinks" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerRelationshipActivityTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerRelationshipManagementActivities" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerStatuses" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/InvoiceLogs" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/OtherCustomerNumbers" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/QuoteRows" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/QuoteRows?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".quoterow where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".quoterow (tenant_id , id , " +
                          " ShowFreeTextIn , " +
                          " AlternatePreparationCode , " +
                          " CreateCustomerOrder , " +
                          " ExemptFromStatistics , " +
                          " Markup , " +
                          " PartCalculationId , " +
                          " CustomerOrderId , " +
                          " SubPartParentRowId , " +
                          " QuantityRatio , " +
                          " ParentOrderId , " +
                          " Position , " +
                          " OrderRowType , " +
                          " PartId , " +
                          " EntityIdentityString , " +
                          " AdditionalRowDescription , " +
                          " FreeTextHtml , " +
                          " FreeText , " +
                          " RowIndex , " +
                          " ParentRowId , " +
                          " SumRowId , " +
                          " DeliveryDate , " +
                          " RevisionId , " +
                          " OrderedQuantity , " +
                          " Price , " +
                          " PriceCurrencyId , " +
                          " PriceOrigin , " +
                          " PriceOriginPriceListId , " +
                          " PriceLockedFromAutomaticChanges , " +
                          " PriceIsFuturePrice , " +
                          " DiscountIsLockedFromAutomaticChanges , " +
                          " Discount , " +
                          " ToolId , " +
                          " UnitId , " +
                          " VatRateId , " +
                          " WarehouseId , " +
                          " WeightPerUnit , " +
                          " OrderDate , " +
                          " ConversionFactor , " +
                          " SetupPrice , " +
                          " SetupPriceCurrencyId , " +
                          " StatisticalGoodsCodeId , " +
                          " IntrastatTransactionTypeId , " +
                          " TariffAndServiceCodeId , " +
                          " PriceInCompanyCurrency , " +
                          " PriceInCompanyCurrencyCurrencyId , " +
                          " SetupPriceInCompanyCurrency , " +
                          " SetupPriceInCompanyCurrencyCurrencyId , " +
                          " StandardPrice , " +
                          " StandardPriceCurrencyId , " +
                          " CodingId , " +
                          " ShowPrice , " +
                          " PartRowType , " +
                          " LifeCycleState , " +
                          " PartStatus , " +
                          " PartConfigurationId , " +
                          " RowsGoodsLabel , " +
                          " PolishGtuCodeId , " +
                          " TextRowCreationContext   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("ShowFreeTextIn") == null)               ? 0 : rec_obj.get("ShowFreeTextIn")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AlternatePreparationCode") == null)     ? 0 : rec_obj.get("AlternatePreparationCode")  )          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CreateCustomerOrder") == "false")       ? 0 : 1 )                                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ExemptFromStatistics") == "false")      ? 0 : 1 )                                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Markup") == null)                       ? 0 : rec_obj.get("Markup")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PartCalculationId") == null)            ? 0 : rec_obj.get("PartCalculationId")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CustomerOrderId") == null)              ? 0 : rec_obj.get("CustomerOrderId")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SubPartParentRowId") == null)           ? 0 : rec_obj.get("SubPartParentRowId")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("QuantityRatio") == null)                ? 0 : rec_obj.get("QuantityRatio")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ParentOrderId") == null)                ? 0 : rec_obj.get("ParentOrderId")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Position") == null)                     ? 0 : rec_obj.get("Position")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OrderRowType") == null)                 ? 0 : rec_obj.get("OrderRowType")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PartId") == null)                       ? 0 : rec_obj.get("PartId")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("EntityIdentityString") == null)         ? 0 : rec_obj.get("EntityIdentityString")  )              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AdditionalRowDescription") == null)     ? 0 : rec_obj.get("AdditionalRowDescription")  )          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("FreeTextHtml") == null)                 ? 0 : rec_obj.get("FreeTextHtml").toString().replaceAll("\"", " ").replaceAll("\\p{Cc}", " ").replaceAll("\\s{2,}", " ")  )   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("FreeText") == null)                     ? 0 : rec_obj.get("FreeText").toString().replaceAll("\"", " ").replaceAll("\\p{Cc}", " ").replaceAll("\\s{2,}", " ")  )   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RowIndex") == null)                     ? 0 : rec_obj.get("RowIndex")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ParentRowId") == null)                  ? 0 : rec_obj.get("ParentRowId")  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SumRowId") == null)                     ? 0 : rec_obj.get("SumRowId")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DeliveryDate") == null      || rec_obj.get("DeliveryDate").toString().substring(0,2).equals("00")  )      ? new Date(2021000000) : rec_obj.get("DeliveryDate").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("RevisionId") == null)                   ? 0 : rec_obj.get("RevisionId")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OrderedQuantity") == null)              ? 0 : rec_obj.get("OrderedQuantity")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Price") == null)                        ? 0 : rec_obj.get("Price")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PriceCurrencyId") == null)              ? 0 : rec_obj.get("PriceCurrencyId")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PriceOrigin") == null)                  ? 0 : rec_obj.get("PriceOrigin")  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PriceOriginPriceListId") == null)       ? 0 : rec_obj.get("PriceOriginPriceListId")  )            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PriceLockedFromAutomaticChanges") == "false")       ? 0 : 1 )                                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PriceIsFuturePrice") == "false")        ? 0 : 1 )                                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DiscountIsLockedFromAutomaticChanges") == "false")  ? 0 : 1 )                                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Discount") == null)                     ? 0 : rec_obj.get("Discount")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ToolId") == null)                       ? 0 : rec_obj.get("ToolId")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("UnitId") == null)                       ? 0 : rec_obj.get("UnitId")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("VatRateId") == null)                    ? 0 : rec_obj.get("VatRateId")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("WarehouseId") == null)                  ? 0 : rec_obj.get("WarehouseId")  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("WeightPerUnit") == null)                ? 0 : rec_obj.get("WeightPerUnit")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OrderDate") == null      || rec_obj.get("OrderDate").toString().substring(0,2).equals("00")  )      ? new Date(2021000000) : rec_obj.get("OrderDate").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("ConversionFactor") == null)             ? 0 : rec_obj.get("ConversionFactor")  )                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SetupPrice") == null)                   ? 0 : rec_obj.get("SetupPrice")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SetupPriceCurrencyId") == null)         ? 0 : rec_obj.get("SetupPriceCurrencyId")  )              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("StatisticalGoodsCodeId") == null)       ? 0 : rec_obj.get("StatisticalGoodsCodeId")  )            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IntrastatTransactionTypeId") == null)   ? 0 : rec_obj.get("IntrastatTransactionTypeId")  )        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("TariffAndServiceCodeId") == null)       ? 0 : rec_obj.get("TariffAndServiceCodeId")  )            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PriceInCompanyCurrency") == null)       ? 0 : rec_obj.get("PriceInCompanyCurrency")  )            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PriceInCompanyCurrencyCurrencyId") == null)   ? 0 : rec_obj.get("PriceInCompanyCurrencyCurrencyId")  )  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SetupPriceInCompanyCurrency") == null)  ? 0 : rec_obj.get("SetupPriceInCompanyCurrency")  )       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SetupPriceInCompanyCurrencyCurrencyId") == null)  ? 0 : rec_obj.get("SetupPriceInCompanyCurrencyCurrencyId")  )    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("StandardPrice") == null)                ? 0 : rec_obj.get("StandardPrice")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("StandardPriceCurrencyId") == null)      ? 0 : rec_obj.get("StandardPriceCurrencyId")  )           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CodingId") == null)                     ? 0 : rec_obj.get("CodingId")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ShowPrice") == "false")                 ? 0 : 1 )                                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PartRowType") == null)                  ? 0 : rec_obj.get("PartRowType")  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("LifeCycleState") == null)               ? 0 : rec_obj.get("LifeCycleState")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PartStatus") == null)                   ? 0 : rec_obj.get("PartStatus")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PartConfigurationId") == null)          ? 0 : rec_obj.get("PartConfigurationId")  )               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RowsGoodsLabel") == null)               ? 0 : rec_obj.get("RowsGoodsLabel")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PolishGtuCodeId") == null)              ? 0 : rec_obj.get("PolishGtuCodeId")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("TextRowCreationContext") == null)       ? 0 : rec_obj.get("TextRowCreationContext")  )            + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "QuoteRow was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getQuoteRows




    public static String getQuoteTypes(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrders" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/Customers" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/Quotes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerAccountGroups" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerDistricts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderDeliveryRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoiceRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderShippingInformationRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerPartLinks" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerRelationshipActivityTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerRelationshipManagementActivities" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerStatuses" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/InvoiceLogs" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/OtherCustomerNumbers" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/QuoteRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/QuoteTypes" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/QuoteTypes?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".quotetype where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".quotetype (tenant_id , id , " +
                          " PriceSetting , " +
                          " PriceListId , " +
                          " FormReportConfigurationId , " +
                          " BaseType , " +
                          " CustomerOrderTypeId , " +
                          " CodingGroupId , " +
                          " Number , " +
                          " Prefix , " +
                          " DescriptionId , " +
                          " Priority , " +
                          " Visible , " +
                          " IsPreset , " +
                          " QuoteActivityTemplateId , " +
                          " Description   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("PriceSetting") == null)               ? 0 : rec_obj.get("PriceSetting")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PriceListId") == null)                ? 0 : rec_obj.get("PriceListId")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("FormReportConfigurationId") == null)  ? 0 : rec_obj.get("FormReportConfigurationId")  )       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BaseType") == null)                   ? 0 : rec_obj.get("BaseType")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CustomerOrderTypeId") == null)        ? 0 : rec_obj.get("CustomerOrderTypeId")  )             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CodingGroupId") == null)              ? 0 : rec_obj.get("CodingGroupId")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Number") == null)                     ? 0 : rec_obj.get("Number")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Prefix") == null)                     ? 0 : rec_obj.get("Prefix")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)              ? 0 : rec_obj.get("DescriptionId")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Priority") == null)                   ? 0 : rec_obj.get("Priority")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Visible") == "false")                 ? 0 : 1 )                                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsPreset") == "false")                ? 0 : 1 )                                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("QuoteActivityTemplateId") == null)    ? 0 : rec_obj.get("QuoteActivityTemplateId")  )         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                ? 0 : rec_obj.get("Description")  )                     + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "QuoteType was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getQuoteTypes





    public static String getReasonCodeLostQuotes(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrders" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/Customers" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/Quotes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerAccountGroups" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerDistricts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderDeliveryRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoiceRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderShippingInformationRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerPartLinks" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerRelationshipActivityTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerRelationshipManagementActivities" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerStatuses" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/InvoiceLogs" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/OtherCustomerNumbers" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/QuoteRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/QuoteTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/ReasonCodeLostQuotes" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/ReasonCodeLostQuotes?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".reasoncodelostquote where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".reasoncodelostquote (tenant_id , id , " +
                          " Code , " +
                          " DescriptionId , " +
                          " CommentMandatory , " +
                          " Active , " +
                          " Description   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Code") == null)                 ? 0 : rec_obj.get("Code")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)        ? 0 : rec_obj.get("DescriptionId")  )           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CommentMandatory") == "false")  ? 0 : 1 )                                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Active") == "false")            ? 0 : 1 )                                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)          ? 0 : rec_obj.get("Description")  )             + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "ReasonCodeLostQuote was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getReasonCodeLostQuotes



    public static String getSalesPickingLists(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrders" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/Customers" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/Quotes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerAccountGroups" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerDistricts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderDeliveryRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoiceRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderShippingInformationRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerPartLinks" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerRelationshipActivityTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerRelationshipManagementActivities" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerStatuses" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/InvoiceLogs" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/OtherCustomerNumbers" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/QuoteRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/QuoteTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/ReasonCodeLostQuotes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/SalesPickingLists" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/SalesPickingLists?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".pickinglist where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".pickinglist (tenant_id , id , " +
                          " State , " +
                          " WarehouseId , " +
                          " Number , " +
                          " PrintedByApplicationUserId , " +
                          " PrintedByPerson , " +
                          " PrintedTimestamp , " +
                          " PickingByApplicationUserId , " +
                          " PickingByPerson , " +
                          " PickingTimestamp , " +
                          " BusinessContactId , " +
                          " DeliveryAddressId , " +
                          " Description , " +
                          " Dock , " +
                          " DeliveryInstruction , " +
                          " UsePackageSpecification , " +
                          " Storage , " +
                          " Status , " +
                          " BusinessTransactionContextType , " +
                          " LifeCycleState , " +
                          " PaymentTermDescription , " +
                          " GracePeriodInDays , " +
                          " DeliveryMethodId , " +
                          " DeliveryTermId , " +
                          " DeliveryTermDescription , " +
                          " DeliveryMethodDescription , " +
                          " ShipmentPayer , " +
                          " ExtendSplitLevel , " +
                          " PackageReadyForDelivery , " +
                          " InternalCommentId , " +
                          " ExternalCommentId ,  " +
                          " PaymentTermId ,  " +
                          " ExcludeFromEdi   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("State") == null)                        ? 0 : rec_obj.get("State")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("WarehouseId") == null)                  ? 0 : rec_obj.get("WarehouseId")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Number") == null)                       ? 0 : rec_obj.get("Number")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PrintedByApplicationUserId") == null)   ? 0 : rec_obj.get("PrintedByApplicationUserId")  )     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PrintedByPerson") == null)              ? 0 : rec_obj.get("PrintedByPerson")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PrintedTimestamp") == null      || rec_obj.get("PrintedTimestamp").toString().substring(0,2).equals("00")  )      ? new Date(2021000000) : rec_obj.get("PrintedTimestamp").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("PickingByApplicationUserId") == null)   ? 0 : rec_obj.get("PickingByApplicationUserId")  )     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PickingByPerson") == null)              ? 0 : rec_obj.get("PickingByPerson")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PickingTimestamp") == null      || rec_obj.get("PickingTimestamp").toString().substring(0,2).equals("00")  )      ? new Date(2021000000) : rec_obj.get("PickingTimestamp").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("BusinessContactId") == null)            ? 0 : rec_obj.get("BusinessContactId")  )              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DeliveryAddressId") == null)            ? 0 : rec_obj.get("DeliveryAddressId")  )              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                  ? 0 : rec_obj.get("Description")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Dock") == null)                         ? 0 : rec_obj.get("Dock")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DeliveryInstruction") == null)          ? 0 : rec_obj.get("DeliveryInstruction")  )            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("UsePackageSpecification") == "false")   ? 0 : 1 )                                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Storage") == null)                      ? 0 : rec_obj.get("Storage")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Status") == null)                           ? 0 : rec_obj.get("Status")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BusinessTransactionContextType") == null)   ? 0 : rec_obj.get("BusinessTransactionContextType")  )  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("LifeCycleState") == null)                   ? 0 : rec_obj.get("LifeCycleState")  )                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PaymentTermDescription") == null)           ? 0 : rec_obj.get("PaymentTermDescription")  )          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("GracePeriodInDays") == null)                ? 0 : rec_obj.get("GracePeriodInDays")  )               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DeliveryMethodId") == null)                 ? 0 : rec_obj.get("DeliveryMethodId")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DeliveryTermId") == null)                   ? 0 : rec_obj.get("DeliveryTermId")  )                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DeliveryTermDescription") == null)          ? 0 : rec_obj.get("DeliveryTermDescription")  )         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DeliveryMethodDescription") == null)        ? 0 : rec_obj.get("DeliveryMethodDescription")  )       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ShipmentPayer") == null)                    ? 0 : rec_obj.get("ShipmentPayer")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ExtendSplitLevel") == null)                 ? 0 : rec_obj.get("ExtendSplitLevel")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PackageReadyForDelivery") == "false")       ? 0 : 1 )                                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InternalCommentId") == null)                ? 0 : rec_obj.get("InternalCommentId")  )               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ExternalCommentId") == null)                ? 0 : rec_obj.get("ExternalCommentId")  )               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PaymentTermId") == null)                    ? 0 : rec_obj.get("PaymentTermId")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ExcludeFromEdi") == "false")                ? 0 : 1 )                                               + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "PickingList was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getSalesPickingLists


    public static String getSalesPrices(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrders" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/Customers" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/Quotes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerAccountGroups" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerDistricts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderDeliveryRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoiceRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderShippingInformationRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerPartLinks" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerRelationshipActivityTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerRelationshipManagementActivities" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerStatuses" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/InvoiceLogs" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/OtherCustomerNumbers" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/QuoteRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/QuoteTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/ReasonCodeLostQuotes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/SalesPickingLists" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/SalesPrices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/SalesPrices?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".salesprice where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".salesprice (tenant_id , id , " +
                          " Price , " +
                          " PriceCurrencyId , " +
                          " SetupPrice , " +
                          " SetupPriceCurrencyId , " +
                          " ValidThrough , " +
                          " PartId , " +
                          " PriceListId , " +
                          " CommentId , " +
                          " FuturePrice , " +
                          " FuturePriceCurrencyId , " +
                          " FuturePriceValidThrough , " +
                          " FutureSetupPrice , " +
                          " FutureSetupPriceCurrencyId   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Price") == null)                        ? 0 : rec_obj.get("Price")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PriceCurrencyId") == null)              ? 0 : rec_obj.get("PriceCurrencyId")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SetupPrice") == null)                   ? 0 : rec_obj.get("SetupPrice")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SetupPriceCurrencyId") == null)         ? 0 : rec_obj.get("SetupPriceCurrencyId")  )           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ValidThrough") == null      || rec_obj.get("ValidThrough").toString().substring(0,2).equals("00")  )      ? new Date(2021000000) : rec_obj.get("ValidThrough").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("PartId") == null)                       ? 0 : rec_obj.get("PartId")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PriceListId") == null)                  ? 0 : rec_obj.get("PriceListId")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CommentId") == null)                    ? 0 : rec_obj.get("CommentId")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("FuturePrice") == null)                  ? 0 : rec_obj.get("FuturePrice")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("FuturePriceCurrencyId") == null)        ? 0 : rec_obj.get("FuturePriceCurrencyId")  )          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("FuturePriceValidThrough") == null      || rec_obj.get("FuturePriceValidThrough").toString().substring(0,2).equals("00")  )      ? new Date(2021000000) : rec_obj.get("FuturePriceValidThrough").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("FutureSetupPrice") == null)             ? 0 : rec_obj.get("FutureSetupPrice")  )               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("FutureSetupPriceCurrencyId") == null)   ? 0 : rec_obj.get("FutureSetupPriceCurrencyId")  )     + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "SalesPrice was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getSalesPrices




    public static String getValidityTimes(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrders" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/Customers" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/Quotes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerAccountGroups" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerDistricts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderDeliveryRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoiceRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderShippingInformationRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerPartLinks" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerRelationshipActivityTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerRelationshipManagementActivities" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerStatuses" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/InvoiceLogs" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/OtherCustomerNumbers" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/QuoteRows" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/QuoteTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/ReasonCodeLostQuotes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/SalesPickingLists" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/SalesPrices" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/ValidityTimes" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/ValidityTimes?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".validitytime where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".validitytime (tenant_id , id , " +
                          " Days , " +
                          " DescriptionId , " +
                          " Number , " +
                          " IsDefault , " +
                          " Description   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Days") == null)                         ? 0 : rec_obj.get("Days")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                ? 0 : rec_obj.get("DescriptionId")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Number") == null)                       ? 0 : rec_obj.get("Number")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsDefault") == "false")                 ? 0 : 1 )                                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                  ? 0 : rec_obj.get("Description")  )                   + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "ValidityTime was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getValidityTimes



}  // Queries_SAL


