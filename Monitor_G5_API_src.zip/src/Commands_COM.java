package sy_my ;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Scanner;
import org.json.simple.JSONObject;
import org.json.simple.JSONArray;
import org.json.simple.JSONValue;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

// import java.time.*;

// -------

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import java.sql.* ;

// import java.sql.Connection;
// import java.sql.Date;
// import java.sql.DriverManager;
// import java.sql.PreparedStatement;
// import java.sql.SQLException;

import java.text.SimpleDateFormat;


public class Commands_COM {



    // TEST START
    public static HttpURLConnection TestQuery(ReadConf conf) throws Exception {
        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals("185.158.177.241");

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end


             // URL url             = new URL( conf.getUrl_sy() );
             URL url                = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", "185.158.177.241"  );
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", "f1bc5219-b382-472e-adc9-ff0926ecbbb0" );



     	     String json = "{\n";
     		 json += "\"Username\": "     +  "\"ADMIN\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"\" "       + ",\n";
		     json += "\"ForceRelogin\": " +  true          + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( response );

   			     return con ;  // response


                 /*
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parse    = new JSONParser();
                 JSONObject data_obj = (JSONObject) parse.parse( json );  // inline
                 //Get the required object from the above created object
                 JSONObject obj = (JSONObject) data_obj.get("Globale");
                 //Get the required data using its key
                 System.out.println(obj.get("TotalRecovered"));
                 JSONArray arr = (JSONArray) data_obj.get("Countries");
                 for (int i = 0; i < arr.size(); i++) {
                      JSONObject new_obj = (JSONObject) arr.get(i);
                      if (new_obj.get("Slug").equals("albania")) {
                         System.out.println("Total Recovered: " + new_obj.get("TotalRecovered"));
                         break;
                      }
                 }
               */

                }


        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() );
        }
        // return con;
    }

    // TEST END




    public static String postCommonApplicationUsersAddPermissionGroup(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_ApplicationUsers_AddPermissionGroup.json");

        System.out.println("Common_ApplicationUsers_AddPermissionGroup  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/ApplicationUsers/AddPermissionGroup"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_ApplicationUsers_AddPermissionGroup done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonApplicationUsersAddPermissionGroup




    public static String postCommonApplicationUsersCreate(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_ApplicationUsers_Create.json");

        System.out.println("Common_ApplicationUsers_Create  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/ApplicationUsers/Create"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_ApplicationUsers_Create done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonApplicationUsersCreate



    public static String postCommonApplicationUsersRemove(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_ApplicationUsers_Remove.json");

        System.out.println("Common_ApplicationUsers_Remove  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/ApplicationUsers/Remove"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_ApplicationUsers_Remove done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonApplicationUsersRemove




    public static String postCommonApplicationUsersRemovePermissionGroup(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_ApplicationUsers_RemovePermissionGroup.json");

        System.out.println("Common_ApplicationUsers_RemovePermissionGroup  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/ApplicationUsers/RemovePermissionGroup"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_ApplicationUsers_RemovePermissionGroup done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonApplicationUsersRemovePermissionGroup





    public static String postCommonApplicationUsersSetEmailProperties(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_ApplicationUsers_SetEmailProperties.json");

        System.out.println("Common_ApplicationUsers_SetEmailProperties  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/ApplicationUsers/SetEmailProperties"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_ApplicationUsers_SetEmailProperties done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonApplicationUsersSetEmailProperties




    public static String postCommonApplicationUsersSetLicense(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_ApplicationUsers_SetLicense.json");

        System.out.println("Common_ApplicationUsers_SetLicense  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/ApplicationUsers/SetLicense"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_ApplicationUsers_SetLicense done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonApplicationUsersSetLicense





    public static String postCommonApplicationUsersSetProperties(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_ApplicationUsers_SetProperties.json");

        System.out.println("Common_ApplicationUsers_SetProperties  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/ApplicationUsers/SetProperties"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_ApplicationUsers_SetProperties done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonApplicationUsersSetProperties





    public static String postCommonCommandsAddFileToComment(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Commands_AddFileToComment.json");

        System.out.println("Common_Commands_AddFileToComment  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Commands/AddFileToComment"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_Commands_AddFileToComment done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonCommandsAddFileToComment






    public static String postCommonCommandsAddWorkdaysToDate(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Commands_AddWorkdaysToDate.json");

        System.out.println("Common_Commands_AddWorkdaysToDate  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Commands/AddWorkdaysToDate"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 /*
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 */


                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */

                 /*

                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()



                 System.out.println("obj  \n " +  sesId );

                 */
                 WriteLog.write(conf.getLogFile(), "Common_Commands_AddWorkdaysToDate done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonCommandsAddWorkdaysToDate





    public static String postCommonCommandsCreateBusinessContactNoteHistory(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Commands_CreateBusinessContactNoteHistory.json");

        System.out.println("Common_Commands_CreateBusinessContactNoteHistory  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Commands/CreateBusinessContactNoteHistory"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_Commands_CreateBusinessContactNoteHistory done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonCommandsCreateBusinessContactNoteHistory



    public static String postCommonCommandsCreateComment(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Commands_CreateComment.json");

        System.out.println("Common_Commands_CreateComment  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Commands/CreateComment"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_Commands_CreateComment done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonCommandsCreateComment




    public static String postCommonCommandsExecuteAutoCompleteSearch(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Commands_ExecuteAutoCompleteSearch.json");

        System.out.println("Common_Commands_ExecuteAutoCompleteSearch  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Commands/ExecuteAutoCompleteSearch"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 /*
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 */


                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */

                 /*

                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()



                 System.out.println("obj  \n " +  sesId );

                 */
                 WriteLog.write(conf.getLogFile(), "Common_Commands_ExecuteAutoCompleteSearch done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonCommandsExecuteAutoCompleteSearch





    public static String postCommonCommandsGetAvailableLicenses(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Commands_GetAvailableLicenses.json");

        System.out.println("Common_Commands_GetAvailableLicenses  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Commands/GetAvailableLicenses"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 /*
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 */


                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */

                 /*

                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()



                 System.out.println("obj  \n " +  sesId );

                 */
                 WriteLog.write(conf.getLogFile(), "Common_Commands_GetAvailableLicenses done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonCommandsGetAvailableLicenses





    public static String postCommonCommandsGetCategoryComponentValues(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Commands_GetCategoryComponentValues.json");

        System.out.println("Common_Commands_GetCategoryComponentValues  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Commands/GetCategoryComponentValues"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 /*
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 */


                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */

                 /*

                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()



                 System.out.println("obj  \n " +  sesId );

                 */
                 WriteLog.write(conf.getLogFile(), "Common_Commands_GetCategoryComponentValues done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonCommandsGetCategoryComponentValues







    public static String postCommonCommandsGetCustomReport(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Commands_GetCustomReport.json");

        System.out.println("Common_Commands_GetCustomReport  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Commands/GetCustomReport"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 /*
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 */


                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */

                 /*

                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()



                 System.out.println("obj  \n " +  sesId );

                 */
                 WriteLog.write(conf.getLogFile(), "Common_Commands_GetCustomReport done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonCommandsGetCustomReport



    public static String postCommonCommandsGetCustomReportByDisplayId(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Commands_GetCustomReportByDisplayId.json");

        System.out.println("Common_Commands_GetCustomReportByDisplayId  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Commands/GetCustomReportByDisplayId"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 /*
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 */


                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */

                 /*

                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()



                 System.out.println("obj  \n " +  sesId );

                 */
                 WriteLog.write(conf.getLogFile(), "Common_Commands_GetCustomReportByDisplayId done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonCommandsGetCustomReportByDisplayId




    public static String postCommonCommandsGetEntity(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Commands_GetEntity.json");

        System.out.println("Common_Commands_GetEntity  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Commands/GetEntity"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_Commands_GetEntity done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonCommandsGetEntity





    public static String postCommonCommandsGetEntityModificationInformation(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Commands_GetEntityModificationInformation.json");

        System.out.println("Common_Commands_GetEntityModificationInformation  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Commands/GetEntityModificationInformation"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 /*
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 */


                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */

                 /*

                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()



                 System.out.println("obj  \n " +  sesId );

                 */
                 WriteLog.write(conf.getLogFile(), "Common_Commands_GetEntityModificationInformation done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonCommandsGetEntityModificationInformation




    public static String postCommonCommandsGetMonitorConfiguration(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Commands_GetMonitorConfiguration.json");

        System.out.println("Common_Commands_GetMonitorConfiguration  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Commands/GetMonitorConfiguration"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 /*
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 */


                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */

                 /*

                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()



                 System.out.println("obj  \n " +  sesId );

                 */
                 WriteLog.write(conf.getLogFile(), "Common_Commands_GetMonitorConfiguration done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonCommandsGetMonitorConfiguration




    public static String postCommonCommandsGetSystemId(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Commands_GetSystemId.json");

        System.out.println("Common_Commands_GetSystemId  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Commands/GetSystemId"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 /*
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 */


                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */

                 /*

                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()



                 System.out.println("obj  \n " +  sesId );

                 */
                 WriteLog.write(conf.getLogFile(), "Common_Commands_GetSystemId done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonCommandsGetSystemId



    public static String postCommonCommandsGetSystemParameters(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Commands_GetSystemParameters.json");

        System.out.println("Common_Commands_GetSystemParameters  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Commands/GetSystemParameters"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 /*
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 */


                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */

                 /*

                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()



                 System.out.println("obj  \n " +  sesId );

                 */
                 WriteLog.write(conf.getLogFile(), "Common_Commands_GetSystemParameters done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonCommandsGetSystemParameters




    public static String postCommonCommandsPrintCustomReportByDisplayId(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Commands_PrintCustomReportByDisplayId.json");

        System.out.println("Common_Commands_PrintCustomReportByDisplayId  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Commands/PrintCustomReportByDisplayId"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 /*
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 */


                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */

                 /*

                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()



                 System.out.println("obj  \n " +  sesId );

                 */
                 WriteLog.write(conf.getLogFile(), "Common_Commands_PrintCustomReportByDisplayId done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonCommandsPrintCustomReportByDisplayId





    public static String postCommonCommandsSendSystemEmail(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Commands_SendSystemEmail.json");

        System.out.println("Common_Commands_SendSystemEmail  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Commands/SendSystemEmail"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 /*
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 */


                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */

                 /*

                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()



                 System.out.println("obj  \n " +  sesId );

                 */
                 WriteLog.write(conf.getLogFile(), "Common_Commands_SendSystemEmail done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonCommandsSendSystemEmail




    public static String postCommonCommandsSendUserEmail(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Commands_SendUserEmail.json");

        System.out.println("Common_Commands_SendUserEmail  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Commands/SendUserEmail"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 /*
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 */


                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */

                 /*

                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()



                 System.out.println("obj  \n " +  sesId );

                 */
                 WriteLog.write(conf.getLogFile(), "Common_Commands_SendUserEmail done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonCommandsSendUserEmail




    public static String postCommonCommandsSetExtraFieldValues(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Commands_SetExtraFieldValues.json");

        System.out.println("Common_Commands_SetExtraFieldValues  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Commands/SetExtraFieldValues"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 /*
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 */


                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */

                 /*

                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()



                 System.out.println("obj  \n " +  sesId );

                 */
                 WriteLog.write(conf.getLogFile(), "Common_Commands_PrintCustomReportByDisplayId done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonCommandsSetExtraFieldValues



    public static String postCommonCommandsUpdateAddress(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Commands_UpdateAddress.json");

        System.out.println("Common_Commands_UpdateAddress  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Commands/UpdateAddress"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_Commands_UpdateAddress done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonCommandsUpdateAddress



    public static String postCommonCommandsUpdateBusinessContactNoteHistory(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Commands_UpdateBusinessContactNoteHistory.json");

        System.out.println("Common_Commands_UpdateBusinessContactNoteHistory  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Commands/UpdateBusinessContactNoteHistory"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_Commands_UpdateBusinessContactNoteHistory done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonCommandsUpdateBusinessContactNoteHistory





    public static String postCommonCommandsUpdateComment(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Commands_UpdateComment.json");

        System.out.println("Common_Commands_UpdateComment  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Commands/UpdateComment"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_Commands_UpdateComment done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonCommandsUpdateComment





    public static String postCommonCommandsUpdateDeliveryAddress(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Commands_UpdateDeliveryAddress.json");

        System.out.println("Common_Commands_UpdateDeliveryAddress  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Commands/UpdateDeliveryAddress"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_Commands_UpdateDeliveryAddress done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonCommandsUpdateDeliveryAddress




    public static String postCommonCommandsUpdateDeliveryAddressWarehouseInformation(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Commands_UpdateDeliveryAddressWarehouseInformation.json");

        System.out.println("Common_Commands_UpdateDeliveryAddressWarehouseInformation  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Commands/UpdateDeliveryAddressWarehouseInformation"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_Commands_UpdateDeliveryAddressWarehouseInformation done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonCommandsUpdateDeliveryAddressWarehouseInformation






    public static String postCommonFileLinksRemove(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_FileLinks_Remove.json");

        System.out.println("Common_FileLinks_Remove  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/FileLinks/Remove"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_FileLinks_Remove done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonFileLinksRemove






    public static String postCommonFileLinksUpdate(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_FileLinks_Update.json");

        System.out.println("Common_FileLinks_Update  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/FileLinks/Update"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_FileLinks_Update done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonFileLinksUpdate






    public static String postCommonFileLinksUpdateData(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_FileLinks_UpdateData.json");

        System.out.println("Common_FileLinks_UpdateData  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/FileLinks/UpdateData"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_FileLinks_UpdateData done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonFileLinksUpdateData



    public static String postCommonFilePathsUploadFile(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_FilePaths_UploadFile.json");

        System.out.println("Common_FilePaths_UploadFile  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/FilePaths/UploadFile"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 /*
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 */


                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */

                 /*

                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()



                 System.out.println("obj  \n " +  sesId );

                 */
                 WriteLog.write(conf.getLogFile(), "Common_FilePaths_UploadFile done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonFilePathsUploadFile





    public static String postCommonPartConfigurationsCreateAndAddFreeSelectionRow(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_PartConfigurations_CreateAndAddFreeSelectionRow.json");

        System.out.println("Common_PartConfigurations_CreateAndAddFreeSelectionRow  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/PartConfigurations/CreateAndAddFreeSelectionRow"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 /*
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 */


                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */

                 /*

                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()



                 System.out.println("obj  \n " +  sesId );

                 */
                 WriteLog.write(conf.getLogFile(), "Common_PartConfigurations_CreateAndAddFreeSelectionRow done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonPartConfigurationsCreateAndAddFreeSelectionRow





    public static String postCommonPartConfigurationsDestroy(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_PartConfigurations_Destroy.json");

        System.out.println("Common_PartConfigurations_Destroy  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/PartConfigurations/Destroy"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 /*
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 */


                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */

                 /*

                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()



                 System.out.println("obj  \n " +  sesId );

                 */
                 WriteLog.write(conf.getLogFile(), "Common_PartConfigurations_Destroy done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonPartConfigurationsDestroy




    public static String postCommonPartConfigurationsExists(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_PartConfigurations_Exists.json");

        System.out.println("Common_PartConfigurations_Exists  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/PartConfigurations/Exists"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 /*
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 */


                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */

                 /*

                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()



                 System.out.println("obj  \n " +  sesId );

                 */
                 WriteLog.write(conf.getLogFile(), "Common_PartConfigurations_Exists done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonPartConfigurationsExists





    public static String postCommonPartConfigurationsGet(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_PartConfigurations_Get.json");

        System.out.println("Common_PartConfigurations_Get  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/PartConfigurations/Get"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 /*
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 */


                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */

                 /*

                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()



                 System.out.println("obj  \n " +  sesId );

                 */
                 WriteLog.write(conf.getLogFile(), "Common_PartConfigurations_Get done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonPartConfigurationsGet



    public static String postCommonPartConfigurationsPoke(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_PartConfigurations_Poke.json");

        System.out.println("Common_PartConfigurations_Poke  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/PartConfigurations/Poke"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 /*
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 */


                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */

                 /*

                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()



                 System.out.println("obj  \n " +  sesId );

                 */
                 WriteLog.write(conf.getLogFile(), "Common_PartConfigurations_Poke done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonPartConfigurationsPoke



    public static String postCommonPartConfigurationsUpdate(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_PartConfigurations_Update.json");

        System.out.println("Common_PartConfigurations_Update  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/PartConfigurations/Update"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 /*
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 */


                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */

                 /*

                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()



                 System.out.println("obj  \n " +  sesId );

                 */
                 WriteLog.write(conf.getLogFile(), "Common_PartConfigurations_Update done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonPartConfigurationsUpdate




    public static String postCommonPaymentPlanTemplatesCreate(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_PaymentPlanTemplates_Create.json");

        System.out.println("Common_PaymentPlanTemplates_Create  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/PaymentPlanTemplates/Create"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_PaymentPlanTemplates_Create done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonPaymentPlanTemplatesCreate





    public static String postCommonPersonsAddEmploymentPeriod(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Persons_AddEmploymentPeriod.json");

        System.out.println("Common_Persons_AddEmploymentPeriod  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Persons/AddEmploymentPeriod"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_Persons_AddEmploymentPeriod done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonPersonsAddEmploymentPeriod





    public static String postCommonPersonsAddRelative(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Persons_AddRelative.json");

        System.out.println("Common_Persons_AddRelative  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Persons/AddRelative"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_Persons_AddRelative done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonPersonsAddRelative






    public static String postCommonPersonsBlock(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Persons_Block.json");

        System.out.println("Common_Persons_Block  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Persons/Block"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_Persons_Block done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonPersonsBlock








    public static String postCommonPersonsCreate(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Persons_Create.json");

        System.out.println("Common_Persons_Create  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Persons/Create"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_Persons_Create done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonPersonsCreate




    public static String postCommonPersonsGetIdByPersonalCardNumber(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Persons_GetIdByPersonalCardNumber.json");

        System.out.println("Common_Persons_GetIdByPersonalCardNumber  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Persons/GetIdByPersonalCardNumber"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 /*
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 */


                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */

                 /*

                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()



                 System.out.println("obj  \n " +  sesId );

                 */
                 WriteLog.write(conf.getLogFile(), "Common_Persons_GetIdByPersonalCardNumber done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonPersonsGetIdByPersonalCardNumber







    public static String postCommonPersonsRemove(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Persons_Remove.json");

        System.out.println("Common_Persons_Remove  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Persons/Remove"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_Persons_Remove done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonPersonsRemove





    public static String postCommonPersonsRemoveEmploymentPeriod(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Persons_RemoveEmploymentPeriod.json");

        System.out.println("Common_Persons_RemoveEmploymentPeriod  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Persons/RemoveEmploymentPeriod"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_Persons_RemoveEmploymentPeriod done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonPersonsRemoveEmploymentPeriod





    public static String postCommonPersonsRemoveRelative(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Persons_RemoveRelative.json");

        System.out.println("Common_Persons_RemoveRelative  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Persons/RemoveRelative"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_Persons_RemoveRelative done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonPersonsRemoveRelative




    public static String postCommonPersonsSetAvailableAsProperties(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Persons_SetAvailableAsProperties.json");

        System.out.println("Common_Persons_SetAvailableAsProperties  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Persons/SetAvailableAsProperties"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_Persons_SetAvailableAsProperties done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonPersonsSetAvailableAsProperties






    public static String postCommonPersonsSetContactInformationProperties(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Persons_SetContactInformationProperties.json");

        System.out.println("Common_Persons_SetContactInformationProperties  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Persons/SetContactInformationProperties"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_Persons_SetContactInformationProperties done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonPersonsSetContactInformationProperties




    public static String postCommonPersonsSetProperties(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Persons_SetProperties.json");

        System.out.println("Common_Persons_SetProperties  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Persons/SetProperties"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_Persons_SetProperties done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonPersonsSetProperties





    public static String postCommonPersonsUpdateEmploymentPeriod(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Persons_UpdateEmploymentPeriod.json");

        System.out.println("Common_Persons_UpdateEmploymentPeriod  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Persons/UpdateEmploymentPeriod"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_Persons_UpdateEmploymentPeriod done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonPersonsUpdateEmploymentPeriod




    public static String postCommonPersonsUpdateRelative(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Persons_UpdateRelative.json");

        System.out.println("Common_Persons_UpdateRelative  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Persons/UpdateRelative"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_Persons_UpdateRelative done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonPersonsUpdateRelative




    public static String postCommonProjectsChangeActivityCostReportingEntry(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Projects_ChangeActivityCostReportingEntry.json");

        System.out.println("Common_Projects_ChangeActivityCostReportingEntry  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Projects/ChangeActivityCostReportingEntry"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_Projects_ChangeActivityCostReportingEntry done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonProjectsChangeActivityCostReportingEntry





    public static String postCommonProjectsCreate(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Projects_Create.json");

        System.out.println("Common_Projects_Create  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Projects/Create"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_Projects_Create done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonProjectsCreate







    public static String postCommonProjectsCreateActivity(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Projects_CreateActivity.json");

        System.out.println("Common_Projects_CreateActivity  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Projects/CreateActivity"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_Projects_CreateActivity done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonProjectsCreateActivity





    public static String postCommonProjectsCreateActivityDelegatedWork(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Projects_CreateActivityDelegatedWork.json");

        System.out.println("Common_Projects_CreateActivityDelegatedWork  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Projects/CreateActivityDelegatedWork"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_Projects_CreateActivityDelegatedWork done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonProjectsCreateActivityDelegatedWork




    public static String postCommonProjectsCreateCostReportingEntry(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Projects_CreateCostReportingEntry.json");

        System.out.println("Common_Projects_CreateCostReportingEntry  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Projects/CreateCostReportingEntry"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_Projects_CreateCostReportingEntry done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonProjectsCreateCostReportingEntry





    public static String postCommonProjectsCreatePhase(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Projects_CreatePhase.json");

        System.out.println("Common_Projects_CreatePhase  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Projects/CreatePhase"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_Projects_CreatePhase done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonProjectsCreatePhase






    public static String postCommonProjectsCreateRootActivity(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Projects_CreateRootActivity.json");

        System.out.println("Common_Projects_CreateRootActivity  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Projects/CreateRootActivity"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_Projects_CreateRootActivity done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonProjectsCreateRootActivity




    public static String postCommonProjectsRemove(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Projects_Remove.json");

        System.out.println("Common_Projects_Remove  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Projects/Remove"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_Projects_Remove done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonProjectsRemove




    public static String postCommonProjectsRemoveActivity(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Projects_RemoveActivity.json");

        System.out.println("Common_Projects_RemoveActivity  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Projects/RemoveActivity"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_Projects_RemoveActivity done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonProjectsRemoveActivity






    public static String postCommonProjectsRemoveActivityDelegatedWork(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Projects_RemoveActivityDelegatedWork.json");

        System.out.println("Common_Projects_RemoveActivityDelegatedWork  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Projects/RemoveActivityDelegatedWork"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_Projects_RemoveActivityDelegatedWork done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonProjectsRemoveActivityDelegatedWork






    public static String postCommonProjectsRemovePhase(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Projects_RemovePhase.json");

        System.out.println("Common_Projects_RemovePhase  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Projects/RemovePhase"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_Projects_RemovePhase done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonProjectsRemovePhase





    public static String postCommonProjectsReplan(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Projects_Replan.json");

        System.out.println("Common_Projects_Replan  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Projects/Replan"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_Projects_Replan done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonProjectsReplan




    public static String postCommonProjectsSetPreviousActivities(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Projects_SetPreviousActivities.json");

        System.out.println("Common_Projects_SetPreviousActivities  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Projects/SetPreviousActivities"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_Projects_SetPreviousActivities done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonProjectsSetPreviousActivities



    public static String postCommonProjectsSetPreviousPhases(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Projects_SetPreviousPhases.json");

        System.out.println("Common_Projects_SetPreviousPhases  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Projects/SetPreviousPhases"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_Projects_SetPreviousPhases done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonProjectsSetPreviousPhases




    public static String postCommonProjectsSetProperties(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Projects_SetProperties.json");

        System.out.println("Common_Projects_SetProperties  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Projects/SetProperties"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_Projects_SetProperties done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonProjectsSetProperties





    public static String postCommonProjectsSetType(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Projects_SetType.json");

        System.out.println("Common_Projects_SetType  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Projects/SetType"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_Projects_SetType done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonProjectsSetType





    public static String postCommonProjectsUpdateActivity(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Projects_UpdateActivity.json");

        System.out.println("Common_Projects_UpdateActivity  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Projects/UpdateActivity"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_Projects_UpdateActivity done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonProjectsUpdateActivity







    public static String postCommonProjectsUpdateCostBudget(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Projects_UpdateCostBudget.json");

        System.out.println("Common_Projects_UpdateCostBudget  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Projects/UpdateCostBudget"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_Projects_UpdateCostBudget done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonProjectsUpdateCostBudget





    public static String postCommonProjectsUpdateCostForecast(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Projects_UpdateCostForecast.json");

        System.out.println("Common_Projects_UpdateCostForecast  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Projects/UpdateCostForecast"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_Projects_UpdateCostForecast done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonProjectsUpdateCostForecast






    public static String postCommonProjectsUpdateCostReportingEntry(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Projects_UpdateCostReportingEntry.json");

        System.out.println("Common_Projects_UpdateCostReportingEntry  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Projects/UpdateCostReportingEntry"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_Projects_UpdateCostReportingEntry done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonProjectsUpdateCostReportingEntry





    public static String postCommonProjectsUpdatePhase(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Common_Projects_UpdatePhase.json");

        System.out.println("Common_Projects_UpdatePhase  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Projects/UpdatePhase"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Common_Projects_UpdatePhase done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postCommonProjectsUpdatePhase








}  // Commands_COM
