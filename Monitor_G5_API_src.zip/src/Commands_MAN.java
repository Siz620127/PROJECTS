package sy_my ;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Scanner;
import org.json.simple.JSONObject;
import org.json.simple.JSONArray;
import org.json.simple.JSONValue;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

// import java.time.*;

// -------

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import java.sql.* ;

// import java.sql.Connection;
// import java.sql.Date;
// import java.sql.DriverManager;
// import java.sql.PreparedStatement;
// import java.sql.SQLException;

import java.text.SimpleDateFormat;


public class Commands_MAN {



    // TEST START
    public static HttpURLConnection TestQuery(ReadConf conf) throws Exception {
        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals("185.158.177.241");

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end


             // URL url             = new URL( conf.getUrl_sy() );
             URL url                = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", "185.158.177.241"  );
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", "f1bc5219-b382-472e-adc9-ff0926ecbbb0" );



     	     String json = "{\n";
     		 json += "\"Username\": "     +  "\"ADMIN\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"\" "       + ",\n";
		     json += "\"ForceRelogin\": " +  true          + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( response );

   			     return con ;  // response


                 /*
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parse    = new JSONParser();
                 JSONObject data_obj = (JSONObject) parse.parse( json );  // inline
                 //Get the required object from the above created object
                 JSONObject obj = (JSONObject) data_obj.get("Globale");
                 //Get the required data using its key
                 System.out.println(obj.get("TotalRecovered"));
                 JSONArray arr = (JSONArray) data_obj.get("Countries");
                 for (int i = 0; i < arr.size(); i++) {
                      JSONObject new_obj = (JSONObject) arr.get(i);
                      if (new_obj.get("Slug").equals("albania")) {
                         System.out.println("Total Recovered: " + new_obj.get("TotalRecovered"));
                         break;
                      }
                 }
               */

                }


        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() );
        }
        // return con;
    }

    // TEST END





    public static String postManufacturingManufacturingOrderMaterialsUpdate(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Manufacturing_ManufacturingOrderMaterials_Update.json");

        System.out.println("Manufacturing_ManufacturingOrderMaterials_Update  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/ManufacturingOrderMaterials/Update"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "ManufacturingOrderMaterials_Update done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postManufacturingManufacturingOrderMaterialsUpdate





    public static String postManufacturingManufacturingOrderMaterialsUpdateMaterialQuantity(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Manufacturing_ManufacturingOrderMaterials_UpdateMaterialQuantity.json");

        System.out.println("Manufacturing_ManufacturingOrderMaterials_UpdateMaterialQuantity  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/ManufacturingOrderMaterials/UpdateMaterialQuantity"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "ManufacturingOrderMaterials_UpdateMaterialQuantity done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postManufacturingManufacturingOrderMaterialsUpdateMaterialQuantity






    public static String postManufacturingManufacturingOrderNodesStepToStatus(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Manufacturing_ManufacturingOrderNodes_StepToStatus.json");

        System.out.println("Manufacturing_ManufacturingOrderNodes_StepToStatus  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/ManufacturingOrderNodes/StepToStatus"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "ManufacturingOrderNodes_StepToStatus done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postManufacturingManufacturingOrderNodesStepToStatus




    public static String postManufacturingManufacturingOrderOperationsAddMaterial(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Manufacturing_ManufacturingOrderOperations_AddMaterial.json");

        System.out.println("Manufacturing_ManufacturingOrderOperations_AddMaterial  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/ManufacturingOrderOperations/AddMaterial"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "ManufacturingOrderOperations_AddMaterial done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postManufacturingManufacturingOrderOperationsAddMaterial




    public static String postManufacturingManufacturingOrderOperationsAddOperation(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Manufacturing_ManufacturingOrderOperations_AddOperation.json");

        System.out.println("Manufacturing_ManufacturingOrderOperations_AddOperation  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/ManufacturingOrderOperations/AddOperation"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "ManufacturingOrderOperations_AddOperation done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postManufacturingManufacturingOrderOperationsAddOperation





    public static String postManufacturingManufacturingOrderOperationsBundle(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Manufacturing_ManufacturingOrderOperations_Bundle.json");

        System.out.println("Manufacturing_ManufacturingOrderOperations_Bundle  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/ManufacturingOrderOperations/Bundle"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");
               
                 /* 
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );
                 */
            
                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 /*
                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );
                 */
                 WriteLog.write(conf.getLogFile(), "ManufacturingOrderOperations_Bundle done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postManufacturingManufacturingOrderOperationsBundle




    public static String postManufacturingManufacturingOrderOperationsPrintDefaultShopPacket(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Manufacturing_ManufacturingOrderOperations_PrintDefaultShopPacket.json");

        System.out.println("Manufacturing_ManufacturingOrderOperations_PrintDefaultShopPacket  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/ManufacturingOrderOperations/PrintDefaultShopPacket"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");
               
                 /* 
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );
                 */
            
                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 /*
                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );
                 */
                 WriteLog.write(conf.getLogFile(), "ManufacturingOrderOperations_PrintDefaultShopPacket done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postManufacturingManufacturingOrderOperationsPrintDefaultShopPacket




    public static String postManufacturingManufacturingOrderOperationsPrintShopPacket(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Manufacturing_ManufacturingOrderOperations_PrintShopPacket.json");

        System.out.println("Manufacturing_ManufacturingOrderOperations_PrintShopPacket  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/ManufacturingOrderOperations/PrintShopPacket"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");
               
                 /* 
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );
                 */
            
                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 /*
                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );
                 */
                 WriteLog.write(conf.getLogFile(), "ManufacturingOrderOperations_PrintShopPacket done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postManufacturingManufacturingOrderOperationsPrintShopPacket





    public static String postManufacturingManufacturingOrderOperationsRemove(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Manufacturing_ManufacturingOrderOperations_Remove.json");

        System.out.println("Manufacturing_ManufacturingOrderOperations_Remove  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/ManufacturingOrderOperations/Remove"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "ManufacturingOrderOperations_Remove done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postManufacturingManufacturingOrderOperationsRemove




    public static String postManufacturingManufacturingOrderOperationsRemoveBundle(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Manufacturing_ManufacturingOrderOperations_RemoveBundle.json");

        System.out.println("Manufacturing_ManufacturingOrderOperations_RemoveBundle  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/ManufacturingOrderOperations/RemoveBundle"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");
               
                 /* 
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );
                 */
            
                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 /*
                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );
                 */
                 WriteLog.write(conf.getLogFile(), "ManufacturingOrderOperations_RemoveBundle done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postManufacturingManufacturingOrderOperationsRemoveBundle





    public static String postManufacturingManufacturingOrderOperationsSetSupplier(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Manufacturing_ManufacturingOrderOperations_SetSupplier.json");

        System.out.println("Manufacturing_ManufacturingOrderOperations_SetSupplier  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/ManufacturingOrderOperations/SetSupplier"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "ManufacturingOrderOperations_SetSupplier done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postManufacturingManufacturingOrderOperationsSetSupplier




    public static String postManufacturingManufacturingOrderOperationsSetWorkCenter(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Manufacturing_ManufacturingOrderOperations_SetWorkCenter.json");

        System.out.println("Manufacturing_ManufacturingOrderOperations_SetWorkCenter  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/ManufacturingOrderOperations/SetWorkCenter"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "ManufacturingOrderOperations_SetWorkCenter done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postManufacturingManufacturingOrderOperationsSetWorkCenter






    public static String postManufacturingManufacturingOrderOperationsUpdate(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Manufacturing_ManufacturingOrderOperations_Update.json");

        System.out.println("Manufacturing_ManufacturingOrderOperations_Update  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/ManufacturingOrderOperations/Update"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "ManufacturingOrderOperations_Update done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postManufacturingManufacturingOrderOperationsUpdate





    public static String postManufacturingManufacturingOrdersCreate(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Manufacturing_ManufacturingOrders_Create.json");

        System.out.println("Manufacturing_ManufacturingOrders_Create  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/ManufacturingOrders/Create"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "ManufacturingOrders_Create done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postManufacturingManufacturingOrdersCreate






    public static String postManufacturingManufacturingOrdersCreateFromCustomerOrderRow(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Manufacturing_ManufacturingOrders_CreateFromCustomerOrderRow.json");

        System.out.println("Manufacturing_ManufacturingOrders_CreateFromCustomerOrderRow  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/ManufacturingOrders/CreateFromCustomerOrderRow"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "ManufacturingOrders_CreateFromCustomerOrderRow done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postManufacturingManufacturingOrdersCreateFromCustomerOrderRow






    public static String postManufacturingManufacturingOrdersRemove(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Manufacturing_ManufacturingOrders_Remove.json");

        System.out.println("Manufacturing_ManufacturingOrders_Remove  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/ManufacturingOrders/Remove"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "ManufacturingOrders_Remove done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postManufacturingManufacturingOrdersRemove





    public static String postManufacturingManufacturingOrdersRemoveMaterial(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Manufacturing_ManufacturingOrders_RemoveMaterial.json");

        System.out.println("Manufacturing_ManufacturingOrders_RemoveMaterial  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/ManufacturingOrders/RemoveMaterial"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "ManufacturingOrders_RemoveMaterial done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postManufacturingManufacturingOrdersRemoveMaterial




    public static String postManufacturingManufacturingOrdersReplan(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Manufacturing_ManufacturingOrders_Replan.json");

        System.out.println("Manufacturing_ManufacturingOrders_Replan  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/ManufacturingOrders/Replan"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "ManufacturingOrders_Replan done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postManufacturingManufacturingOrdersReplan





    public static String postManufacturingManufacturingOrdersReplanOperation(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Manufacturing_ManufacturingOrders_ReplanOperation.json");

        System.out.println("Manufacturing_ManufacturingOrders_ReplanOperation  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/ManufacturingOrders/ReplanOperation"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "ManufacturingOrders_ReplanOperation done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postManufacturingManufacturingOrdersReplanOperation






    public static String postManufacturingManufacturingOrdersReplanPinnedOperation(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Manufacturing_ManufacturingOrders_ReplanPinnedOperation.json");

        System.out.println("Manufacturing_ManufacturingOrders_ReplanPinnedOperation  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/ManufacturingOrders/ReplanPinnedOperation"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "ManufacturingOrders_ReplanPinnedOperation done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postManufacturingManufacturingOrdersReplanPinnedOperation




    public static String postManufacturingManufacturingOrdersReplanQuantity(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Manufacturing_ManufacturingOrders_ReplanQuantity.json");

        System.out.println("Manufacturing_ManufacturingOrders_ReplanQuantity  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/ManufacturingOrders/ReplanQuantity"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "ManufacturingOrders_ReplanQuantity done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postManufacturingManufacturingOrdersReplanQuantity





    public static String postManufacturingManufacturingOrdersSetProperties(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Manufacturing_ManufacturingOrders_SetProperties.json");

        System.out.println("Manufacturing_ManufacturingOrders_SetProperties  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/ManufacturingOrders/SetProperties"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "ManufacturingOrders_SetProperties done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postManufacturingManufacturingOrdersSetProperties






    public static String postManufacturingManufacturingPickingListsCreate(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Manufacturing_ManufacturingPickingLists_Create.json");

        System.out.println("Manufacturing_ManufacturingPickingLists_Create  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/ManufacturingPickingLists/Create"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "ManufacturingPickingLists_Create done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postManufacturingManufacturingPickingListsCreate





    public static String postManufacturingManufacturingPickingListsDelete(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Manufacturing_ManufacturingPickingLists_Delete.json");

        System.out.println("Manufacturing_ManufacturingPickingLists_Delete  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/ManufacturingPickingLists/Delete"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "ManufacturingPickingLists_Delete done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postManufacturingManufacturingPickingListsDelete






    public static String postManufacturingManufacturingPickingListsReport(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Manufacturing_ManufacturingPickingLists_Report.json");

        System.out.println("Manufacturing_ManufacturingPickingLists_Report  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/ManufacturingPickingLists/Report"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "ManufacturingPickingLists_Report done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postManufacturingManufacturingPickingListsReport





    public static String postManufacturingMaterialRowsRemove(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Manufacturing_MaterialRows_Remove.json");

        System.out.println("Manufacturing_MaterialRows_Remove  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/MaterialRows/Remove"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "MaterialRows_Remove done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postManufacturingMaterialRowsRemove




    public static String postManufacturingMaterialRowsSetPart(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Manufacturing_MaterialRows_SetPart.json");

        System.out.println("Manufacturing_MaterialRows_SetPart  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/MaterialRows/SetPart"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "MaterialRows_SetPart done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postManufacturingMaterialRowsSetPart



    public static String postManufacturingMaterialRowsUpdate(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Manufacturing_MaterialRows_Update.json");

        System.out.println("Manufacturing_MaterialRows_Update  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/MaterialRows/Update"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "MaterialRows_Update done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postManufacturingMaterialRowsUpdate





    public static String postManufacturingMaterialRowsUpdatePreparationTerm(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Manufacturing_MaterialRows_UpdatePreparationTerm.json");

        System.out.println("Manufacturing_MaterialRows_UpdatePreparationTerm  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/MaterialRows/UpdatePreparationTerm"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "MaterialRows_UpdatePreparationTerm done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postManufacturingMaterialRowsUpdatePreparationTerm






    public static String postManufacturingOperationRowsRemove(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Manufacturing_OperationRows_Remove.json");

        System.out.println("Manufacturing_OperationRows_Remove  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/OperationRows/Remove"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "OperationRows_Remove done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postManufacturingOperationRowsRemove






    public static String postManufacturingOperationRowsSetSupplier(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Manufacturing_OperationRows_SetSupplier.json");

        System.out.println("Manufacturing_OperationRows_SetSupplier  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/OperationRows/SetSupplier"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "OperationRows_SetSupplier done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postManufacturingOperationRowsSetSupplier




    public static String postManufacturingOperationRowsSetWorkCenter(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Manufacturing_OperationRows_SetWorkCenter.json");

        System.out.println("Manufacturing_OperationRows_SetWorkCenter  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/OperationRows/SetWorkCenter"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "OperationRows_SetWorkCenter done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postManufacturingOperationRowsSetWorkCenter




    public static String postManufacturingOperationRowsUpdate(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Manufacturing_OperationRows_Update.json");

        System.out.println("Manufacturing_OperationRows_Update  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/OperationRows/Update"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "OperationRows_Update done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postManufacturingOperationRowsUpdate






    public static String postManufacturingOperationRowsUpdatePreparationTerm(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Manufacturing_OperationRows_UpdatePreparationTerm.json");

        System.out.println("Manufacturing_OperationRows_UpdatePreparationTerm  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/OperationRows/UpdatePreparationTerm"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "OperationRows_UpdatePreparationTerm done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postManufacturingOperationRowsUpdatePreparationTerm






    public static String postManufacturingPreparationsAddMaterialRow(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Manufacturing_Preparations_AddMaterialRow.json");

        System.out.println("Manufacturing_Preparations_AddMaterialRow  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/Preparations/AddMaterialRow"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Preparations_AddMaterialRow  done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postManufacturingPreparationsAddMaterialRow





    public static String postManufacturingPreparationsAddOperationRow(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Manufacturing_Preparations_AddOperationRow.json");

        System.out.println("Manufacturing_Preparations_AddOperationRow  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/Preparations/AddOperationRow"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Preparations_AddOperationRow  done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postManufacturingPreparationsAddOperationRow








    public static String postManufacturingPreparationsCreate(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Manufacturing_Preparations_Create.json");

        System.out.println("Manufacturing_Preparations_Create  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/Preparations/Create"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Preparations_Create  done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postManufacturingPreparationsCreate







    public static String postManufacturingReportingCreateManufacturingTransportLabel(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Manufacturing_Reporting_CreateManufacturingTransportLabel.json");

        System.out.println("Manufacturing_Reporting_CreateManufacturingTransportLabel  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/Reporting/CreateManufacturingTransportLabel"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");
                 /*
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );
                 */

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */

                 /*
                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );
                 */
                 WriteLog.write(conf.getLogFile(), "Reporting_CreateManufacturingTransportLabel  done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postManufacturingReportingCreateManufacturingTransportLabel






    public static String postManufacturingReportingGetTraceabilityDataForReportManufacturingOrderOperation(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Manufacturing_Reporting_GetTraceabilityDataForReportManufacturingOrderOperation.json");

        System.out.println("Manufacturing_Reporting_GetTraceabilityDataForReportManufacturingOrderOperation  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/Reporting/GetTraceabilityDataForReportManufacturingOrderOperation"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");
                 /*
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );
                 */

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */

                 /*
                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );
                 */
                 WriteLog.write(conf.getLogFile(), "Reporting_GetTraceabilityDataForReportManufacturingOrderOperation  done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postManufacturingReportingGetTraceabilityDataForReportManufacturingOrderOperation






    public static String postManufacturingReportingReportManufacturingOrderMaterial(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Manufacturing_Reporting_ReportManufacturingOrderMaterial.json");

        System.out.println("Manufacturing_Reporting_ReportManufacturingOrderMaterial  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/Reporting/ReportManufacturingOrderMaterial"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");
                 
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );
                 

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */

                 
                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );
                 
                 WriteLog.write(conf.getLogFile(), "Reporting_ReportManufacturingOrderMaterial  done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postManufacturingReportingReportManufacturingOrderMaterial







    public static String postManufacturingReportingReportManufacturingOrderOperation(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Manufacturing_Reporting_ReportManufacturingOrderOperation.json");

        System.out.println("Manufacturing_Reporting_ReportManufacturingOrderOperation  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/Reporting/ReportManufacturingOrderOperation"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");
                 
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );
                 

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */

                 
                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );
                 
                 WriteLog.write(conf.getLogFile(), "Reporting_ReportManufacturingOrderOperation  done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postManufacturingReportingReportManufacturingOrderOperation






    public static String postManufacturingReportingReportTraceableManufacturingOrderMaterial(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Manufacturing_Reporting_ReportTraceableManufacturingOrderMaterial.json");

        System.out.println("Manufacturing_Reporting_ReportTraceableManufacturingOrderMaterial  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/Reporting/ReportTraceableManufacturingOrderMaterial"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");
                 
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );
                 

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */

                 
                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );
                 
                 WriteLog.write(conf.getLogFile(), "Reporting_ReportTraceableManufacturingOrderMaterial  done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postManufacturingReportingReportTraceableManufacturingOrderMaterial





    public static String postManufacturingScheduleCyclesIsWithin(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Manufacturing_ScheduleCycles_IsWithin.json");

        System.out.println("Manufacturing_ScheduleCycles_IsWithin  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/ScheduleCycles/IsWithin"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");
                 
                 /*
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );
                 */                 

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */

                 /*                 
                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );
                 */                 
                 WriteLog.write(conf.getLogFile(), "ScheduleCycles_IsWithin  done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postManufacturingScheduleCyclesIsWithin





    public static String postManufacturingWorkCentersCreateCostFactorGroup(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Manufacturing_WorkCenters_CreateCostFactorGroup.json");

        System.out.println("Manufacturing_WorkCenters_CreateCostFactorGroup  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/WorkCenters/CreateCostFactorGroup"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");
                 
                 
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );
                                  

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */

                                  
                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );
                                  
                 WriteLog.write(conf.getLogFile(), "WorkCenters_CreateCostFactorGroup  done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postManufacturingWorkCentersCreateCostFactorGroup





    public static String postManufacturingWorkCentersGetCapacityAndLoading(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Manufacturing_WorkCenters_GetCapacityAndLoading.json");

        System.out.println("Manufacturing_WorkCenters_GetCapacityAndLoading  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/WorkCenters/GetCapacityAndLoading"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");
                 
                 /*                  
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );
                 */                                  

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */

                 /*                                  
                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );
                 */                                  
                 WriteLog.write(conf.getLogFile(), "WorkCenters_GetCapacityAndLoading  done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postManufacturingWorkCentersGetCapacityAndLoading






    public static String postManufacturingWorkCentersSetCostFactorGroupTypes(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Manufacturing_WorkCenters_SetCostFactorGroupTypes.json");

        System.out.println("Manufacturing_WorkCenters_SetCostFactorGroupTypes  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/WorkCenters/SetCostFactorGroupTypes"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");
                 
                                   
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );
                                                   

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */

                                                   
                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );
                                                   
                 WriteLog.write(conf.getLogFile(), "WorkCenters_SetCostFactorGroupTypes  done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postManufacturingWorkCentersSetCostFactorGroupTypes





    public static String postManufacturingWorkCentersUpdateCostFactorGroup(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Manufacturing_WorkCenters_UpdateCostFactorGroup.json");

        System.out.println("Manufacturing_WorkCenters_UpdateCostFactorGroup  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/WorkCenters/UpdateCostFactorGroup"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");
                 
                                   
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );
                                                   

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */

                                                   
                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );
                                                   
                 WriteLog.write(conf.getLogFile(), "WorkCenters_UpdateCostFactorGroup  done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postManufacturingWorkCentersUpdateCostFactorGroup









}  // Commands_MAN
