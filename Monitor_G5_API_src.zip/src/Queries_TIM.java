package sy_my ;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Scanner;
import org.json.simple.JSONObject;
import org.json.simple.JSONArray;
import org.json.simple.JSONValue;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

// import java.time.*;

// -------

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import java.sql.* ;

// import java.sql.Connection;
// import java.sql.Date;
// import java.sql.DriverManager;
// import java.sql.PreparedStatement;
// import java.sql.SQLException;

import java.text.SimpleDateFormat;


public class Queries_TIM {



    // TEST START
    public static HttpURLConnection TestQuery(ReadConf conf) throws Exception {
        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals("185.158.177.241");

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end


             // URL url             = new URL( conf.getUrl_sy() );
             URL url                = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", "185.158.177.241"  );
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", "f1bc5219-b382-472e-adc9-ff0926ecbbb0" );



     	     String json = "{\n";
     		 json += "\"Username\": "     +  "\"ADMIN\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"\" "       + ",\n";
		     json += "\"ForceRelogin\": " +  true          + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( response );

   			     return con ;  // response


                 /*
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parse    = new JSONParser();
                 JSONObject data_obj = (JSONObject) parse.parse( json );  // inline
                 //Get the required object from the above created object
                 JSONObject obj = (JSONObject) data_obj.get("Globale");
                 //Get the required data using its key
                 System.out.println(obj.get("TotalRecovered"));
                 JSONArray arr = (JSONArray) data_obj.get("Countries");
                 for (int i = 0; i < arr.size(); i++) {
                      JSONObject new_obj = (JSONObject) arr.get(i);
                      if (new_obj.get("Slug").equals("albania")) {
                         System.out.println("Total Recovered: " + new_obj.get("TotalRecovered"));
                         break;
                      }
                 }
               */

                }


        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() );
        }
        // return con;
    }

    // TEST END





    public static String getAbsenceCodes(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/AbsenceCodes" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/TimeRecording/AbsenceCodes?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".absencecode  where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".absencecode (tenant_id , id , " +
                          " RowNumber , " +
                          " Code , " +
                          " DescriptionId , " +
                          " TimeBankId , " +
                          " SalaryTypeFromScheduleAbcenseOne , " +
                          " SalaryTypeFromScheduleAbcenseTwo , " +
                          " IncludedInDailyHours , " +
                          " IncludedInSWH  , "  +
                          " DeductedIfDailyHoursNotFulfilled , " +
                          " AbsenceStatisticsType , " +
                          " MaximumTime , " +
                          " SubsequentAbsenceCodeId , " +
                          " Continuous  , " +

                          " Description  "  +


                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("RowNumber") == null)                                     ? 0 : rec_obj.get("RowNumber")  )                                   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("Code") == null)                                          ? 0 : rec_obj.get("Code")  )                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                                 ? 0 : rec_obj.get("DescriptionId")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("TimeBankId") == null)                                    ? 0 : rec_obj.get("TimeBankId")  )                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SalaryTypeFromScheduleAbcenseOne") == null)              ? 0 : rec_obj.get("SalaryTypeFromScheduleAbcenseOne")  )            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SalaryTypeFromScheduleAbcenseTwo") == null)              ? 0 : rec_obj.get("SalaryTypeFromScheduleAbcenseTwo")  )            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IncludedInDailyHours") == null)                          ? 0 : rec_obj.get("IncludedInDailyHours")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IncludedInSWH") == null)                                 ? 0 : rec_obj.get("IncludedInDailyHours")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DeductedIfDailyHoursNotFulfilled") == null)              ? 0 : rec_obj.get("DeductedIfDailyHoursNotFulfilled")  )            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AbsenceStatisticsType") == null)                         ? 0 : rec_obj.get("AbsenceStatisticsType")  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("MaximumTime") == null)                                   ? 0 : rec_obj.get("MaximumTime")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SubsequentAbsenceCodeId") == null)                       ? 0 : rec_obj.get("SubsequentAbsenceCodeId")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Continuous") == null)                                    ? 0 : rec_obj.get("Continuous")  )                                  + "\" "    + ", " +

                           "\"" + ((rec_obj.get("Description") == null)                                   ? 0 : rec_obj.get("Description")  )                                 + "\" "    + "  " +


                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                         // break;
                         rs_count = rs_count + 1 ;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "AbsenceCode was imported from Monitor API to MySql. " + rs_count + " records "  , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getAbsenceCodes





    public static String getAttendanceGroupSettings(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/AbsenceCodes" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/TimeRecording/AttendanceGroupSettings?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".attendancegroupsettings  where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".attendancegroupsettings (tenant_id , id , " +
                          " Version , " +
                          " Name , " +
                          " DescriptionId , " +
                          " AbsenceCheck , " +
                          " AddRoundOffOvertimeToTimeBank , " +
                          " AllowOvertime , " +
                          " AllowAbsenceRecordingInNegativeFlexZones , " +
                          " AllowAttendanceRecordingAdditionsInRecordingTerminal , " +
                          " AllowAttendanceRecordingAdjustmentsInRecordingTerminal , " +
                          " AllowShorterWorkingHours , " +
                          " GenerateShorterWorkingHoursForHoliday , " +
                          " AutomaticOvertimeQuestionOutsideSchedule , " +
                          " CalculationBase , " +
                          " CalculationFactor , " +
                          " CalculateOvertime , " +
                          " FlexTime , " +
                          " SalaryTypeForPositiveFlex , " +
                          " SalaryTypeForNegativeFlex , " +
                          " SalaryTypeForScheduleLessRecording , " +
                          " FlexTimeTimeBankId , " +
                          " MinTimePerDay , " +
                          " NegativeFlexIncludedInDailyHours , " +
                          " NumberOfDaysBackInTimeThatCanBeAdjusted , " +
                          " NumberOfDaysBackInTimeThatCanBeEdited , " +
                          " OvertimeInFlexZone , " +
                          " OvertimeLimitAfter , " +
                          " OvertimeLimitBefore , " +
                          " PlanAbsenceViaRecordingTerminal , " +
                          " RoundOffOvertime , " +
                          " RoundOffOvertimeTimebankId , " +
                          " RoundOffTo , " +
                          " SalaryTypeAccordingToOvertime , " +
                          " ShorterWorkingHoursTimeBankId , " +
                          " TimeAfterScheduleEnd , " +
                          " TimeBeforeScheduleStart , " +
                          " Description    " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Version") == null)                                     ? 0 : rec_obj.get("Version")  )                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Name") == null)                                        ? 0 : rec_obj.get("Name")  )                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                               ? 0 : rec_obj.get("DescriptionId")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AbsenceCheck") == "false")                             ? 0 : 1  )                                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AddRoundOffOvertimeToTimeBank") == null)               ? 0 : rec_obj.get("AddRoundOffOvertimeToTimeBank")  )             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AllowOvertime") == "false")                            ? 0 : 1  )                                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AllowAbsenceRecordingInNegativeFlexZones") == "false") ? 0 : 1  )                                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AllowAttendanceRecordingAdditionsInRecordingTerminal") == "false")   ? 0 : 1  )                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AllowAttendanceRecordingAdjustmentsInRecordingTerminal") == "false") ? 0 : 1  )                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AllowShorterWorkingHours") == "false")                 ? 0 : 1  )                                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("GenerateShorterWorkingHoursForHoliday") == "false")    ? 0 : 1  )                                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AutomaticOvertimeQuestionOutsideSchedule") == "false") ? 0 : 1  )                                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CalculationBase") == null)                             ? 0 : rec_obj.get("CalculationBase")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CalculationFactor") == null)                           ? 0 : rec_obj.get("CalculationFactor")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CalculateOvertime") == null)                           ? 0 : rec_obj.get("CalculateOvertime")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("FlexTime") == "false")                                 ? 0 : 1  )                                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SalaryTypeForPositiveFlex") == null)                   ? 0 : rec_obj.get("SalaryTypeForPositiveFlex")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SalaryTypeForNegativeFlex") == null)                   ? 0 : rec_obj.get("SalaryTypeForNegativeFlex")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SalaryTypeForScheduleLessRecording") == null)          ? 0 : rec_obj.get("SalaryTypeForScheduleLessRecording")  )        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("FlexTimeTimeBankId") == null)                          ? 0 : rec_obj.get("FlexTimeTimeBankId")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("MinTimePerDay") == null)                               ? 0 : rec_obj.get("MinTimePerDay")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("NegativeFlexIncludedInDailyHours") == "false")         ? 0 : 1  )                                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("NumberOfDaysBackInTimeThatCanBeAdjusted") == null)     ? 0 : rec_obj.get("NumberOfDaysBackInTimeThatCanBeAdjusted")  )   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("NumberOfDaysBackInTimeThatCanBeEdited") == null)       ? 0 : rec_obj.get("NumberOfDaysBackInTimeThatCanBeEdited")  )     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OvertimeInFlexZone") == "false")                       ? 0 : 1  )                                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OvertimeLimitAfter") == null)                          ? 0 : rec_obj.get("OvertimeLimitAfter")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OvertimeLimitBefore") == null)                         ? 0 : rec_obj.get("OvertimeLimitBefore")  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PlanAbsenceViaRecordingTerminal") == "false")          ? 0 : 1  )                                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RoundOffOvertime") == "false")                         ? 0 : 1  )                                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RoundOffOvertimeTimebankId") == null)                  ? 0 : rec_obj.get("RoundOffOvertimeTimebankId")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RoundOffTo") == null)                                  ? 0 : rec_obj.get("RoundOffTo")  )                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SalaryTypeAccordingToOvertime") == "false")            ? 0 : 1  )                                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ShorterWorkingHoursTimeBankId") == null)               ? 0 : rec_obj.get("ShorterWorkingHoursTimeBankId")  )             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("TimeAfterScheduleEnd") == null)                        ? 0 : rec_obj.get("TimeAfterScheduleEnd")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("TimeBeforeScheduleStart") == null)                     ? 0 : rec_obj.get("TimeBeforeScheduleStart")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                                 ? 0 : rec_obj.get("Description")  )                               + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                         // break;
                         rs_count = rs_count + 1 ;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "AttendanceGroupSettings was imported from Monitor API to MySql. " + rs_count + " records "  , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getAttendanceGroupSettings







    public static String getIndirectWorkCodes(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/AbsenceCodes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/IndirectWorkCodes" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/TimeRecording/IndirectWorkCodes?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".indirectworkcode  where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".indirectworkcode (tenant_id , id , " +
                          " Code , " +
                          " DescriptionId , " +
                          " ReportAsDirectTime , " +
                          " CommentInputType , " +
                          " IndirectWorkLinkType , " +
                          " GroupId , " +
                          " ExcludeFromFollowUp , " +
                          " AffectsOrder , " +
                          " ColorCode , " +

                          " Description  "  +


                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                           "\"" + ((rec_obj.get("Code") == null)                                     ? 0 : rec_obj.get("Code")  )                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                            ? 0 : rec_obj.get("DescriptionId")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReportAsDirectTime") == "false")                    ? 0 : 1 )                                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CommentInputType") == null)                         ? 0 : rec_obj.get("CommentInputType")  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IndirectWorkLinkType") == null)                     ? 0 : rec_obj.get("IndirectWorkLinkType")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("GroupId") == null)                                  ? 0 : rec_obj.get("GroupId")  )                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ExcludeFromFollowUp") == "false")                   ? 0 : 1 )                                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AffectsOrder") == null)                             ? 0 : rec_obj.get("AffectsOrder")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ColorCode") == null)                                ? 0 : rec_obj.get("ColorCode")  )                              + "\" "    + ", " +

                           "\"" + ((rec_obj.get("Description") == null)                              ? 0 : rec_obj.get("Description")  )                            + "\" "    + "  " +

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                         // break;
                         rs_count = rs_count + 1 ;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "IndirectWorkCode was imported from Monitor API to MySql. " + rs_count + " records " , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getIndirectWorkCodes







    public static String getOvertimeTypes(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/AbsenceCodes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/IndirectWorkCodes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/OvertimeTypes" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/TimeRecording/OvertimeTypes?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".overtimetype  where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".overtimetype (tenant_id , id , " +
                          " RowNumber , " +
                          " Code , " +
                          " DescriptionId , " +
                          " NotAllowedDuringFlex , " +
                          " TimeBankId , " +
                          " IsActive , " +
                          " CalculationType , " +
                          " InactivatedDate , " +
                          " InactivatedBy , " +

                          " Description   " +

                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("RowNumber") == null)                                ? 0 : rec_obj.get("RowNumber")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Code") == null)                                     ? 0 : rec_obj.get("Code")  )                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                            ? 0 : rec_obj.get("DescriptionId")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("NotAllowedDuringFlex") == "false")                  ? 0 : 1 )                                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("TimeBankId") == null)                               ? 0 : rec_obj.get("TimeBankId")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsActive") == "false")                              ? 0 : 1 )                                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CalculationType") == null)                          ? 0 : rec_obj.get("CalculationType")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InactivatedDate") == null || rec_obj.get("InactivatedDate ").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("InactivatedDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                          "\"" + ((rec_obj.get("InactivatedBy") == null)                            ? 0 : rec_obj.get("InactivatedBy")  )                          + "\" "    + ", " +

                          "\"" + ((rec_obj.get("Description") == null)                              ? 0 : rec_obj.get("Description")  )                            + "\" "    + "  " +

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                         // break;
                         rs_count = rs_count + 1 ;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "OvertimeType was imported from Monitor API to MySql. " + rs_count + " records " , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getOvertimeTypes









    public static String getPlannedAbsences(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/AbsenceCodes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/IndirectWorkCodes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/OvertimeTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/PlannedAbsences" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/TimeRecording/PlannedAbsences?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".plannedabsence  where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".plannedabsence (tenant_id , id , " +
                          " PersonId , " +
                          " PartOfDay , " +
                          " AbsenceFrom , " +
                          " AbsenceTo , " +
                          " AbsenceCodeId , " +
                          " Approved , " +
                          " AbsenceDuration , " +
                          " AttendanceDuration  " +

                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("PersonId") == null)                             ? 0 : rec_obj.get("PersonId")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PartOfDay") == "false")                         ? 0 : 1 )                                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AbsenceFrom") == null || rec_obj.get("AbsenceFrom").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("AbsenceFrom").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                          "\"" + ((rec_obj.get("AbsenceTo") == null || rec_obj.get("AbsenceTo").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("AbsenceTo").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                          "\"" + ((rec_obj.get("AbsenceCodeId") == null)                        ? 0 : rec_obj.get("AbsenceCodeId")  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Approved") == "false")                          ? 0 : 1 )                                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AbsenceDuration") == null)                      ? 0 : rec_obj.get("AbsenceDuration")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AttendanceDuration") == null)                   ? 0 : rec_obj.get("AttendanceDuration")  )                  + "\" "    + "  " +

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                         // break;
                         rs_count = rs_count + 1 ;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "PlannedAbsence was imported from Monitor API to MySql. " + rs_count + " records " , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getPlannedAbsences








    public static String getAttendanceChart(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/AbsenceCodes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/IndirectWorkCodes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/OvertimeTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/PlannedAbsences" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/AttendanceChart" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/TimeRecording/AttendanceChart?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);


                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".attendancechart  where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".attendancechart (tenant_id , id , " +
                          " RecordingDate , " +
                          " EmployeeId , " +
                          " EmployeeNumber , " +
                          " FirstName , " +
                          " LastName , " +
                          " InternalPhoneNumber , " +
                          " IsClosedInterval , " +
                          " IntervalStart , " +
                          " IntervalEnd , " +
                          " AbsenceCodeId , " +
                          " AbsenceCode , " +
                          " AbsenceDescription , " +
                          " IsBreak , " +
                          " ScheduleId , " +
                          " AbsenceKind , " +
                          " ScheduleType , " +
                          " IsNightSchedule , " +
                          " ScheduleNumber , " +
                          " DepartmentId , " +
                          " DepartmentCode  " +

                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("RecordingDate") == null || rec_obj.get("RecordingDate").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("RecordingDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                          "\"" + ((rec_obj.get("EmployeeId") == null)                      ? 0 : rec_obj.get("EmployeeId")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("EmployeeNumber") == null)                  ? 0 : rec_obj.get("EmployeeNumber")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("FirstName") == null)                       ? 0 : rec_obj.get("FirstName")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("LastName") == null)                        ? 0 : rec_obj.get("LastName")  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InternalPhoneNumber") == null)             ? 0 : rec_obj.get("InternalPhoneNumber")  )            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsClosedInterval") == "false")             ? 0 : 1 )                                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IntervalStart") == null || rec_obj.get("IntervalStart").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("IntervalStart").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                          "\"" + ((rec_obj.get("IntervalEnd") == null || rec_obj.get("IntervalEnd").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("IntervalEnd").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                          "\"" + ((rec_obj.get("AbsenceCodeId") == null)                   ? 0 : rec_obj.get("AbsenceCodeId")  )                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AbsenceCode") == null)                     ? 0 : rec_obj.get("AbsenceCode")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AbsenceDescription") == null)              ? 0 : rec_obj.get("AbsenceDescription")  )             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsBreak") == "false")                      ? 0 : 1 )                                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ScheduleId") == null)                      ? 0 : rec_obj.get("ScheduleId")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AbsenceKind") == null)                     ? 0 : rec_obj.get("AbsenceKind")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ScheduleType") == null)                    ? 0 : rec_obj.get("ScheduleType")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsNightSchedule") == "false")              ? 0 : 1 )                                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ScheduleNumber") == null)                  ? 0 : rec_obj.get("ScheduleNumber")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DepartmentId") == null)                    ? 0 : rec_obj.get("DepartmentId")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DepartmentCode") == null)                  ? 0 : rec_obj.get("DepartmentCode")  )                 + "\" "    + "  " +

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;

                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "AttendanceChart was imported from Monitor API to MySql. " + rs_count + " records ", true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getAttendanceChart







    public static String getAttendanceIntervals(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/AbsenceCodes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/IndirectWorkCodes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/OvertimeTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/PlannedAbsences" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/AttendanceChart" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/AttendanceIntervals" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/TimeRecording/AttendanceIntervals?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);


                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".attendanceinterval  where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".attendanceinterval (tenant_id , id , " +
                          " IntervalStart , " +
                          " IntervalEnd , " +
                          " IsClosedInterval , " +
                          " AbsenceCodeId , " +
                          " DeductedIfDailyHoursNotFulfilledOverride , " +
                          " OvertimeTypeBeforeId , " +
                          " OvertimeTypeAfterId , " +
                          " IsBreak , " +
                          " IsAutomaticOut , " +
                          " AbsenceKind , " +
                          " CalculatedTime , " +
                          " CalculatedOvertimeBefore , " +
                          " CalculatedOvertimeAfter   " +

                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("IntervalStart") == null || rec_obj.get("IntervalStart").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("IntervalStart").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                          "\"" + ((rec_obj.get("IntervalEnd") == null || rec_obj.get("IntervalEnd").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("IntervalEnd").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                          "\"" + ((rec_obj.get("IsClosedInterval") == "false")             ? 0 : 1 )                                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AbsenceCodeId") == null)                   ? 0 : rec_obj.get("AbsenceCodeId")  )                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DeductedIfDailyHoursNotFulfilledOverride") == "false")  ? 0 : 1 )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OvertimeTypeBeforeId") == null)            ? 0 : rec_obj.get("OvertimeTypeBeforeId")  )           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OvertimeTypeAfterId") == null)             ? 0 : rec_obj.get("OvertimeTypeAfterId")  )            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsBreak") == "false")                      ? 0 : 1 )                                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsAutomaticOut ") == "false")              ? 0 : 1 )                                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AbsenceKind") == null)                     ? 0 : rec_obj.get("AbsenceKind")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CalculatedTime") == null)                  ? 0 : rec_obj.get("CalculatedTime")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CalculatedOvertimeBefore") == null)        ? 0 : rec_obj.get("CalculatedOvertimeBefore")  )       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CalculatedOvertimeAfter") == null)         ? 0 : rec_obj.get("CalculatedOvertimeAfter")  )        + "\" "    + "  " +

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;

                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "AttendanceInterval was imported from Monitor API to MySql. " + rs_count + " records ", true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getAttendanceIntervals






    public static String getRecordingDays(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/AbsenceCodes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/IndirectWorkCodes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/OvertimeTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/PlannedAbsences" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/AttendanceChart" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/AttendanceIntervals" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/RecordingDays" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/TimeRecording/RecordingDays?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);


                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".recordingday  where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".recordingday (tenant_id , id , " +
                          " Version , " +
                          " PersonId , " +
                          " ScheduleId , " +
                          " ShorterWorkingHoursScheduleId , " +
                          " CalculatedSequenceNumber , " +
                          " CalculatedScheduleDiff , " +
                          " CalculatedFlex , " +
                          " CalculatedOvertime , " +
                          " CalculatedAbsence , " +
                          " CalculatedAttendance , " +
                          " CalculatedPaidBreak , " +
                          " Exported , " +
                          " Authorized , " +
                          " DayType , " +
                          " TimeZone , " +
                          " CommentText , " +
                          " SequenceCounter , " +
                          " RecordingDate , " +
                          " OvertimeCalculationType , " +
                          " OvertimeScheduleId , " +
                          " LockedOvertimeScheduleId   " +

                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Version") == null)                            ? 0 : rec_obj.get("Version")  )                             + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PersonId") == null)                           ? 0 : rec_obj.get("PersonId")  )                            + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ScheduleId") == null)                         ? 0 : rec_obj.get("ScheduleId")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ShorterWorkingHoursScheduleId") == null)      ? 0 : rec_obj.get("ShorterWorkingHoursScheduleId")  )       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CalculatedSequenceNumber") == null)           ? 0 : rec_obj.get("CalculatedSequenceNumber")  )            + "\" "    + ", " +
                           "\"" + ((rec_obj.get("CalculatedScheduleDiff") == null)             ? 0 : rec_obj.get("CalculatedScheduleDiff")  )              + "\" "    + ", " +
                           "\"" + ((rec_obj.get("CalculatedFlex") == null)                     ? 0 : rec_obj.get("CalculatedFlex")  )                      + "\" "    + ", " +
                           "\"" + ((rec_obj.get("CalculatedOvertime") == null)                 ? 0 : rec_obj.get("CalculatedOvertime")  )                  + "\" "    + ", " +
                           "\"" + ((rec_obj.get("CalculatedAbsence") == null)                  ? 0 : rec_obj.get("CalculatedAbsence")  )                   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("CalculatedAttendance") == null)               ? 0 : rec_obj.get("CalculatedAttendance")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CalculatedPaidBreak") == null)                ? 0 : rec_obj.get("CalculatedPaidBreak")  )                 + "\" "    + ", " +
                           "\"" + ((rec_obj.get("Exported") == "false")                        ? 0 : 1 )                                                   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("Authorized") == "false")                      ? 0 : 1 )                                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DayType") == null)                            ? 0 : rec_obj.get("DayType")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("TimeZone") == null)                           ? 0 : rec_obj.get("TimeZone")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CommentText") == null)                        ? 0 : rec_obj.get("CommentText")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SequenceCounter") == null)                    ? 0 : rec_obj.get("SequenceCounter")  )                     + "\" "    + ", " +
                           "\"" + ((rec_obj.get("RecordingDate") == null || rec_obj.get("RecordingDate").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("RecordingDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                          "\"" + ((rec_obj.get("OvertimeCalculationType") == null)            ? 0 : rec_obj.get("OvertimeCalculationType")  )             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OvertimeScheduleId") == null)                 ? 0 : rec_obj.get("OvertimeScheduleId")  )                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("LockedOvertimeScheduleId") == null)           ? 0 : rec_obj.get("LockedOvertimeScheduleId")  )            + "\" "    + "  " +

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;

                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "RecordingDay was imported from Monitor API to MySql. " + rs_count + " records ", true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getRecordingDays






    public static String getSalaryTypes(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/AbsenceCodes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/IndirectWorkCodes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/OvertimeTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/PlannedAbsences" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/AttendanceChart" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/AttendanceIntervals" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/RecordingDays" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/SalaryTypes" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/TimeRecording/SalaryTypes?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);


                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".salarytype  where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".salarytype (tenant_id , id , " +
                          " Code , " +
                          " DescriptionId , " +
                          " SalaryTypeClassId , " +
                          " SalaryTypeExportType , " +
                          " ExportAttendanceAbsenceType , " +
                          " ExportAlias , " +
                          " Description   " +

                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                           "\"" + ((rec_obj.get("Code") == null)                              ? 0 : rec_obj.get("Code")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                     ? 0 : rec_obj.get("DescriptionId")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SalaryTypeClassId") == null)                 ? 0 : rec_obj.get("SalaryTypeClassId")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SalaryTypeExportType") == null)              ? 0 : rec_obj.get("SalaryTypeExportType")  )             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ExportAttendanceAbsenceType") == null)       ? 0 : rec_obj.get("ExportAttendanceAbsenceType")  )      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ExportAlias") == null)                       ? 0 : rec_obj.get("ExportAlias")  )                      + "\" "    + ", " +
                           "\"" + ((rec_obj.get("Description") == null)                       ? 0 : rec_obj.get("Description")  )                      + "\" "    + "  " +

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;

                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "SalaryType was imported from Monitor API to MySql. " + rs_count + " records ", true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getSalaryTypes




    public static String getShedules(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/AbsenceCodes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/IndirectWorkCodes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/OvertimeTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/PlannedAbsences" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/AttendanceChart" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/AttendanceIntervals" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/RecordingDays" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/SalaryTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/Shedules" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/TimeRecording/Shedules?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);


                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".shedule  where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".shedule (tenant_id , id , " +
                          " Code , " +
                          " Description   " +

                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                           "\"" + ((rec_obj.get("Code") == null)                              ? 0 : rec_obj.get("Code")  )                             + "\" "    + ", " +
                           "\"" + ((rec_obj.get("Description") == null)                       ? 0 : rec_obj.get("Description")  )                      + "\" "    + "  " +

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;

                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Shedule was imported from Monitor API to MySql. " + rs_count + " records ", true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getShedules





    public static String getStandbyWorks(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/AbsenceCodes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/IndirectWorkCodes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/OvertimeTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/PlannedAbsences" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/AttendanceChart" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/AttendanceIntervals" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/RecordingDays" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/SalaryTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/Shedules" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/StandbyWorks" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/TimeRecording/StandbyWorks?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);


                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".standbywork  where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".standbywork (tenant_id , id , " +
                          " EmployeeId , " +
                          " BundleId , " +
                          " WorkRecordingType , " +
                          " IndirectWorkCodeId , " +
                          " IndirectWorkCode , " +
                          " OperationId , " +
                          " Operation , " +
                          " ActivityId   " +

                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("EmployeeId") == null)              ? 0 : rec_obj.get("EmployeeId")  )           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BundleId") == null)                ? 0 : rec_obj.get("BundleId")  )             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("WorkRecordingType") == null)       ? 0 : rec_obj.get("WorkRecordingType")  )    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IndirectWorkCodeId") == null)      ? 0 : rec_obj.get("IndirectWorkCodeId")  )   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IndirectWorkCode") == null)        ? 0 : rec_obj.get("IndirectWorkCode")  )     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OperationId") == null)             ? 0 : rec_obj.get("OperationId")  )          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Operation") == null)               ? 0 : rec_obj.get("Operation")  )            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ActivityId") == null)              ? 0 : rec_obj.get("ActivityId")  )           + "\" "    + "  " +

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;

                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "StandbyWork was imported from Monitor API to MySql. " + rs_count + " records ", true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getStandbyWorks





    public static String getTimeBanks(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/AbsenceCodes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/IndirectWorkCodes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/OvertimeTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/PlannedAbsences" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/AttendanceChart" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/AttendanceIntervals" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/RecordingDays" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/SalaryTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/Shedules" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/StandbyWorks" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/TimeBanks" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/TimeRecording/TimeBanks?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);


                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".timebank  where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".timebank (tenant_id , id , " +
                          " DescriptionId , " +
                          " IsActive , " +
                          " RowNumber , " +
                          " Description , " +
                          " Code   " +

                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)              ? 0 : rec_obj.get("DescriptionId")  )           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsActive") == "false")                ? 0 : 1 )                                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RowNumber") == null)                  ? 0 : rec_obj.get("RowNumber")  )               + "\" "    + ", " +
                           "\"" + ((rec_obj.get("Description") == null)                ? 0 : rec_obj.get("Description")  )             + "\" "    + ", " +
                           "\"" + ((rec_obj.get("Code") == null)                       ? 0 : rec_obj.get("Code")  )                    + "\" "    + "  " +

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;

                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "TimeBank was imported from Monitor API to MySql. " + rs_count + " records ", true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getTimeBanks




    public static String getWorkIntervals(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/AbsenceCodes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/IndirectWorkCodes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/OvertimeTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/PlannedAbsences" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/AttendanceChart" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/AttendanceIntervals" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/RecordingDays" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/SalaryTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/Shedules" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/StandbyWorks" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/TimeBanks" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/TimeRecording/WorkIntervals" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/TimeRecording/WorkIntervals?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);


                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".workinterval  where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".workinterval (tenant_id , id , " +
                          " IntervalStart , " +
                          " IntervalEnd , " +
                          " IsClosedInterval , " +
                          " BundleId , " +
                          " WorkRecordingType , " +
                          " IndirectWorkCodeId , " +
                          " OperationId , " +
                          " TimeCalculationType , " +
                          " ReportingEmployeeId , " +
                          " WorkCenterId , " +
                          " WorkedTime , " +
                          " OfWichOvertime , " +
                          " ReportedQuantity , " +
                          " RejectedQuantity   " +

                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("IntervalStart") == null || rec_obj.get("IntervalStart").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("IntervalStart").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                          "\"" + ((rec_obj.get("IntervalEnd") == null || rec_obj.get("IntervalEnd").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("IntervalEnd").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                          "\"" + ((rec_obj.get("IsClosedInterval") == "false")                ? 0 : 1 )                                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BundleId") == null)                           ? 0 : rec_obj.get("BundleId")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("WorkRecordingType") == null)                  ? 0 : rec_obj.get("WorkRecordingType")  )       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IndirectWorkCodeId") == null)                 ? 0 : rec_obj.get("IndirectWorkCodeId")  )      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OperationId") == null)                        ? 0 : rec_obj.get("OperationId")  )             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("TimeCalculationType") == null)                ? 0 : rec_obj.get("TimeCalculationType")  )     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReportingEmployeeId") == null)                ? 0 : rec_obj.get("ReportingEmployeeId")  )     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("WorkCenterId") == null)                       ? 0 : rec_obj.get("WorkCenterId")  )            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("WorkedTime") == null)                         ? 0 : rec_obj.get("WorkedTime")  )              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OfWichOvertime") == null)                     ? 0 : rec_obj.get("OfWichOvertime")  )          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReportedQuantity") == null)                   ? 0 : rec_obj.get("ReportedQuantity")  )        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RejectedQuantity") == null)                   ? 0 : rec_obj.get("RejectedQuantity")  )        + "\" "    + "  " +

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;

                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "WorkInterval was imported from Monitor API to MySql. " + rs_count + " records ", true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getWorkIntervals








}  // Queries_TIM
