package sy_my ;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

public class ReadConf {
    // konfi-failist baasi�henduse ja failide asukoha parameetrite lugemine

    private String url_sy;

    private String host_sy;
    private String port_sy;
    private String languageCode_sy;
    private String companyNumber_sy;
    private String ForceRelogin_sy;
    private String sessionId_sy;
    private String recordsLimit_sy;


    private String dbName_sy;
    private String driver_sy;
    private String username_sy;
    private String password_sy;

    private String fromDir;
    private String toDir;
    private String logFile;
    private String confFile;
    private String jsonPath;

    private String url_my;
    private String dbName_my;
    private String driver_my;
    private String username_my;
    private String password_my;
    private String tenant_id_my ;

    private String url_myra;
    private String dbName_myra;
    private String driver_myra;
    private String username_myra;
    private String password_myra;

    private String url_myhe;
    private String dbName_myhe;
    private String driver_myhe;
    private String username_myhe;
    private String password_myhe;

    public ReadConf(String cfile) {
        confFile = cfile;
        try {
            Properties p  = new Properties();
            File conffile = new File(cfile);
            p.load(new FileInputStream(conffile));

            url_sy            = p.getProperty("URL_SY");
            host_sy           = p.getProperty("HOST_SY");
            port_sy           = p.getProperty("PORT_SY");
            languageCode_sy   = p.getProperty("LANGUAGECODE_SY");
            companyNumber_sy  = p.getProperty("COMPANYNUMBER_SY");
            ForceRelogin_sy   = p.getProperty("FORCERELOGIN_SY");
            sessionId_sy      = p.getProperty("SESSIONID_SY");
            recordsLimit_sy   = p.getProperty("RECORDS_LIMIT_SY");


            dbName_sy    = p.getProperty("DBNAME_SY");
            driver_sy    = p.getProperty("DRIVER_SY");
            username_sy  = p.getProperty("USERNAME_SY");
            password_sy  = p.getProperty("PASSWORD_SY");
            fromDir      = p.getProperty("FROMDIR");
            toDir        = p.getProperty("TODIR");
            logFile      = p.getProperty("LOGFILE");
            jsonPath     = p.getProperty("JSON_PATH");

            url_my       = p.getProperty("URL_MY");
            dbName_my    = p.getProperty("DBNAME_MY");
            driver_my    = p.getProperty("DRIVER_MY");
            username_my  = p.getProperty("USERNAME_MY");
            password_my  = p.getProperty("PASSWORD_MY");
            tenant_id_my = p.getProperty("TENANT_ID_MY");

            url_myra       = p.getProperty("URL_MYRA");
            dbName_myra    = p.getProperty("DBNAME_MYRA");
            driver_myra    = p.getProperty("DRIVER_MYRA");
            username_myra  = p.getProperty("USERNAME_MYRA");
            password_myra  = p.getProperty("PASSWORD_MYRA");

            url_myhe       = p.getProperty("URL_MYHE");
            dbName_myhe    = p.getProperty("DBNAME_MYHE");
            driver_myhe    = p.getProperty("DRIVER_MYHE");
            username_myhe  = p.getProperty("USERNAME_MYHE");
            password_myhe  = p.getProperty("PASSWORD_MYHE");

            // p.list(System.out);

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public String getUrl_sy() {
        return url_sy;
    }

    public String getHost_sy() {
        return host_sy;
    }

    public String getPort_sy() {
        return port_sy;
    }

    public String getLanguageCode_sy() {
        return languageCode_sy ;
    }

    public String getCompanyNumber_sy() {
        return companyNumber_sy ;
    }

    public String getForceRelogin_sy() {
        return ForceRelogin_sy ;
    }

    public String getSessionId_sy() {
        return sessionId_sy ;
    }

    public String getRecordsLimit_sy() {
        return recordsLimit_sy ;
    }

    public String getDbName_sy() {
        return dbName_sy;
    }

    public String getDriver_sy() {
        return driver_sy;
    }

    public String getUsername_sy() {
        return username_sy;
    }

    public String getPassword_sy() {
        return password_sy;
    }

    public String getFromDir() {
        return fromDir;
    }

    public String getToDir() {
        return toDir;
    }

    public String getLogFile() {
        return logFile;
    }

    public String getJsonPath() {
        return jsonPath;
    }




    // ----------------------------------

    public String getUrl_my() {
        return url_my;
    }

    public String getDbName_my() {
        return dbName_my;
    }

    public String getDriver_my() {
        return driver_my;
    }

    public String getUsername_my() {
        return username_my;
    }

    public String getPassword_my() {
        return password_my;
    }

    public String getTenant_id_my() {
        return tenant_id_my ;
    }


    // ----------------------------------
    public String getUrl_myra() {
        return url_myra;
    }

    public String getDbName_myra() {
        return dbName_myra;
    }

    public String getDriver_myra() {
        return driver_myra;
    }

    public String getUsername_myra() {
        return username_myra;
    }

    public String getPassword_myra() {
        return password_myra;
    }

    // ----------------------------------
    public String getUrl_myhe() {
        return url_myhe;
    }

    public String getDbName_myhe() {
        return dbName_myhe;
    }

    public String getDriver_myhe() {
        return driver_myhe;
    }

    public String getUsername_myhe() {
        return username_myhe;
    }

    public String getPassword_myhe() {
        return password_myhe;
    }

    // ----------------------------------



    public String toString() {
        // see on v�ljastamise jaoks tehtud �lekate, v�imaldab tr�kkida terve klassi muutujaid korraga System.out.println k�suga
        String nl = System.getProperty("line.separator");
        return "Konfiguratsiooni fail " + confFile        + nl +
               "url_sy = "           + url_sy             + nl +
               "host_sy = "          + host_sy            + nl +
               "port_sy = "          + port_sy            + nl +
               "languageCode_sy = "  + languageCode_sy    + nl +
               "companyNumber_sy = " + companyNumber_sy   + nl +
               "ForceRelogin_sy = "  + ForceRelogin_sy    + nl +
               "sessionId_sy = "     + sessionId_sy       + nl +
               "recordsLimit_sy = "  + recordsLimit_sy    + nl +
               "dbName_sy = "        + dbName_sy      + nl +
               "driver_sy = "        + driver_sy      + nl +
               "username_sy = "      + username_sy    + nl +
               "password_sy = "      + "***"          + nl +
               "fromDir = "          + fromDir        + nl +
               "toDir = "            + toDir          + nl +
               "logFile = "          + logFile        + nl +
               "jsonPath = "         + jsonPath       + nl +

               "url_my = "           + url_my         + nl +
               "dbName_my = "        + dbName_my      + nl +
               "driver_my = "        + driver_my      + nl +
               "username_my = "      + username_my    + nl +
               "password_my = "      + "***"          + nl +
               "tenant_id_my = "     + tenant_id_my   + nl +

               "url_myra = "         + url_myra       + nl +
               "dbName_myra = "      + dbName_myra    + nl +
               "driver_myra = "      + driver_myra    + nl +
               "username_myra = "    + username_myra  + nl +
               "password_myra = "    + "***"          + nl +

               "url_myhe = "         + url_myhe       + nl +
               "dbName_myhe = "      + dbName_myhe    + nl +
               "driver_myhe = "      + driver_myhe    + nl +
               "username_myhe = "    + username_myhe  + nl +
               "password_myhe = "    + "***"
        ;

    }

}
