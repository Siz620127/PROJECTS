package sy_my ;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Scanner;
import org.json.simple.JSONObject;
import org.json.simple.JSONArray;
import org.json.simple.JSONValue;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

// import java.time.*;

// -------

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import java.sql.* ;

// import java.sql.Connection;
// import java.sql.Date;
// import java.sql.DriverManager;
// import java.sql.PreparedStatement;
// import java.sql.SQLException;

import java.text.SimpleDateFormat;


public class Queries_PUR {



    // TEST START
    public static HttpURLConnection TestQuery(ReadConf conf) throws Exception {
        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals("185.158.177.241");

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end


             // URL url             = new URL( conf.getUrl_sy() );
             URL url                = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", "185.158.177.241"  );
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", "f1bc5219-b382-472e-adc9-ff0926ecbbb0" );



     	     String json = "{\n";
     		 json += "\"Username\": "     +  "\"ADMIN\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"\" "       + ",\n";
		     json += "\"ForceRelogin\": " +  true          + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( response );

   			     return con ;  // response


                 /*
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parse    = new JSONParser();
                 JSONObject data_obj = (JSONObject) parse.parse( json );  // inline
                 //Get the required object from the above created object
                 JSONObject obj = (JSONObject) data_obj.get("Globale");
                 //Get the required data using its key
                 System.out.println(obj.get("TotalRecovered"));
                 JSONArray arr = (JSONArray) data_obj.get("Countries");
                 for (int i = 0; i < arr.size(); i++) {
                      JSONObject new_obj = (JSONObject) arr.get(i);
                      if (new_obj.get("Slug").equals("albania")) {
                         System.out.println("Total Recovered: " + new_obj.get("TotalRecovered"));
                         break;
                      }
                 }
               */

                }


        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() );
        }
        // return con;
    }

    // TEST END





    public static String getInquiries(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Purchase/Inquiries?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".inquiry  where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".inquiry (tenant_id , id , " +
                          " Version , " +
                          " Status , " +
                          " ShowPriceInDocument , " +
                          " ShowTotalInDocument , " +
                          " InquiryDescription , " +
                          " InquiryDate , " +
                          " ValidThroughDate , " +
                          " ResponseTimeId , " +
                          " ResponseTimeDescription , " +
                          " ResponseTimeInDays , " +
                          " ResponseDate , " +
                          " DeliveryTimeId , " +
                          " DeliveryTimeDescription , " +
                          " DeliveryTimeInDays , " +
                          " LatestContactDate , " +
                          " GoodsAddressNumber , " +
                          " RelatedInquiriesId , " +
                          " ActiveDeliveryAddressCustomerId , " +
                          " ActiveDeliveryAddressSupplierId , " +
                          " ActiveDeliveryAddressCompanyId , " +
                          " SourceOfAlternativeDeliveryAddresses , " +
                          " BusinessContactId , " +
                          " OrderTypeId , " +
                          " AccountGroupId , " +
                          " CategoryString , " +
                          " BusinessContactReferenceId , " +
                          " DeliveryAddressId , " +
                          " OrderNumber , " +
                          " OrderDate , " +
                          " BusinessContactOrderNumber , " +
                          " OurReferenceId , " +
                          " OurReferenceName , " +
                          " BusinessContactReferenceName , " +
                          " GoodsLabel , " +
                          " CurrencyId , " +
                          " VatGroupId , " +
                          " WarehouseId , " +
                          " Priority , " +
                          " ProjectId , " +
                          " MailingAddressId , " +
                          " SendMethod , " +
                          " InvoicePrintoutMethod , " +
                          " InternalCommentId , " +
                          " ExternalCommentId , " +
                          " TransportTime , " +
                          " LifeCycleState , " +
                          " UseForwardRate , " +
                          " ExchangeRate , " +
                          " PaymentTermId , " +
                          " PaymentTermDescription , " +
                          " GracePeriodInDays , " +
                          " DeliveryMethodId , " +
                          " DeliveryTermId , " +
                          " DeliveryTermDescription , " +
                          " DeliveryMethodDescription , " +
                          " ShipmentPayer , " +
                          " MalaysianTaxExemptionId , " +
                          " ActiveDeliveryAddressDeliveryAddressId   " +

                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Version") == null)                                         ? 0 : rec_obj.get("Version")  )                                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Status") == null)                                          ? 0 : rec_obj.get("Status")  )                                                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ShowPriceInDocument") == "false")                          ? 0 : 1 )                                                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ShowTotalInDocument") == "false")                          ? 0 : 1 )                                                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InquiryDescription") == null)                              ? 0 : rec_obj.get("InquiryDescription")  )                                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InquiryDate") == null || rec_obj.get("InquiryDate").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("InquiryDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                          "\"" + ((rec_obj.get("ValidThroughDate") == null || rec_obj.get("ValidThroughDate").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("ValidThroughDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                          "\"" + ((rec_obj.get("ResponseTimeId") == null)                                  ? 0 : rec_obj.get("ResponseTimeId")  )                                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ResponseTimeDescription") == null)                         ? 0 : rec_obj.get("ResponseTimeDescription")  )                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ResponseTimeInDays") == null)                              ? 0 : rec_obj.get("ResponseTimeInDays")  )                                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ResponseDate") == null || rec_obj.get("ResponseDate").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("ResponseDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                          "\"" + ((rec_obj.get("DeliveryTimeId") == null)                                  ? 0 : rec_obj.get("DeliveryTimeId")  )                                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DeliveryTimeDescription") == null)                         ? 0 : rec_obj.get("DeliveryTimeDescription")  )                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DeliveryTimeInDays") == null)                              ? 0 : rec_obj.get("DeliveryTimeInDays")  )                                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("LatestContactDate") == null || rec_obj.get("LatestContactDate").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("LatestContactDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                          "\"" + ((rec_obj.get("GoodsAddressNumber") == null)                              ? 0 : rec_obj.get("GoodsAddressNumber")  )                                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RelatedInquiriesId") == null)                              ? 0 : rec_obj.get("RelatedInquiriesId")  )                                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ActiveDeliveryAddressCustomerId") == null)                 ? 0 : rec_obj.get("ActiveDeliveryAddressCustomerId")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ActiveDeliveryAddressSupplierId") == null)                 ? 0 : rec_obj.get("ActiveDeliveryAddressSupplierId")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ActiveDeliveryAddressCompanyId") == null)                  ? 0 : rec_obj.get("ActiveDeliveryAddressCompanyId")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SourceOfAlternativeDeliveryAddresses") == null)            ? 0 : rec_obj.get("SourceOfAlternativeDeliveryAddresses")  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BusinessContactId") == null)                               ? 0 : rec_obj.get("BusinessContactId")  )                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OrderTypeId") == null)                                     ? 0 : rec_obj.get("OrderTypeId")  )                                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AccountGroupId") == null)                                  ? 0 : rec_obj.get("AccountGroupId")  )                                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CategoryString") == null)                                  ? 0 : rec_obj.get("CategoryString")  )                                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BusinessContactReferenceId") == null)                      ? 0 : rec_obj.get("BusinessContactReferenceId")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DeliveryAddressId") == null)                               ? 0 : rec_obj.get("DeliveryAddressId")  )                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OrderNumber") == null)                                     ? 0 : rec_obj.get("OrderNumber")  )                                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OrderDate") == null || rec_obj.get("OrderDate").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("OrderDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                          "\"" + ((rec_obj.get("BusinessContactOrderNumber") == null)                      ? 0 : rec_obj.get("BusinessContactOrderNumber")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OurReferenceId") == null)                                  ? 0 : rec_obj.get("OurReferenceId")  )                                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OurReferenceName") == null)                                ? 0 : rec_obj.get("OurReferenceName")  )                                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BusinessContactReferenceName") == null)                    ? 0 : rec_obj.get("BusinessContactReferenceName")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("GoodsLabel") == null)                                      ? 0 : rec_obj.get("GoodsLabel")  )                                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CurrencyId") == null)                                      ? 0 : rec_obj.get("CurrencyId")  )                                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("VatGroupId") == null)                                      ? 0 : rec_obj.get("VatGroupId")  )                                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("WarehouseId") == null)                                     ? 0 : rec_obj.get("WarehouseId")  )                                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Priority") == null)                                        ? 0 : rec_obj.get("Priority")  )                                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ProjectId") == null)                                       ? 0 : rec_obj.get("ProjectId")  )                                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("MailingAddressId") == null)                                ? 0 : rec_obj.get("MailingAddressId")  )                                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SendMethod") == null)                                      ? 0 : rec_obj.get("SendMethod")  )                                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InvoicePrintoutMethod") == null)                           ? 0 : rec_obj.get("InvoicePrintoutMethod")  )                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InternalCommentId") == null)                               ? 0 : rec_obj.get("InternalCommentId")  )                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ExternalCommentId") == null)                               ? 0 : rec_obj.get("ExternalCommentId")  )                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("TransportTime") == null)                                   ? 0 : rec_obj.get("TransportTime")  )                                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("LifeCycleState") == null)                                  ? 0 : rec_obj.get("LifeCycleState")  )                                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("UseForwardRate") == "false")                               ? 0 : 1 )                                                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ExchangeRate") == null)                                    ? 0 : rec_obj.get("ExchangeRate")  )                                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PaymentTermId") == null)                                   ? 0 : rec_obj.get("PaymentTermId")  )                                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PaymentTermDescription") == null)                          ? 0 : rec_obj.get("PaymentTermDescription")  )                                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("GracePeriodInDays") == null)                               ? 0 : rec_obj.get("GracePeriodInDays")  )                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DeliveryMethodId") == null)                                ? 0 : rec_obj.get("DeliveryMethodId")  )                                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DeliveryTermId") == null)                                  ? 0 : rec_obj.get("DeliveryTermId")  )                                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DeliveryTermDescription") == null)                         ? 0 : rec_obj.get("DeliveryTermDescription")  )                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DeliveryMethodDescription") == null)                       ? 0 : rec_obj.get("DeliveryMethodDescription")  )                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ShipmentPayer") == null)                                   ? 0 : rec_obj.get("ShipmentPayer")  )                                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("MalaysianTaxExemptionId") == null)                         ? 0 : rec_obj.get("MalaysianTaxExemptionId")  )                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ActiveDeliveryAddressDeliveryAddressId") == null)          ? 0 : rec_obj.get("ActiveDeliveryAddressDeliveryAddressId")  )                     + "\" "    + "  " +

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Inquiry was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getInquiries





    public static String getInquiryRows(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Purchase/InquiryRows?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".inquiryrow  where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".inquiryrow (tenant_id , id , " +
                          " ShowFreeTextIn  , " +
                         
                          " CreatePurchaseOrder , " +
                          " PurchaseOrderId , " +
                          " ExemptFromStatistics , " +
                     
                          " SupplierPartNumber , " +
                          " SubPartParentRowId , " +
                          " QuantityRatio , " +
                          " ParentOrderId , " +
                          " Position , " +
                          " OrderRowType , " +
                        
                          " PartId , " +
                          " EntityIdentityString , " +
                          " AdditionalRowDescription , " +
                          " FreeTextHtml , " +
                          " FreeText , " +
                      
                          " RowIndex , " +
                          " ParentRowId , " +
                          " SumRowId , " +
                          " DeliveryDate , " +
                          " RevisionId , " +
                          " OrderedQuantity , " +
                          " Price , " +
                          " PriceCurrencyId , " +
                          " PriceOrigin , " +
                          " PriceOriginPriceListId , " +
                          " PriceLockedFromAutomaticChanges , " +
                          " PriceIsFuturePrice ,  " +
                      
                          " DiscountIsLockedFromAutomaticChanges , " +
                      
                          " Discount , " +
                          " ToolId , " +
                          " UnitId , " +
                          " VatRateId , " +
                          " WarehouseId , " +
                      
                          " WeightPerUnit , " +
                      
                          " OrderDate , " +
                                            
                          " ConversionFactor , " +
                          " SetupPrice , " +
                          " SetupPriceCurrencyId , " +
                      
                          " StatisticalGoodsCodeId , " +
                          " IntrastatTransactionTypeId , " +
                          " TariffAndServiceCodeId , " +
                          " PriceInCompanyCurrency , " +
                          " PriceInCompanyCurrencyCurrencyId , " +
                          " SetupPriceInCompanyCurrency , " +
                          " SetupPriceInCompanyCurrencyCurrencyId , " +
                          " StandardPrice , " +
                          " StandardPriceCurrencyId , " +
                        
                          " CodingId , " +
                          " ShowPrice , " +
                          " PartRowType , " +
                          " LifeCycleState , " +
                          " PartStatus , " +
                          " PartConfigurationId , " +
                          " RowsGoodsLabel , " +
                          " TextRowCreationContext   " +
                          
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("ShowFreeTextIn") == null)                            ? 0 : rec_obj.get("ShowFreeTextIn")  )                            + "\" "    + ", " +

                          "\"" + ((rec_obj.get("CreatePurchaseOrder") == "false")                    ? 0 : 1 )                                                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PurchaseOrderId") == null)                           ? 0 : rec_obj.get("PurchaseOrderId")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ExemptFromStatistics") == "false")                   ? 0 : 1 )                                                         + "\" "    + ", " +

                          "\"" + ((rec_obj.get("SupplierPartNumber") == null)                        ? 0 : rec_obj.get("SupplierPartNumber")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SubPartParentRowId") == null)                        ? 0 : rec_obj.get("SubPartParentRowId")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("QuantityRatio") == null)                             ? 0 : rec_obj.get("QuantityRatio")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ParentOrderId") == null)                             ? 0 : rec_obj.get("ParentOrderId")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Position") == null)                                  ? 0 : rec_obj.get("Position")  )                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OrderRowType") == null)                              ? 0 : rec_obj.get("OrderRowType")  )                              + "\" "    + ", " +

                          "\"" + ((rec_obj.get("PartId") == null)                                    ? 0 : rec_obj.get("PartId")  )                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("EntityIdentityString") == null)                      ? 0 : rec_obj.get("EntityIdentityString")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AdditionalRowDescription") == null)                  ? 0 : rec_obj.get("AdditionalRowDescription")  )                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("FreeTextHtml") == null)                     ? 0 : rec_obj.get("FreeTextHtml").toString().replaceAll("\"", " ").replaceAll("\\p{Cc}", " ").replaceAll("\\s{2,}", " ")  )   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("FreeText") == null)                         ? 0 : rec_obj.get("FreeText").toString().replaceAll("\"", " ").replaceAll("\\p{Cc}", " ").replaceAll("\\s{2,}", " ")  )   + "\" "    + ",  " +
                       
                          "\"" + ((rec_obj.get("RowIndex") == null)                                  ? 0 : rec_obj.get("RowIndex")  )                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ParentRowId") == null)                               ? 0 : rec_obj.get("ParentRowId")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SumRowId") == null)                                  ? 0 : rec_obj.get("SumRowId")  )                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DeliveryDate") == null      || rec_obj.get("DeliveryDate").toString().substring(0,2).equals("00")  )      ? new Date(2021000000) : rec_obj.get("DeliveryDate").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("RevisionId") == null)                                ? 0 : rec_obj.get("RevisionId")  )                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OrderedQuantity") == null)                           ? 0 : rec_obj.get("OrderedQuantity")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Price") == null)                                     ? 0 : rec_obj.get("Price")  )                                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PriceCurrencyId") == null)                           ? 0 : rec_obj.get("PriceCurrencyId")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PriceOrigin") == null)                               ? 0 : rec_obj.get("PriceOrigin")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PriceOriginPriceListId") == null)                    ? 0 : rec_obj.get("PriceOriginPriceListId")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PriceLockedFromAutomaticChanges") == "false")        ? 0 : 1 )                                                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PriceIsFuturePrice") == "false")                     ? 0 : 1 )                                                         + "\" "    + ", " +
                    
                          "\"" + ((rec_obj.get("DiscountIsLockedFromAutomaticChanges") == "false")   ? 0 : 1 )                                                         + "\" "    + ", " +
                      
                          "\"" + ((rec_obj.get("Discount") == null)                                  ? 0 : rec_obj.get("Discount")  )                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ToolId") == null)                                    ? 0 : rec_obj.get("ToolId")  )                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("UnitId") == null)                                    ? 0 : rec_obj.get("UnitId")  )                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("VatRateId") == null)                                 ? 0 : rec_obj.get("VatRateId")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("WarehouseId") == null)                               ? 0 : rec_obj.get("WarehouseId")  )                               + "\" "    + ", " +
                       
                          "\"" + ((rec_obj.get("WeightPerUnit") == null)                             ? 0 : rec_obj.get("WeightPerUnit")  )                             + "\" "    + ", " +
                      
                          "\"" + ((rec_obj.get("OrderDate") == null      || rec_obj.get("OrderDate").toString().substring(0,2).equals("00")  )      ? new Date(2021000000) : rec_obj.get("OrderDate").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                                            
                          "\"" + ((rec_obj.get("ConversionFactor") == null)                          ? 0 : rec_obj.get("ConversionFactor")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SetupPrice") == null)                                ? 0 : rec_obj.get("SetupPrice")  )                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SetupPriceCurrencyId") == null)                      ? 0 : rec_obj.get("SetupPriceCurrencyId")  )                      + "\" "    + ", " +
                      
                          "\"" + ((rec_obj.get("StatisticalGoodsCodeId") == null)                    ? 0 : rec_obj.get("StatisticalGoodsCodeId")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IntrastatTransactionTypeId") == null)                ? 0 : rec_obj.get("IntrastatTransactionTypeId")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("TariffAndServiceCodeId") == null)                    ? 0 : rec_obj.get("TariffAndServiceCodeId")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PriceInCompanyCurrency") == null)                    ? 0 : rec_obj.get("PriceInCompanyCurrency")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PriceInCompanyCurrencyCurrencyId") == null)          ? 0 : rec_obj.get("PriceInCompanyCurrencyCurrencyId")  )          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SetupPriceInCompanyCurrency") == null)               ? 0 : rec_obj.get("SetupPriceInCompanyCurrency")  )               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SetupPriceInCompanyCurrencyCurrencyId") == null)     ? 0 : rec_obj.get("SetupPriceInCompanyCurrencyCurrencyId")  )     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("StandardPrice") == null)                             ? 0 : rec_obj.get("StandardPrice")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("StandardPriceCurrencyId") == null)                   ? 0 : rec_obj.get("StandardPriceCurrencyId")  )                   + "\" "    + ", " +
                       
                          "\"" + ((rec_obj.get("CodingId") == null)                                  ? 0 : rec_obj.get("CodingId")  )                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ShowPrice") == "false")                              ? 0 : 1 )                                                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PartRowType") == null)                               ? 0 : rec_obj.get("PartRowType")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("LifeCycleState") == null)                            ? 0 : rec_obj.get("LifeCycleState")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PartStatus") == null)                                ? 0 : rec_obj.get("PartStatus")  )                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PartConfigurationId") == null)                       ? 0 : rec_obj.get("PartConfigurationId")  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RowsGoodsLabel") == null)                            ? 0 : rec_obj.get("RowsGoodsLabel")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("TextRowCreationContext") == null)                    ? 0 : rec_obj.get("TextRowCreationContext")  )                    + "\" "    + "  " +
                                             
                          " )";



                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "InquiryRow was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getInquiryRows




    public static String getInquiryTypes(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Purchase/InquiryTypes?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".inquirytype  where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".inquirytype (tenant_id , id , " +
                          " BaseType , " +
                          " CodingGroupId , " +
                          " Number , " +
                          " Prefix , " +
                          " DescriptionId , " +
                          " Priority , " +
                          " Visible , " +
                          " IsPreset , " +
                          " InquiryActivityTemplateId , " +
                          " Description   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("BaseType") == null)                              ? 0 : rec_obj.get("BaseType")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CodingGroupId") == null)                         ? 0 : rec_obj.get("CodingGroupId")  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Number") == null)                                ? 0 : rec_obj.get("Number")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Prefix") == null)                                ? 0 : rec_obj.get("Prefix")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                         ? 0 : rec_obj.get("DescriptionId")  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Priority") == null)                              ? 0 : rec_obj.get("Priority")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Visible") == "false")                            ? 0 : 1 )                                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsPreset") == "false")                           ? 0 : 1 )                                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InquiryActivityTemplateId") == null)             ? 0 : rec_obj.get("InquiryActivityTemplateId")  )           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                           ? 0 : rec_obj.get("Description")  )                         + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "InquiryType was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getInquiryTypes






    public static String getOtherSupplierNumbers(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Purchase/OtherSupplierNumbers?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".othersuppliernumber  where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".othersuppliernumber (tenant_id , id , " +
                          " IsDefault , " +
                          " Number , " +
                          " SupplierId  " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("IsDefault") == "false")                          ? 0 : 1 )                                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Number") == null)                                ? 0 : rec_obj.get("Number")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SupplierId") == null)                            ? 0 : rec_obj.get("SupplierId")  )                         + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "OtherSupplierNumber was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getOtherSupplierNumbers





    public static String getPackingTerms(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Purchase/PackingTerms?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".packingterm  where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".packingterm (tenant_id , id , " +
                          " DescriptionId , " +
                          " Number , " +
                          " IsDefault , " +
                          " Description   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                         ? 0 : rec_obj.get("DescriptionId")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Number") == null)                                ? 0 : rec_obj.get("Number")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsDefault") == "false")                          ? 0 : 1 )                                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                           ? 0 : rec_obj.get("Description")  )                        + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "PackingTerm was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getPackingTerms













    public static String getPurchaseOrderDeliveries(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/PurchaseOrderDeliveries" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Purchase/PurchaseOrderDeliveries?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".purchaseorderdelivery  where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".purchaseorderdelivery (tenant_id , id , " +
                          " PurchaseOrderId , " +
                          " ConfirmationDate , " +
                          " AdviceDate , " +
                          " DeliveryNoteNumber , " +
                          " WaybillNumber , " +
                          " AdvicedByApplicationUserId , " +
                          " SendDate , " +
                          " ShippingAgentSupplierId , " +
                          " LoggingTimeStamp , " +
                          " DeliveredByApplicationUserId , " +
                          " DeliveredByPersonId , " +
                          " IsConverted , " +
                          " ArrivalNoteNumber , " +
                          " PurchaseOrderAdviceId   " +

                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                           "\"" + ((rec_obj.get("PurchaseOrderId") == null)                                    ? 0 : rec_obj.get("PurchaseOrderId")  )                                            + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ConfirmationDate") == null || rec_obj.get("ConfirmationDate").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("ConfirmationDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                           "\"" + ((rec_obj.get("AdviceDate") == null || rec_obj.get("AdviceDate").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("AdviceDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                           "\"" + ((rec_obj.get("DeliveryNoteNumber") == null)                                 ? 0 : rec_obj.get("DeliveryNoteNumber")  )                                         + "\" "    + ", " +
                           "\"" + ((rec_obj.get("WaybillNumber") == null)                                      ? 0 : rec_obj.get("WaybillNumber")  )                                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AdvicedByApplicationUserId") == null)                         ? 0 : rec_obj.get("AdvicedByApplicationUserId")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SendDate") == null || rec_obj.get("SendDate").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("SendDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                          "\"" + ((rec_obj.get("ShippingAgentSupplierId") == null)                            ? 0 : rec_obj.get("ShippingAgentSupplierId")  )                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("LoggingTimeStamp") == null || rec_obj.get("LoggingTimeStamp").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("LoggingTimeStamp").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                          "\"" + ((rec_obj.get("DeliveredByApplicationUserId") == null)                       ? 0 : rec_obj.get("DeliveredByApplicationUserId")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DeliveredByPersonId") == null)                                ? 0 : rec_obj.get("DeliveredByPersonId")  )                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsConverted") == "false")                                     ? 0 : 1 )                                                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ArrivalNoteNumber") == null)                                  ? 0 : rec_obj.get("ArrivalNoteNumber")  )                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PurchaseOrderAdviceId") == null)                              ? 0 : rec_obj.get("PurchaseOrderAdviceId")  )                                      + "\" "    + "  " +

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "PurchaseOrderDelivery was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getPurchaseOrderDeliveries





    public static String getPurchaseOrderDeliveryRows(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Purchase/PurchaseOrderDeliveryRows?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".purchaseorderdeliveryrow  where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".purchaseorderdeliveryrow (tenant_id , id , " +
                          " Version , " +
                          " PurchaseOrderId , " +
                          " PurchaseOrderRowId , " +
                          " AccountsPayableId , " +
                          " InstructionId , " +
                          " InvoiceRowId , " +
                          " InvoiceCancelled , " +
                          " InvoiceCancelledById , " +
                          " InvoiceCancelledDate , " +
                          " DeliveryDate , " +
                          " GoodsLocation , " +
                          " GoodsMessage , " +
                          " ReceivingInspectionOrigin , " +
                          " ArrivedQuantity , " +
                          " ApprovedQuantity , " +
                          " CancelRestAdviced , " +
                          " PurchaseOrderDeliveryId , " +
                          " ParentClass , " +
                          " ParentId , " +
                          " InvoiceImportRowInformationId , " +
                          " ParameterPurchaseOrderRowId , " +
                          " PurchaseOrderAdviceRowId   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Version") == null)                            ? 0 : rec_obj.get("Version")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PurchaseOrderId") == null)                    ? 0 : rec_obj.get("PurchaseOrderId")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PurchaseOrderRowId") == null)                 ? 0 : rec_obj.get("PurchaseOrderRowId")  )             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AccountsPayableId") == null)                  ? 0 : rec_obj.get("AccountsPayableId")  )              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InstructionId") == null)                      ? 0 : rec_obj.get("InstructionId")  )                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InvoiceRowId") == null)                       ? 0 : rec_obj.get("InvoiceRowId")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InvoiceCancelled") == "false")                ? 0 : 1 )                                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InvoiceCancelledById") == null)               ? 0 : rec_obj.get("InvoiceCancelledById")  )           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InvoiceCancelledDate") == null      || rec_obj.get("InvoiceCancelledDate").toString().substring(0,2).equals("00")  )      ? new Date(2021000000) : rec_obj.get("InvoiceCancelledDate").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("DeliveryDate") == null              || rec_obj.get("DeliveryDate").toString().substring(0,2).equals("00")  )      ? new Date(2021000000) : rec_obj.get("DeliveryDate").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("GoodsLocation") == null)                      ? 0 : rec_obj.get("GoodsLocation")  )                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("GoodsMessage") == null)                       ? 0 : rec_obj.get("GoodsMessage")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReceivingInspectionOrigin") == null)          ? 0 : rec_obj.get("ReceivingInspectionOrigin")  )      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ArrivedQuantity") == null)                    ? 0 : rec_obj.get("ArrivedQuantity")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ApprovedQuantity") == null)                   ? 0 : rec_obj.get("ApprovedQuantity")  )               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CancelRestAdviced") == "false")               ? 0 : 1 )                                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PurchaseOrderDeliveryId") == null)            ? 0 : rec_obj.get("PurchaseOrderDeliveryId")  )        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ParentClass") == null)                        ? 0 : rec_obj.get("ParentClass")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ParentId") == null)                           ? 0 : rec_obj.get("ParentId")  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InvoiceImportRowInformationId") == null)      ? 0 : rec_obj.get("InvoiceImportRowInformationId")  )  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ParameterPurchaseOrderRowId") == null)        ? 0 : rec_obj.get("ParameterPurchaseOrderRowId")  )    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PurchaseOrderAdviceRowId") == null)           ? 0 : rec_obj.get("PurchaseOrderAdviceRowId")  )       + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "PurchaseOrderDeliveryRow was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getPurchaseOrderDeliveryRows









    public static String getPurchaseOrderInvoices(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/PurchaseOrderDeliveries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/PurchaseOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Purchase/PurchaseOrderInvoices?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".purchaseorderinvoice  where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".purchaseorderinvoice (tenant_id , id , " +
                          " PurchaseOrderDeliveryId , " +
                          " LedgerId , " +
                          " BusinessContactOrderId , " +
                          " InvoiceBusinessContactId , " +
                          " AccountGroupId , " +
                          " WarehouseId , " +
                          " VatGroupId , " +
                          " PaymentTermId , " +
                          " PaymentTermDescription , " +
                          " GracePeriodInDays , " +
                          " DeliveryMethodId , " +
                          " DeliveryTermId , " +
                          " DeliveryTermDescription , " +
                          " DeliveryMethodDescription , " +
                          " ShipmentPayer   " +

                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                           "\"" + ((rec_obj.get("PurchaseOrderDeliveryId") == null)                              ? 0 : rec_obj.get("PurchaseOrderDeliveryId")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("LedgerId") == null)                                             ? 0 : rec_obj.get("LedgerId")  )                                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BusinessContactOrderId") == null)                               ? 0 : rec_obj.get("BusinessContactOrderId")  )                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InvoiceBusinessContactId") == null)                             ? 0 : rec_obj.get("InvoiceBusinessContactId")  )                                + "\" "    + ", " +
                           "\"" + ((rec_obj.get("AccountGroupId") == null)                                       ? 0 : rec_obj.get("AccountGroupId")  )                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("WarehouseId") == null)                                          ? 0 : rec_obj.get("WarehouseId")  )                                             + "\" "    + ", " +
                           "\"" + ((rec_obj.get("VatGroupId") == null)                                           ? 0 : rec_obj.get("VatGroupId")  )                                              + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PaymentTermId") == null)                                        ? 0 : rec_obj.get("PaymentTermId")  )                                           + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PaymentTermDescription") == null)                               ? 0 : rec_obj.get("PaymentTermDescription")  )                                  + "\" "    + ", " +
                           "\"" + ((rec_obj.get("GracePeriodInDays") == null)                                    ? 0 : rec_obj.get("GracePeriodInDays")  )                                       + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DeliveryMethodId") == null)                                     ? 0 : rec_obj.get("DeliveryMethodId")  )                                        + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DeliveryTermId") == null)                                       ? 0 : rec_obj.get("DeliveryTermId")  )                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DeliveryTermDescription") == null)                              ? 0 : rec_obj.get("DeliveryTermDescription")  )                                 + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DeliveryMethodDescription") == null)                            ? 0 : rec_obj.get("DeliveryMethodDescription")  )                               + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ShipmentPayer") == null)                                        ? 0 : rec_obj.get("ShipmentPayer")  )                                           + "\" "    + "  " +

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "PurchaseOrderInvoice was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getPurchaseOrderInvoices





    public static String getPurchaseOrderInvoiceRows(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Purchase/PurchaseOrderInvoiceRows?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".purchaseorderinvoicerow  where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".purchaseorderinvoicerow (tenant_id , id , " +
                          " PurchaseOrderDeliveryRowId , " +
                          " CommentId , " +
                          " Price , " +
                          " PriceCurrencyId , " +
                          " PriceOrigin , " +
                          " PriceOriginPriceListId , " +
                          " PriceLockedFromAutomaticChanges , " +
                          " PriceIsFuturePrice , " +
                          " PriceInCompanyCurrency , " +
                          " PriceInCompanyCurrencyCurrencyId , " +
                          " SetupPrice , " +
                          " SetupPriceCurrencyId , " +
                          " SetupPriceInCompanyCurrency , " +
                          " SetupPriceInCompanyCurrencyCurrencyId , " +
                          " CodingId , " +
                          " VatRateId , " +
                          " Discount , " +
                          " StandardPrice , " +
                          " StandardPriceCurrencyId , " +
                          " LedgerId   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("PurchaseOrderDeliveryRowId") == null)                  ? 0 : rec_obj.get("PurchaseOrderDeliveryRowId")  )           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CommentId") == null)                                   ? 0 : rec_obj.get("CommentId")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Price") == null)                                       ? 0 : rec_obj.get("Price")  )                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PriceCurrencyId") == null)                             ? 0 : rec_obj.get("PriceCurrencyId")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PriceOrigin") == null)                                 ? 0 : rec_obj.get("PriceOrigin")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PriceOriginPriceListId") == null)                      ? 0 : rec_obj.get("PriceOriginPriceListId")  )               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PriceLockedFromAutomaticChanges") == "false")          ? 0 : 1 )                                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PriceIsFuturePrice") == "false")                       ? 0 : 1 )                                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PriceInCompanyCurrency") == null)                      ? 0 : rec_obj.get("PriceInCompanyCurrency")  )               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PriceInCompanyCurrencyCurrencyId") == null)            ? 0 : rec_obj.get("PriceInCompanyCurrencyCurrencyId")  )     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SetupPrice") == null)                                  ? 0 : rec_obj.get("SetupPrice")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SetupPriceCurrencyId") == null)                        ? 0 : rec_obj.get("SetupPriceCurrencyId")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SetupPriceInCompanyCurrency") == null)                 ? 0 : rec_obj.get("SetupPriceInCompanyCurrency")  )          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SetupPriceInCompanyCurrencyCurrencyId") == null)       ? 0 : rec_obj.get("SetupPriceInCompanyCurrencyCurrencyId")  )  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CodingId") == null)                                    ? 0 : rec_obj.get("CodingId")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("VatRateId") == null)                                   ? 0 : rec_obj.get("VatRateId")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Discount") == null)                                    ? 0 : rec_obj.get("Discount")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("StandardPrice") == null)                               ? 0 : rec_obj.get("StandardPrice")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("StandardPriceCurrencyId") == null)                     ? 0 : rec_obj.get("StandardPriceCurrencyId")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("LedgerId") == null)                                    ? 0 : rec_obj.get("LedgerId")  )                               + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "PurchaseOrderInvoiceRow was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getPurchaseOrderInvoiceRows







    public static String getPurchaseOrders(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/PurchaseOrderDeliveries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/PurchaseOrderInvoices" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/PurchaseOrders" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Purchase/PurchaseOrders?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".purchaseorder  where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".purchaseorder (tenant_id , id , " +
                          " Version , " +
                          " IsStockOrder , " +
                          " ExcludeFromEdi , " +
                          " CreatedFrom , " +
                          " SuppliersQuoteNumber , " +
                          " InquiryId , " +
                          " PackingTermId , " +
                          " PackingTermDescription , " +
                          " ActiveDeliveryAddressCustomerId , " +
                          " ActiveDeliveryAddressSupplierId , " +
                          " ActiveDeliveryAddressCompanyId , " +
                          " SourceOfAlternativeDeliveryAddresses , " +
                          " FromInquiryNumber , " +
                          " AgentSupplierId , " +
                          " GoodsAddressNumber , " +
                          " Status , " +
                          " IsConfirmed , " +
                          " ShowPriceInFormReport , " +
                          " ShowTotalInFormReport , " +
                          " ImportInformationId , " +
                          " CustomerOrderId , " +
                          " IsCredit , " +
                          " CausingCreditPurchaseOrderId , " +
                          " BusinessContactId , " +
                          " InvoiceBusinessContactId , " +
                          " OrderTypeId , " +
                          " AccountGroupId , " +
                          " CategoryString , " +
                          " BusinessContactReferenceId , " +
                          " DeliveryAddressId , " +
                          " OrderNumber , " +
                          " OrderDate , " +
                          " BusinessContactOrderNumber , " +
                          " OurReferenceId , " +
                          " OurReferenceName , " +
                          " BusinessContactReferenceName , " +
                          " GoodsLabel , " +
                          " CurrencyId , " +
                          " VatGroupId , " +
                          " WarehouseId , " +
                          " Priority , " +
                          " ProjectId , " +
                          " MailingAddressId , " +
                          " SendMethod , " +
                          " InvoicePrintoutMethod , " +
                          " InternalCommentId , " +
                          " ExternalCommentId , " +
                          " TransportTime , " +
                          " LifeCycleState , " +
                          " UseForwardRate , " +
                          " ExchangeRate , " +
                          " PaymentTermId , " +
                          " PaymentTermDescription , " +
                          " GracePeriodInDays , " +
                          " DeliveryMethodId , " +
                          " DeliveryTermId , " +
                          " DeliveryTermDescription , " +
                          " DeliveryMethodDescription , " +
                          " ShipmentPayer , " +
                          " ParameterAccountPayableId , " +
                          " MalaysianTaxExemptionId , " +
                          " ActiveDeliveryAddressDeliveryAddressId , " +
                          " DestinationForDeliveryTerm   " +

                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                           "\"" + ((rec_obj.get("Version") == null)                                    ? 0 : rec_obj.get("Version")  )                                            + "\" "    + ", " +
                           "\"" + ((rec_obj.get("IsStockOrder") == "false")                            ? 0 : 1 )                                                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ExcludeFromEdi") == "false")                          ? 0 : 1 )                                                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CreatedFrom") == null)                                ? 0 : rec_obj.get("CreatedFrom")  )                                        + "\" "    + ", " +
                           "\"" + ((rec_obj.get("SuppliersQuoteNumber") == null)                       ? 0 : rec_obj.get("SuppliersQuoteNumber")  )                               + "\" "    + ", " +
                           "\"" + ((rec_obj.get("InquiryId") == null)                                  ? 0 : rec_obj.get("InquiryId")  )                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PackingTermId") == null)                              ? 0 : rec_obj.get("PackingTermId")  )                                      + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PackingTermDescription") == null)                     ? 0 : rec_obj.get("PackingTermDescription")  )                             + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ActiveDeliveryAddressCustomerId") == null)            ? 0 : rec_obj.get("ActiveDeliveryAddressCustomerId")  )                    + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ActiveDeliveryAddressSupplierId") == null)            ? 0 : rec_obj.get("ActiveDeliveryAddressSupplierId")  )                    + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ActiveDeliveryAddressCompanyId") == null)             ? 0 : rec_obj.get("ActiveDeliveryAddressCompanyId")  )                     + "\" "    + ", " +
                           "\"" + ((rec_obj.get("SourceOfAlternativeDeliveryAddresses") == null)       ? 0 : rec_obj.get("SourceOfAlternativeDeliveryAddresses")  )               + "\" "    + ", " +
                           "\"" + ((rec_obj.get("FromInquiryNumber") == null)                          ? 0 : rec_obj.get("FromInquiryNumber")  )                                  + "\" "    + ", " +
                           "\"" + ((rec_obj.get("AgentSupplierId") == null)                            ? 0 : rec_obj.get("AgentSupplierId")  )                                    + "\" "    + ", " +
                           "\"" + ((rec_obj.get("GoodsAddressNumber") == null)                         ? 0 : rec_obj.get("GoodsAddressNumber")  )                                 + "\" "    + ", " +
                           "\"" + ((rec_obj.get("Status") == null)                                     ? 0 : rec_obj.get("Status")  )                                             + "\" "    + ", " +
                           "\"" + ((rec_obj.get("IsConfirmed") == "false")                             ? 0 : 1 )                                                                  + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ShowPriceInFormReport") == "false")                   ? 0 : 1 )                                                                  + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ShowTotalInFormReport") == "false")                   ? 0 : 1 )                                                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ImportInformationId") == null)                        ? 0 : rec_obj.get("ImportInformationId")  )                                + "\" "    + ", " +
                           "\"" + ((rec_obj.get("CustomerOrderId") == null)                            ? 0 : rec_obj.get("CustomerOrderId")  )                                    + "\" "    + ", " +
                           "\"" + ((rec_obj.get("IsCredit") == "false")                                ? 0 : 1 )                                                                  + "\" "    + ", " +
                           "\"" + ((rec_obj.get("CausingCreditPurchaseOrderId") == null)               ? 0 : rec_obj.get("CausingCreditPurchaseOrderId")  )                       + "\" "    + ", " +
                           "\"" + ((rec_obj.get("BusinessContactId") == null)                          ? 0 : rec_obj.get("BusinessContactId")  )                                  + "\" "    + ", " +
                           "\"" + ((rec_obj.get("InvoiceBusinessContactId") == null)                   ? 0 : rec_obj.get("InvoiceBusinessContactId")  )                           + "\" "    + ", " +
                           "\"" + ((rec_obj.get("OrderTypeId") == null)                                ? 0 : rec_obj.get("OrderTypeId")  )                                        + "\" "    + ", " +
                           "\"" + ((rec_obj.get("AccountGroupId") == null)                             ? 0 : rec_obj.get("AccountGroupId")  )                                     + "\" "    + ", " +
                           "\"" + ((rec_obj.get("CategoryString") == null)                             ? 0 : rec_obj.get("CategoryString")  )                                     + "\" "    + ", " +
                           "\"" + ((rec_obj.get("BusinessContactReferenceId") == null)                 ? 0 : rec_obj.get("BusinessContactReferenceId")  )                         + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DeliveryAddressId") == null)                          ? 0 : rec_obj.get("DeliveryAddressId")  )                                  + "\" "    + ", " +
                           "\"" + ((rec_obj.get("OrderNumber") == null)                                ? 0 : rec_obj.get("OrderNumber")  )                                        + "\" "    + ", " +
                           "\"" + ((rec_obj.get("OrderDate") == null || rec_obj.get("OrderDate").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("OrderDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                           "\"" + ((rec_obj.get("BusinessContactOrderNumber") == null)                 ? 0 : rec_obj.get("BusinessContactOrderNumber")  )                         + "\" "    + ", " +
                           "\"" + ((rec_obj.get("OurReferenceId") == null)                             ? 0 : rec_obj.get("OurReferenceId")  )                                     + "\" "    + ", " +
                           "\"" + ((rec_obj.get("OurReferenceName") == null)                           ? 0 : rec_obj.get("OurReferenceName")  )                                   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("BusinessContactReferenceName") == null)               ? 0 : rec_obj.get("BusinessContactReferenceName")  )                       + "\" "    + ", " +
                           "\"" + ((rec_obj.get("GoodsLabel") == null)                                 ? 0 : rec_obj.get("GoodsLabel")  )                                         + "\" "    + ", " +
                           "\"" + ((rec_obj.get("CurrencyId") == null)                                 ? 0 : rec_obj.get("CurrencyId")  )                                         + "\" "    + ", " +
                           "\"" + ((rec_obj.get("VatGroupId") == null)                                 ? 0 : rec_obj.get("VatGroupId")  )                                         + "\" "    + ", " +
                           "\"" + ((rec_obj.get("WarehouseId") == null)                                ? 0 : rec_obj.get("WarehouseId")  )                                        + "\" "    + ", " +
                           "\"" + ((rec_obj.get("Priority") == null)                                   ? 0 : rec_obj.get("Priority")  )                                           + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ProjectId") == null)                                  ? 0 : rec_obj.get("ProjectId")  )                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("MailingAddressId") == null)                           ? 0 : rec_obj.get("MailingAddressId")  )                                   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("SendMethod") == null)                                 ? 0 : rec_obj.get("SendMethod")  )                                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InvoicePrintoutMethod") == null)                      ? 0 : rec_obj.get("InvoicePrintoutMethod")  )                              + "\" "    + ", " +
                           "\"" + ((rec_obj.get("InternalCommentId") == null)                          ? 0 : rec_obj.get("InternalCommentId")  )                                  + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ExternalCommentId") == null)                          ? 0 : rec_obj.get("ExternalCommentId")  )                                  + "\" "    + ", " +
                           "\"" + ((rec_obj.get("TransportTime") == null)                              ? 0 : rec_obj.get("TransportTime")  )                                      + "\" "    + ", " +
                           "\"" + ((rec_obj.get("LifeCycleState") == null)                             ? 0 : rec_obj.get("LifeCycleState")  )                                     + "\" "    + ", " +
                           "\"" + ((rec_obj.get("UseForwardRate") == "false")                          ? 0 : 1 )                                                                  + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ExchangeRate") == null)                               ? 0 : rec_obj.get("ExchangeRate")  )                                       + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PaymentTermId") == null)                              ? 0 : rec_obj.get("PaymentTermId")  )                                      + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PaymentTermDescription") == null)                     ? 0 : rec_obj.get("PaymentTermDescription")  )                             + "\" "    + ", " +
                           "\"" + ((rec_obj.get("GracePeriodInDays") == null)                          ? 0 : rec_obj.get("GracePeriodInDays")  )                                  + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DeliveryMethodId") == null)                           ? 0 : rec_obj.get("DeliveryMethodId")  )                                   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DeliveryTermId") == null)                             ? 0 : rec_obj.get("DeliveryTermId")  )                                     + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DeliveryTermDescription") == null)                    ? 0 : rec_obj.get("DeliveryTermDescription")  )                            + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DeliveryMethodDescription") == null)                  ? 0 : rec_obj.get("DeliveryMethodDescription")  )                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ShipmentPayer") == null)                              ? 0 : rec_obj.get("ShipmentPayer")  )                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ParameterAccountPayableId") == null)                  ? 0 : rec_obj.get("ParameterAccountPayableId")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("MalaysianTaxExemptionId") == null)                    ? 0 : rec_obj.get("MalaysianTaxExemptionId")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ActiveDeliveryAddressDeliveryAddressId") == null)     ? 0 : rec_obj.get("ActiveDeliveryAddressDeliveryAddressId")  )             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DestinationForDeliveryTerm") == null)                 ? 0 : rec_obj.get("DestinationForDeliveryTerm")  )                         + "\" "    + "  " +

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "PurchaseOrder was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getPurchaseOrders





    public static String getPurchaseOrderRows(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Purchase/PurchaseOrderRows?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".purchaseorderrow  where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".purchaseorderrow (tenant_id , id , " +
                          " Version , " +
                          " SupplierPartNumber , " +
                          " ArrivalReporting , " +
                          " ConfirmedDelayed , " +
                          " DelayCommentId , " +
                          " DelayReasonId , " +
                          " SupplierOrderNumber , " +
                          " SupplierOrderRowPosition , " +
                          " CodingId , " +
                          " RowStatus , " +
                          " IsConfirmed , " +
                          " ReceivingInspectionInstructionId , " +
                          " ReceivingInspectionType , " +
                          " ReceivingMessageId , " +
                          " RequiredForManufacturingOrderNode , " +
                          " ShowFreeTextIn , " +
                          " Weight , " +
                          " LinkedStockOrderRowId , " +
                          " ImportInformationId , " +
                          " LinkedSubcontractingManufacturingOrderOperation , " +
                          " CreatedFrom , " +
                          " OrderedQuantity , " +
                          " DeliveryDate , " +
                          " OriginatingPurchaseOrderDeliveryRowId , " +
                          " CausingTransType , " +
                          " CausingOrderRowId , " +
                          " RequirementDate , " +
                          " PreviousOrderedQuantity , " +
                          " PreviousDeliveryDate , " +
                          " AuthorizationListId , " +
                          " IsAuthorized , " +
                          " SupplierPriceAgreementReference , " +
                          " SupplierRevisionNumber , " +
                          " SupplierDrawingNumber , " +
                          " SupplierConfirmationAction , " +
                          " RestQuantity , " +
                          " DeliveredQuantity , " +
                          " InitialDeliveryDate , " +
                          " DesiredDeliveryDate , " +
                          " CreationContext , " +
                          " SubPartParentRowId , " +
                          " QuantityRatio , " +
                          " ParentOrderId , " +
                          " Position , " +
                          " OrderRowType , " +
                          " PartId , " +
                          " EntityIdentityString , " +
                          " AdditionalRowDescription , " +
                          " FreeTextHtml , " +
                          " FreeText , " +
                          " RowIndex , " +
                          " ParentRowId , " +
                          " SumRowId , " +
                          " RevisionId , " +
                          " Price , " +
                          " PriceCurrencyId , " +
                          " PriceOrigin , " +
                          " PriceOriginPriceListId , " +
                          " PriceLockedFromAutomaticChanges , " +
                          " PriceIsFuturePrice , " +
                          " DiscountIsLockedFromAutomaticChanges , " +
                          " Discount , " +
                          " ToolId , " +
                          " UnitId , " +
                          " VatRateId , " +
                          " WarehouseId , " +
                          " WeightPerUnit , " +
                          " OrderDate , " +
                          " ConversionFactor , " +
                          " SetupPrice , " +
                          " SetupPriceCurrencyId , " +
                          " StatisticalGoodsCodeId , " +
                          " IntrastatTransactionTypeId , " +
                          " TariffAndServiceCodeId , " +
                          " PriceInCompanyCurrency , " +
                          " PriceInCompanyCurrencyCurrencyId , " +
                          " SetupPriceInCompanyCurrency , " +
                          " SetupPriceInCompanyCurrencyCurrencyId , " +
                          " StandardPrice , " +
                          " StandardPriceCurrencyId , " +
                          " ShowPrice , " +
                          " PartRowType , " +
                          " LifeCycleState , " +
                          " PartStatus , " +
                          " PartConfigurationId , " +
                          " RowsGoodsLabel , " +
                          " BlanketOrderPurchaseRowId , " +
                          " BlanketOrderRowQuantity , " +
                          " RemainingBlanketOrderRowQuantity , " +
                          " BlanketOrderRowValidThrough , " +
                          " TextRowCreationContext   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Version") == null)                                       ? 0 : rec_obj.get("Version")  )                                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SupplierPartNumber") == null)                            ? 0 : rec_obj.get("SupplierPartNumber")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ArrivalReporting") == "false")                           ? 0 : 1 )                                                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ConfirmedDelayed") == "false")                           ? 0 : 1 )                                                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DelayCommentId") == null)                                ? 0 : rec_obj.get("DelayCommentId")  )                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DelayReasonId") == null)                                 ? 0 : rec_obj.get("DelayReasonId")  )                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SupplierOrderNumber") == null)                           ? 0 : rec_obj.get("SupplierOrderNumber")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SupplierOrderRowPosition") == null)                      ? 0 : rec_obj.get("SupplierOrderRowPosition")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CodingId") == null)                                      ? 0 : rec_obj.get("CodingId")  )                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RowStatus") == null)                                     ? 0 : rec_obj.get("RowStatus")  )                                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsConfirmed") == "false")                                ? 0 : 1 )                                                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReceivingInspectionInstructionId") == null)              ? 0 : rec_obj.get("ReceivingInspectionInstructionId")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReceivingInspectionType") == null)                       ? 0 : rec_obj.get("ReceivingInspectionType")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReceivingMessageId") == null)                            ? 0 : rec_obj.get("ReceivingMessageId")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RequiredForManufacturingOrderNode") == null)             ? 0 : rec_obj.get("RequiredForManufacturingOrderNode")  )               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ShowFreeTextIn") == null)                                ? 0 : rec_obj.get("ShowFreeTextIn")  )                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Weight") == null)                                        ? 0 : rec_obj.get("Weight")  )                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("LinkedStockOrderRowId") == null)                         ? 0 : rec_obj.get("LinkedStockOrderRowId")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ImportInformationId") == null)                           ? 0 : rec_obj.get("ImportInformationId")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("LinkedSubcontractingManufacturingOrderOperation") == null)     ? 0 : rec_obj.get("LinkedSubcontractingManufacturingOrderOperation")  )      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CreatedFrom") == null)                                   ? 0 : rec_obj.get("CreatedFrom")  )                                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OrderedQuantity") == null)                               ? 0 : rec_obj.get("OrderedQuantity")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DeliveryDate") == null      || rec_obj.get("DeliveryDate").toString().substring(0,2).equals("00")  )      ? new Date(2021000000) : rec_obj.get("DeliveryDate").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("OriginatingPurchaseOrderDeliveryRowId") == null)         ? 0 : rec_obj.get("OriginatingPurchaseOrderDeliveryRowId")  )           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CausingTransType") == null)                              ? 0 : rec_obj.get("CausingTransType")  )                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CausingOrderRowId") == null)                             ? 0 : rec_obj.get("CausingOrderRowId")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RequirementDate") == null        || rec_obj.get("RequirementDate").toString().substring(0,2).equals("00")  )        ? new Date(2021000000) : rec_obj.get("RequirementDate").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("PreviousOrderedQuantity") == null)                       ? 0 : rec_obj.get("PreviousOrderedQuantity")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PreviousDeliveryDate") == null   || rec_obj.get("PreviousDeliveryDate").toString().substring(0,2).equals("00")  )   ? new Date(2021000000) : rec_obj.get("PreviousDeliveryDate").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("AuthorizationListId") == null)                           ? 0 : rec_obj.get("AuthorizationListId")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsAuthorized") == "false")                               ? 0 : 1 )                                                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SupplierPriceAgreementReference") == null)               ? 0 : rec_obj.get("SupplierPriceAgreementReference")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SupplierRevisionNumber") == null)                        ? 0 : rec_obj.get("SupplierRevisionNumber")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SupplierDrawingNumber") == null)                         ? 0 : rec_obj.get("SupplierDrawingNumber")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SupplierConfirmationAction") == null)                    ? 0 : rec_obj.get("SupplierConfirmationAction")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RestQuantity") == null)                                  ? 0 : rec_obj.get("RestQuantity")  )                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DeliveredQuantity") == null)                             ? 0 : rec_obj.get("DeliveredQuantity")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InitialDeliveryDate") == null   || rec_obj.get("InitialDeliveryDate").toString().substring(0,2).equals("00")  )   ? new Date(2021000000) : rec_obj.get("InitialDeliveryDate").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("DesiredDeliveryDate") == null   || rec_obj.get("DesiredDeliveryDate").toString().substring(0,2).equals("00")  )   ? new Date(2021000000) : rec_obj.get("DesiredDeliveryDate").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("CreationContext") == null)                               ? 0 : rec_obj.get("CreationContext")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SubPartParentRowId") == null)                            ? 0 : rec_obj.get("SubPartParentRowId")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("QuantityRatio") == null)                                 ? 0 : rec_obj.get("QuantityRatio")  )                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ParentOrderId") == null)                                 ? 0 : rec_obj.get("ParentOrderId")  )                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Position") == null)                                      ? 0 : rec_obj.get("Position")  )                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OrderRowType") == null)                                  ? 0 : rec_obj.get("OrderRowType")  )                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PartId") == null)                                        ? 0 : rec_obj.get("PartId")  )                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("EntityIdentityString") == null)                          ? 0 : rec_obj.get("EntityIdentityString")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AdditionalRowDescription") == null)                      ? 0 : rec_obj.get("AdditionalRowDescription")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("FreeTextHtml") == null)                     ? 0 : rec_obj.get("FreeTextHtml").toString().replaceAll("\"", " ").replaceAll("\\p{Cc}", " ").replaceAll("\\s{2,}", " ")  )   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("FreeText") == null)                         ? 0 : rec_obj.get("FreeText").toString().replaceAll("\"", " ").replaceAll("\\p{Cc}", " ").replaceAll("\\s{2,}", " ")  )   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RowIndex") == null)                         ? 0 : rec_obj.get("RowIndex")  )                                                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ParentRowId") == null)                      ? 0 : rec_obj.get("ParentRowId")  )                                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SumRowId") == null)                         ? 0 : rec_obj.get("SumRowId")  )                                                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RevisionId") == null)                       ? 0 : rec_obj.get("RevisionId")  )                                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Price") == null)                            ? 0 : rec_obj.get("Price")  )                                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PriceCurrencyId") == null)                  ? 0 : rec_obj.get("PriceCurrencyId")  )                                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PriceOrigin") == null)                      ? 0 : rec_obj.get("PriceOrigin")  )                                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PriceOriginPriceListId") == null)           ? 0 : rec_obj.get("PriceOriginPriceListId")  )                                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PriceLockedFromAutomaticChanges") == "false")       ? 0 : 1 )                                                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PriceIsFuturePrice") == "false")                    ? 0 : 1 )                                                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DiscountIsLockedFromAutomaticChanges") == "false")  ? 0 : 1 )                                                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Discount") == null)                                 ? 0 : rec_obj.get("Discount")  )                                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ToolId") == null)                                   ? 0 : rec_obj.get("ToolId")  )                                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("UnitId") == null)                                   ? 0 : rec_obj.get("UnitId")  )                                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("VatRateId") == null)                                ? 0 : rec_obj.get("VatRateId")  )                                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("WarehouseId") == null)                              ? 0 : rec_obj.get("WarehouseId")  )                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("WeightPerUnit") == null)                            ? 0 : rec_obj.get("WeightPerUnit")  )                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OrderDate") == null    || rec_obj.get("OrderDate").toString().substring(0,2).equals("00")  )   ? new Date(2021000000) : rec_obj.get("OrderDate").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("ConversionFactor") == null)                         ? 0 : rec_obj.get("ConversionFactor")  )                                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SetupPrice") == null)                               ? 0 : rec_obj.get("SetupPrice")  )                                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SetupPriceCurrencyId") == null)                     ? 0 : rec_obj.get("SetupPriceCurrencyId")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("StatisticalGoodsCodeId") == null)                   ? 0 : rec_obj.get("StatisticalGoodsCodeId")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IntrastatTransactionTypeId") == null)               ? 0 : rec_obj.get("IntrastatTransactionTypeId")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("TariffAndServiceCodeId") == null)                   ? 0 : rec_obj.get("TariffAndServiceCodeId")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PriceInCompanyCurrency") == null)                   ? 0 : rec_obj.get("PriceInCompanyCurrency")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PriceInCompanyCurrencyCurrencyId") == null)         ? 0 : rec_obj.get("PriceInCompanyCurrencyCurrencyId")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SetupPriceInCompanyCurrency") == null)              ? 0 : rec_obj.get("SetupPriceInCompanyCurrency")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SetupPriceInCompanyCurrencyCurrencyId") == null)    ? 0 : rec_obj.get("SetupPriceInCompanyCurrencyCurrencyId")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("StandardPrice") == null)                            ? 0 : rec_obj.get("StandardPrice")  )                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("StandardPriceCurrencyId") == null)                  ? 0 : rec_obj.get("StandardPriceCurrencyId")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ShowPrice") == "false")                             ? 0 : 1 )                                                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PartRowType") == null)                              ? 0 : rec_obj.get("PartRowType")  )                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("LifeCycleState") == null)                           ? 0 : rec_obj.get("LifeCycleState")  )                                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PartStatus") == null)                               ? 0 : rec_obj.get("PartStatus")  )                                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PartConfigurationId") == null)                      ? 0 : rec_obj.get("PartConfigurationId")  )                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RowsGoodsLabel") == null)                           ? 0 : rec_obj.get("RowsGoodsLabel")  )                                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BlanketOrderPurchaseRowId") == null)                ? 0 : rec_obj.get("BlanketOrderPurchaseRowId")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BlanketOrderRowQuantity") == null)                  ? 0 : rec_obj.get("BlanketOrderRowQuantity")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RemainingBlanketOrderRowQuantity") == null)         ? 0 : rec_obj.get("RemainingBlanketOrderRowQuantity")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BlanketOrderRowValidThrough") == null    || rec_obj.get("BlanketOrderRowValidThrough").toString().substring(0,2).equals("00")  )   ? new Date(2021000000) : rec_obj.get("BlanketOrderRowValidThrough").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("TextRowCreationContext") == null)                   ? 0 : rec_obj.get("TextRowCreationContext")  )                               + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "PurchaseOrderRow was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getPurchaseOrderRows





    public static String getPurchaseOrderTypes(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Purchase/PurchaseOrderTypes?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".purchaseordertype  where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".purchaseordertype (tenant_id , id , " +
                          " IncludeInPurchaseStatistics , " +
                          " BaseType , " +
                          " TransactionTypeIntrastatImportId , " +
                          " IntrastatValueImport , " +
                          " PriceListIntrastatImportId , " +
                          " IntrastatImportCurrencyExchangeTypeId , " +
                          " TransactionTypeIntrastatExportId , " +
                          " IntrastatValueExport , " +
                          " PriceListIntrastatExportId , " +
                          " IntrastatExportCurrencyExchangeTypeId , " +
                          " CodingGroupId , " +
                          " Number , " +
                          " Prefix , " +
                          " DescriptionId , " +
                          " Priority , " +
                          " Visible , " +
                          " IsPreset , " +
                          " PurchaseOrderActivityTemplateId , " +
                          " Description   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("IncludeInPurchaseStatistics") == "false")               ? 0 : 1 )                                                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BaseType") == null)                                     ? 0 : rec_obj.get("BaseType")  )                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("TransactionTypeIntrastatImportId") == null)             ? 0 : rec_obj.get("TransactionTypeIntrastatImportId")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IntrastatValueImport") == null)                         ? 0 : rec_obj.get("IntrastatValueImport")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PriceListIntrastatImportId") == null)                   ? 0 : rec_obj.get("PriceListIntrastatImportId")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IntrastatImportCurrencyExchangeTypeId") == null)        ? 0 : rec_obj.get("IntrastatImportCurrencyExchangeTypeId")  )           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("TransactionTypeIntrastatExportId") == null)             ? 0 : rec_obj.get("TransactionTypeIntrastatExportId")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IntrastatValueExport") == null)                         ? 0 : rec_obj.get("IntrastatValueExport")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PriceListIntrastatExportId") == null)                   ? 0 : rec_obj.get("PriceListIntrastatExportId")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IntrastatExportCurrencyExchangeTypeId") == null)        ? 0 : rec_obj.get("IntrastatExportCurrencyExchangeTypeId")  )           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CodingGroupId") == null)                                ? 0 : rec_obj.get("CodingGroupId")  )                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Number") == null)                                       ? 0 : rec_obj.get("Number")  )                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Prefix") == null)                                       ? 0 : rec_obj.get("Prefix")  )                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                                ? 0 : rec_obj.get("DescriptionId")  )                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Priority") == null)                                     ? 0 : rec_obj.get("Priority")  )                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Visible") == "false")                                   ? 0 : 1 )                                                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsPreset") == "false")                                  ? 0 : 1 )                                                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PurchaseOrderActivityTemplateId") == null)              ? 0 : rec_obj.get("PurchaseOrderActivityTemplateId")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                                  ? 0 : rec_obj.get("Description")  )                                     + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "PurchaseOrderType was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getPurchaseOrderTypes





    public static String getResponseTimes(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Purchase/ResponseTimes?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".responsetime  where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".responsetime (tenant_id , id , " +
                          " Days , " +
                          " DescriptionId , " +
                          " Number , " +
                          " IsDefault , " +
                          " Description  " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Days") == null)                                     ? 0 : rec_obj.get("Days")  )                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                            ? 0 : rec_obj.get("DescriptionId")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Number") == null)                                   ? 0 : rec_obj.get("Number")  )                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsDefault") == "false")                             ? 0 : 1 )                                                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                              ? 0 : rec_obj.get("Description")  )                                 + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "ResponseTime was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getResponseTimes





    public static String getSupplierAccountGroups(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Purchase/SupplierAccountGroups?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".supplieraccountgroup  where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".supplieraccountgroup (tenant_id , id , " +
                          " IsDefault , " +
                          " Number , " +
                          " DescriptionId , " +
                          " Description  " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("IsDefault") == "false")                             ? 0 : 1 )                                                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Number") == null)                                   ? 0 : rec_obj.get("Number")  )                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                            ? 0 : rec_obj.get("DescriptionId")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                              ? 0 : rec_obj.get("Description")  )                                 + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "SupplierAccountGroup was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getSupplierAccountGroups




    public static String getSupplierDistricts(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Purchase/SupplierDistricts?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".supplierdistrict  where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".supplierdistrict (tenant_id , id , " +
                          " Code , " +
                          " DescriptionId , " +
                          " Description    " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Code") == null)                                     ? 0 : rec_obj.get("Code")  )                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                            ? 0 : rec_obj.get("DescriptionId")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                              ? 0 : rec_obj.get("Description")  )                                 + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "SupplierDistrict was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getSupplierDistricts





    public static String getSupplierPartLinks(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Purchase/SupplierPartLinks?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".supplierpartlink  where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".supplierpartlink (tenant_id , id , " +
                          " SupplierId , " +
                          " SupplierPartNumber , " +
                          " Dock , " +
                          " Storage , " +
                          " FixedOrderNo , " +
                          " PurchaseDistribution , " +
                          " OverridePurchaseCommentId , " +
                          " PurchaseCommentShowInForms , " +
                          " ExportDeliverySchedule , " +
                          " IncludeAlloyCostOnPurchaseOrder , " +
                          " UnitId , " +
                          " PartId , " +
                          " PriceCurrencyId , " +
                          " Price , " +
                          " SetupPrice , " +
                          " LeadTime , " +
                          " Discount , " +
                          " PriceValidThrough , " +
                          " FuturePrice , " +
                          " FuturePriceValidThrough , " +
                          " FutureSetupPrice , " +
                          " PriceCommentId , " +
                          " QuantityPerPackage , " +
                          " Brand , " +
                          " Unit , " +
                          " PriceCurrency , " +
                          " PriceComment   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("SupplierId") == null)                                 ? 0 : rec_obj.get("SupplierId")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SupplierPartNumber") == null)                         ? 0 : rec_obj.get("SupplierPartNumber")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Dock") == null)                                       ? 0 : rec_obj.get("Dock")  )                                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Storage") == null)                                    ? 0 : rec_obj.get("Storage")  )                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("FixedOrderNo") == null)                               ? 0 : rec_obj.get("FixedOrderNo")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PurchaseDistribution") == null)                       ? 0 : rec_obj.get("PurchaseDistribution")  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OverridePurchaseCommentId") == null)                  ? 0 : rec_obj.get("OverridePurchaseCommentId")  )                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PurchaseCommentShowInForms") == null)                 ? 0 : rec_obj.get("PurchaseCommentShowInForms")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ExportDeliverySchedule") == "false")                  ? 0 : 1  )                                                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IncludeAlloyCostOnPurchaseOrder") == "false")         ? 0 : 1  )                                                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("UnitId") == null)                                     ? 0 : rec_obj.get("UnitId")  )                                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PartId") == null)                                     ? 0 : rec_obj.get("PartId")  )                                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PriceCurrencyId") == null)                            ? 0 : rec_obj.get("PriceCurrencyId")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Price") == null)                                      ? 0 : rec_obj.get("Price")  )                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SetupPrice") == null)                                 ? 0 : rec_obj.get("SetupPrice")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("LeadTime") == null)                                   ? 0 : rec_obj.get("LeadTime")  )                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Discount") == null)                                   ? 0 : rec_obj.get("Discount")  )                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PriceValidThrough") == null      || rec_obj.get("PriceValidThrough").toString().substring(0,2).equals("00")  )      ? new Date(2021000000) : rec_obj.get("PriceValidThrough").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("FuturePrice") == null)                                ? 0 : rec_obj.get("FuturePrice")  )                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("FuturePriceValidThrough") == null      || rec_obj.get("FuturePriceValidThrough").toString().substring(0,2).equals("00")  )      ? new Date(2021000000) : rec_obj.get("FuturePriceValidThrough").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("FutureSetupPrice") == null)                           ? 0 : rec_obj.get("FutureSetupPrice")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PriceCommentId") == null)                             ? 0 : rec_obj.get("PriceCommentId")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("QuantityPerPackage") == null)                         ? 0 : rec_obj.get("QuantityPerPackage")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Brand") == null)                                      ? 0 : rec_obj.get("Brand")  )                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Unit") == null)                                       ? 0 : rec_obj.get("Unit")  )                                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PriceCurrency") == null)                              ? 0 : rec_obj.get("PriceCurrency")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PriceComment") == null)                               ? 0 : rec_obj.get("PriceComment")  )                               + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "SupplierPartLink was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getSupplierPartLinks









    public static String getSuppliers(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/PurchaseOrderDeliveries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/PurchaseOrderInvoices" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/PurchaseOrders" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Suppliers" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Purchase/Suppliers?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".supplier  where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 com_stmt = "Delete from  monitordb5.supplierroot  where tenant_id = 100 " ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".supplier (tenant_id , id , " +
                          " HidePricePerUnit , " +
                          " DefaultShippingExporterId , " +
                          " DanishGiroCode , " +
                          " DanishGiroNumber , " +
                          " PackingTermId , " +
                          " GracePeriodOrderConfirmation , " +
                          " GracePeriodDelivery , " +
                          " PaymentMethodId , " +
                          " InvoiceSupplierId , " +
                          " RequiresReceivingInspection , " +
                          " RequiresReceivingInspectionModifiedTimestamp , " +
                          " RequiresReceivingInspectionModifiedBy , " +
                          " ReceivingInspectionTextNo , " +
                          " AuthorizedSignerPersonId , " +
                          " AuthorizationListId , " +
                          " EvaluationDate , " +
                          " EvaluationValidityDate , " +
                          " EvaluationTextNo , " +
                          " EvaluationByWhom , " +
                          " Evaluation , " +
                          " PayViaId , " +
                          " BankIdNumber , " +
                          " AdditionalPurchasingCost , " +
                          " CentralBankCode , " +
                          " ResponseTimeId , " +
                          " UseFinalAuthorization , " +
                          " InvoiceBasisException , " +
                          " IsPrivateSupplier , " +
                          " Role , " +
                          " AttachDatafileWithOrder , " +
                          " AttachDatafileWithPart , " +
                          " AttachDatafileWithAnnualVolume , " +
                          " AttachDatafileWithDeliverySchedule , " +
                          " AttachDatafileWithComplaint , " +
                          " AttachDatafileWithForecast , " +
                          " InquiryReportConfigurationId , " +
                          " PurchaseOrderFormReportConfigurationId , " +
                          " SubcontractDeliveryNoteReportConfigurationId , " +
                          " SubcontractPurchaseOrderReportConfigurationId , " +
                          " SubcontractComprehensivePurchaseOrderReportConfigurationId , " +
                          " SubcontractComprehensiveDeliveryNoteReportConfigurationId , " +
                          " SupplierClaimReportConfigurationId , " +
                          " ReceivingInspectionType , " +
                          " ArrivalReportingInstructionId , " +
                          " UseOCRNumber , " +
                          " UseReferenceNumber , " +
                          " FixedReferenceNumber , " +
                          " EInvoiceId , " +
                          " PurchaseManagerId , " +
                          " ShippingAgentCode , " +
                          " DefaultBusinessContactBankAccountId , " +
                          " OutgoingPaymentsAccountId , " +
                          " PurchaseAccountId , " +
                          " AccrualAccountingReverseAccountId , " +
                          " IsCasualSupplier , " +
                          " ShippingAgentType , " +
                          " BookTransport , " +
                          " ReturnLabel , " +
                          " ShipmentPrintSetting , " +
                          " StatusId , " +
                          " TypeId , " +
                          " DistrictId , " +
                          " DateForTransitionToActualContact , " +
                          " RootId , " +
                          " VisitingAddressId , " +
                          " DefaultReferenceId , " +
                          " PaymentTermId , " +
                          " ApplyBankCharge , " +
                          " BankChargeAmount , " +
                          " BankGiroNo , " +
                          " DateDisplayFormat , " +
                          " DecimalSymbol , " +
                          " TimeZone , " +
                          " CategoryString , " +
                          " CreditLimit , " +
                          " DefaultOrderPrintoutVia , " +
                          " PalletRegistrationNo , " +
                          " PlusGiroNo , " +
                          " Discount , " +
                          " BlockedFromDate , " +
                          " BlockedStatus , " +
                          " BlockMessageId , " +
                          " BlockedToDate , " +
                          " BlockedById , " +
                          " LanguageId , " +
                          " CommentId , " +
                          " OurCodeByYou , " +
                          " Url , " +
                          " CurrencyId , " +
                          " DiscountCategoryId , " +
                          " DeliveryInstruction , " +
                          " VatRateId , " +
                          " ToleranceForLateDelivery , " +
                          " ToleranceForEarlyDelivery , " +
                          " Alias , " +
                          " Priority , " +
                          " BlockedContextType , " +
                          " IsInternal , " +
                          " CompanyId , " +
                          " MalaysianTaxExemptionId , " +
                          " SplitPayment , " +
                          " BlockAutomaticFinalCodingImportedInvoice , " +
                          " AllowedPriceDifferenceImportedInvoiceEach , " +
                          " AllowedPriceDifferenceImportedInvoiceEachPercentage , " +
                          " AllowedAmountDifferenceImportedInvoiceRow , " +
                          " AllowedAmountDifferenceImportedInvoiceRowPercentage , " +
                          " AllowedAmountDifferenceImportedInvoiceTotal , " +
                          " AllowedAmountDifferenceImportedInvoiceTotalPercentage , " +
                          " TaxMethod , " +
                          " PurchaseDeliveryScheduleFormReportConfigurationId , " +
                          " PurchaseVatInfo   " +

                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("HidePricePerUnit") == null)                              ? 0 : rec_obj.get("HidePricePerUnit")  )                                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DefaultShippingExporterId") == null)                     ? 0 : rec_obj.get("DefaultShippingExporterId")  )                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DanishGiroCode") == null)                                ? 0 : rec_obj.get("DanishGiroCode")  )                                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DanishGiroNumber") == null)                              ? 0 : rec_obj.get("DanishGiroNumber")  )                                            + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PackingTermId") == null)                                 ? 0 : rec_obj.get("PackingTermId")  )                                               + "\" "    + ", " +
                           "\"" + ((rec_obj.get("GracePeriodOrderConfirmation") == null)                  ? 0 : rec_obj.get("GracePeriodOrderConfirmation")  )                                + "\" "    + ", " +
                           "\"" + ((rec_obj.get("GracePeriodDelivery") == null)                           ? 0 : rec_obj.get("GracePeriodDelivery")  )                                         + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PaymentMethodId") == null)                               ? 0 : rec_obj.get("PaymentMethodId")  )                                             + "\" "    + ", " +
                           "\"" + ((rec_obj.get("InvoiceSupplierId") == null)                             ? 0 : rec_obj.get("InvoiceSupplierId")  )                                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RequiresReceivingInspection") == "false")                ? 0 : 1 )                                                                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RequiresReceivingInspectionModifiedTimestamp") == null || rec_obj.get("RequiresReceivingInspectionModifiedTimestamp").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("RequiresReceivingInspectionModifiedTimestamp").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                          "\"" + ((rec_obj.get("RequiresReceivingInspectionModifiedBy") == null)         ? 0 : rec_obj.get("RequiresReceivingInspectionModifiedBy")  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReceivingInspectionTextNo") == null)                     ? 0 : rec_obj.get("ReceivingInspectionTextNo")  )                                   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("AuthorizedSignerPersonId") == null)                      ? 0 : rec_obj.get("AuthorizedSignerPersonId")  )                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AuthorizationListId") == null)                           ? 0 : rec_obj.get("AuthorizationListId")  )                                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("EvaluationDate") == null || rec_obj.get("EvaluationDate").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("EvaluationDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                          "\"" + ((rec_obj.get("EvaluationValidityDate") == null || rec_obj.get("EvaluationValidityDate").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("EvaluationValidityDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                          "\"" + ((rec_obj.get("EvaluationTextNo") == null)                              ? 0 : rec_obj.get("EvaluationTextNo")  )                                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("EvaluationByWhom") == null)                              ? 0 : rec_obj.get("EvaluationByWhom")  )                                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Evaluation") == null)                                    ? 0 : rec_obj.get("Evaluation")  )                                                  + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PayViaId") == null)                                      ? 0 : rec_obj.get("PayViaId")  )                                                    + "\" "    + ", " +
                           "\"" + ((rec_obj.get("BankIdNumber") == null)                                  ? 0 : rec_obj.get("BankIdNumber")  )                                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AdditionalPurchasingCost") == null)                      ? 0 : rec_obj.get("AdditionalPurchasingCost")  )                                    + "\" "    + ", " +
                           "\"" + ((rec_obj.get("CentralBankCode") == null)                               ? 0 : rec_obj.get("CentralBankCode")  )                                             + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ResponseTimeId") == null)                                ? 0 : rec_obj.get("ResponseTimeId")  )                                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("UseFinalAuthorization") == "false")                      ? 0 : 1 )                                                                           + "\" "    + ", " +
                           "\"" + ((rec_obj.get("InvoiceBasisException") == "false")                      ? 0 : 1 )                                                                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsPrivateSupplier") == "false")                          ? 0 : 1 )                                                                           + "\" "    + ", " +
                           "\"" + ((rec_obj.get("Role") == null)                                          ? 0 : rec_obj.get("Role")  )                                                        + "\" "    + ", " +
                           "\"" + ((rec_obj.get("AttachDatafileWithOrder") == "false")                    ? 0 : 1 )                                                                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AttachDatafileWithPart") == "false")                     ? 0 : 1 )                                                                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AttachDatafileWithAnnualVolume") == "false")             ? 0 : 1 )                                                                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AttachDatafileWithDeliverySchedule") == "false")         ? 0 : 1 )                                                                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AttachDatafileWithComplaint") == "false")                ? 0 : 1 )                                                                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AttachDatafileWithForecast") == "false")                 ? 0 : 1 )                                                                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InquiryReportConfigurationId") == null)                  ? 0 : rec_obj.get("InquiryReportConfigurationId")  )                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PurchaseOrderFormReportConfigurationId") == null)        ? 0 : rec_obj.get("PurchaseOrderFormReportConfigurationId")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SubcontractDeliveryNoteReportConfigurationId") == null)  ? 0 : rec_obj.get("SubcontractDeliveryNoteReportConfigurationId")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SubcontractPurchaseOrderReportConfigurationId") == null) ? 0 : rec_obj.get("SubcontractPurchaseOrderReportConfigurationId")  )               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SubcontractComprehensivePurchaseOrderReportConfigurationId") == null)    ? 0 : rec_obj.get("SubcontractComprehensivePurchaseOrderReportConfigurationId")  )   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SubcontractComprehensiveDeliveryNoteReportConfigurationId") == null)     ? 0 : rec_obj.get("SubcontractComprehensiveDeliveryNoteReportConfigurationId")  )    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SupplierClaimReportConfigurationId") == null)                            ? 0 : rec_obj.get("SupplierClaimReportConfigurationId")  )                           + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ReceivingInspectionType") == null)                                       ? 0 : rec_obj.get("ReceivingInspectionType")  )                                      + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ArrivalReportingInstructionId") == null)                                 ? 0 : rec_obj.get("ArrivalReportingInstructionId")  )                                + "\" "    + ", " +
                           "\"" + ((rec_obj.get("UseOCRNumber") == "false")                                               ? 0 : 1 )                                                                            + "\" "    + ", " +
                           "\"" + ((rec_obj.get("UseReferenceNumber") == "false")                                         ? 0 : 1 )                                                                            + "\" "    + ", " +
                           "\"" + ((rec_obj.get("FixedReferenceNumber") == null)                                          ? 0 : rec_obj.get("FixedReferenceNumber")  )                                         + "\" "    + ", " +
                           "\"" + ((rec_obj.get("EInvoiceId") == null)                                                    ? 0 : rec_obj.get("EInvoiceId")  )                                                   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PurchaseManagerId") == null)                                             ? 0 : rec_obj.get("PurchaseManagerId")  )                                            + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ShippingAgentCode") == null)                                             ? 0 : rec_obj.get("ShippingAgentCode")  )                                            + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DefaultBusinessContactBankAccountId") == null)                           ? 0 : rec_obj.get("DefaultBusinessContactBankAccountId")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OutgoingPaymentsAccountId") == null)                                     ? 0 : rec_obj.get("OutgoingPaymentsAccountId")  )                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PurchaseAccountId") == null)                                             ? 0 : rec_obj.get("PurchaseAccountId")  )                                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AccrualAccountingReverseAccountId") == null)                             ? 0 : rec_obj.get("AccrualAccountingReverseAccountId")  )                            + "\" "    + ", " +
                           "\"" + ((rec_obj.get("IsCasualSupplier") == "false")                                           ? 0 : 1 )                                                                            + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ShippingAgentType") == null)                                             ? 0 : rec_obj.get("ShippingAgentType")  )                                            + "\" "    + ", " +
                           "\"" + ((rec_obj.get("BookTransport") == "false")                                              ? 0 : 1 )                                                                            + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ReturnLabel") == "false")                                                ? 0 : 1 )                                                                            + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ShipmentPrintSetting") == null)                                          ? 0 : rec_obj.get("ShipmentPrintSetting")  )                                         + "\" "    + ", " +
                           "\"" + ((rec_obj.get("StatusId") == null)                                                      ? 0 : rec_obj.get("StatusId")  )                                                     + "\" "    + ", " +
                           "\"" + ((rec_obj.get("TypeId") == null)                                                        ? 0 : rec_obj.get("TypeId")  )                                                       + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DistrictId") == null)                                                    ? 0 : rec_obj.get("DistrictId")  )                                                   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DateForTransitionToActualContact") == null || rec_obj.get("DateForTransitionToActualContact").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("DateForTransitionToActualContact").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                          "\"" + ((rec_obj.get("RootId") == null)                                                        ? Id : rec_obj.get("RootId")  )                                                       + "\" "    + ", " +
                           "\"" + ((rec_obj.get("VisitingAddressId") == null)                                             ? 0 : rec_obj.get("VisitingAddressId")  )                                            + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DefaultReferenceId") == null)                                            ? 0 : rec_obj.get("DefaultReferenceId")  )                                           + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PaymentTermId") == null)                                                 ? 0 : rec_obj.get("PaymentTermId")  )                                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ApplyBankCharge") == "false")                                            ? 0 : 1 )                                                                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BankChargeAmount") == null)                                              ? 0 : rec_obj.get("BankChargeAmount")  )                                             + "\" "    + ", " +
                           "\"" + ((rec_obj.get("BankGiroNo") == null)                                                    ? 0 : rec_obj.get("BankGiroNo")  )                                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DateDisplayFormat") == null)                                             ? 0 : rec_obj.get("DateDisplayFormat")  )                                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DecimalSymbol") == null)                                                 ? 0 : rec_obj.get("DecimalSymbol")  )                                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("TimeZone") == null)                                                      ? 0 : rec_obj.get("TimeZone")  )                                                     + "\" "    + ", " +
                           "\"" + ((rec_obj.get("CategoryString") == null)                                                ? 0 : rec_obj.get("CategoryString")  )                                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CreditLimit") == null)                                                   ? 0 : rec_obj.get("CreditLimit")  )                                                  + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DefaultOrderPrintoutVia") == null)                                       ? 0 : rec_obj.get("DefaultOrderPrintoutVia")  )                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PalletRegistrationNo") == null)                                          ? 0 : rec_obj.get("PalletRegistrationNo")  )                                         + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PlusGiroNo") == null)                                                    ? 0 : rec_obj.get("PlusGiroNo")  )                                                   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("Discount") == null)                                                      ? 0 : rec_obj.get("Discount")  )                                                     + "\" "    + ", " +
                           "\"" + ((rec_obj.get("BlockedFromDate") == null || rec_obj.get("BlockedFromDate").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("BlockedFromDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                           "\"" + ((rec_obj.get("BlockedStatus") == null)                                                 ? 0 : rec_obj.get("BlockedStatus")  )                                                + "\" "    + ", " +
                           "\"" + ((rec_obj.get("BlockMessageId") == null)                                                ? 0 : rec_obj.get("BlockMessageId")  )                                               + "\" "    + ", " +
                           "\"" + ((rec_obj.get("BlockedToDate") == null || rec_obj.get("BlockedToDate").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("BlockedToDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                           "\"" + ((rec_obj.get("BlockedById") == null)                                                   ? 0 : rec_obj.get("BlockedById")  )                                                  + "\" "    + ", " +
                           "\"" + ((rec_obj.get("LanguageId") == null)                                                    ? 0 : rec_obj.get("LanguageId")  )                                                   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("CommentId") == null)                                                     ? 0 : rec_obj.get("CommentId")  )                                                    + "\" "    + ", " +
                           "\"" + ((rec_obj.get("OurCodeByYou") == null)                                                  ? 0 : rec_obj.get("OurCodeByYou")  )                                                 + "\" "    + ", " +
                           "\"" + ((rec_obj.get("Url") == null)                                                           ? 0 : rec_obj.get("Url")  )                                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("CurrencyId") == null)                                                    ? 0 : rec_obj.get("CurrencyId")  )                                                   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DiscountCategoryId") == null)                                            ? 0 : rec_obj.get("DiscountCategoryId")  )                                           + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DeliveryInstruction") == null)                                           ? 0 : rec_obj.get("DeliveryInstruction")  )                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("VatRateId") == null)                                                     ? 0 : rec_obj.get("VatRateId")  )                                                    + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ToleranceForLateDelivery") == null)                                      ? 0 : rec_obj.get("ToleranceForLateDelivery")  )                                     + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ToleranceForEarlyDelivery") == null)                                     ? 0 : rec_obj.get("ToleranceForEarlyDelivery")  )                                    + "\" "    + ", " +
                           "\"" + ((rec_obj.get("Alias") == null)                                                         ? 0 : rec_obj.get("Alias")  )                                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Priority") == null)                                                      ? 0 : rec_obj.get("Priority")  )                                                     + "\" "    + ", " +
                           "\"" + ((rec_obj.get("BlockedContextType") == null)                                            ? 0 : rec_obj.get("BlockedContextType")  )                                           + "\" "    + ", " +
                           "\"" + ((rec_obj.get("IsInternal") == null)                                                    ? 0 : 1 )                                                                            + "\" "    + ", " +
                           "\"" + ((rec_obj.get("CompanyId") == null)                                                     ? 0 : rec_obj.get("CompanyId")  )                                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("MalaysianTaxExemptionId") == null)                                       ? 0 : rec_obj.get("MalaysianTaxExemptionId")  )                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SplitPayment") == "false")                                               ? 0 : 1 )                                                                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BlockAutomaticFinalCodingImportedInvoice") == "false")                   ? 0 : 1 )                                                                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AllowedPriceDifferenceImportedInvoiceEach") == null)                     ? 0 : rec_obj.get("AllowedPriceDifferenceImportedInvoiceEach")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AllowedPriceDifferenceImportedInvoiceEachPercentage") == null)           ? 0 : rec_obj.get("AllowedPriceDifferenceImportedInvoiceEachPercentage")  )          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AllowedAmountDifferenceImportedInvoiceRow") == null)                     ? 0 : rec_obj.get("AllowedAmountDifferenceImportedInvoiceRow")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AllowedAmountDifferenceImportedInvoiceRowPercentage") == null)           ? 0 : rec_obj.get("AllowedAmountDifferenceImportedInvoiceRowPercentage")  )          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AllowedAmountDifferenceImportedInvoiceTotal") == null)                   ? 0 : rec_obj.get("AllowedAmountDifferenceImportedInvoiceTotal")  )                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AllowedAmountDifferenceImportedInvoiceTotalPercentage") == null)         ? 0 : rec_obj.get("AllowedAmountDifferenceImportedInvoiceTotalPercentage")  )        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("TaxMethod") == null)                                                     ? 0 : rec_obj.get("TaxMethod")  )                                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PurchaseDeliveryScheduleFormReportConfigurationId") == null)             ? 0 : rec_obj.get("PurchaseDeliveryScheduleFormReportConfigurationId")  )            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PurchaseVatInfo") == null)                                               ? 0 : rec_obj.get("PurchaseVatInfo")  )                                              + "\" "    + "  " +

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();


                          // 2 UPDATE

                         com_stmt =
                          "Insert into monitordb5.supplierroot (tenant_id , id , " +
                          " SupplierCode , " +
                          " Name , " +
                          " AlternativeName , " +
                          " MailingAddressId , " +
                          " CorporationIdentificationNumber , " +
                          " VatNumber , " +
                          " ServiceTaxNumber , " +
                          " DeliveryAddressId , " +
                          " LastChange   " +

                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("SupplierCode") == null)                              ? 0 : rec_obj.get("SupplierCode")  )                                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Name") == null)                                      ? 0 : rec_obj.get("Name")  )                                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AlternativeName") == null)                           ? 0 : rec_obj.get("AlternativeName")  )                                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("MailingAddressId") == null)                          ? 0 : rec_obj.get("MailingAddressId")  )                                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CorporationIdentificationNumber") == null)           ? 0 : rec_obj.get("CorporationIdentificationNumber")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("VatNumber") == null)                                 ? 0 : rec_obj.get("VatNumber")  )                                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ServiceTaxNumber") == null)                          ? 0 : rec_obj.get("ServiceTaxNumber")  )                                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DeliveryAddressId") == null)                         ? 0 : rec_obj.get("DeliveryAddressId")  )                                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("LastChange") == null)                                ? 0 : rec_obj.get("LastChange")  )                                                  + "\" "    + "  " +

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Supplier was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getSuppliers






    public static String getSupplierStatuses(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Purchase/SupplierStatuses?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".supplierstatus  where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".supplierstatus (tenant_id , id , " +
                          " Code , " +
                          " DescriptionId , " +
                          " Description   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Code") == null)                                   ? 0 : rec_obj.get("Code")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                          ? 0 : rec_obj.get("DescriptionId")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                            ? 0 : rec_obj.get("Description")  )                          + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "SupplierStatus was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getSupplierStatuses




    public static String getSupplierTypes(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Purchase/SupplierTypes?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".suppliertype  where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".suppliertype (tenant_id , id , " +
                          " Code , " +
                          " DescriptionId , " +
                          " Description   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Code") == null)                                   ? 0 : rec_obj.get("Code")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                          ? 0 : rec_obj.get("DescriptionId")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                            ? 0 : rec_obj.get("Description")  )                          + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "SupplierType was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getSupplierTypes



}  // Queries_PUR
