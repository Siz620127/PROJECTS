package sy_my ;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import java.sql.* ;

// import java.sql.Connection;
// import java.sql.Date;
// import java.sql.DriverManager;
// import java.sql.PreparedStatement;
// import java.sql.SQLException;

import java.text.SimpleDateFormat;


public class Loefailid {

    public static Connection getConnection(ReadConf conf) throws Exception {
        // baasiconnecti jaoks
        Connection con;
        try {
            System.out.println("getConnection / getDriver_sy " );
            Class.forName(conf.getDriver_sy());
        } catch (ClassNotFoundException e) {
            throw new Exception("Cannot find jdbc driver class " +
                                conf.getDriver_sy() );
        }
        con = DriverManager.getConnection(conf.getUrl_sy() , conf.getUsername_sy(), conf.getPassword_sy()   );
             // + conf.getDbName_sy()
             // + , conf.getUsername_my(), conf.getPassword_my()   );
        return con;
    }

    public static void Liiguta(ReadConf conf) throws Exception {
        // Meetod liigutab konfiguratsioonifailis conf n�idatud l�htekataloogist FROMDIR k�ik failid sihtkataloogi TODIR
        // ja kirjutab failide sisu baasi tabelisse
        // kui baasi kirjutamine ei �nnestu, siis sihtkataloogi ei liigutata
        // oma t��st teeb tekstifaili logi (konfiguratsioonifailis LOGFILE)
        Connection con         = Loefailid.getConnection(conf);
        PreparedStatement stmt = null;
        String lause           = null;
        boolean edukas         = false;

    //  Statement stmt_1       = null;
        ResultSet rs           = null;

        System.out.println("Liiguta starts " );

        // Source directory
        File kust = new File(conf.getFromDir());
        // Destination directory
        File kuhu = new File(conf.getToDir());
        String[] nimekiri = kust.list();
        String   failinimi;
        SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
        long     lastModified;
        String   kpv;

        // hakkan �kshaaval faile lugema
        for (int i = 0; i < nimekiri.length; i++) {
            failinimi = nimekiri[i];
            System.out.println("Liiguta failinimi "  + failinimi );

            FileInputStream fis = null;
            File algfail  = new File(conf.getFromDir() + "/" + failinimi);
            File loppfail = new File(conf.getToDir()   + "/" + failinimi);
            edukas = false;

            try {
                // loen faili viimase muutmise kuup�eva-kella
                lastModified = algfail.lastModified();
                kpv          = sdf.format(new Date(lastModified));
                byte[] bytes = null;
                fis          = new FileInputStream(algfail);
                bytes        = new byte[fis.available()];
                fis.read(bytes);
                //siin on faili sisu bytes-massiivis
                String sisu  = new String(bytes);

                System.out.println("Liiguta faili sisu "  + sisu );

                // lisan faili baasi
                /*
                lause =
                        "Insert into SULAR.RAHAFAILID (RAHAFAILI_ID,FAILINIMI,SAADUD,PAISEKAART,PLOMM,CREATED,STAATUS,LAADVIGA,KOTI_ID,SISU) " +
                        "values (sular.seq_rahafaili_id.nextval,'" +
                        failinimi + "', sysdate, null, null, to_date('" + kpv +
                        "','DD.MM.YYYY HH24:MI:SS'), 'S', null, null,?)";
                */   

                lause =
                        "Select ID,DepartmentId,DepartmentCode,DepartmentName,TSM  from G5_DEPARTMENTS  " + 
                        "order by DepartmentCode " ;

                //System.out.println( sisu );
                stmt = con.prepareStatement( sisu );  
                // stmt.setObject(1, sisu);
                // stmt.executeUpdate();
                rs = stmt.executeQuery();
                edukas = true;

                // ----------------------------
                // Write to Destination DB
                // ----------------------------
                System.out.println("Liiguta Write to Destination " );

                while (rs.next()) {
                  String str = rs.getString("id") + ":" + rs.getString(2);
                  System.out.println("id:" + str);

                }
                lause =
                        "Insert into G5_DEPARTMENTS  " + 
                        "( ID,DepartmentId,DepartmentCode,DepartmentName,TSM   ) " +
                        "values ( 101,101 ,'java_code_1' ,'java_name_1' , now() ) " ;
                System.out.println("executeUpdate: " + lause );

                stmt = con.prepareStatement( lause );  // lause
                stmt.executeUpdate();

                rs.close();
                stmt.close();

            } catch (IOException e) {
                WriteLog.write(conf.getLogFile(),
                               algfail.getName() + " IO Error while opening file ");
                WriteLog.write(conf.getLogFile(), e.toString(), false);
                //return;
            } catch (SQLException e) {
                WriteLog.write(conf.getLogFile(),
                               algfail.getName() + " SQL Error while inserting into database ");
                WriteLog.write(conf.getLogFile(), e.toString() + lause, false);
            } catch (Exception e) {
                WriteLog.write(conf.getLogFile(),
                               algfail.getName() + " Error while processing file ");
                WriteLog.write(conf.getLogFile(), e.toString(), false);
            } finally {
                if (fis != null) {
                    try {
                        fis.close();
                    } catch (IOException e) {
                        WriteLog.write(conf.getLogFile(),
                                       algfail.getName() + " IO Error while closing file ");
                        WriteLog.write(conf.getLogFile(), e.toString(), false);
                    }
                }
            }
            if (edukas) {
                // Move file to new directory
                boolean success = true;
                success = algfail.renameTo(loppfail);
                if (!success) {
                    // File was not successfully moved
                    WriteLog.write(conf.getLogFile(),
                                   algfail.getName() + " Fail baasi kirjutatud, aga ei �nnestunud liigutada seda kataloogi " +
                                   conf.getToDir());
                } else {
                    WriteLog.write(conf.getLogFile(),
                                   algfail.getName() + " OK");
                }
            }

        }
        // sulgen baasi�henduse
        con.close();
    }

    public static void main(String[] args) throws Exception {
        // loe �ra argumentidest konfiguratsioonifaili asukoht
        String paramfail;
        paramfail = args[0];
        paramfail = "SY_MY.conf";
        //paramfail = "c:/PROJECTS/KLIPFOLIO/src/SY_MY.conf";

        System.out.println("ReadConf: " + paramfail);

        ReadConf conf = new ReadConf(paramfail);
        WriteLog.write(conf.getLogFile(), "", false);
        WriteLog.write(conf.getLogFile(),
                       "=============================  Alustasin laadimist ==============================");
        // kirjuta logisse konfifailist loetud kraam
        WriteLog.write(conf.getLogFile(), conf.toString(), false);
        try {
            System.out.println("Liiguta calling " );
            Liiguta(conf);
        } catch (Exception e) {
            WriteLog.write(conf.getLogFile(), " ERROR ");
            WriteLog.write(conf.getLogFile(), e.toString(), false);
        }

    }


}
