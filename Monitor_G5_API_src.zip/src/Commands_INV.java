package sy_my ;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Scanner;
import org.json.simple.JSONObject;
import org.json.simple.JSONArray;
import org.json.simple.JSONValue;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

// import java.time.*;

// -------

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import java.sql.* ;

// import java.sql.Connection;
// import java.sql.Date;
// import java.sql.DriverManager;
// import java.sql.PreparedStatement;
// import java.sql.SQLException;

import java.text.SimpleDateFormat;


public class Commands_INV {



    // TEST START
    public static HttpURLConnection TestQuery(ReadConf conf) throws Exception {
        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals("185.158.177.241");

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end


             // URL url             = new URL( conf.getUrl_sy() );
             URL url                = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", "185.158.177.241"  );
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", "f1bc5219-b382-472e-adc9-ff0926ecbbb0" );



     	     String json = "{\n";
     		 json += "\"Username\": "     +  "\"ADMIN\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"\" "       + ",\n";
		     json += "\"ForceRelogin\": " +  true          + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( response );

   			     return con ;  // response


                 /*
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parse    = new JSONParser();
                 JSONObject data_obj = (JSONObject) parse.parse( json );  // inline
                 //Get the required object from the above created object
                 JSONObject obj = (JSONObject) data_obj.get("Globale");
                 //Get the required data using its key
                 System.out.println(obj.get("TotalRecovered"));
                 JSONArray arr = (JSONArray) data_obj.get("Countries");
                 for (int i = 0; i < arr.size(); i++) {
                      JSONObject new_obj = (JSONObject) arr.get(i);
                      if (new_obj.get("Slug").equals("albania")) {
                         System.out.println("Total Recovered: " + new_obj.get("TotalRecovered"));
                         break;
                      }
                 }
               */

                }


        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() );
        }
        // return con;
    }

    // TEST END





    public static String postInventoryPartsCreate(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Parts_Create.json");

        System.out.println("InventoryPartsCreate  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Parts/Create"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "InventoryPartsCreate done =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryPartsCreate







    public static String postInventoryPartsAddCustomerPartLink(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Parts_AddCustomerPartLink.json");

        System.out.println("Inventory_Parts_AddCustomerPartLink  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Parts/AddCustomerPartLink"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "AddCustomerPartLink done =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryPartsAddCustomerPartLink





    public static String postInventoryPartsAddDrawing(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Parts_AddDrawing.json");

        System.out.println("Inventory_Parts_AddDrawing  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Parts/AddDrawing"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "AddDrawing done =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryPartsAddDrawing



    public static String postInventoryPartsAddDrawingRevision(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Parts_AddDrawingRevision.json");

        System.out.println("Inventory_Parts_AddDrawingRevision  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Parts/AddDrawingRevision"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "AddDrawingRevision done =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryPartsAddDrawingRevision




    public static String postInventoryPartsAddPartUnitUsage(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Parts_AddPartUnitUsage.json");

        System.out.println("Inventory_Parts_AddPartUnitUsage  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Parts/AddPartUnitUsage"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "AddPartUnitUsage done =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryPartsAddPartUnitUsage




    public static String postInventoryPartsAddRevision(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Parts_AddRevision.json");

        System.out.println("Inventory_Parts_AddRevision  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Parts/AddRevision"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "AddRevision done =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryPartsAddRevision



    public static String postInventoryPartsAddStaggeredSupplierPartLinkPrice(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Parts_AddStaggeredSupplierPartLinkPrice.json");

        System.out.println("Inventory_Parts_AddStaggeredSupplierPartLinkPrice  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Parts/AddStaggeredSupplierPartLinkPrice"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "AddStaggeredSupplierPartLinkPrice done =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryPartsAddStaggeredSupplierPartLinkPrice




    public static String postInventoryPartsAddSupplierPartLink(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Parts_AddSupplierPartLink.json");

        System.out.println("Inventory_Parts_AddSupplierPartLink  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Parts/AddSupplierPartLink"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "AddSupplierPartLink done =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryPartsAddSupplierPartLink




    public static String postInventoryPartsApplyPartTemplate(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Parts_ApplyPartTemplate.json");

        System.out.println("Inventory_Parts_ApplyPartTemplate  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Parts/ApplyPartTemplate"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "ApplyPartTemplate done  =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryPartsApplyPartTemplate




    public static String postInventoryPartsChangeDefaultUnit(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Parts_ChangeDefaultUnit.json");

        System.out.println("Inventory_Parts_ChangeDefaultUnit  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Parts/ChangeDefaultUnit"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "ChangeDefaultUnit done  =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryPartsChangeDefaultUnit




    public static String postInventoryPartsCreateHyperLink(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Parts_CreateHyperLink.json");

        System.out.println("Inventory_Parts_CreateHyperLink  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Parts/CreateHyperLink"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code
             /*
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);
             */


             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");
               /*
                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);
                */

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "CreateHyperLink done  =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryPartsCreateHyperLink




    public static String postInventoryPartsCreateLocation(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Parts_CreateLocation.json");

        System.out.println("Inventory_Parts_CreateLocation  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Parts/CreateLocation"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code
             /*
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);
             */


             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "CreateLocation done  =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryPartsCreateLocation






    public static String postInventoryPartsCreatePartOtherIdentity(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Parts_CreatePartOtherIdentity.json");

        System.out.println("Inventory_Parts_CreatePartOtherIdentity  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Parts/CreatePartOtherIdentity"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "CreatePartOtherIdentity done  =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryPartsCreatePartOtherIdentity




    public static String postInventoryPartsGetFromPartLocations(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Parts_GetFromPartLocations.json");

        System.out.println("Inventory_Parts_GetFromPartLocations  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Parts/GetFromPartLocations"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Name") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Key") != "111" ) {
                         System.out.println("Id: " + Id );
                         }
                 }



                 //Get the required object from the above created object
                 //Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 //String sesId = obj.toString() ;
                 //Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  Id );

                 WriteLog.write(conf.getLogFile(), "GetFromPartLocations done  =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryPartsGetFromPartLocations





    public static String postInventoryPartsGetPartBalanceInfo(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Parts_GetPartBalanceInfo.json");

        System.out.println("Inventory_Parts_GetPartBalanceInfo  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Parts/GetPartBalanceInfo"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("CurrentBalance");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "GetPartBalanceInfo done  =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryPartsGetPartBalanceInfo





    public static String postInventoryPartsGetToPartLocations(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Parts_GetToPartLocations.json");

        System.out.println("Inventory_Parts_GetToPartLocations  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Parts/GetToPartLocations"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Name") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Key") != "111" ) {
                         System.out.println("Id: " + Id );
                         }
                 }



                 //Get the required object from the above created object
                 //Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 //String sesId = obj.toString() ;
                 //Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  Id );

                 WriteLog.write(conf.getLogFile(), "GetToPartLocations done  =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryPartsGetToPartLocations







    public static String postInventoryPartsRemoveCustomerPartLink(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Parts_RemoveCustomerPartLink.json");

        System.out.println("Inventory_Parts_RemoveCustomerPartLink  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Parts/RemoveCustomerPartLink"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "RemoveCustomerPartLink done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryPartsRemoveCustomerPartLink








    public static String postInventoryPartsRemoveDrawing(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Parts_RemoveDrawing.json");

        System.out.println("Inventory_Parts_RemoveDrawing  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Parts/RemoveDrawing"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "RemoveDrawing done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryPartsRemoveDrawing




    public static String postInventoryPartsRemoveDrawingRevision(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Parts_RemoveDrawingRevision.json");

        System.out.println("Inventory_Parts_RemoveDrawingRevision  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Parts/RemoveDrawingRevision"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "RemoveDrawingRevision done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryPartsRemoveDrawingRevision




    public static String postInventoryPartsRemoveHyperLink(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Parts_RemoveHyperLink.json");

        System.out.println("Inventory_Parts_RemoveHyperLink  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Parts/RemoveHyperLink"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "RemoveHyperLink done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryPartsRemoveHyperLink





    public static String postInventoryPartsRemoveLocation(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Parts_RemoveLocation.json");

        System.out.println("Inventory_Parts_RemoveLocation  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Parts/RemoveLocation"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);



             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "RemoveLocation done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryPartsRemoveLocation





    public static String postInventoryPartsRemovePartOtherIdentity(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Parts_RemovePartOtherIdentity.json");

        System.out.println("Inventory_Parts_RemovePartOtherIdentity  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Parts/RemovePartOtherIdentity"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "RemovePartOtherIdentity done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryPartsRemovePartOtherIdentity




    public static String postInventoryPartsRemovePartUnitUsage(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Parts_RemovePartUnitUsage.json");

        System.out.println("Inventory_Parts_RemovePartUnitUsage  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Parts/RemovePartUnitUsage"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "RemovePartUnitUsage done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryPartsRemovePartUnitUsage




    public static String postInventoryPartsRemoveRevision(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Parts_RemoveRevision.json");

        System.out.println("Inventory_Parts_RemoveRevision  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Parts/RemoveRevision"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "RemoveRevision done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryPartsRemoveRevision






    public static String postInventoryPartsRemoveStaggeredSupplierPartLinkPrice(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Parts_RemoveStaggeredSupplierPartLinkPrice.json");

        System.out.println("Inventory_Parts_RemoveStaggeredSupplierPartLinkPrice  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Parts/RemoveStaggeredSupplierPartLinkPrice"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "RemoveStaggeredSupplierPartLinkPrice done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryPartsRemoveStaggeredSupplierPartLinkPrice





    public static String postInventoryPartsRemoveSupplierPartLink(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Parts_RemoveSupplierPartLink.json");

        System.out.println("Inventory_Parts_RemoveSupplierPartLink  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Parts/RemoveSupplierPartLink"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "RemoveSupplierPartLink done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryPartsRemoveSupplierPartLink




    public static String postInventoryPartsReportStockCount(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Parts_ReportStockCount.json");

        System.out.println("Inventory_Parts_ReportStockCount  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Parts/ReportStockCount"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "ReportStockCount done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryPartsReportStockCount





    public static String postInventoryPartsSaveAs(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Parts_SaveAs.json");

        System.out.println("Inventory_Parts_SaveAs  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Parts/SaveAs"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "SaveAs done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryPartsSaveAs



    public static String postInventoryPartsSetActiveDrawingRevision(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Parts_SetActiveDrawingRevision.json");

        System.out.println("Inventory_Parts_SetActiveDrawingRevision  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Parts/SetActiveDrawingRevision"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "SetActiveDrawingRevision done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryPartsSetActiveDrawingRevision




    public static String postInventoryPartsSetActiveRevision(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Parts_SetActiveRevision.json");

        System.out.println("Inventory_Parts_SetActiveRevision  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Parts/SetActiveRevision"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "SetActiveRevision done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryPartsSetActiveRevision



    public static String postInventoryPartsSetActiveSupplierPartLink(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Parts_SetActiveSupplierPartLink.json");

        System.out.println("Inventory_Parts_SetActiveSupplierPartLink  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Parts/SetActiveSupplierPartLink"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "SetActiveSupplierPartLink done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryPartsSetActiveSupplierPartLink



    public static String postInventoryPartsSetProperties(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Parts_SetProperties.json");

        System.out.println("Inventory_Parts_SetProperties  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Parts/SetProperties"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "SetProperties done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryPartsSetProperties



    public static String postInventoryPartsUnplannedArrivalStockMovement(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Parts_UnplannedArrivalStockMovement.json");

        System.out.println("Inventory_Parts_UnplannedArrivalStockMovement  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Parts/UnplannedArrivalStockMovement"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "UnplannedArrivalStockMovement done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryPartsUnplannedArrivalStockMovement




    public static String postInventoryPartsUnplannedWithdrawalStockMovement(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Parts_UnplannedWithdrawalStockMovement.json");

        System.out.println("Inventory_Parts_UnplannedWithdrawalStockMovement  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Parts/UnplannedWithdrawalStockMovement"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "UnplannedWithdrawalStockMovement done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryPartsUnplannedWithdrawalStockMovement



    public static String postInventoryPartsUpdateCustomerPartLink(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Parts_UpdateCustomerPartLink.json");

        System.out.println("Inventory_Parts_UpdateCustomerPartLink  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Parts/UpdateCustomerPartLink"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "UpdateCustomerPartLink done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryPartsUpdateCustomerPartLink




    public static String postInventoryPartsUpdateDescription(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Parts_UpdateDescription.json");

        System.out.println("Inventory_Parts_UpdateDescription  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Parts/UpdateDescription"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "UpdateDescription done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryPartsUpdateDescription




    public static String postInventoryPartsUpdateDrawing(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Parts_UpdateDrawing.json");

        System.out.println("Inventory_Parts_UpdateDrawing  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Parts/UpdateDrawing"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "UpdateDrawing done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryPartsUpdateDrawing




    public static String postInventoryPartsUpdateDrawingRevision(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Parts_UpdateDrawingRevision.json");

        System.out.println("Inventory_Parts_UpdateDrawingRevision  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Parts/UpdateDrawingRevision"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "UpdateDrawingRevision done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryPartsUpdateDrawingRevision





    public static String postInventoryPartsUpdateHyperLink(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Parts_UpdateHyperLink.json");

        System.out.println("Inventory_Parts_UpdateHyperLink  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Parts/UpdateHyperLink"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "UpdateHyperLink done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryPartsUpdateHyperLink






    public static String postInventoryPartsUpdateLocation(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Parts_UpdateLocation.json");

        System.out.println("Inventory_Parts_UpdateLocation  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Parts/UpdateLocation"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "UpdateLocation done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryPartsUpdateLocation





    public static String postInventoryPartsUpdatePartBlockedStatus(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Parts_UpdatePartBlockedStatus.json");

        System.out.println("Inventory_Parts_UpdatePartBlockedStatus  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Parts/UpdatePartBlockedStatus"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "UpdatePartBlockedStatus done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryPartsUpdatePartBlockedStatus






    public static String postInventoryPartsUpdatePartOtherIdentity(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Parts_UpdatePartOtherIdentity.json");

        System.out.println("Inventory_Parts_UpdatePartOtherIdentity  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Parts/UpdatePartOtherIdentity"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "UpdatePartOtherIdentity done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryPartsUpdatePartOtherIdentity




    public static String postInventoryPartsUpdatePartPlanningInformation(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Parts_UpdatePartPlanningInformation.json");

        System.out.println("Inventory_Parts_UpdatePartPlanningInformation  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Parts/UpdatePartPlanningInformation"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "UpdatePartPlanningInformation done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryPartsUpdatePartPlanningInformation




    public static String postInventoryPartsUpdatePartPurchaseExpenseValues(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Parts_UpdatePartPurchaseExpenseValues.json");

        System.out.println("Inventory_Parts_UpdatePartPurchaseExpenseValues  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Parts/UpdatePartPurchaseExpenseValues"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "UpdatePartPurchaseExpenseValues done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryPartsUpdatePartPurchaseExpenseValues





    public static String postInventoryPartsUpdatePartUnitUsage(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Parts_UpdatePartUnitUsage.json");

        System.out.println("Inventory_Parts_UpdatePartUnitUsage  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Parts/UpdatePartUnitUsage"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "UpdatePartUnitUsage done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryPartsUpdatePartUnitUsage




    public static String postInventoryPartsUpdateRevision(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Parts_UpdateRevision.json");

        System.out.println("Inventory_Parts_UpdateRevision  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Parts/UpdateRevision"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "UpdateRevision done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryPartsUpdateRevision




    public static String postInventoryPartsUpdateStaggeredSupplierPartLinkPrice(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Parts_UpdateStaggeredSupplierPartLinkPrice.json");

        System.out.println("Inventory_Parts_UpdateStaggeredSupplierPartLinkPrice  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Parts/UpdateStaggeredSupplierPartLinkPrice"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "UpdateStaggeredSupplierPartLinkPrice done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryPartsUpdateStaggeredSupplierPartLinkPrice




    public static String postInventoryPartsUpdateSupplierPartLink(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Parts_UpdateSupplierPartLink.json");

        System.out.println("Inventory_Parts_UpdateSupplierPartLink  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Parts/UpdateSupplierPartLink"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "UpdateSupplierPartLink done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryPartsUpdateSupplierPartLink





    public static String postInventoryProductRecordsChangeOwner(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_ProductRecords_ChangeOwner.json");

        System.out.println("Inventory_ProductRecords_ChangeOwner  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/ProductRecords/ChangeOwner"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "ProductRecordsChangeOwner done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryProductRecordsChangeOwner




    public static String postInventoryProductRecordsCreate(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_ProductRecords_Create.json");

        System.out.println("Inventory_ProductRecords_Create  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/ProductRecords/Create"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "ProductRecords_Create done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryProductRecordsCreate






    public static String postInventoryProductRecordsGetPartLocations(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_ProductRecords_GetPartLocations.json");

        System.out.println("Inventory_ProductRecords_GetPartLocations  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/ProductRecords/GetPartLocations"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "GetPartLocations done. " + rs_count + " records "   , true);



                 //Get the required object from the above created object
                 // Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 // String sesId = obj.toString() ;
                 // Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 // System.out.println("obj  \n " +  sesId );

                 // WriteLog.write(conf.getLogFile(), "ProductRecords_GetPartLocations done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryProductRecordsGetPartLocations



    public static String postInventoryProductRecordsGetStructure(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_ProductRecords_GetStructure.json");

        System.out.println("Inventory_ProductRecords_GetStructure  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/ProductRecords/GetStructure"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "GetStructure done. " + rs_count + " records "   , true);



                 //Get the required object from the above created object
                 // Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 // String sesId = obj.toString() ;
                 // Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 // System.out.println("obj  \n " +  sesId );

                 // WriteLog.write(conf.getLogFile(), "ProductRecords_GetStructure done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryProductRecordsGetStructure




    public static String postInventoryProductRecordsRename(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_ProductRecords_Rename.json");

        System.out.println("Inventory_ProductRecords_Rename  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/ProductRecords/Rename"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "ProductRecords_Rename done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryProductRecordsRename






    public static String postInventoryProductRecordsReportReading(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_ProductRecords_ReportReading.json");

        System.out.println("Inventory_ProductRecords_ReportReading  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/ProductRecords/ReportReading"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "ProductRecords_ReportReading done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryProductRecordsReportReading




    public static String postInventoryProductRecordsSetLifeCycle(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_ProductRecords_SetLifeCycle.json");

        System.out.println("Inventory_ProductRecords_SetLifeCycle  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/ProductRecords/SetLifeCycle"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "ProductRecords_SetLifeCycle done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryProductRecordsSetLifeCycle





    public static String postInventoryProductRecordsSetManufacturingOrder(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_ProductRecords_SetManufacturingOrder.json");

        System.out.println("Inventory_ProductRecords_SetManufacturingOrder  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/ProductRecords/SetManufacturingOrder"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "ProductRecords_SetManufacturingOrder done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryProductRecordsSetManufacturingOrder




    public static String postInventoryProductRecordsSetProperties(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_ProductRecords_SetProperties.json");

        System.out.println("Inventory_ProductRecords_SetProperties  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/ProductRecords/SetProperties"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "ProductRecords_SetProperties done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryProductRecordsSetProperties





    public static String postInventoryProductRecordsUpdateDeliveryAddress(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_ProductRecords_UpdateDeliveryAddress.json");

        System.out.println("Inventory_ProductRecords_UpdateDeliveryAddress  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/ProductRecords/UpdateDeliveryAddress"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "ProductRecords_UpdateDeliveryAddress done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryProductRecordsUpdateDeliveryAddress






    public static String postInventoryCommandsSetCaseEntryManufacturingOrder(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Commands_SetCaseEntryManufacturingOrder.json");

        System.out.println("Inventory_Commands_SetCaseEntryManufacturingOrder  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Commands/SetCaseEntryManufacturingOrder"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Commands_SetCaseEntryManufacturingOrder done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryCommandsSetCaseEntryManufacturingOrder





    public static String postInventoryCommandsSetCaseEntryPart(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Commands_SetCaseEntryPart.json");

        System.out.println("Inventory_Commands_SetCaseEntryPart  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Commands/SetCaseEntryPart"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Commands_SetCaseEntryPart done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryCommandsSetCaseEntryPart





    public static String postInventoryCommandsSetCaseEntryProductRecord(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_Commands_SetCaseEntryProductRecord.json");

        System.out.println("Inventory_Commands_SetCaseEntryProductRecord  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Commands/SetCaseEntryProductRecord"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Commands_SetCaseEntryProductRecord done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryCommandsSetCaseEntryProductRecord




    public static String postInventoryCaseEntryAdditionalCostCreateCaseEntryAdditionalCost(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_CaseEntryAdditionalCost_CreateCaseEntryAdditionalCost.json");

        System.out.println("Inventory_CaseEntryAdditionalCost_CreateCaseEntryAdditionalCost  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/CaseEntryAdditionalCost/CreateCaseEntryAdditionalCost"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "CaseEntryAdditionalCost_CreateCaseEntryAdditionalCost done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryCaseEntryAdditionalCostCreateCaseEntryAdditionalCost




    public static String postInventoryCaseEntryAdditionalCostUpdateCaseEntryAdditionalCost(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_CaseEntryAdditionalCost_UpdateCaseEntryAdditionalCost.json");

        System.out.println("Inventory_CaseEntryAdditionalCost_UpdateCaseEntryAdditionalCost  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/CaseEntryAdditionalCost/UpdateCaseEntryAdditionalCost"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "CaseEntryAdditionalCost_UpdateCaseEntryAdditionalCost done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryCaseEntryAdditionalCostUpdateCaseEntryAdditionalCost




    public static String postInventoryCaseEntryAddCommunicationAddress(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_CaseEntry_AddCommunicationAddress.json");

        System.out.println("Inventory_CaseEntry_AddCommunicationAddress  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/CaseEntry/AddCommunicationAddress"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "CaseEntry_AddCommunicationAddress done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryCaseEntryAddCommunicationAddress





    public static String postInventoryCaseEntryChangeNumber(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_CaseEntry_ChangeNumber.json");

        System.out.println("Inventory_CaseEntry_ChangeNumber  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/CaseEntry/ChangeNumber"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "CaseEntry_ChangeNumber done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryCaseEntryChangeNumber






    public static String postInventoryCaseEntryCreate(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_CaseEntry_Create.json");

        System.out.println("Inventory_CaseEntry_Create  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/CaseEntry/Create"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "CaseEntry_Create done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryCaseEntryCreate




    public static String postInventoryCaseEntryCreateFormReport(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_CaseEntry_CreateFormReport.json");

        System.out.println("Inventory_CaseEntry_CreateFormReport  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/CaseEntry/CreateFormReport"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("Name");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "CaseEntry_CreateFormReport done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( not UNIQUE record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryCaseEntryCreateFormReport





    public static String postInventoryCaseEntryRemove(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_CaseEntry_Remove.json");

        System.out.println("Inventory_CaseEntry_Remove  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/CaseEntry/Remove"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "CaseEntry_Remove done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryCaseEntryRemove





    public static String postInventoryCaseEntrySetProperties(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_CaseEntry_SetProperties.json");

        System.out.println("Inventory_CaseEntry_SetProperties  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/CaseEntry/SetProperties"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "CaseEntry_SetProperties done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryCaseEntrySetProperties






    public static String postInventoryCaseEntriesCreateActivity(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_CaseEntries_CreateActivity.json");

        System.out.println("Inventory_CaseEntries_CreateActivity  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/CaseEntries/CreateActivity"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "CaseEntries_CreateActivity done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryCaseEntriesCreateActivity






    public static String postInventoryCaseEntriesCreatePhase(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_CaseEntries_CreatePhase.json");

        System.out.println("Inventory_CaseEntries_CreatePhase  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/CaseEntries/CreatePhase"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "CaseEntries_CreatePhase done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryCaseEntriesCreatePhase







    public static String postInventoryCaseEntriesRemoveActivity(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_CaseEntries_RemoveActivity.json");

        System.out.println("Inventory_CaseEntries_RemoveActivity  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/CaseEntries/RemoveActivity"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "CaseEntries_RemoveActivity done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryCaseEntriesRemoveActivity






    public static String postInventoryCaseEntriesRemovePhase(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_CaseEntries_RemovePhase.json");

        System.out.println("Inventory_CaseEntries_RemovePhase  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/CaseEntries/RemovePhase"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "CaseEntries_RemovePhase done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryCaseEntriesRemovePhase





    public static String postInventoryCaseEntriesSetReplacementDelivery(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_CaseEntries_SetReplacementDelivery.json");

        System.out.println("Inventory_CaseEntries_SetReplacementDelivery  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/CaseEntries/SetReplacementDelivery"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "CaseEntries_SetReplacementDelivery done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryCaseEntriesSetReplacementDelivery





    public static String postInventoryCaseEntriesUpdateActivity(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_CaseEntries_UpdateActivity.json");

        System.out.println("Inventory_CaseEntries_UpdateActivity  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/CaseEntries/UpdateActivity"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "CaseEntries_UpdateActivity done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryCaseEntriesUpdateActivity





    public static String postInventoryCaseEntriesUpdatePhase(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_CaseEntries_UpdatePhase.json");

        System.out.println("Inventory_CaseEntries_UpdatePhase  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/CaseEntries/UpdatePhase"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "CaseEntries_UpdatePhase done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventoryCaseEntriesUpdatePhase






    public static String postInventorySalesForecastsAddRow(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_SalesForecasts_AddRow.json");

        System.out.println("Inventory_SalesForecasts_AddRow  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/SalesForecasts/AddRow"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "SalesForecasts_AddRow done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventorySalesForecastsAddRow





    public static String postInventorySalesForecastsCreate(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_SalesForecasts_Create.json");

        System.out.println("Inventory_SalesForecasts_Create  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/SalesForecasts/Create"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "SalesForecasts_Create done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventorySalesForecastsCreate





    public static String postInventorySalesForecastsRemove(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_SalesForecasts_Remove.json");

        System.out.println("Inventory_SalesForecasts_Remove  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/SalesForecasts/Remove"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "SalesForecasts_Remove done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventorySalesForecastsRemove



    public static String postInventorySalesForecastsRemoveRow(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_SalesForecasts_RemoveRow.json");

        System.out.println("Inventory_SalesForecasts_RemoveRow  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/SalesForecasts/RemoveRow"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "SalesForecasts_RemoveRow done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventorySalesForecastsRemoveRow




    public static String postInventorySalesForecastsSetProperties(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_SalesForecasts_SetProperties.json");

        System.out.println("Inventory_SalesForecasts_SetProperties  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/SalesForecasts/SetProperties"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "SalesForecasts_SetProperties done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventorySalesForecastsSetProperties



    public static String postInventorySalesForecastsUpdateRow(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Inventory_SalesForecasts_UpdateRow.json");

        System.out.println("Inventory_SalesForecasts_UpdateRow  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/SalesForecasts/UpdateRow"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "SalesForecasts_UpdateRow done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postInventorySalesForecastsUpdateRow







}  // Commands_INV
