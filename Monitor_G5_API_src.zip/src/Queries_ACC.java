package sy_my ;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Scanner;
import org.json.simple.JSONObject;
import org.json.simple.JSONArray;
import org.json.simple.JSONValue;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

// -------

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import java.sql.* ;

// import java.sql.Connection;
// import java.sql.Date;
// import java.sql.DriverManager;
// import java.sql.PreparedStatement;
// import java.sql.SQLException;

import java.text.SimpleDateFormat;


public class Queries_ACC {



    // TEST START
    public static HttpURLConnection TestQuery(ReadConf conf) throws Exception {
        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals("185.158.177.241");

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end


             // URL url             = new URL( conf.getUrl_sy() );
             URL url                = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", "185.158.177.241"  );
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", "f1bc5219-b382-472e-adc9-ff0926ecbbb0" );



     	     String json = "{\n";
     		 json += "\"Username\": "     +  "\"ADMIN\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"\" "       + ",\n";
		     json += "\"ForceRelogin\": " +  true          + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( response );

   			     return con ;  // response


                 /*
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parse    = new JSONParser();
                 JSONObject data_obj = (JSONObject) parse.parse( json );  // inline
                 //Get the required object from the above created object
                 JSONObject obj = (JSONObject) data_obj.get("Globale");
                 //Get the required data using its key
                 System.out.println(obj.get("TotalRecovered"));
                 JSONArray arr = (JSONArray) data_obj.get("Countries");
                 for (int i = 0; i < arr.size(); i++) {
                      JSONObject new_obj = (JSONObject) arr.get(i);
                      if (new_obj.get("Slug").equals("albania")) {
                         System.out.println("Total Recovered: " + new_obj.get("TotalRecovered"));
                         break;
                      }
                 }
               */

                }


        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() );
        }
        // return con;
    }

    // TEST END





    public static String getAccountingYearPeriods(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Accounting/AccountingYearPeriods?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".accountingyearperiod where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".accountingyearperiod (tenant_id , id , " +
                          " FromDate , " +
                          " ToDate , " +
                          " Number , " +
                          " Status , " +
                          " AccountingYearId , " +
                          " AccountingYear   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("FromDate") == null      || rec_obj.get("FromDate").toString().substring(0,2).equals("00")  )      ? new Date(2021000000) : rec_obj.get("FromDate").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("ToDate") == null        || rec_obj.get("ToDate").toString().substring(0,2).equals("00")  )        ? new Date(2021000000) : rec_obj.get("ToDate").toString().substring(0,19).replace('T', ' ')  )        + "\" " + ", " +
                          "\"" + ((rec_obj.get("Number") == null)                ? 0 : rec_obj.get("Number")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Status") == null)                ? 0 : rec_obj.get("Status")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AccountingYearId") == null)      ? 0 : rec_obj.get("AccountingYearId")  )       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AccountingYear") == null)        ? 0 : rec_obj.get("AccountingYear")  )         + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "AccountingYearPeriod was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getAccountingYearPeriods




    public static String getAccountingYears(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Accounting/AccountingYears?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".accountingyear where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".accountingyear (tenant_id , id , " +
                          " ActivePeriodId , " +
                          " Description , " +
                          " Status , " +
                          " OpeningBalanceLocked  " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("ActivePeriodId") == null)                ? 0 : rec_obj.get("ActivePeriodId")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                   ? 0 : rec_obj.get("Description")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Status") == null)                        ? 0 : rec_obj.get("Status")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OpeningBalanceLocked") == "false")       ? 0 : 1  )                                             + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "AccountingYear was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getAccountingYears




    public static String getAccounts(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Accounting/Accounts"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".account where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".account (tenant_id , id , " +
                          " Number, " +
                          " Type " +

                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                           "\"" + ((rec_obj.get("Number") == null) ? 0 : rec_obj.get("Number")  )    + "\" "    + ", " +
                           "\"" + ((rec_obj.get("Type") == null)   ? 0 : rec_obj.get("Type")  )      + "\" "    + "  " +

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Account was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getAccounts




    public static String getAccountsPayables(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Accounting/AccountsPayables?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".accountspayable where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".accountspayable (tenant_id , id , " +
                          " Version , " +
                          " CancelCommentId , " +
                          " PaymentMethodId , " +
                          " LanguageId , " +
                          " SuppliersInvoiceNumber , " +
                          " InvoiceType , " +
                          " IsCredit , " +
                          " PreBookingId , " +
                          " FinalBookingId , " +
                          " PreliminaryBookingId , " +
                          " CancelBookingId , " +
                          " IsFinalBooked , " +
                          " FinalBookedByUserId , " +
                          " FinalBookingTimeStamp , " +
                          " PurchaseOrderId , " +
                          " WarehouseId , " +
                          " PreliminaryBookingDate , " +
                          " VoucherDate , " +
                          " CancelVoucherDate , " +
                          " SupplierAccountGroupId , " +
                          " AuthorizedSignerId , " +
                          " AuthorizationListId , " +
                          " PaymentVia , " +
                          " CountryId , " +
                          " Status , " +
                          " BankAccountId , " +
                          " BlockMessageId , " +
                          " OnAccountOutgoingPaymentLedgerId , " +
                          " OnAccountCancelledOutgoingPaymentLedgerId , " +
                          " NextPaymentSubNumber , " +
                          " InvoiceImportInformationId , " +
                          " OCRNumber , " +
                          " UseOCRNumber , " +
                          " CreditedAccountsPayableId , " +
                          " BlockedById , " +
                          " BlockedFromDate , " +
                          " BlockedToDate , " +
                          " BlockedStatus , " +
                          " BlockedContextType , " +
                          " LegacyLogDiff , " +
                          " HasEimInvoice , " +
                          " HoldEimInvoice , " +
                          " AccountsPayableLedgerId , " +
                          " CancelledAccountsPayableLedgerId , " +
                          " CancelledPreliminaryAccountsPayableLedgerId , " +
                          " PreliminaryAccountsPayableLedgerId , " +
                          " EimInvoiceStatus , " +
                          " HasImportExportDeclaration , " +
                          " ImportExportDeclarationId , " +
                          " BusinessContactId , " +
                          " InvoiceNumber , " +
                          " InvoiceDate , " +
                          " DueDate , " +
                          " InvoiceAmount , " +
                          " InvoiceAmountCurrencyId , " +
                          " InvoiceAmountInCompanyCurrency , " +
                          " InvoiceAmountInCompanyCurrencyCurrencyId , " +
                          " VatAmount , " +
                          " VatAmountCurrencyId , " +
                          " VatAmountInCompanyCurrency , " +
                          " VatAmountInCompanyCurrencyCurrencyId , " +
                          " RestAmount , " +
                          " RestAmountCurrencyId , " +
                          " RestAmountInCompanyCurrency , " +
                          " RestAmountInCompanyCurrencyCurrencyId , " +
                          " OrderedRestAmount , " +
                          " OrderedRestAmountCurrencyId , " +
                          " CurrencyId , " +
                          " ExchangeRate , " +
                          " PaidInFullDate , " +
                          " CommentId , " +
                          " OnAccountBundleNumber , " +
                          " OnAccountPaymentMethodId , " +
                          " OnAccountVoucherText , " +
                          " ReferenceNumber , " +
                          " UseFixedDueDate , " +
                          " VatGroupId , " +
                          " PaymentTermId , " +
                          " UseReferenceNumber , " +
                          " ReceptionDate , " +
                          " ImportedInvoiceId , " +
                          " SplitPayment , " +
                          " VatSupplierId , " +
                          " WorkflowStatus , " +
                          " InputVatDate , " +
                          " OutputVatDate , " +
                          " MarginInvoice , " +
                          " OnAccountJointPaymentLedgerId , " +
                          " CancelledOnAccountJointPaymentLedgerId , " +
                          " OverrideOnAccountJointPaymentVoucherSeriesId   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Version") == null)                                       ? 0 : rec_obj.get("Version")  )                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CancelCommentId") == null)                               ? 0 : rec_obj.get("CancelCommentId")  )                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PaymentMethodId") == null)                               ? 0 : rec_obj.get("PaymentMethodId")  )                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("LanguageId") == null)                                    ? 0 : rec_obj.get("LanguageId")  )                                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SuppliersInvoiceNumber") == null)                        ? 0 : rec_obj.get("SuppliersInvoiceNumber")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InvoiceType") == null)                                   ? 0 : rec_obj.get("InvoiceType")  )                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsCredit") == "false")                                   ? 0 : 1  )                                                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PreBookingId") == null)                                  ? 0 : rec_obj.get("PreBookingId")  )                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("FinalBookingId") == null)                                ? 0 : rec_obj.get("FinalBookingId")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PreliminaryBookingId") == null)                          ? 0 : rec_obj.get("PreliminaryBookingId")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CancelBookingId") == null)                               ? 0 : rec_obj.get("CancelBookingId")  )                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsFinalBooked") == "false")                              ? 0 : 1  )                                                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("FinalBookedByUserId") == null)                           ? 0 : rec_obj.get("FinalBookedByUserId")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("FinalBookingTimeStamp") == null      || rec_obj.get("FinalBookingTimeStamp").toString().substring(0,2).equals("00")  )          ? new Date(2021000000) : rec_obj.get("FinalBookingTimeStamp").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("PurchaseOrderId") == null)                               ? 0 : rec_obj.get("PurchaseOrderId")  )                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("WarehouseId") == null)                                   ? 0 : rec_obj.get("WarehouseId")  )                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PreliminaryBookingDate") == null     || rec_obj.get("PreliminaryBookingDate").toString().substring(0,2).equals("00")  )         ? new Date(2021000000) : rec_obj.get("PreliminaryBookingDate").toString().substring(0,19).replace('T', ' ')  )     + "\" " + ", " +
                          "\"" + ((rec_obj.get("VoucherDate") == null                || rec_obj.get("VoucherDate").toString().substring(0,2).equals("00")  )                    ? new Date(2021000000) : rec_obj.get("VoucherDate").toString().substring(0,19).replace('T', ' ')  )                + "\" " + ", " +
                          "\"" + ((rec_obj.get("CancelVoucherDate") == null          || rec_obj.get("CancelVoucherDate").toString().substring(0,2).equals("00")  )              ? new Date(2021000000) : rec_obj.get("CancelVoucherDate").toString().substring(0,19).replace('T', ' ')  )          + "\" " + ", " +
                          "\"" + ((rec_obj.get("SupplierAccountGroupId") == null)                        ? 0 : rec_obj.get("SupplierAccountGroupId")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AuthorizedSignerId") == null)                            ? 0 : rec_obj.get("AuthorizedSignerId")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AuthorizationListId") == null)                           ? 0 : rec_obj.get("AuthorizationListId")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PaymentVia") == null)                                    ? 0 : rec_obj.get("PaymentVia")  )                                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CountryId") == null)                                     ? 0 : rec_obj.get("CountryId")  )                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Status") == null)                                        ? 0 : rec_obj.get("Status")  )                                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BankAccountId") == null)                                 ? 0 : rec_obj.get("BankAccountId")  )                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BlockMessageId") == null)                                ? 0 : rec_obj.get("BlockMessageId")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OnAccountOutgoingPaymentLedgerId") == null)              ? 0 : rec_obj.get("OnAccountOutgoingPaymentLedgerId")  )               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OnAccountCancelledOutgoingPaymentLedgerId") == null)     ? 0 : rec_obj.get("OnAccountCancelledOutgoingPaymentLedgerId")  )      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("NextPaymentSubNumber") == null)                          ? 0 : rec_obj.get("NextPaymentSubNumber")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InvoiceImportInformationId") == null)                    ? 0 : rec_obj.get("InvoiceImportInformationId")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OCRNumber") == null)                                     ? 0 : rec_obj.get("OCRNumber")  )                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("UseOCRNumber") == "false")                               ? 0 : 1  )                                                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CreditedAccountsPayableId") == null)                     ? 0 : rec_obj.get("CreditedAccountsPayableId")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BlockedById") == null)                                   ? 0 : rec_obj.get("BlockedById")  )                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BlockedFromDate") == null            || rec_obj.get("BlockedFromDate").toString().substring(0,2).equals("00")  )                ? new Date(2021000000) : rec_obj.get("BlockedFromDate").toString().substring(0,19).replace('T', ' ')  )                + "\" " + ", " +
                          "\"" + ((rec_obj.get("BlockedToDate") == null              || rec_obj.get("BlockedToDate").toString().substring(0,2).equals("00")  )                  ? new Date(2021000000) : rec_obj.get("BlockedToDate").toString().substring(0,19).replace('T', ' ')  )                  + "\" " + ", " +
                          "\"" + ((rec_obj.get("BlockedStatus") == null)                                 ? 0 : rec_obj.get("BlockedStatus")  )                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BlockedContextType") == null)                            ? 0 : rec_obj.get("BlockedContextType")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("LegacyLogDiff") == null)                                 ? 0 : rec_obj.get("LegacyLogDiff")  )                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("HasEimInvoice") == "false")                              ? 0 : 1  )                                                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("HoldEimInvoice") == "false")                             ? 0 : 1  )                                                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AccountsPayableLedgerId") == null)                       ? 0 : rec_obj.get("AccountsPayableLedgerId")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CancelledAccountsPayableLedgerId") == null)              ? 0 : rec_obj.get("CancelledAccountsPayableLedgerId")  )               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CancelledPreliminaryAccountsPayableLedgerId") == null)   ? 0 : rec_obj.get("CancelledPreliminaryAccountsPayableLedgerId")  )    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PreliminaryAccountsPayableLedgerId") == null)            ? 0 : rec_obj.get("PreliminaryAccountsPayableLedgerId")  )             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("EimInvoiceStatus") == null)                              ? 0 : rec_obj.get("EimInvoiceStatus")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("HasImportExportDeclaration") == "false")                 ? 0 : 1  )                                                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ImportExportDeclarationId") == null)                     ? 0 : rec_obj.get("ImportExportDeclarationId")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BusinessContactId") == null)                             ? 0 : rec_obj.get("BusinessContactId")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InvoiceNumber") == null)                                 ? 0 : rec_obj.get("InvoiceNumber")  )                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InvoiceDate") == null                || rec_obj.get("InvoiceDate").toString().substring(0,2).equals("00")  )                    ? new Date(2021000000) : rec_obj.get("InvoiceDate").toString().substring(0,19).replace('T', ' ')  )                + "\" " + ", " +
                          "\"" + ((rec_obj.get("DueDate") == null                    || rec_obj.get("DueDate").toString().substring(0,2).equals("00")  )                        ? new Date(2021000000) : rec_obj.get("DueDate").toString().substring(0,19).replace('T', ' ')  )                    + "\" " + ", " +
                          "\"" + ((rec_obj.get("InvoiceAmount") == null)                                 ? 0 : rec_obj.get("InvoiceAmount")  )                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InvoiceAmountCurrencyId") == null)                       ? 0 : rec_obj.get("InvoiceAmountCurrencyId")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InvoiceAmountInCompanyCurrency") == null)                ? 0 : rec_obj.get("InvoiceAmountInCompanyCurrency")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InvoiceAmountInCompanyCurrencyCurrencyId") == null)      ? 0 : rec_obj.get("InvoiceAmountInCompanyCurrencyCurrencyId")  )       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("VatAmount") == null)                                     ? 0 : rec_obj.get("VatAmount")  )                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("VatAmountCurrencyId") == null)                           ? 0 : rec_obj.get("VatAmountCurrencyId")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("VatAmountInCompanyCurrency") == null)                    ? 0 : rec_obj.get("VatAmountInCompanyCurrency")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("VatAmountInCompanyCurrencyCurrencyId") == null)          ? 0 : rec_obj.get("VatAmountInCompanyCurrencyCurrencyId")  )           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RestAmount") == null)                                    ? 0 : rec_obj.get("RestAmount")  )                                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RestAmountCurrencyId") == null)                          ? 0 : rec_obj.get("RestAmountCurrencyId")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RestAmountInCompanyCurrency") == null)                   ? 0 : rec_obj.get("RestAmountInCompanyCurrency")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RestAmountInCompanyCurrencyCurrencyId") == null)         ? 0 : rec_obj.get("RestAmountInCompanyCurrencyCurrencyId")  )          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OrderedRestAmount") == null)                             ? 0 : rec_obj.get("OrderedRestAmount")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OrderedRestAmountCurrencyId") == null)                   ? 0 : rec_obj.get("OrderedRestAmountCurrencyId")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CurrencyId") == null)                                    ? 0 : rec_obj.get("CurrencyId")  )                                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ExchangeRate") == null)                                  ? 0 : rec_obj.get("ExchangeRate")  )                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PaidInFullDate") == null             || rec_obj.get("PaidInFullDate").toString().substring(0,2).equals("00")  )                 ? new Date(2021000000) : rec_obj.get("PaidInFullDate").toString().substring(0,19).replace('T', ' ')  )                    + "\" " + ", " +
                          "\"" + ((rec_obj.get("CommentId") == null)                                     ? 0 : rec_obj.get("CommentId")  )                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OnAccountBundleNumber") == null)                         ? 0 : rec_obj.get("OnAccountBundleNumber")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OnAccountPaymentMethodId") == null)                      ? 0 : rec_obj.get("OnAccountPaymentMethodId")  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OnAccountVoucherText") == null)                          ? 0 : rec_obj.get("OnAccountVoucherText")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReferenceNumber") == null)                               ? 0 : rec_obj.get("ReferenceNumber")  )                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("UseFixedDueDate") == "false")                            ? 0 : 1  )                                                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("VatGroupId") == null)                                    ? 0 : rec_obj.get("VatGroupId")  )                                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PaymentTermId") == null)                                 ? 0 : rec_obj.get("PaymentTermId")  )                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("UseReferenceNumber") == "false")                         ? 0 : 1  )                                                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReceptionDate") == null              || rec_obj.get("ReceptionDate").toString().substring(0,2).equals("00")  )                  ? new Date(2021000000) : rec_obj.get("ReceptionDate").toString().substring(0,19).replace('T', ' ')  )                    + "\" " + ", " +
                          "\"" + ((rec_obj.get("ImportedInvoiceId") == null)                             ? 0 : rec_obj.get("ImportedInvoiceId")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SplitPayment") == "false")                               ? 0 : 1  )                                                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("VatSupplierId") == null)                                 ? 0 : rec_obj.get("VatSupplierId")  )                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("WorkflowStatus") == null)                                ? 0 : rec_obj.get("WorkflowStatus")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InputVatDate") == null               || rec_obj.get("InputVatDate").toString().substring(0,2).equals("00")  )                   ? new Date(2021000000) : rec_obj.get("InputVatDate").toString().substring(0,19).replace('T', ' ')  )                      + "\" " + ", " +
                          "\"" + ((rec_obj.get("OutputVatDate") == null              || rec_obj.get("OutputVatDate").toString().substring(0,2).equals("00")  )                  ? new Date(2021000000) : rec_obj.get("OutputVatDate").toString().substring(0,19).replace('T', ' ')  )                     + "\" " + ", " +
                          "\"" + ((rec_obj.get("MarginInvoice") == "false")                              ? 0 : 1  )                                                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OnAccountJointPaymentLedgerId") == null)                 ? 0 : rec_obj.get("OnAccountJointPaymentLedgerId")  )                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CancelledOnAccountJointPaymentLedgerId") == null)        ? 0 : rec_obj.get("CancelledOnAccountJointPaymentLedgerId")  )         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OverrideOnAccountJointPaymentVoucherSeriesId") == null)  ? 0 : rec_obj.get("OverrideOnAccountJointPaymentVoucherSeriesId")  )   + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "AccountsPayable was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getAccountsPayables




    public static String getAccountsReceivables(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Accounting/AccountsReceivables?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".accountsreceivable where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".accountsreceivable (tenant_id , id , " +
                          " Version , " +
                          " BookingId , " +
                          " InvoiceType , " +
                          " LatestReminderDate , " +
                          " PaymentReminder , " +
                          " NumberOfPaymentReminders , " +
                          " CollectionDate , " +
                          " Collection , " +
                          " InterestType , " +
                          " HasBeenExported , " +
                          " IsComprehensive , " +
                          " PartialInvoiceType , " +
                          " CustomerAccountGroupId , " +
                          " DebitInvoiceId , " +
                          " AutomaticSetOff , " +
                          " OnAccountIncomingPaymentLedgerId , " +
                          " OnAccountCancelledIncomingPaymentLedgerId , " +
                          " IsEInvoiceExported , " +
                          " AccountsReceivableLedgerId , " +
                          " CancelledAccountsReceivableLedgerId , " +
                          " Status , " +
                          " LatePaymentFee , " +
                          " CancelCommentId , " +
                          " CancelDate , " +
                          " CancelBookingId , " +
                          " BusinessContactId , " +
                          " InvoiceNumber , " +
                          " InvoiceDate , " +
                          " DueDate , " +
                          " IsCredit , " +
                          " InvoiceAmount , " +
                          " InvoiceAmountCurrencyId , " +
                          " InvoiceAmountInCompanyCurrency , " +
                          " InvoiceAmountInCompanyCurrencyCurrencyId , " +
                          " VatAmount , " +
                          " VatAmountCurrencyId , " +
                          " VatAmountInCompanyCurrency , " +
                          " VatAmountInCompanyCurrencyCurrencyId , " +
                          " RestAmount , " +
                          " RestAmountCurrencyId , " +
                          " RestAmountInCompanyCurrency , " +
                          " RestAmountInCompanyCurrencyCurrencyId , " +
                          " OrderedRestAmount , " +
                          " OrderedRestAmountCurrencyId , " +
                          " CurrencyId , " +
                          " ExchangeRate , " +
                          " PaidInFullDate , " +
                          " CommentId , " +
                          " OnAccountBundleNumber , " +
                          " OnAccountPaymentMethodId , " +
                          " OnAccountVoucherText , " +
                          " ReferenceNumber , " +
                          " UseFixedDueDate , " +
                          " VatGroupId , " +
                          " PaymentTermId , " +
                          " ChineseVatInvoiceNumber , " +
                          " ChineseVatInvoiceDate , " +
                          " HasImportExportDeclaration , " +
                          " ImportExportDeclarationId , " +
                          " SplitPayment , " +
                          " GtuCodes , " +
                          " PolishVatInfo , " +
                          " OnAccountJointPaymentLedgerId , " +
                          " CancelledOnAccountJointPaymentLedgerId , " +
                          " OverrideOnAccountJointPaymentVoucherSeriesId   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Version") == null)                                       ? 0 : rec_obj.get("Version")  )                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BookingId") == null)                                     ? 0 : rec_obj.get("BookingId")  )                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InvoiceType") == null)                                   ? 0 : rec_obj.get("InvoiceType")  )                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("LatestReminderDate") == null        || rec_obj.get("LatestReminderDate").toString().substring(0,2).equals("00")  )              ? new Date(2021000000) : rec_obj.get("LatestReminderDate").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("PaymentReminder") == "false")                            ? 0 : 1  )                                                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("NumberOfPaymentReminders") == null)                      ? 0 : rec_obj.get("NumberOfPaymentReminders")  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CollectionDate") == null            || rec_obj.get("CollectionDate").toString().substring(0,2).equals("00")  )                  ? new Date(2021000000) : rec_obj.get("CollectionDate").toString().substring(0,19).replace('T', ' ')  )          + "\" " + ", " +
                          "\"" + ((rec_obj.get("Collection") == "false")                                 ? 0 : 1  )                                                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InterestType") == null)                                  ? 0 : rec_obj.get("InterestType")  )                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("HasBeenExported") == "false")                            ? 0 : 1  )                                                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsComprehensive") == "false")                            ? 0 : 1  )                                                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PartialInvoiceType") == null)                            ? 0 : rec_obj.get("PartialInvoiceType")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CustomerAccountGroupId") == null)                        ? 0 : rec_obj.get("CustomerAccountGroupId")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DebitInvoiceId") == null)                                ? 0 : rec_obj.get("DebitInvoiceId")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AutomaticSetOff") == "false")                            ? 0 : 1  )                                                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OnAccountIncomingPaymentLedgerId") == null)              ? 0 : rec_obj.get("OnAccountIncomingPaymentLedgerId")  )               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OnAccountCancelledIncomingPaymentLedgerId") == null)     ? 0 : rec_obj.get("OnAccountCancelledIncomingPaymentLedgerId")  )      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsEInvoiceExported") == "false")                         ? 0 : 1  )                                                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AccountsReceivableLedgerId") == null)                    ? 0 : rec_obj.get("AccountsReceivableLedgerId")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CancelledAccountsReceivableLedgerId") == null)           ? 0 : rec_obj.get("CancelledAccountsReceivableLedgerId")  )            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Status") == null)                                        ? 0 : rec_obj.get("Status")  )                                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("LatePaymentFee") == null)                                ? 0 : rec_obj.get("LatePaymentFee")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CancelCommentId") == null)                               ? 0 : rec_obj.get("CancelCommentId")  )                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CancelDate") == null              || rec_obj.get("CancelDate").toString().substring(0,2).equals("00")  )                        ? new Date(2021000000) : rec_obj.get("CancelDate").toString().substring(0,19).replace('T', ' ')  )          + "\" " + ", " +
                          "\"" + ((rec_obj.get("CancelBookingId") == null)                               ? 0 : rec_obj.get("CancelBookingId")  )                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BusinessContactId") == null)                             ? 0 : rec_obj.get("BusinessContactId")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InvoiceNumber") == null)                                 ? 0 : rec_obj.get("InvoiceNumber")  )                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InvoiceDate") == null             || rec_obj.get("InvoiceDate").toString().substring(0,2).equals("00")  )                       ? new Date(2021000000) : rec_obj.get("InvoiceDate").toString().substring(0,19).replace('T', ' ')  )         + "\" " + ", " +
                          "\"" + ((rec_obj.get("DueDate") == null                 || rec_obj.get("DueDate").toString().substring(0,2).equals("00")  )                           ? new Date(2021000000) : rec_obj.get("DueDate").toString().substring(0,19).replace('T', ' ')  )             + "\" " + ", " +
                          "\"" + ((rec_obj.get("IsCredit ") == "false")                                  ? 0 : 1  )                                                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InvoiceAmount") == null)                                 ? 0 : rec_obj.get("InvoiceAmount")  )                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InvoiceAmountCurrencyId") == null)                       ? 0 : rec_obj.get("InvoiceAmountCurrencyId")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InvoiceAmountInCompanyCurrency") == null)                ? 0 : rec_obj.get("InvoiceAmountInCompanyCurrency")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InvoiceAmountInCompanyCurrencyCurrencyId") == null)      ? 0 : rec_obj.get("InvoiceAmountInCompanyCurrencyCurrencyId")  )       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("VatAmount") == null)                                     ? 0 : rec_obj.get("VatAmount")  )                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("VatAmountCurrencyId") == null)                           ? 0 : rec_obj.get("VatAmountCurrencyId")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("VatAmountInCompanyCurrency") == null)                    ? 0 : rec_obj.get("VatAmountInCompanyCurrency")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("VatAmountInCompanyCurrencyCurrencyId") == null)          ? 0 : rec_obj.get("VatAmountInCompanyCurrencyCurrencyId")  )           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RestAmount") == null)                                    ? 0 : rec_obj.get("RestAmount")  )                                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RestAmountCurrencyId") == null)                          ? 0 : rec_obj.get("RestAmountCurrencyId")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RestAmountInCompanyCurrency") == null)                   ? 0 : rec_obj.get("RestAmountInCompanyCurrency")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RestAmountInCompanyCurrencyCurrencyId") == null)         ? 0 : rec_obj.get("RestAmountInCompanyCurrencyCurrencyId")  )          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OrderedRestAmount") == null)                             ? 0 : rec_obj.get("OrderedRestAmount")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OrderedRestAmountCurrencyId") == null)                   ? 0 : rec_obj.get("OrderedRestAmountCurrencyId")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CurrencyId") == null)                                    ? 0 : rec_obj.get("CurrencyId")  )                                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ExchangeRate") == null)                                  ? 0 : rec_obj.get("ExchangeRate")  )                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PaidInFullDate") == null            || rec_obj.get("PaidInFullDate").toString().substring(0,2).equals("00")  )                  ? new Date(2021000000) : rec_obj.get("PaidInFullDate").toString().substring(0,19).replace('T', ' ')  )          + "\" " + ", " +
                          "\"" + ((rec_obj.get("CommentId") == null)                                     ? 0 : rec_obj.get("CommentId")  )                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OnAccountBundleNumber") == null)                         ? 0 : rec_obj.get("OnAccountBundleNumber")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OnAccountPaymentMethodId") == null)                      ? 0 : rec_obj.get("OnAccountPaymentMethodId")  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OnAccountVoucherText") == null)                          ? 0 : rec_obj.get("OnAccountVoucherText")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReferenceNumber") == null)                               ? 0 : rec_obj.get("ReferenceNumber")  )                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("UseFixedDueDate") == "false")                            ? 0 : 1  )                                                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("VatGroupId") == null)                                    ? 0 : rec_obj.get("VatGroupId")  )                                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PaymentTermId") == null)                                 ? 0 : rec_obj.get("PaymentTermId")  )                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ChineseVatInvoiceNumber") == null)                       ? 0 : rec_obj.get("ChineseVatInvoiceNumber")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ChineseVatInvoiceDate") == null       || rec_obj.get("ChineseVatInvoiceDate").toString().substring(0,2).equals("00")  )         ? new Date(2021000000) : rec_obj.get("ChineseVatInvoiceDate").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("HasImportExportDeclaration") == "false")                 ? 0 : 1  )                                                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ImportExportDeclarationId") == null)                     ? 0 : rec_obj.get("ImportExportDeclarationId")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SplitPayment") == "false")                               ? 0 : 1  )                                                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("GtuCodes") == null)                                      ? 0 : rec_obj.get("GtuCodes")  )                                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PolishVatInfo") == null)                                 ? 0 : rec_obj.get("PolishVatInfo")  )                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OnAccountJointPaymentLedgerId") == null)                 ? 0 : rec_obj.get("OnAccountJointPaymentLedgerId")  )                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CancelledOnAccountJointPaymentLedgerId") == null)        ? 0 : rec_obj.get("CancelledOnAccountJointPaymentLedgerId")  )         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OverrideOnAccountJointPaymentVoucherSeriesId") == null)  ? 0 : rec_obj.get("OverrideOnAccountJointPaymentVoucherSeriesId")  )   + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "AccountsReceivable was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getAccountsReceivables





    public static String getAccountYearSettingCodingDimensionAvailabilities(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Accounting/AccountYearSettingCodingDimensionAvailabilities?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".accountyearsettingcodingdimensionavailability where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".accountyearsettingcodingdimensionavailability (tenant_id , id , " +
                          " CodingDimensionId , " +
                          " CodingDimensionAvailability , " +
                          " AccountYearSettingId , " +
                          " CodingDimension   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("CodingDimensionId") == null)                             ? 0 : rec_obj.get("CodingDimensionId")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CodingDimensionAvailability") == null)                   ? 0 : rec_obj.get("CodingDimensionAvailability")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AccountYearSettingId") == null)                          ? 0 : rec_obj.get("AccountYearSettingId")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CodingDimension") == null)                               ? 0 : rec_obj.get("CodingDimension")  )                                + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "AccountYearSettingCodingDimensionAvailability was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getAccountYearSettingCodingDimensionAvailabilities






    public static String getAccountYearSettings(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Accounting/AccountYearSettings?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".accountyearsetting where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".accountyearsetting (tenant_id , id , " +
                          " AccountingYearId , " +
                          " DescriptionId , " +
                          " AllowSpecification , " +
                          " AllowQuantity , " +
                          " IsCurrencyAccount , " +
                          " CurrencyId , " +
                          " IsAccrual , " +
                          " DebitOrCreditType , " +
                          " BlockedContextType , " +
                          " BlockedFromDate , " +
                          " BlockedToDate , " +
                          " BlockedById , " +
                          " BlockedStatus , " +
                          " HeaderId , " +
                          " SRUCodeId , " +
                          " CommentId , " +
                          " BlockMessageId , " +
                          " VatType , " +
                          " VatRateId , " +
                          " BlockedForManualCoding , " +
                          " IsFixedAssetAccount , " +
                          " FixedAssetGroupId , " +
                          " IncludeOrderNumberInCoding , " +
                          " ProjectCostTypeId , " +
                          " ProjectCostOrIncomeType , " +
                          " IsSystemAccount , " +
                          " ParentId , " +
                          " BudgetChartId , " +
                          " OverrideVATCode , " +
                          " SAFTStandardAccountId , " +
                          " Description , " +
                          " Account   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("AccountingYearId") == null)                           ? 0 : rec_obj.get("AccountingYearId")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                              ? 0 : rec_obj.get("DescriptionId")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AllowSpecification") == "false")                      ? 0 : 1  )                                                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AllowQuantity") == "false")                           ? 0 : 1  )                                                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsCurrencyAccount") == "false")                       ? 0 : 1  )                                                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CurrencyId") == null)                                 ? 0 : rec_obj.get("CurrencyId")  )                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsAccrual") == "false")                               ? 0 : 1  )                                                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DebitOrCreditType") == null)                          ? 0 : rec_obj.get("DebitOrCreditType")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BlockedContextType") == null)                         ? 0 : rec_obj.get("BlockedContextType")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BlockedFromDate") == null      || rec_obj.get("BlockedFromDate").toString().substring(0,2).equals("00")  )      ? new Date(2021000000) : rec_obj.get("BlockedFromDate").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("BlockedToDate") == null        || rec_obj.get("BlockedToDate").toString().substring(0,2).equals("00")  )        ? new Date(2021000000) : rec_obj.get("BlockedToDate").toString().substring(0,19).replace('T', ' ')  )        + "\" " + ", " +
                          "\"" + ((rec_obj.get("BlockedById") == null)                                ? 0 : rec_obj.get("BlockedById")  )                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BlockedStatus") == null)                              ? 0 : rec_obj.get("BlockedStatus")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("HeaderId") == null)                                   ? 0 : rec_obj.get("HeaderId")  )                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SRUCodeId") == null)                                  ? 0 : rec_obj.get("SRUCodeId")  )                                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CommentId") == null)                                  ? 0 : rec_obj.get("CommentId")  )                                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BlockMessageId") == null)                             ? 0 : rec_obj.get("BlockMessageId")  )                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("VatType") == null)                                    ? 0 : rec_obj.get("VatType")  )                                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("VatRateId") == null)                                  ? 0 : rec_obj.get("VatRateId")  )                                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BlockedForManualCoding") == "false")                  ? 0 : 1  )                                                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsFixedAssetAccount") == "false")                     ? 0 : 1  )                                                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("FixedAssetGroupId") == null)                          ? 0 : rec_obj.get("FixedAssetGroupId")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IncludeOrderNumberInCoding") == "false")              ? 0 : 1  )                                                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ProjectCostTypeId") == null)                          ? 0 : rec_obj.get("ProjectCostTypeId")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ProjectCostOrIncomeType") == null)                    ? 0 : rec_obj.get("ProjectCostOrIncomeType")  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsSystemAccount") == "false")                         ? 0 : 1  )                                                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ParentId") == null)                                   ? 0 : rec_obj.get("ParentId")  )                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BudgetChartId") == null)                              ? 0 : rec_obj.get("BudgetChartId")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OverrideVATCode") == "false")                         ? 0 : 1  )                                                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SAFTStandardAccountId") == null)                      ? 0 : rec_obj.get("SAFTStandardAccountId")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                                ? 0 : rec_obj.get("Description")  )                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Account") == null)                                    ? 0 : rec_obj.get("Account")  )                                       + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "AccountYearSetting was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getAccountYearSettings





    public static String getAccrualAccountingLedgers(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Accounting/AccrualAccountingLedgers?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".accrualaccountingledger where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".accrualaccountingledger (tenant_id , id , " +
                          " Number , " +
                          " ApprovedDate , " +
                          " ApprovedByApplicationUserId   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Number") == null)                             ? 0 : rec_obj.get("Number")  )                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ApprovedDate") == null        || rec_obj.get("ApprovedDate").toString().substring(0,2).equals("00")  )      ? new Date(2021000000) : rec_obj.get("ApprovedDate").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("ApprovedByApplicationUserId") == null)        ? 0 : rec_obj.get("ApprovedByApplicationUserId")  )           + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "AccrualAccountingLedger was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getAccrualAccountingLedgers




    public static String getAccrualAccountingRows(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Accounting/AccrualAccountingRows?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".accrualaccountingrow where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".accrualaccountingrow (tenant_id , id , " +
                          " PeriodId , " +
                          " PeriodAmountInCompanyCurrency , " +
                          " AccrualAccountingId , " +
                          " IsReleased , " +
                          " LedgerId , " +
                          " BookingId , " +
                          " RowIndex   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("PeriodId") == null)                             ? 0 : rec_obj.get("PeriodId")  )                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PeriodAmountInCompanyCurrency") == null)        ? 0 : rec_obj.get("PeriodAmountInCompanyCurrency")  )           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AccrualAccountingId") == null)                  ? 0 : rec_obj.get("AccrualAccountingId")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsReleased") == "false")                        ? 0 : 1  )                                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("LedgerId") == null)                             ? 0 : rec_obj.get("LedgerId")  )                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BookingId") == null)                            ? 0 : rec_obj.get("BookingId")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RowIndex") == null)                             ? 0 : rec_obj.get("RowIndex")  )                                + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "AccrualAccountingRow was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getAccrualAccountingRows




    public static String getAccrualAccountings(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Accounting/AccrualAccountings?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".accrualaccounting where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".accrualaccounting (tenant_id , id , " +
                          " Number , " +
                          " Text , " +
                          " Type , " +
                          " StartDate , " +
                          " AccountsPayableId , " +
                          " AccountsPayableBookingRowId , " +
                          " VoucherId , " +
                          " VoucherRowId , " +
                          " CommentId , " +
                          " CancelCommentId , " +
                          " IsCancelled , " +
                          " BookingId   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Number") == null)                              ? 0 : rec_obj.get("Number")  )                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Text") == null)                                ? 0 : rec_obj.get("Text")  )                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Type") == null)                                ? 0 : rec_obj.get("Type")  )                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("StartDate") == null      || rec_obj.get("StartDate").toString().substring(0,2).equals("00")  )      ? new Date(2021000000) : rec_obj.get("StartDate").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("AccountsPayableId") == null)                   ? 0 : rec_obj.get("AccountsPayableId")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AccountsPayableBookingRowId") == null)         ? 0 : rec_obj.get("AccountsPayableBookingRowId")  )           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("VoucherId") == null)                           ? 0 : rec_obj.get("VoucherId")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("VoucherRowId") == null)                        ? 0 : rec_obj.get("VoucherRowId")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CommentId") == null)                           ? 0 : rec_obj.get("CommentId")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CancelCommentId") == null)                     ? 0 : rec_obj.get("CancelCommentId")  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsCancelled") == "false")                      ? 0 : 1  )                                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BookingId") == null)                           ? 0 : rec_obj.get("BookingId")  )                             + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "AccrualAccounting was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getAccrualAccountings




    public static String getBookingRows(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Accounting/BookingRows?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".bookingrow where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".bookingrow (tenant_id , id , " +
                          " Type , " +
                          " AuthorizedById , " +
                          " AuthorizedWhen , " +
                          " PurchaseOrderDeliveryRowId , " +
                          " BookingId , " +
                          " VatRateId , " +
                          " AccrualAccountingId , " +
                          " FixedAssetId , " +
                          " OrderNumber , " +
                          " TariffAndServiceCodeId , " +
                          " DebitInCompanyCurrency , " +
                          " DebitInCompanyCurrencyCurrencyId , " +
                          " CreditInCompanyCurrency , " +
                          " CreditInCompanyCurrencyCurrencyId , " +
                          " Debit , " +
                          " DebitCurrencyId , " +
                          " Credit , " +
                          " CreditCurrencyId , " +
                          " Quantity , " +
                          " CodingEntryId , " +
                          " RowIndex , " +
                          " ImportInvoiceRowId   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Type") == null)                                ? 0 : rec_obj.get("Type")  )                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AuthorizedById") == null)                      ? 0 : rec_obj.get("AuthorizedById")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AuthorizedWhen") == null      || rec_obj.get("AuthorizedWhen").toString().substring(0,2).equals("00")  )     ? new Date(2021000000) : rec_obj.get("AuthorizedWhen").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("PurchaseOrderDeliveryRowId") == null)          ? 0 : rec_obj.get("PurchaseOrderDeliveryRowId")  )            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BookingId") == null)                           ? 0 : rec_obj.get("BookingId")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("VatRateId") == null)                           ? 0 : rec_obj.get("VatRateId")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AccrualAccountingId") == null)                 ? 0 : rec_obj.get("AccrualAccountingId")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("FixedAssetId") == null)                        ? 0 : rec_obj.get("FixedAssetId")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OrderNumber") == null)                         ? 0 : rec_obj.get("OrderNumber")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("TariffAndServiceCodeId") == null)              ? 0 : rec_obj.get("TariffAndServiceCodeId")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DebitInCompanyCurrency") == null)              ? 0 : rec_obj.get("DebitInCompanyCurrency")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DebitInCompanyCurrencyCurrencyId") == null)    ? 0 : rec_obj.get("DebitInCompanyCurrencyCurrencyId")  )      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CreditInCompanyCurrency") == null)             ? 0 : rec_obj.get("CreditInCompanyCurrency")  )               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CreditInCompanyCurrencyCurrencyId") == null)   ? 0 : rec_obj.get("CreditInCompanyCurrencyCurrencyId")  )     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Debit") == null)                               ? 0 : rec_obj.get("Debit")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DebitCurrencyId") == null)                     ? 0 : rec_obj.get("DebitCurrencyId")  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Credit") == null)                              ? 0 : rec_obj.get("Credit")  )                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CreditCurrencyId") == null)                    ? 0 : rec_obj.get("CreditCurrencyId")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Quantity") == null)                            ? 0 : rec_obj.get("Quantity")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CodingEntryId") == null)                       ? 0 : rec_obj.get("CodingEntryId")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RowIndex") == null)                            ? 0 : rec_obj.get("RowIndex")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ImportInvoiceRowId") == null)                  ? 0 : rec_obj.get("ImportInvoiceRowId")  )                    + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "BookingRow was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getBookingRows




    public static String getBookings(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Bookings" );
             //        "/" + "api/v1/Manufacturing/ManufacturingOrders?$filter=isnotnull(StartDate)&StartDate%20Gt%20'2021-10-10'$skip=0&$top=50000&$orderby=Id%20desc"


              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Accounting/Bookings?$top=" + recordsLimit +"&$orderby=Id%20desc "
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".booking where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".booking (tenant_id , id , " +
                          " ParentClass, " +
                          " ParentId  " +

                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("ParentClass") == null)   ? 0 : rec_obj.get("ParentClass")  )    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ParentId") == null)      ? 0 : rec_obj.get("ParentId")  )       + "\" "    + "  " +

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Booking was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getBookings




    public static String getCodingDimensions(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Accounting/CodingDimensions?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".codingdimension where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".codingdimension (tenant_id , id , " +
                          " Number , " +
                          " DescriptionId , " +
                          " CodeDescriptionId , " +
                          " ReferenceEntityType , " +
                          " IncludePostingToPurchaseOrder , " +
                          " Description , " +
                          " CodeDescription  " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Number") == null)                ? 0 : rec_obj.get("Number")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)         ? 0 : rec_obj.get("DescriptionId")  )          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CodeDescriptionId") == null)     ? 0 : rec_obj.get("CodeDescriptionId")  )      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReferenceEntityType") == null)   ? 0 : rec_obj.get("ReferenceEntityType")  )    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IncludePostingToPurchaseOrder") == "false")    ? 0 : 1  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)           ? 0 : rec_obj.get("Description")  )            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CodeDescription") == null)       ? 0 : rec_obj.get("CodeDescription")  )        + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "CodingDimension was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getCodingDimensions



    public static String getCodingElements(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Accounting/CodingElements?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".codingelement where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".codingelement (tenant_id , id , " +
                          " Code , " +
                          " DescriptionId , " +
                          " CodingDimensionId , " +
                          " IsActive , " +
                          " Description   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Code") == null)                  ? 0 : rec_obj.get("Code")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)         ? 0 : rec_obj.get("DescriptionId")  )        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CodingDimensionId") == null)     ? 0 : rec_obj.get("CodingDimensionId")  )    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsActive") == "false")           ? 0 : 1  )                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)           ? 0 : rec_obj.get("Description")  )          + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "CodingElement was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getCodingElements





    public static String getCodingEntries(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Accounting/CodingEntries?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".codingentry where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".codingentry (tenant_id , id , " +
                          " AccountId , " +
                          " CodingEntryDescription , " +
                          " UniqueCodingIdentifier , " +
                          " ParentClass , " +
                          " ParentId , " +
                          " AutoCodingParentRowId, " +
                          " AutoCodingId, " +
                          " AutoAllocationId, " +
                          " ElementReferencingEntityId1, " +
                          " ElementReferencingEntityId2, " +
                          " ElementReferencingEntityId3, " +
                          " ElementReferencingEntityId4, " +
                          " ElementReferencingEntityId5, " +
                          " ElementReferencingEntityId6, " +
                          " ElementReferencingEntityId7, " +
                          " ElementReferencingEntityId8, " +
                          " Account  " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("AccountId") == null)                ? 0 : rec_obj.get("AccountId")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CodingEntryDescription") == null)   ? 0 : rec_obj.get("CodingEntryDescription")  )    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("UniqueCodingIdentifier") == null)   ? 0 : rec_obj.get("UniqueCodingIdentifier")  )    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ParentClass") == null)              ? 0 : rec_obj.get("ParentClass")  )               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ParentId") == null)                 ? 0 : rec_obj.get("ParentId")  )                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AutoCodingParentRowId") == null)    ? 0 : rec_obj.get("AutoCodingParentRowId")  )     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AutoCodingId") == null)             ? 0 : rec_obj.get("AutoCodingId")  )              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AutoAllocationId") == null)         ? 0 : rec_obj.get("AutoAllocationId")  )          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ElementReferencingEntityId1") == null)     ? 0 : rec_obj.get("ElementReferencingEntityId1")  )        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ElementReferencingEntityId2") == null)     ? 0 : rec_obj.get("ElementReferencingEntityId2")  )        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ElementReferencingEntityId3") == null)     ? 0 : rec_obj.get("ElementReferencingEntityId3")  )        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ElementReferencingEntityId4") == null)     ? 0 : rec_obj.get("ElementReferencingEntityId4")  )        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ElementReferencingEntityId5") == null)     ? 0 : rec_obj.get("ElementReferencingEntityId5")  )        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ElementReferencingEntityId6") == null)     ? 0 : rec_obj.get("ElementReferencingEntityId6")  )        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ElementReferencingEntityId7") == null)     ? 0 : rec_obj.get("ElementReferencingEntityId7")  )        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ElementReferencingEntityId8") == null)     ? 0 : rec_obj.get("ElementReferencingEntityId8")  )        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Account") == null)                         ? 0 : rec_obj.get("Account")  )                            + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "CodingEntry was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getCodingEntries





    public static String getCodingEntryElements(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Accounting/CodingEntryElements?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".codingentryelement where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".codingentryelement (tenant_id , id , " +
                          " ReferencingEntityId , " +
                          " CodingDimensionId , " +
                          " CodingEntryId , " +
                          " CodingDimension  " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("ReferencingEntityId") == null)                ? 0 : rec_obj.get("ReferencingEntityId")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CodingDimensionId") == null)                  ? 0 : rec_obj.get("CodingDimensionId")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CodingEntryId") == null)                      ? 0 : rec_obj.get("CodingEntryId")  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CodingDimension") == null)                    ? 0 : rec_obj.get("CodingDimension")  )                     + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "CodingEntryElement was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getCodingEntryElements





    public static String getCodingRows(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Accounting/CodingRows?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".codingrow where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".codingrow (tenant_id , id , " +
                          " CodingEntryId , " +
                          " Type , " +
                          " ParentId , " +
                          " CodingEntry   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("CodingEntryId") == null)                ? 0 : rec_obj.get("CodingEntryId")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Type") == null)                         ? 0 : rec_obj.get("Type")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ParentId") == null)                     ? 0 : rec_obj.get("ParentId")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CodingEntry") == null)                  ? 0 : rec_obj.get("CodingEntry")  )                   + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "CodingRow was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getCodingRows





    public static String getCodings(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Accounting/Codings?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".coding where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".coding (tenant_id , id , " +
                          " CodingOwnerClass , " +
                          " CodingOwnerId , " +
                          " CodingRows   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("CodingOwnerClass") == null)                ? 0 : rec_obj.get("CodingOwnerClass")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CodingOwnerId") == null)                   ? 0 : rec_obj.get("CodingOwnerId")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CodingRows") == null)                      ? 0 : rec_obj.get("CodingRows")  )                       + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Coding was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getCodings






    public static String getVoucherNumberSeries(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Accounting/VoucherNumberSeries?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".vouchernumberseries where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".vouchernumberseries (tenant_id , id , " +
                          " AccountingYearId , " +
                          " Number , " +
                          " VoucherSeriesId , " +
                          " DescriptionId , " +
                          " Description , " +
                          " VoucherSeries , " +
                          " AccountingYear   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("AccountingYearId") == null)                ? 0 : rec_obj.get("AccountingYearId")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Number") == null)                          ? 0 : rec_obj.get("Number")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("VoucherSeriesId") == null)                 ? 0 : rec_obj.get("VoucherSeriesId")  )                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                   ? 0 : rec_obj.get("DescriptionId")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                     ? 0 : rec_obj.get("Description")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("VoucherSeries") == null)                   ? 0 : rec_obj.get("VoucherSeries")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AccountingYear") == null)                  ? 0 : rec_obj.get("AccountingYear")  )                   + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "VoucherNumberSeries was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getVoucherNumberSeries



    public static String getVoucherRows(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Accounting/VoucherRows?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".voucherrow where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".voucherrow (tenant_id , id , " +
                          " EntryIdentifier , " +
                          " VoucherId , " +
                          " ParentVoucherDate , " +
                          " ParentIsPreliminary , " +
                          " BalanceId , " +
                          " CodingMethodId , " +
                          " ExchangeRate , " +
                          " IsReconciled , " +
                          " ReconciliationDate , " +
                          " ReconciliationTimestamp , " +
                          " ReconciledByUserId , " +
                          " VatRateId , " +
                          " AccrualAccountingId , " +
                          " FixedAssetId , " +
                          " OrderNumber , " +
                          " TariffAndServiceCodeId , " +
                          " DebitInCompanyCurrency , " +
                          " DebitInCompanyCurrencyCurrencyId , " +
                          " CreditInCompanyCurrency  , " +
                          " CreditInCompanyCurrencyCurrencyId  , " +
                          " Debit  , " +
                          " DebitCurrencyId  , " +
                          " Credit  , " +
                          " CreditCurrencyId  , " +
                          " Quantity  , " +
                          " CodingEntryId  , " +
                          " Type  , " +
                          " AccountsPayableId  , " +
                          " AccountsReceivableId  , " +
                          " OriginBookingRowId  , " +
                          " CommentText  , " +
                          " ModifiedByUserId  , " +
                          " ModifiedTimestamp  , " +
                          " OldDebitInCompanyCurrency  , " +
                          " OldDebitInCompanyCurrencyCurrencyId  , " +
                          " OldCreditInCompanyCurrency  , " +
                          " OldCreditInCompanyCurrencyCurrencyId  , " +
                          " OldDebit  , " +
                          " OldDebitCurrencyId  , " +
                          " OldCredit  , " +
                          " OldCreditCurrencyId  , " +
                          " OldQuantity  , " +
                          " Status  , " +
                          " IsActive  , " +
                          " OriginalBalanceId    " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("EntryIdentifier") == null)                          ? 0 : rec_obj.get("EntryIdentifier")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("VoucherId") == null)                                ? 0 : rec_obj.get("VoucherId")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ParentVoucherDate") == null       || rec_obj.get("ParentVoucherDate").toString().substring(0,2).equals("00")  )       ? new Date(2021000000) : rec_obj.get("ParentVoucherDate").toString().substring(0,19).replace('T', ' ')  )        + "\" " + ", " +
                          "\"" + ((rec_obj.get("ParentIsPreliminary") == "false")                   ? 0 : 1  )                                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BalanceId") == null)                                ? 0 : rec_obj.get("BalanceId")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CodingMethodId") == null)                           ? 0 : rec_obj.get("CodingMethodId")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ExchangeRate") == null)                             ? 0 : rec_obj.get("ExchangeRate")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsReconciled") == "false")                          ? 0 : 1  )                                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReconciliationDate") == null      || rec_obj.get("ReconciliationDate").toString().substring(0,2).equals("00")  )      ? new Date(2021000000) : rec_obj.get("ReconciliationDate").toString().substring(0,19).replace('T', ' ')  )       + "\" " + ", " +
                          "\"" + ((rec_obj.get("ReconciliationTimestamp") == null || rec_obj.get("ReconciliationTimestamp").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("ReconciliationTimestamp").toString().substring(0,19).replace('T', ' ')  )  + "\" " + ", " +
                          "\"" + ((rec_obj.get("ReconciledByUserId") == null)                       ? 0 : rec_obj.get("ReconciledByUserId")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("VatRateId") == null)                                ? 0 : rec_obj.get("VatRateId")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AccrualAccountingId") == null)                      ? 0 : rec_obj.get("AccrualAccountingId")  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("FixedAssetId") == null)                             ? 0 : rec_obj.get("FixedAssetId")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OrderNumber") == null)                              ? 0 : rec_obj.get("OrderNumber")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("TariffAndServiceCodeId") == null)                   ? 0 : rec_obj.get("TariffAndServiceCodeId")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DebitInCompanyCurrency") == null)                   ? 0 : rec_obj.get("DebitInCompanyCurrency")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DebitInCompanyCurrencyCurrencyId") == null)         ? 0 : rec_obj.get("DebitInCompanyCurrencyCurrencyId")  )          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CreditInCompanyCurrency") == null)                  ? 0 : rec_obj.get("CreditInCompanyCurrency")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CreditInCompanyCurrencyCurrencyId") == null)        ? 0 : rec_obj.get("CreditInCompanyCurrencyCurrencyId")  )         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Debit") == null)                                    ? 0 : rec_obj.get("Debit")  )                                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DebitCurrencyId") == null)                          ? 0 : rec_obj.get("DebitCurrencyId")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Credit") == null)                                   ? 0 : rec_obj.get("Credit")  )                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CreditCurrencyId") == null)                         ? 0 : rec_obj.get("CreditCurrencyId")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Quantity") == null)                                 ? 0 : rec_obj.get("Quantity")  )                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CodingEntryId") == null)                            ? 0 : rec_obj.get("CodingEntryId")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Type") == null)                                     ? 0 : rec_obj.get("Type")  )                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AccountsPayableId") == null)                        ? 0 : rec_obj.get("AccountsPayableId")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AccountsReceivableId") == null)                     ? 0 : rec_obj.get("AccountsReceivableId")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OriginBookingRowId") == null)                       ? 0 : rec_obj.get("OriginBookingRowId")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CommentText") == null)                              ? 0 : rec_obj.get("CommentText")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ModifiedByUserId") == null)                         ? 0 : rec_obj.get("ModifiedByUserId")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ModifiedTimestamp") == null || rec_obj.get("ModifiedTimestamp").toString().substring(0,2).equals("00")  )             ? new Date(2021000000) : rec_obj.get("ModifiedTimestamp").toString().substring(0,19).replace('T', ' ')  )  + "\" " + ", " +
                          "\"" + ((rec_obj.get("OldDebitInCompanyCurrency") == null)                ? 0 : rec_obj.get("OldDebitInCompanyCurrency")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OldDebitInCompanyCurrencyCurrencyId") == null)      ? 0 : rec_obj.get("OldDebitInCompanyCurrencyCurrencyId")  )       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OldCreditInCompanyCurrency") == null)               ? 0 : rec_obj.get("OldCreditInCompanyCurrency")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OldCreditInCompanyCurrencyCurrencyId") == null)     ? 0 : rec_obj.get("OldCreditInCompanyCurrencyCurrencyId")  )      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OldDebit") == null)                                 ? 0 : rec_obj.get("OldDebit")  )                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OldDebitCurrencyId") == null)                       ? 0 : rec_obj.get("OldDebitCurrencyId")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OldCredit") == null)                                ? 0 : rec_obj.get("OldCredit")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OldCreditCurrencyId") == null)                      ? 0 : rec_obj.get("OldCreditCurrencyId")  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OldQuantity") == null)                              ? 0 : rec_obj.get("OldQuantity")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Status") == null)                                   ? 0 : rec_obj.get("Status")  )                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsActive") == "false")                              ? 0 : 1  )                                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OriginalBalanceId") == null)                        ? 0 : rec_obj.get("OriginalBalanceId")  )                         + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "VoucherRow was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getVoucherRows




    public static String getVouchers(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Bookings" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Vouchers" );
             //        "/" + "api/v1/Manufacturing/ManufacturingOrders?$filter=isnotnull(StartDate)&StartDate%20Gt%20'2021-10-10'$skip=0&$top=50000&$orderby=Id%20desc"


              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Accounting/Vouchers?$filter=isnotnull(VoucherDate)&VoucherDate%20Gt%20'2021-10-01'&$top=" + recordsLimit +"&$orderby=Id%20desc "
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".voucher where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".voucher (tenant_id , id , " +
                          " Version, " +
                          " SeriesId, " +
                          " AccountingYearId, " +
                          " Number, " +
                          " VoucherDate, " +
                          " Text, " +
                          " ConnectedVoucherId, " +
                          " ConnectionType, " +
                          " ReverseConnectionVoucherId, " +
                          " ReverseConnectionType, " +
                          " IsPreliminary, " +
                          " AccountsReceivableLedgerId, " +
                          " CancelledAccountsReceivableLedgerId, " +
                          " AccountsPayableLedgerId, " +
                          " PreliminaryAccountsPayableLedgerId, " +
                          " CancelledAccountsPayableLedgerId, " +
                          " CancelledPreliminaryAccountsPayableLedgerId, " +
                          " IncomingPaymentLedgerId, " +
                          " AccrualAccountingLedgerId, " +
                          " OutgoingPaymentLedgerId, " +
                          " FixedAssetLedgerId, " +
                          " UnplannedStockBalanceChangeLedgerId, " +
                          " StockTransactionLogLedgerId, " +
                          " ManufacturingOrderLogLedgerId, " +
                          " InvoiceLogLedgerId, " +
                          " PriceChangeLogLedgerId, " +
                          " CalculationDifferenceLedgerId, " +
                          " UnplannedStockBalanceChangeTransactionId, " +
                          " AccountsReceivableId, " +
                          " AccountsPayableId, " +
                          " AccrualAccountingRowId, " +
                          " VatBookingId, " +
                          " BundleNumber, " +
                          " CommentId, " +
                          " CorrectionBookingId, " +
                          " ExcludeFromBalanceValidation, " +
                          " OutputVatDate, " +
                          " InputVatDate, " +
                          " JointPaymentLedgerId  " +

                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                           "\"" + ((rec_obj.get("Version") == null)                                      ? 0 : rec_obj.get("Version")  )                                      + "\" "    + ", " +
                           "\"" + ((rec_obj.get("SeriesId") == null)                                     ? 0 : rec_obj.get("SeriesId")  )                                     + "\" "    + ", " +
                           "\"" + ((rec_obj.get("AccountingYearId") == null)                             ? 0 : rec_obj.get("AccountingYearId")  )                             + "\" "    + ", " +
                           "\"" + ((rec_obj.get("Number") == null)                                       ? 0 : rec_obj.get("Number")  )                                       + "\" "    + ", " +
                           "\"" + ((rec_obj.get("VoucherDate") == null )                                 ? new Date(2021000000) : rec_obj.get("VoucherDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                           "\"" + ((rec_obj.get("Text") == null)                                         ? 0 : rec_obj.get("Text")  )                                         + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ConnectedVoucherId") == null)                           ? 0 : rec_obj.get("ConnectedVoucherId")  )                           + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ConnectionType") == null)                               ? 0 : rec_obj.get("ConnectionType")  )                               + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ReverseConnectionVoucherId") == null)                   ? 0 : rec_obj.get("ReverseConnectionVoucherId")  )                   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ReverseConnectionType") == null)                        ? 0 : rec_obj.get("ReverseConnectionType")  )                        + "\" "    + ", " +
                           "\"" + ((rec_obj.get("IsPreliminary") == "false")                             ? 0 : 1  )                                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("AccountsReceivableLedgerId") == null)                   ? 0 : rec_obj.get("AccountsReceivableLedgerId")  )                   + "\" "    + ", " +
                          "\"" + ((null == null)                                                         ? 0 : 0 )                                                           + "\" "    + ", " +       /* rec_obj.get("CancelledAccountsReceivableLedgerId") */
                           "\"" + ((rec_obj.get("AccountsPayableLedgerId") == null)                      ? 0 : rec_obj.get("AccountsPayableLedgerId")  )                      + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PreliminaryAccountsPayableLedgerId") == null)           ? 0 : rec_obj.get("PreliminaryAccountsPayableLedgerId")  )           + "\" "    + ", " +
                           "\"" + ((rec_obj.get("CancelledAccountsPayableLedgerId") == null)             ? 0 : rec_obj.get("CancelledAccountsPayableLedgerId")  )             + "\" "    + ", " +
                           "\"" + ((rec_obj.get("CancelledPreliminaryAccountsPayableLedgerId") == null)  ? 0 : rec_obj.get("CancelledPreliminaryAccountsPayableLedgerId")  )   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("IncomingPaymentLedgerId") == null)                      ? 0 : rec_obj.get("IncomingPaymentLedgerId")  )                       + "\" "    + ", " +
                           "\"" + ((rec_obj.get("AccrualAccountingLedgerId") == null)                    ? 0 : rec_obj.get("AccrualAccountingLedgerId")  )                     + "\" "    + ", " +
                           "\"" + ((rec_obj.get("OutgoingPaymentLedgerId") == null)                      ? 0 : rec_obj.get("OutgoingPaymentLedgerId")  )                       + "\" "    + ", " +
                           "\"" + ((rec_obj.get("FixedAssetLedgerId") == null)                           ? 0 : rec_obj.get("FixedAssetLedgerId")  )                            + "\" "    + ", " +
                          "\"" + ((null == null)                                                        ? 0 : 0 )                                                             + "\" "    + ", " +      /* rec_obj.get("UnplannedStockBalanceChangeLedgerId") */
                           "\"" + ((rec_obj.get("StockTransactionLogLedgerId") == null)                  ? 0 : rec_obj.get("StockTransactionLogLedgerId")  )                   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ManufacturingOrderLogLedgerId") == null)                ? 0 : rec_obj.get("ManufacturingOrderLogLedgerId")  )                 + "\" "    + ", " +
                           "\"" + ((rec_obj.get("InvoiceLogLedgerId") == null)                           ? 0 : rec_obj.get("InvoiceLogLedgerId")  )                            + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PriceChangeLogLedgerId") == null)                       ? 0 : rec_obj.get("PriceChangeLogLedgerId")  )                        + "\" "    + ", " +
                           "\"" + ((rec_obj.get("CalculationDifferenceLedgerId") == null)                ? 0 : rec_obj.get("CalculationDifferenceLedgerId")  )                 + "\" "    + ", " +
                           "\"" + ((rec_obj.get("UnplannedStockBalanceChangeTransactionId") == null)     ? 0 : rec_obj.get("UnplannedStockBalanceChangeTransactionId")  )      + "\" "    + ", " +
                           "\"" + ((rec_obj.get("AccountsReceivableId") == null)                         ? 0 : rec_obj.get("AccountsReceivableId")  )                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("AccountsPayableId") == null)                            ? 0 : rec_obj.get("AccountsPayableId")  )                             + "\" "    + ", " +
                           "\"" + ((rec_obj.get("AccrualAccountingRowId") == null)                       ? 0 : rec_obj.get("AccrualAccountingRowId")  )                        + "\" "    + ", " +
                           "\"" + ((rec_obj.get("VatBookingId") == null)                                 ? 0 : rec_obj.get("VatBookingId")  )                                  + "\" "    + ", " +
                           "\"" + ((rec_obj.get("BundleNumber") == null)                                 ? 0 : rec_obj.get("BundleNumber")  )                                  + "\" "    + ", " +
                           "\"" + ((rec_obj.get("CommentId") == null)                                    ? 0 : rec_obj.get("CommentId")  )                                     + "\" "    + ", " +
                           "\"" + ((rec_obj.get("CorrectionBookingId") == null)                          ? 0 : rec_obj.get("CorrectionBookingId")  )                           + "\" "    + ", " +
                          "\"" + ((null == null)                                                        ? 0 : 0 )                                                             + "\" "    + ", " +     /* rec_obj.get("ExcludeFromBalanceValidation") */
                          "\"" + ((null == null)                                                        ? new Date(2021000000) : new Date(2021000000)  )                      + "\" "    + ", " +     /* rec_obj.get("OutputVatDate") */
                          "\"" + ((null == null)                                                        ? new Date(2021000000) : new Date(2021000000)  )                      + "\" "    + ", " +     /* rec_obj.get("InputVatDate") */
                          "\"" + ((null == null)                                                        ? 0 : 0 )                                                             + "\" "    + "  " +     /* rec_obj.get("JointPaymentLedgerId") */

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Voucher was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getVouchers




    public static String getVoucherSeries(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Accounting/VoucherSeries?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".voucherseries where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".voucherseries (tenant_id , id , " +
                          " Series , " +
                          " IsActive   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Series") == null)                ? 0 : rec_obj.get("Series")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsActive") == "false")           ? 0 : 1  )                                     + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "VoucherSeries was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getVoucherSeries






}  // Queries_ACC
