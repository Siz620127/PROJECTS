package sy_my ;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Scanner;
import org.json.simple.JSONObject;
import org.json.simple.JSONArray;
import org.json.simple.JSONValue;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

// import java.time.*;

// -------

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import java.sql.* ;

// import java.sql.Connection;
// import java.sql.Date;
// import java.sql.DriverManager;
// import java.sql.PreparedStatement;
// import java.sql.SQLException;

import java.text.SimpleDateFormat;


public class Queries_INV {



    // TEST START
    public static HttpURLConnection TestQuery(ReadConf conf) throws Exception {
        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals("185.158.177.241");

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end


             // URL url             = new URL( conf.getUrl_sy() );
             URL url                = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", "185.158.177.241"  );
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", "f1bc5219-b382-472e-adc9-ff0926ecbbb0" );



     	     String json = "{\n";
     		 json += "\"Username\": "     +  "\"ADMIN\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"\" "       + ",\n";
		     json += "\"ForceRelogin\": " +  true          + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( response );

   			     return con ;  // response


                 /*
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parse    = new JSONParser();
                 JSONObject data_obj = (JSONObject) parse.parse( json );  // inline
                 //Get the required object from the above created object
                 JSONObject obj = (JSONObject) data_obj.get("Globale");
                 //Get the required data using its key
                 System.out.println(obj.get("TotalRecovered"));
                 JSONArray arr = (JSONArray) data_obj.get("Countries");
                 for (int i = 0; i < arr.size(); i++) {
                      JSONObject new_obj = (JSONObject) arr.get(i);
                      if (new_obj.get("Slug").equals("albania")) {
                         System.out.println("Total Recovered: " + new_obj.get("TotalRecovered"));
                         break;
                      }
                 }
               */

                }


        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() );
        }
        // return con;
    }

    // TEST END



    public static String getAbcCodes(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/AbcCodes?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".abccode where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".abccode (tenant_id , id , " +
                          " Code , " +
                          " BasicSafetyTime , " +
                          " AmountLimit , " +
                          " AmountLimitCurrencyId , " +
                          " AmountLimitExceptionPurchasePart , " +
                          " AmountLimitExceptionPurchasePartCurrencyId , " +
                          " DescriptionId , " +
                          " AbcCodeType , " +
                          " PercentLimit , " +
                          " Description   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Code") == null)                                          ? 0 : rec_obj.get("Code")  )                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BasicSafetyTime") == null)                               ? 0 : rec_obj.get("BasicSafetyTime")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AmountLimit") == null)                                   ? 0 : rec_obj.get("AmountLimit")  )                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AmountLimitCurrencyId") == null)                         ? 0 : rec_obj.get("AmountLimitCurrencyId")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AmountLimitExceptionPurchasePart") == null)              ? 0 : rec_obj.get("AmountLimitExceptionPurchasePart")  )              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AmountLimitExceptionPurchasePartCurrencyId") == null)    ? 0 : rec_obj.get("AmountLimitExceptionPurchasePartCurrencyId")  )    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                                 ? 0 : rec_obj.get("DescriptionId")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AbcCodeType") == null)                                   ? 0 : rec_obj.get("AbcCodeType")  )                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PercentLimit") == null)                                  ? 0 : rec_obj.get("PercentLimit")  )                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                                   ? 0 : rec_obj.get("Description")  )                                   + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "AbcCode was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getAbcCodes





    public static String getAlloys(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Alloys?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".alloy where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".alloy (tenant_id , id , " +
                          " Code , " +
                          " DescriptionId , " +
                          " Price , " +
                          " PriceCurrencyId , " +
                          " UnitId , " +
                          " PartId , " +
                          " Description   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Code") == null)                                          ? 0 : rec_obj.get("Code")  )                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                                 ? 0 : rec_obj.get("DescriptionId")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Price") == null)                                         ? 0 : rec_obj.get("Price")  )                                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PriceCurrencyId") == null)                               ? 0 : rec_obj.get("PriceCurrencyId")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("UnitId") == null)                                        ? 0 : rec_obj.get("UnitId")  )                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PartId") == null)                                        ? 0 : rec_obj.get("PartId")  )                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                                   ? 0 : rec_obj.get("Description")  )                                   + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Alloy was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getAlloys






    public static String getCaseEntry(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/CaseEntry?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".caseentry where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".caseentry (tenant_id , id , " +
                          " Number , " +
                          " CaseTypeId , " +
                          " Status , " +
                          " CaseDate , " +
                          " WarehouseId , " +
                          " CustomerId , " +
                          " SupplierId , " +
                          " CaseBaseType , " +
                          " ManagementTemplateId , " +
                          " ContactCaseNumber , " +
                          " ProductRecordId , " +
                          " PartId , " +
                          " PartRevisionId , " +
                          " RejectionCodeItemId , " +
                          " RejectedQuantity , " +
                          " RejectionDescriptionId , " +
                          " ProductRecordBatchId , " +
                          " CustomerOrderId , " +
                          " DeliveredQuantity , " +
                          " DeliveryDate , " +
                          " AccountReciveableId , " +
                          " PurchaseOrderId , " +
                          " SupplierPartNumber , " +
                          " ArrivedQuantity , " +
                          " ArrivalDate , " +
                          " AccountsPayableId , " +
                          " ProjectId , " +
                          " ManufacturingOrderId , " +
                          " ManufacturedDate , " +
                          " ManufacturedQuantity , " +
                          " WorkCenterId , " +
                          " OperationNumber , " +
                          " InitialPurchaseOrderId , " +
                          " InitialArrivedQuantity , " +
                          " InitialArrivalDate , " +
                          " OurReferenceId , " +
                          " OurReferenceName , " +
                          " ContactReferenceId , " +
                          " ContactName , " +
                          " CategoryString , " +
                          " Priority , " +
                          " GoodsLocation , " +
                          " CreditCustomerOrderId , " +
                          " CreditAccountsReceivableId , " +
                          " RequestCredit , " +
                          " CreditAccountsPayableId , " +
                          " CompensationCustomerOrderId , " +
                          " CompensationAccountsReceivableId , " +
                          " CompensationPurchaseOrderId , " +
                          " CompensationAccountsPayableId , " +
                          " ReasonRejectionCodeId , " +
                          " ReasonSupplierId , " +
                          " ReasonPartId , " +
                          " ReasonWorkCenterId , " +
                          " ReasonDepartmentId , " +
                          " ReasonCommentId , " +
                          " ActualRejectionCodeId , " +
                          " ActualRejectedQuantity , " +
                          " ActualRejectionDescriptionId , " +
                          " ContactCommentId , " +
                          " InternalCommentId , " +
                          " ExternalCommentId , " +
                          " PlannedMaterialCost , " +
                          " PlannedMaterialCostCurrencyId , " +
                          " PlannedSubcontractorCost , " +
                          " PlannedSubcontractorCostCurrencyId , " +
                          " PlannedProcessingCost , " +
                          " PlannedProcessingCostCurrencyId , " +
                          " PlannedProcessingTime , " +
                          " ActualMaterialCost , " +
                          " ActualMaterialCostCurrencyId , " +
                          " ActualSubcontractorCost , " +
                          " ActualSubcontractorCostCurrencyId , " +
                          " ActualProcessingCost , " +
                          " ActualProcessingCostCurrencyId , " +
                          " ActualProcessingTime , " +
                          " CostCommentId , " +
                          " Project , " +
                          " CustomerOrder , " +
                          " PurchaseOrder , " +
                          " InternalComment , " +
                          " ReasonComment , " +
                          " ActualRejectionComment , " +
                          " CaseType , " +
                          " Warehouse , " +
                          " ProductRecord , " +
                          " Part , " +
                          " ManufacturingOrder , " +
                          " ActualRejectionCode , " +
                          " RejectionCodeItem , " +
                          " AccountsReceivable   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Number") == null)                                          ? 0 : rec_obj.get("Number")  )                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CaseTypeId") == null)                                      ? 0 : rec_obj.get("CaseTypeId")  )                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Status") == null)                                          ? 0 : rec_obj.get("Status")  )                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CaseDate") == null      || rec_obj.get("CaseDate").toString().substring(0,2).equals("00")  )      ? new Date(2021000000) : rec_obj.get("CaseDate").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("WarehouseId") == null)                                     ? 0 : rec_obj.get("WarehouseId")  )                                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CustomerId") == null)                                      ? 0 : rec_obj.get("CustomerId")  )                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SupplierId") == null)                                      ? 0 : rec_obj.get("SupplierId")  )                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CaseBaseType") == null)                                    ? 0 : rec_obj.get("CaseBaseType")  )                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ManagementTemplateId") == null)                            ? 0 : rec_obj.get("ManagementTemplateId")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ContactCaseNumber") == null)                               ? 0 : rec_obj.get("ContactCaseNumber")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ProductRecordId") == null)                                 ? 0 : rec_obj.get("ProductRecordId")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PartId") == null)                                          ? 0 : rec_obj.get("PartId")  )                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PartRevisionId") == null)                                  ? 0 : rec_obj.get("PartRevisionId")  )                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RejectionCodeItemId") == null)                             ? 0 : rec_obj.get("RejectionCodeItemId")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RejectedQuantity") == null)                                ? 0 : rec_obj.get("RejectedQuantity")  )                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RejectionDescriptionId") == null)                          ? 0 : rec_obj.get("RejectionDescriptionId")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ProductRecordBatchId") == null)                            ? 0 : rec_obj.get("ProductRecordBatchId")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CustomerOrderId") == null)                                 ? 0 : rec_obj.get("CustomerOrderId")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DeliveredQuantity") == null)                               ? 0 : rec_obj.get("DeliveredQuantity")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DeliveryDate") == null      || rec_obj.get("DeliveryDate").toString().substring(0,2).equals("00")  )      ? new Date(2021000000) : rec_obj.get("DeliveryDate").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("AccountReciveableId") == null)                             ? 0 : rec_obj.get("AccountReciveableId")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PurchaseOrderId") == null)                                 ? 0 : rec_obj.get("PurchaseOrderId")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SupplierPartNumber") == null)                              ? 0 : rec_obj.get("SupplierPartNumber")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ArrivedQuantity") == null)                                 ? 0 : rec_obj.get("ArrivedQuantity")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ArrivalDate") == null      || rec_obj.get("ArrivalDate").toString().substring(0,2).equals("00")  )      ? new Date(2021000000) : rec_obj.get("ArrivalDate").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("AccountsPayableId") == null)                               ? 0 : rec_obj.get("AccountsPayableId")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ProjectId") == null)                                       ? 0 : rec_obj.get("ProjectId")  )                                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ManufacturingOrderId") == null)                            ? 0 : rec_obj.get("ManufacturingOrderId")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ManufacturedDate") == null      || rec_obj.get("ManufacturedDate").toString().substring(0,2).equals("00")  )      ? new Date(2021000000) : rec_obj.get("ManufacturedDate").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("ManufacturedQuantity") == null)                            ? 0 : rec_obj.get("ManufacturedQuantity")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("WorkCenterId") == null)                                    ? 0 : rec_obj.get("WorkCenterId")  )                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OperationNumber") == null)                                 ? 0 : rec_obj.get("OperationNumber")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InitialPurchaseOrderId") == null)                          ? 0 : rec_obj.get("InitialPurchaseOrderId")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InitialArrivedQuantity") == null)                          ? 0 : rec_obj.get("InitialArrivedQuantity")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InitialArrivalDate") == null      || rec_obj.get("InitialArrivalDate").toString().substring(0,2).equals("00")  )      ? new Date(2021000000) : rec_obj.get("InitialArrivalDate").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("OurReferenceId") == null)                                  ? 0 : rec_obj.get("OurReferenceId")  )                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OurReferenceName") == null)                                ? 0 : rec_obj.get("OurReferenceName")  )                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ContactReferenceId") == null)                              ? 0 : rec_obj.get("ContactReferenceId")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ContactName") == null)                                     ? 0 : rec_obj.get("ContactName")  )                                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CategoryString") == null)                                  ? 0 : rec_obj.get("CategoryString")  )                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Priority") == null)                                        ? 0 : rec_obj.get("Priority")  )                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("GoodsLocation") == null)                                   ? 0 : rec_obj.get("GoodsLocation")  )                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CreditCustomerOrderId") == null)                           ? 0 : rec_obj.get("CreditCustomerOrderId")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CreditAccountsReceivableId") == null)                      ? 0 : rec_obj.get("CreditAccountsReceivableId")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RequestCredit") == "false")                                ? 0 : 1  )                                                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CreditAccountsPayableId") == null)                         ? 0 : rec_obj.get("CreditAccountsPayableId")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CompensationCustomerOrderId") == null)                     ? 0 : rec_obj.get("CompensationCustomerOrderId")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CompensationAccountsReceivableId") == null)                ? 0 : rec_obj.get("CompensationAccountsReceivableId")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CompensationPurchaseOrderId") == null)                     ? 0 : rec_obj.get("CompensationPurchaseOrderId")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CompensationAccountsPayableId") == null)                   ? 0 : rec_obj.get("CompensationAccountsPayableId")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReasonRejectionCodeId") == null)                           ? 0 : rec_obj.get("ReasonRejectionCodeId")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReasonSupplierId") == null)                                ? 0 : rec_obj.get("ReasonSupplierId")  )                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReasonPartId") == null)                                    ? 0 : rec_obj.get("ReasonPartId")  )                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReasonWorkCenterId") == null)                              ? 0 : rec_obj.get("ReasonWorkCenterId")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReasonDepartmentId") == null)                              ? 0 : rec_obj.get("ReasonDepartmentId")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReasonCommentId") == null)                                 ? 0 : rec_obj.get("ReasonCommentId")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ActualRejectionCodeId") == null)                           ? 0 : rec_obj.get("ActualRejectionCodeId")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ActualRejectedQuantity") == null)                          ? 0 : rec_obj.get("ActualRejectedQuantity")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ActualRejectionDescriptionId") == null)                    ? 0 : rec_obj.get("ActualRejectionDescriptionId")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ContactCommentId") == null)                                ? 0 : rec_obj.get("ContactCommentId")  )                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InternalCommentId") == null)                               ? 0 : rec_obj.get("InternalCommentId")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ExternalCommentId") == null)                               ? 0 : rec_obj.get("ExternalCommentId")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PlannedMaterialCost") == null)                             ? 0 : rec_obj.get("PlannedMaterialCost")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PlannedMaterialCostCurrencyId") == null)                   ? 0 : rec_obj.get("PlannedMaterialCostCurrencyId")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PlannedSubcontractorCost") == null)                        ? 0 : rec_obj.get("PlannedSubcontractorCost")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PlannedSubcontractorCostCurrencyId") == null)              ? 0 : rec_obj.get("PlannedSubcontractorCostCurrencyId")  )              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PlannedProcessingCost") == null)                           ? 0 : rec_obj.get("PlannedProcessingCost")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PlannedProcessingCostCurrencyId") == null)                 ? 0 : rec_obj.get("PlannedProcessingCostCurrencyId")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PlannedProcessingTime") == null)                           ? 0 : rec_obj.get("PlannedProcessingTime")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ActualMaterialCost") == null)                              ? 0 : rec_obj.get("ActualMaterialCost")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ActualMaterialCostCurrencyId") == null)                    ? 0 : rec_obj.get("ActualMaterialCostCurrencyId")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ActualSubcontractorCost") == null)                         ? 0 : rec_obj.get("ActualSubcontractorCost")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ActualSubcontractorCostCurrencyId") == null)               ? 0 : rec_obj.get("ActualSubcontractorCostCurrencyId")  )               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ActualProcessingCost") == null)                            ? 0 : rec_obj.get("ActualProcessingCost")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ActualProcessingCostCurrencyId") == null)                  ? 0 : rec_obj.get("ActualProcessingCostCurrencyId")  )                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ActualProcessingTime") == null)                            ? 0 : rec_obj.get("ActualProcessingTime")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CostCommentId") == null)                                   ? 0 : rec_obj.get("CostCommentId")  )                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Project") == null)                                         ? 0 : rec_obj.get("Project")  )                                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CustomerOrder") == null)                                   ? 0 : rec_obj.get("CustomerOrder")  )                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PurchaseOrder") == null)                                   ? 0 : rec_obj.get("PurchaseOrder")  )                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InternalComment") == null)                                 ? 0 : rec_obj.get("InternalComment")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReasonComment") == null)                                   ? 0 : rec_obj.get("ReasonComment")  )                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ActualRejectionComment") == null)                          ? 0 : rec_obj.get("ActualRejectionComment")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CaseType") == null)                                        ? 0 : rec_obj.get("CaseType")  )                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Warehouse") == null)                                       ? 0 : rec_obj.get("Warehouse")  )                                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ProductRecord") == null)                                   ? 0 : rec_obj.get("ProductRecord")  )                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Part") == null)                                            ? 0 : rec_obj.get("Part")  )                                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ManufacturingOrder") == null)                              ? 0 : rec_obj.get("ManufacturingOrder")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ActualRejectionCode") == null)                             ? 0 : rec_obj.get("ActualRejectionCode")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RejectionCodeItem") == null)                               ? 0 : rec_obj.get("RejectionCodeItem")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AccountsReceivable") == null)                              ? 0 : rec_obj.get("AccountsReceivable")  )                              + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "CaseEntry was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getCaseEntry






    public static String getCaseEntryActivities(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/CaseEntryActivities?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".caseentryactivity where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".caseentryactivity (tenant_id , id , " +
                          " CaseEntryId , " +
                          " PlannedTime , " +
                          " ReportedTime , " +
                          " ShowOnDocuments , " +
                          " ReportingType , " +
                          " Mandatory , " +
                          " CostPerHour , " +
                          " CostPerHourCurrencyId , " +
                          " Chargeable , " +
                          " ActivityTypeId , " +
                          " CompletedByUserId , " +
                          " ResponsibleUserId , " +
                          " DescriptionId , " +
                          " CommentId , " +
                          " Status , " +
                          " ReminderId , " +
                          " PlannedCompletionDate , " +
                          " CompletionDate , " +
                          " PlannedStartDate , " +
                          " ActualStartDate , " +
                          " CalendarAppointmentId , " +
                          " Description , " +
                          " Comment   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("CaseEntryId") == null)                                        ? 0 : rec_obj.get("CaseEntryId")  )                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PlannedTime") == null)                                        ? 0 : rec_obj.get("PlannedTime")  )                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReportedTime") == null)                                       ? 0 : rec_obj.get("ReportedTime")  )                                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ShowOnDocuments") == "false")                                 ? 0 : 1  )                                                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReportingType") == null)                                      ? 0 : rec_obj.get("ReportingType")  )                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Mandatory") == "false")                                       ? 0 : 1  )                                                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CostPerHour") == null)                                        ? 0 : rec_obj.get("CostPerHour")  )                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CostPerHourCurrencyId") == null)                              ? 0 : rec_obj.get("CostPerHourCurrencyId")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Chargeable") == "false")                                      ? 0 : 1  )                                                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ActivityTypeId") == null)                                     ? 0 : rec_obj.get("ActivityTypeId")  )                                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CompletedByUserId") == null)                                  ? 0 : rec_obj.get("CompletedByUserId")  )                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ResponsibleUserId") == null)                                  ? 0 : rec_obj.get("ResponsibleUserId")  )                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                                      ? 0 : rec_obj.get("DescriptionId")  )                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CommentId") == null)                                          ? 0 : rec_obj.get("CommentId")  )                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Status") == null)                                             ? 0 : rec_obj.get("Status")  )                                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReminderId") == null)                                         ? 0 : rec_obj.get("ReminderId")  )                                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PlannedCompletionDate") == null      || rec_obj.get("PlannedCompletionDate").toString().substring(0,2).equals("00")  )      ? new Date(2021000000) : rec_obj.get("PlannedCompletionDate").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("CompletionDate") == null             || rec_obj.get("CompletionDate").toString().substring(0,2).equals("00")  )             ? new Date(2021000000) : rec_obj.get("CompletionDate").toString().substring(0,19).replace('T', ' ')  )             + "\" " + ", " +
                          "\"" + ((rec_obj.get("PlannedStartDate") == null           || rec_obj.get("PlannedStartDate").toString().substring(0,2).equals("00")  )           ? new Date(2021000000) : rec_obj.get("PlannedStartDate").toString().substring(0,19).replace('T', ' ')  )           + "\" " + ", " +
                          "\"" + ((rec_obj.get("ActualStartDate") == null            || rec_obj.get("ActualStartDate").toString().substring(0,2).equals("00")  )            ? new Date(2021000000) : rec_obj.get("ActualStartDate").toString().substring(0,19).replace('T', ' ')  )            + "\" " + ", " +
                          "\"" + ((rec_obj.get("CalendarAppointmentId") == null)                              ? 0 : rec_obj.get("CalendarAppointmentId")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                                        ? 0 : rec_obj.get("Description")  )                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Comment") == null)                                            ? 0 : rec_obj.get("Comment")  )                                            + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "CaseEntryActivity was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getCaseEntryActivities




    public static String getCaseEntryAdditionalCost(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/CaseEntryAdditionalCost?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".caseentryadditionalcost where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".caseentryadditionalcost (tenant_id , id , " +
                          " CaseManagementCostId , " +
                          " Cost , " +
                          " CostCurrencyId , " +
                          " CaseEntryId , " +
                          " CostType , " +
                          " Chargeable , " +
                          " CaseManagementCost   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("CaseManagementCostId") == null)                                  ? 0 : rec_obj.get("CaseManagementCostId")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Cost") == null)                                                  ? 0 : rec_obj.get("Cost")  )                                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CostCurrencyId") == null)                                        ? 0 : rec_obj.get("CostCurrencyId")  )                                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CaseEntryId") == null)                                           ? 0 : rec_obj.get("CaseEntryId")  )                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CostType") == null)                                              ? 0 : rec_obj.get("CostType")  )                                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Chargeable") == "false")                                         ? 0 : 1  )                                                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CaseManagementCost") == null)                                    ? 0 : rec_obj.get("CaseManagementCost")  )                                 + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "CaseEntryAdditionalCost was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getCaseEntryAdditionalCost




    public static String getCaseEntryPhases(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/CaseEntryPhases?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".caseentryphase where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".caseentryphase (tenant_id , id , " +
                          " CaseManagementPhaseId , " +
                          " DescriptionId , " +
                          " ResposibleUserId , " +
                          " ParentId , " +
                          " RowIndex , " +
                          " CaseManagementPhase , " +
                          " Description   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("CaseManagementPhaseId") == null)                                ? 0 : rec_obj.get("CaseManagementPhaseId")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                                        ? 0 : rec_obj.get("DescriptionId")  )                                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ResposibleUserId") == null)                                     ? 0 : rec_obj.get("ResposibleUserId")  )                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ParentId") == null)                                             ? 0 : rec_obj.get("ParentId")  )                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RowIndex") == null)                                             ? 0 : rec_obj.get("RowIndex")  )                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CaseManagementPhase") == null)                                  ? 0 : rec_obj.get("CaseManagementPhase")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                                          ? 0 : rec_obj.get("Description")  )                                       + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "CaseEntryPhase was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getCaseEntryPhases






    public static String getCaseManagementActivities(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/CaseManagementActivities?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".casemanagementactivity where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".casemanagementactivity (tenant_id , id , " +
                          " PlannedTime , " +
                          " CostPerHour , " +
                          " CostPerHourCurrencyId , " +
                          " Chargeable , " +
                          " Code , " +
                          " DescriptionId , " +
                          " Description   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("PlannedTime") == null)                                ? 0 : rec_obj.get("PlannedTime")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CostPerHour") == null)                                ? 0 : rec_obj.get("CostPerHour")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CostPerHourCurrencyId") == null)                      ? 0 : rec_obj.get("CostPerHourCurrencyId")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Chargeable") == "false")                              ? 0 : 1  )                                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Code") == null)                                       ? 0 : rec_obj.get("Code")  )                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                              ? 0 : rec_obj.get("DescriptionId")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                                ? 0 : rec_obj.get("Description")  )                             + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "CaseManagementActivity was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getCaseManagementActivities





    public static String getCaseManagementCost(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/CaseManagementCost?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".casemanagementcost where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".casemanagementcost (tenant_id , id , " +
                          " Number , " +
                          " DescriptionId , " +
                          " Cost , " +
                          " CostCurrencyId , " +
                          " Chargeable , " +
                          " Description   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Number") == null)                                ? 0 : rec_obj.get("Number")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                         ? 0 : rec_obj.get("DescriptionId")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Cost") == null)                                  ? 0 : rec_obj.get("Cost")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CostCurrencyId") == null)                        ? 0 : rec_obj.get("CostCurrencyId")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Chargeable") == "false")                         ? 0 : 1  )                                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                           ? 0 : rec_obj.get("Description")  )                        + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "CaseManagementCost was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getCaseManagementCost




    public static String getCaseManagementPhases(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/CaseManagementPhases?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".casemanagementphase where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".casemanagementphase (tenant_id , id , " +
                          " Number , " +
                          " DescriptionId , " +
                          " Description   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Number") == null)                                ? 0 : rec_obj.get("Number")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                         ? 0 : rec_obj.get("DescriptionId")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                           ? 0 : rec_obj.get("Description")  )                        + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "CaseManagementPhase was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getCaseManagementPhases





    public static String getCaseManagementType(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/CaseManagementType?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".casemanagementtype where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".casemanagementtype (tenant_id , id , " +
                          " Type , " +
                          " Number , " +
                          " Prefix , " +
                          " DescriptionId , " +
                          " Priority , " +
                          " Visible , " +
                          " IsPreset , " +
                          " Description   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Type") == null)                                  ? 0 : rec_obj.get("Type")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Number") == null)                                ? 0 : rec_obj.get("Number")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Prefix") == null)                                ? 0 : rec_obj.get("Prefix")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                         ? 0 : rec_obj.get("DescriptionId")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Priority") == null)                              ? 0 : rec_obj.get("Priority")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Visible") == "false")                            ? 0 : 1  )                                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsPreset") == "false")                           ? 0 : 1  )                                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                           ? 0 : rec_obj.get("Description")  )                        + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "CaseManagementType was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getCaseManagementType






    public static String getGoodsTypes(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/GoodsTypes?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".goodstype where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".goodstype (tenant_id , id , " +
                          " Number , " +
                          " DescriptionId , " +
                          " IsActive , " +
                          " Description   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Number") == null)                                ? 0 : rec_obj.get("Number")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                         ? 0 : rec_obj.get("DescriptionId")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsActive") == "false")                           ? 0 : 1  )                                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                           ? 0 : rec_obj.get("Description")  )                       + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "GoodsType was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getGoodsTypes




    public static String getHyperLinks(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/HyperLinks?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".hyperlink where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".hyperlink (tenant_id , id , " +
                          " DescriptionId , " +
                          " Link , " +
                          " PartId , " +
                          " Description    " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                         ? 0 : rec_obj.get("DescriptionId")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Link") == null)                                  ? 0 : rec_obj.get("Link")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PartId") == null)                                ? 0 : rec_obj.get("PartId")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                           ? 0 : rec_obj.get("Description")  )                       + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "HyperLink was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getHyperLinks




    public static String getPackageTypes(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/PackageTypes?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".packagetype where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".packagetype (tenant_id , id , " +
                          " Number , " +
                          " DescriptionId , " +
                          " IsActive , " +
                          " DefaultCode , " +
                          " Description   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Number") == null)                                ? 0 : rec_obj.get("Number")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                         ? 0 : rec_obj.get("DescriptionId")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsActive") == "false")                           ? 0 : 1  )                                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DefaultCode") == null)                           ? 0 : rec_obj.get("DefaultCode")  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                           ? 0 : rec_obj.get("Description")  )                       + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "PackageType was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getPackageTypes




    public static String getParts(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/Parts?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".part where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".part (tenant_id , id , " +
                          " ExtraDescriptionId, " +
                          " CompanyId, " +
                          " DaysToAddToBestBeforeDate, " +
                          " PartNumber, " +
                          " Length, " +
                          " Width, " +
                          " Height, " +
                          " PackagingType, " +
                          " PackageVolumeConsistsOf, " +
                          " PackageTypeId, " +
                          " UseRandomLocationStorage, " +
                          " ShowFictiousStructureOnOrderRegistration, " +
                          " TraceabilityMode, " +
                          " UseBestBeforeDate, " +
                          " ManageStockBalance, " +
                          " StandardPrice, " +
                          " StandardPriceCurrencyId, " +
                          " FutureStandardPrice, " +
                          " FutureStandardPriceCurrencyId, " +
                          " PostCalculatedAveragePrice, " +
                          " PostCalculatedAveragePriceCurrencyId, " +
                          " Type, " +
                          " ProductGroupId, " +
                          " WeightPerUnit, " +
                          " StatisticalGoodsCodeId, " +
                          " StatisticalGoodsValue, " +
                          " CountryOfOriginId, " +
                          " GermanRegionOfOrigin, " +
                          " GermanRegionOfDestination, " +
                          " PartCodeId, " +
                          " CategoryString, " +
                          " StorageOverheadMarkupId, " +
                          " SalesOverheadMarkupId, " +
                          " ProfitMarkupId, " +
                          " VolumePerUnit, " +
                          " AveragePrice, " +
                          " AveragePriceCurrencyId, " +
                          " LastPurchasePrice, " +
                          " LastPurchasePriceCurrencyId, " +
                          " AveragePriceTimestamp, " +
                          " PurchaseLabelType, " +
                          " CurrentAlloyId, " +
                          " CurrentAlloyQuantity, " +
                          " ReceivingInspectionChanged, " +
                          " ReceivingInspectionCounter, " +
                          " ReceivingInspectionChangedById, " +
                          " ReceivingInspectionIntervall, " +
                          " ReceivingInspectionStartDate, " +
                          " ReceivingInspectionEndDate, " +
                          " PurchaseQuantityPerPackage, " +
                          " IsPackaging, " +
                          " Status, " +
                          " PurchaseAndManufactureOnProject, " +
                          " ServiceType, " +
                          " QuantityPerPackage, " +
                          " PackagingWeightPerPackage, " +
                          " PackagingPartId, " +
                          " LoadingMetersPerUnit, " +
                          " PackingReference, " +
                          " Gs1Code, " +
                          " VatRateId, " +
                          " LastSalesPrice, " +
                          " LastSalesPriceCurrencyId, " +
                          " TransportCost, " +
                          " SerialNumberGeneration, " +
                          " SerialNumberGenerationSource, " +
                          " GoodsType, " +
                          " LeadTimeToCustomer, " +
                          " QuantityForLeadtimeToCustomer, " +
                          " SalesLabelType, " +
                          " DefaultCustomerOrderWarehouseId, " +
                          " ManufacturingLabelType, " +
                          " PreparerId, " +
                          " SuggestBestBeforeDate, " +
                          " GoodsTypeId, " +
                          " CalculatedQuantity, " +
                          " Alias, " +
                          " BlockedFromDate, " +
                          " BlockedStatus, " +
                          " BlockedToDate, " +
                          " BlockedById, " +
                          " BlockedContextType, " +
                          " ReceivingInspectionType, " +
                          " DescriptionId, " +
                          " StandardPartUnitUsageId, " +
                          " TariffAndServiceCodeId, " +
                          " CommentId, " +
                          " ActiveRevisionId, " +
                          " BlockMessageId, " +
                          " LatestCalculationId, " +
                          " ReceivingInstructionId, " +
                          " PurchaseCommentId, " +
                          " PurchaseCommentShowInForms, " +
                          " PickingInstructionId, " +
                          " SalesCommentId, " +
                          " SalesCommentShowInForms, " +
                          " ManufacturingCommentId, " +
                          " PreparationId, " +
                          " ProjectId, " +
                          " TagContainerId, " +
                          " ConfigurationTemplateId, " +
                          " ConfigurationSelectionDescriptionId, " +
                          " ConfigurationSelectionImageId, " +
                          " ConfigurationSelectionExtraDescriptionId, " +
                          " ConfigurationOpenAutomatically, " +
                          " ConfigurationDefaultPresetId, " +
                          " FormulaApplicationMethod, " +
                          " AutomaticReportingMode, " +
                          " LatestPurchaseCalculationId, " +
                          " PartPurchaseExpenseValuesId, " +
                          " PartTemplateId, " +
                          " PackageNumberSubscriber, " +
                          " PolishGtuCodeId, " +
                          " PackageTransportLabelFormReportConfigurationId , " +

                          " PackagingTemplateId , " +
                          " IsFixedWeight , " +
                          " Description , " +
                          " ExtraDescription , " +
                          " StandardUnitId  "  +

                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("ExtraDescriptionId") == null)                               ? 0 : rec_obj.get("ExtraDescriptionId")  )                               + "\" "    + ", " +
                           "\"" + ((rec_obj.get("CompanyId") == null)                                        ? 0 : rec_obj.get("CompanyId")  )                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DaysToAddToBestBeforeDate") == null)                        ? 0 : rec_obj.get("DaysToAddToBestBeforeDate")  )                        + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PartNumber") == null)                                       ? 0 : rec_obj.get("PartNumber")  )                                       + "\" "    + ", " +
                           "\"" + ((rec_obj.get("Length") == null)                                           ? 0 : rec_obj.get("Length")  )                                           + "\" "    + ", " +
                           "\"" + ((rec_obj.get("Width") == null)                                            ? 0 : rec_obj.get("Width")  )                                            + "\" "    + ", " +
                           "\"" + ((rec_obj.get("Height") == null)                                           ? 0 : rec_obj.get("Height")  )                                           + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PackagingType") == null)                                    ? 0 : rec_obj.get("PackagingType")  )                                    + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PackageVolumeConsistsOf") == null)                          ? 0 : rec_obj.get("PackageVolumeConsistsOf")  )                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PackageTypeId") == null)                                    ? 0 : rec_obj.get("PackageTypeId")  )                                    + "\" "    + ", " +
                           "\"" + ((rec_obj.get("UseRandomLocationStorage") == "false")                      ? 0 : 1  )                                                               + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ShowFictiousStructureOnOrderRegistration") == "false")      ? 0 : 1  )                                                               + "\" "    + ", " +
                           "\"" + ((rec_obj.get("TraceabilityMode") == null)                                 ? 0 : rec_obj.get("TraceabilityMode")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("UseBestBeforeDate") == "false")                             ? 0 : 1  )                                                               + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ManageStockBalance") == "false")                            ? 0 : 1  )                                                               + "\" "    + ", " +
                           "\"" + ((rec_obj.get("StandardPrice") == null)                                    ? 0 : rec_obj.get("StandardPrice")  )                                    + "\" "    + ", " +
                           "\"" + ((rec_obj.get("StandardPriceCurrencyId") == null)                          ? 0 : rec_obj.get("StandardPriceCurrencyId")  )                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("FutureStandardPrice") == null)                              ? 0 : rec_obj.get("FutureStandardPrice")  )                              + "\" "    + ", " +
                           "\"" + ((rec_obj.get("FutureStandardPriceCurrencyId") == null)                    ? 0 : rec_obj.get("FutureStandardPriceCurrencyId")  )                    + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PostCalculatedAveragePrice") == null)                       ? 0 : rec_obj.get("PostCalculatedAveragePrice")  )                       + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PostCalculatedAveragePriceCurrencyId") == null)             ? 0 : rec_obj.get("PostCalculatedAveragePriceCurrencyId")  )             + "\" "    + ", " +
                           "\"" + ((rec_obj.get("Type") == null)                                             ? 0 : rec_obj.get("Type")  )                                             + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ProductGroupId") == null)                                   ? 0 : rec_obj.get("ProductGroupId")  )                                   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("WeightPerUnit") == null)                                    ? 0 : rec_obj.get("WeightPerUnit")  )                                    + "\" "    + ", " +
                           "\"" + ((rec_obj.get("StatisticalGoodsCodeId") == null)                           ? 0 : rec_obj.get("StatisticalGoodsCodeId")  )                           + "\" "    + ", " +
                           "\"" + ((rec_obj.get("StatisticalGoodsValue") == null)                            ? 0 : rec_obj.get("StatisticalGoodsValue")  )                            + "\" "    + ", " +
                           "\"" + ((rec_obj.get("CountryOfOriginId") == null)                                ? 0 : rec_obj.get("CountryOfOriginId")  )                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("GermanRegionOfOrigin") == null)                             ? 0 : rec_obj.get("GermanRegionOfOrigin")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("GermanRegionOfDestination") == null)                        ? 0 : rec_obj.get("GermanRegionOfDestination")  )                        + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PartCodeId") == null)                                       ? 0 : rec_obj.get("PartCodeId")  )                                       + "\" "    + ", " +
                           "\"" + ((rec_obj.get("CategoryString") == null)                                   ? 0 : rec_obj.get("CategoryString")  )                                   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("StorageOverheadMarkupId") == null)                          ? 0 : rec_obj.get("StorageOverheadMarkupId")  )                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("SalesOverheadMarkupId") == null)                            ? 0 : rec_obj.get("SalesOverheadMarkupId")  )                            + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ProfitMarkupId") == null)                                   ? 0 : rec_obj.get("ProfitMarkupId")  )                                   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("VolumePerUnit") == null)                                    ? 0 : rec_obj.get("VolumePerUnit")  )                                    + "\" "    + ", " +
                           "\"" + ((rec_obj.get("AveragePrice") == null)                                     ? 0 : rec_obj.get("AveragePrice")  )                                     + "\" "    + ", " +
                           "\"" + ((rec_obj.get("AveragePriceCurrencyId") == null)                           ? 0 : rec_obj.get("AveragePriceCurrencyId")  )                           + "\" "    + ", " +
                           "\"" + ((rec_obj.get("LastPurchasePrice") == null)                                ? 0 : rec_obj.get("LastPurchasePrice")  )                                + "\" "    + ", " +
                           "\"" + ((rec_obj.get("LastPurchasePriceCurrencyId") == null)                      ? 0 : rec_obj.get("LastPurchasePriceCurrencyId")  )                      + "\" "    + ", " +
                           "\"" + ((rec_obj.get("AveragePriceTimestamp") == null)                            ? new Date(2021000000) : rec_obj.get("AveragePriceTimestamp").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                           "\"" + ((rec_obj.get("PurchaseLabelType") == null)                                ? 0 : rec_obj.get("PurchaseLabelType")  )                                + "\" "    + ", " +
                           "\"" + ((rec_obj.get("CurrentAlloyId") == null)                                   ? 0 : rec_obj.get("CurrentAlloyId")  )                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CurrentAlloyQuantity") == null)                             ? 0 : rec_obj.get("CurrentAlloyQuantity")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReceivingInspectionChanged") == null)                       ? new Date(2021000000) : rec_obj.get("ReceivingInspectionChanged").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                          "\"" + ((rec_obj.get("ReceivingInspectionCounter") == null)                       ? 0 : rec_obj.get("ReceivingInspectionCounter")  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReceivingInspectionChangedById") == null)                   ? 0 : rec_obj.get("ReceivingInspectionChangedById")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReceivingInspectionIntervall") == null)                     ? 0 : rec_obj.get("ReceivingInspectionIntervall")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReceivingInspectionStartDate") == null)                     ? new Date(2021000000) : rec_obj.get("ReceivingInspectionStartDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                          "\"" + ((rec_obj.get("ReceivingInspectionEndDate") == null)                       ? new Date(2021000000) : rec_obj.get("ReceivingInspectionEndDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                           "\"" + ((rec_obj.get("PurchaseQuantityPerPackage") == null)                       ? 0 : rec_obj.get("PurchaseQuantityPerPackage")  )                       + "\" "    + ", " +
                           "\"" + ((rec_obj.get("IsPackaging") == "false")                                   ? 0 : 1 )                                                                + "\" "    + ", " +
                           "\"" + ((rec_obj.get("Status") == null)                                           ? 0 : rec_obj.get("Status")  )                                           + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PurchaseAndManufactureOnProject") == "false")               ? 0 : 1 )                                                                + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ServiceType") == null)                                      ? 0 : rec_obj.get("ServiceType")  )                                      + "\" "    + ", " +
                           "\"" + ((rec_obj.get("QuantityPerPackage") == null)                               ? 0 : rec_obj.get("QuantityPerPackage")  )                               + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PackagingWeightPerPackage") == null)                        ? 0 : rec_obj.get("PackagingWeightPerPackage")  )                        + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PackagingPartId") == null)                                  ? 0 : rec_obj.get("PackagingPartId")  )                                  + "\" "    + ", " +
                           "\"" + ((rec_obj.get("LoadingMetersPerUnit") == null)                             ? 0 : rec_obj.get("LoadingMetersPerUnit")  )                             + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PackingReference") == null)                                 ? 0 : rec_obj.get("PackingReference")  )                                 + "\" "    + ", " +
                           "\"" + ((rec_obj.get("Gs1Code") == null)                                          ? 0 : rec_obj.get("Gs1Code")  )                                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("VatRateId") == null)                                        ? 0 : rec_obj.get("VatRateId")  )                                        + "\" "    + ", " +
                           "\"" + ((rec_obj.get("LastSalesPrice") == null)                                   ? 0 : rec_obj.get("LastSalesPrice")  )                                   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("LastSalesPriceCurrencyId") == null)                         ? 0 : rec_obj.get("LastSalesPriceCurrencyId")  )                         + "\" "    + ", " +
                           "\"" + ((rec_obj.get("TransportCost") == null)                                    ? 0 : rec_obj.get("TransportCost")  )                                    + "\" "    + ", " +
                           "\"" + ((rec_obj.get("SerialNumberGeneration") == null)                           ? 0 : rec_obj.get("SerialNumberGeneration")  )                           + "\" "    + ", " +
                           "\"" + ((rec_obj.get("SerialNumberGenerationSource") == null)                     ? 0 : rec_obj.get("SerialNumberGenerationSource")  )                     + "\" "    + ", " +
                           "\"" + ((rec_obj.get("GoodsType") == null)                                        ? 0 : rec_obj.get("GoodsType")  )                                        + "\" "    + ", " +
                           "\"" + ((rec_obj.get("LeadTimeToCustomer") == null)                               ? 0 : rec_obj.get("LeadTimeToCustomer")  )                               + "\" "    + ", " +
                           "\"" + ((rec_obj.get("QuantityForLeadtimeToCustomer") == null)                    ? 0 : rec_obj.get("QuantityForLeadtimeToCustomer")  )                    + "\" "    + ", " +
                           "\"" + ((rec_obj.get("SalesLabelType") == null)                                   ? 0 : rec_obj.get("SalesLabelType")  )                                   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("DefaultCustomerOrderWarehouseId") == null)                  ? 0 : rec_obj.get("DefaultCustomerOrderWarehouseId")  )                  + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ManufacturingLabelType") == null)                           ? 0 : rec_obj.get("ManufacturingLabelType")  )                           + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PreparerId") == null)                                       ? 0 : rec_obj.get("PreparerId")  )                                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SuggestBestBeforeDate") == null)                            ? 0 : rec_obj.get("SuggestBestBeforeDate")  )                            + "\" "    + ", " +
                           "\"" + ((rec_obj.get("GoodsTypeId") == null)                                      ? 0 : rec_obj.get("GoodsTypeId")  )                                      + "\" "    + ", " +
                           "\"" + ((rec_obj.get("CalculatedQuantity") == null)                               ? 0 : rec_obj.get("CalculatedQuantity")  )                               + "\" "    + ", " +
                           "\"" + ((rec_obj.get("Alias") == null)                                            ? 0 : rec_obj.get("Alias")  )                                            + "\" "    + ", " +
                           "\"" + ((rec_obj.get("BlockedFromDate") == null)                                  ? new Date(2021000000) : rec_obj.get("BlockedFromDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                           "\"" + ((rec_obj.get("BlockedStatus") == null)                                    ? 0 : rec_obj.get("BlockedStatus")  )                                    + "\" "    + ", " +
                           "\"" + ((rec_obj.get("BlockedToDate") == null)                                    ? new Date(2021000000) : rec_obj.get("BlockedToDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                           "\"" + ((rec_obj.get("BlockedById") == null)                                      ? 0 : rec_obj.get("BlockedById")  )                                      + "\" "    + ", " +
                           "\"" + ((rec_obj.get("BlockedContextType") == null)                               ? 0 : rec_obj.get("BlockedContextType")  )                               + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ReceivingInspectionType") == null)                          ? 0 : rec_obj.get("ReceivingInspectionType")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                                    ? 0 : rec_obj.get("DescriptionId")  )                                    + "\" "    + ", " +
                           "\"" + ((rec_obj.get("StandardPartUnitUsageId") == null)                          ? 0 : rec_obj.get("StandardPartUnitUsageId")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("TariffAndServiceCodeId") == null)                           ? 0 : rec_obj.get("TariffAndServiceCodeId")  )                           + "\" "    + ", " +
                           "\"" + ((rec_obj.get("CommentId") == null)                                        ? 0 : rec_obj.get("CommentId")  )                                        + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ActiveRevisionId") == null)                                 ? 0 : rec_obj.get("ActiveRevisionId")  )                                 + "\" "    + ", " +
                           "\"" + ((rec_obj.get("BlockMessageId") == null)                                   ? 0 : rec_obj.get("BlockMessageId")  )                                   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("LatestCalculationId") == null)                              ? 0 : rec_obj.get("LatestCalculationId")  )                              + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ReceivingInstructionId") == null)                           ? 0 : rec_obj.get("ReceivingInstructionId")  )                           + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PurchaseCommentId") == null)                                ? 0 : rec_obj.get("PurchaseCommentId")  )                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PurchaseCommentShowInForms") == null)                       ? 0 : rec_obj.get("PurchaseCommentShowInForms")  )                       + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PickingInstructionId") == null)                             ? 0 : rec_obj.get("PickingInstructionId")  )                             + "\" "    + ", " +
                           "\"" + ((rec_obj.get("SalesCommentId") == null)                                   ? 0 : rec_obj.get("SalesCommentId")  )                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SalesCommentShowInForms") == null)                          ? 0 : rec_obj.get("SalesCommentShowInForms")  )                          + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ManufacturingCommentId") == null)                           ? 0 : rec_obj.get("ManufacturingCommentId")  )                           + "\" "    + ", " +
                           "\"" + ((rec_obj.get("PreparationId") == null)                                    ? 0 : rec_obj.get("PreparationId")  )                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ProjectId") == null)                                        ? 0 : rec_obj.get("ProjectId")  )                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("TagContainerId") == null)                                   ? 0 : rec_obj.get("TagContainerId")  )                                   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ConfigurationTemplateId") == null)                          ? 0 : rec_obj.get("ConfigurationTemplateId")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ConfigurationSelectionDescriptionId") == null)              ? 0 : rec_obj.get("ConfigurationSelectionDescriptionId")  )              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ConfigurationSelectionImageId") == null)                    ? 0 : rec_obj.get("ConfigurationSelectionImageId")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ConfigurationSelectionExtraDescriptionId") == null)         ? 0 : rec_obj.get("ConfigurationSelectionExtraDescriptionId")  )         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ConfigurationOpenAutomatically") == null)                   ? 0 : rec_obj.get("ConfigurationOpenAutomatically")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ConfigurationDefaultPresetId") == null)                     ? 0 : rec_obj.get("ConfigurationDefaultPresetId")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("FormulaApplicationMethod") == null)                         ? 0 : rec_obj.get("FormulaApplicationMethod")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AutomaticReportingMode") == null)                           ? 0 : rec_obj.get("AutomaticReportingMode")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("LatestPurchaseCalculationId") == null)                      ? 0 : rec_obj.get("LatestPurchaseCalculationId")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PartPurchaseExpenseValuesId") == null)                      ? 0 : rec_obj.get("PartPurchaseExpenseValuesId")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PartTemplateId") == null)                                   ? 0 : rec_obj.get("PartTemplateId")  )                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PackageNumberSubscriber") == "false")                       ? 0 : 1 )                                                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PolishGtuCodeId") == null)                                  ? 0 : rec_obj.get("PolishGtuCodeId")  )                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PackageTransportLabelFormReportConfigurationId") == null)   ? 0 : rec_obj.get("PackageTransportLabelFormReportConfigurationId")  )   + "\" "    + ", " +

                          "\"" + ((rec_obj.get("PackagingTemplateId") == null)                              ? 0 : rec_obj.get("PackagingTemplateId")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsFixedWeight") == "false")                                 ? 0 : 1 )                                                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                     ? 0 : rec_obj.get("Description").toString().replaceAll("\"", " ").replaceAll("\\p{Cc}", " ").replaceAll("\\s{2,}", " ")  )   + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ExtraDescription") == null)                                 ? 0 : rec_obj.get("ExtraDescription")  )                                 + "\" "    + ", " +
                           "\"" + ((rec_obj.get("StandardUnitId") == null)                                   ? 0 : rec_obj.get("StandardUnitId")  )                                   + "\" "    + "  " +


                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Part was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getParts





    public static String getPartCodes(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/PartCodes?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".partcode where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".partcode (tenant_id , id , " +
                          " Code , " +
                          " DescriptionId , " +
                          " Alias , " +
                          " Description   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Code") == null)                              ? 0 : rec_obj.get("Code")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                     ? 0 : rec_obj.get("DescriptionId")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Alias") == null)                             ? 0 : rec_obj.get("Alias")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                       ? 0 : rec_obj.get("Description")  )                     + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "PartCode was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getPartCodes




    public static String getPartIdentityTypes(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/PartIdentityTypes?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".partidentitytype where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".partidentitytype (tenant_id , id , " +
                          " Code , " +
                          " DescriptionId , " +
                          " IsActive , " +
                          " Type , " +
                          " Description   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Code") == null)                              ? 0 : rec_obj.get("Code")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                     ? 0 : rec_obj.get("DescriptionId")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsActive") == "false")                       ? 0 : 1  )                                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Type") == null)                              ? 0 : rec_obj.get("Type")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                       ? 0 : rec_obj.get("Description")  )                     + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "PartIdentityType was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getPartIdentityTypes





    public static String getPartLocationProductRecords(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/PartLocationProductRecords?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".partlocationproductrecord where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".partlocationproductrecord (tenant_id , id , " +
                          " Version , " +
                          " PartLocationId , " +
                          " ProductRecordId , " +
                          " Quantity   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Version") == null)                          ? 0 : rec_obj.get("Version")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PartLocationId") == null)                   ? 0 : rec_obj.get("PartLocationId")  )                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ProductRecordId") == null)                  ? 0 : rec_obj.get("ProductRecordId")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Quantity") == null)                         ? 0 : rec_obj.get("Quantity")  )                        + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "PartLocationProductRecord was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getPartLocationProductRecords





    public static String getPartLocations(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/PartLocations?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".partlocation where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".partlocation (tenant_id , id , " +
                          " Version , " +
                          " WorkCenterPickingLocation , " +
                          " WorkCenterPickingLocationFillingQuantity , " +
                          " PartId , " +
                          " WarehouseId , " +
                          " LifeCycleState , " +
                          " Balance , " +
                          " Name , " +
                          " LatestArrivalDate , " +
                          " OutgoingPickLocation , " +
                          " ArrivalLocation , " +
                          " Priority , " +
                          " OutgoingPickLocationReorderPoint , " +
                          " BatchNumber , " +
                          " SerialNumber , " +
                          " IsOngoingRefill , " +
                          " RevisionId , " +
                          " IgnoredBalance , " +
                          " Warehouse , " +
                          " Revision  " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Version") == null)                                      ? 0 : rec_obj.get("Version")  )                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("WorkCenterPickingLocation") == "false")                 ? 0 : 1  )                                                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("WorkCenterPickingLocationFillingQuantity") == null)     ? 0 : rec_obj.get("WorkCenterPickingLocationFillingQuantity")  )     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PartId") == null)                                       ? 0 : rec_obj.get("PartId")  )                                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("WarehouseId") == null)                                  ? 0 : rec_obj.get("WarehouseId")  )                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("LifeCycleState") == null)                               ? 0 : rec_obj.get("LifeCycleState")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Balance") == null)                                      ? 0 : rec_obj.get("Balance")  )                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Name") == null)                                         ? 0 : rec_obj.get("Name")  )                                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("LatestArrivalDate") == null      || rec_obj.get("LatestArrivalDate").toString().substring(0,2).equals("00")  )      ? new Date(2021000000) : rec_obj.get("LatestArrivalDate").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("OutgoingPickLocation") == "false")                      ? 0 : 1  )                                                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ArrivalLocation") == "false")                           ? 0 : 1  )                                                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Priority") == null)                                     ? 0 : rec_obj.get("Priority")  )                                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OutgoingPickLocationReorderPoint") == null)             ? 0 : rec_obj.get("OutgoingPickLocationReorderPoint")  )             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BatchNumber") == null)                                  ? 0 : rec_obj.get("BatchNumber")  )                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SerialNumber") == null)                                 ? 0 : rec_obj.get("SerialNumber")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsOngoingRefill") == "false")                           ? 0 : 1  )                                                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RevisionId") == null)                                   ? 0 : rec_obj.get("RevisionId")  )                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IgnoredBalance") == "false")                            ? 0 : 1  )                                                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Warehouse") == null)                                    ? 0 : rec_obj.get("Warehouse")  )                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Revision") == null)                                     ? 0 : rec_obj.get("Revision")  )                                     + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "PartLocation was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getPartLocations






    public static String getPartOtherIdentities(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/PartOtherIdentities?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".partotheridentity where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".partotheridentity (tenant_id , id , " +
                          " Value , " +
                          " IsActive , " +
                          " PartId , " +
                          " TypeId   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Value") == null)                                      ? 0 : rec_obj.get("Value")  )                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsActive") == "false")                                ? 0 : 1  )                                                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PartId") == null)                                     ? 0 : rec_obj.get("PartId")  )                                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("TypeId") == null)                                     ? 0 : rec_obj.get("TypeId")  )                                     + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "PartOtherIdentity was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getPartOtherIdentities






    public static String getPartPlanningInformation(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/PartPlanningInformation?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".partplanninginformation where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".partplanninginformation (tenant_id , id , " +
                          " ActiveSupplierPartLinkId , " +
                          " WarehouseId , " +
                          " AbcCodeId , " +
                          " Eoq , " +
                          " LotSizingRule , " +
                          " LotSizingPeriod , " +
                          " RoundingBase , " +
                          " SafetyStock , " +
                          " SafetyTime , " +
                          " AnnualVolume , " +
                          " LocationRestrictionId , " +
                          " TransferProfileId , " +
                          " AllowOrderCreationFromCustomerOrder , " +
                          " LeadTime , " +
                          " IsLowValue , " +
                          " MinQuantity , " +
                          " MaxQuantity , " +
                          " AcquisitionWarehouseId , " +
                          " AnnualBudgetCalculationType , " +
                          " ReorderPoint , " +
                          " PalletQuantity , " +
                          " TransportQuantity , " +
                          " AnnualVolumePace , " +
                          " EoqPace , " +
                          " FirstInventoryMonth , " +
                          " SecondInventoryMonth , " +
                          " CalculatedTurnoverRatio , " +
                          " ActualTurnoverRatio , " +
                          " ContactId , " +
                          " ArrivalLocationTerm , " +
                          " PlanningMethod , " +
                          " DeductSalesForecast , " +
                          " DeductionMethod , " +
                          " PartId   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("ActiveSupplierPartLinkId") == null)                      ? 0 : rec_obj.get("ActiveSupplierPartLinkId")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("WarehouseId") == null)                                   ? 0 : rec_obj.get("WarehouseId")  )                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AbcCodeId") == null)                                     ? 0 : rec_obj.get("AbcCodeId")  )                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Eoq") == null)                                           ? 0 : rec_obj.get("Eoq")  )                                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("LotSizingRule") == null)                                 ? 0 : rec_obj.get("LotSizingRule")  )                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("LotSizingPeriod") == null)                               ? 0 : rec_obj.get("LotSizingPeriod")  )                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RoundingBase") == null)                                  ? 0 : rec_obj.get("RoundingBase")  )                                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SafetyStock") == null)                                   ? 0 : rec_obj.get("SafetyStock")  )                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SafetyTime") == null)                                    ? 0 : rec_obj.get("SafetyTime")  )                                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AnnualVolume") == null)                                  ? 0 : rec_obj.get("AnnualVolume")  )                                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("LocationRestrictionId") == null)                         ? 0 : rec_obj.get("LocationRestrictionId")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("TransferProfileId") == null)                             ? 0 : rec_obj.get("TransferProfileId")  )                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AllowOrderCreationFromCustomerOrder") == "false")        ? 0 : 1  )                                                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("LeadTime") == null)                                      ? 0 : rec_obj.get("LeadTime")  )                                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsLowValue") == "false")                                 ? 0 : 1  )                                                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("MinQuantity") == null)                                   ? 0 : rec_obj.get("MinQuantity")  )                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("MaxQuantity") == null)                                   ? 0 : rec_obj.get("MaxQuantity")  )                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AcquisitionWarehouseId") == null)                        ? 0 : rec_obj.get("AcquisitionWarehouseId")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AnnualBudgetCalculationType") == null)                   ? 0 : rec_obj.get("AnnualBudgetCalculationType")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReorderPoint") == null)                                  ? 0 : rec_obj.get("ReorderPoint")  )                                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PalletQuantity") == null)                                ? 0 : rec_obj.get("PalletQuantity")  )                                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("TransportQuantity") == null)                             ? 0 : rec_obj.get("TransportQuantity")  )                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AnnualVolumePace") == null)                              ? 0 : rec_obj.get("AnnualVolumePace")  )                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("EoqPace") == null)                                       ? 0 : rec_obj.get("EoqPace")  )                                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("FirstInventoryMonth") == null)                           ? 0 : rec_obj.get("FirstInventoryMonth")  )                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SecondInventoryMonth") == null)                          ? 0 : rec_obj.get("SecondInventoryMonth")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CalculatedTurnoverRatio") == null)                       ? 0 : rec_obj.get("CalculatedTurnoverRatio")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ActualTurnoverRatio") == null)                           ? 0 : rec_obj.get("ActualTurnoverRatio")  )                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ContactId") == null)                                     ? 0 : rec_obj.get("ContactId")  )                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ArrivalLocationTerm") == null)                           ? 0 : rec_obj.get("ArrivalLocationTerm")  )                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PlanningMethod") == null)                                ? 0 : rec_obj.get("PlanningMethod")  )                                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DeductSalesForecast") == null)                           ? 0 : rec_obj.get("DeductSalesForecast")  )                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DeductionMethod") == null)                               ? 0 : rec_obj.get("DeductionMethod")  )                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PartId") == null)                                        ? 0 : rec_obj.get("PartId")  )                                             + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );
                       // WriteLog.write(conf.getLogFile(), "executeUpdate: \n" + com_stmt   , false );


                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "PartPlanningInformation was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getPartPlanningInformation






    public static String getPartPurchaseExpenseValues(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/PartPurchaseExpenseValues?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".partpurchaseexpensevalues where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".partpurchaseexpensevalues (tenant_id , id , " +
                          " PartId , " +
                          " CertificatePercentOfPriceValue , " +
                          " CertificatePerEachValue , " +
                          " CertificatePerKgValue , " +
                          " CertificatePerPackageValue , " +
                          " CertificatePerOrderValue , " +
                          " CertificatePerQuantityValue , " +
                          " CertificateQuantityValue , " +
                          " Expense1PercentOfPriceValue , " +
                          " Expense1PerEachValue , " +
                          " Expense1PerKgValue , " +
                          " Expense1PerPackageValue , " +
                          " Expense1PerOrderValue , " +
                          " Expense1PerQuantityValue , " +
                          " Expense1QuantityValue , " +
                          " Expense2PercentOfPriceValue , " +
                          " Expense2PerEachValue , " +
                          " Expense2PerKgValue , " +
                          " Expense2PerPackageValue , " +
                          " Expense2PerOrderValue , " +
                          " Expense2PerQuantityValue , " +
                          " Expense2QuantityValue , " +
                          " Expense3PercentOfPriceValue , " +
                          " Expense3PerEachValue , " +
                          " Expense3PerKgValue , " +
                          " Expense3PerPackageValue , " +
                          " Expense3PerOrderValue , " +
                          " Expense3PerQuantityValue , " +
                          " Expense3QuantityValue , " +
                          " Expense4PercentOfPriceValue , " +
                          " Expense4PerEachValue , " +
                          " Expense4PerKgValue , " +
                          " Expense4PerPackageValue , " +
                          " Expense4PerOrderValue , " +
                          " Expense4PerQuantityValue , " +
                          " Expense4QuantityValue , " +
                          " Expense5PercentOfPriceValue , " +
                          " Expense5PerEachValue , " +
                          " Expense5PerKgValue , " +
                          " Expense5PerPackageValue , " +
                          " Expense5PerOrderValue , " +
                          " Expense5PerQuantityValue , " +
                          " Expense5QuantityValue   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("PartId") == null)                                 ? 0 : rec_obj.get("PartId")  )                                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CertificatePercentOfPriceValue") == null)         ? 0 : rec_obj.get("CertificatePercentOfPriceValue")  )             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CertificatePerEachValue") == null)                ? 0 : rec_obj.get("CertificatePerEachValue")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CertificatePerKgValue") == null)                  ? 0 : rec_obj.get("CertificatePerKgValue")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CertificatePerPackageValue") == null)             ? 0 : rec_obj.get("CertificatePerPackageValue")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CertificatePerOrderValue") == null)               ? 0 : rec_obj.get("CertificatePerOrderValue")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CertificatePerQuantityValue") == null)            ? 0 : rec_obj.get("CertificatePerQuantityValue")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CertificateQuantityValue") == null)               ? 0 : rec_obj.get("CertificateQuantityValue")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Expense1PercentOfPriceValue") == null)            ? 0 : rec_obj.get("Expense1PercentOfPriceValue")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Expense1PerEachValue") == null)                   ? 0 : rec_obj.get("Expense1PerEachValue")  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Expense1PerKgValue") == null)                     ? 0 : rec_obj.get("Expense1PerKgValue")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Expense1PerPackageValue") == null)                ? 0 : rec_obj.get("Expense1PerPackageValue")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Expense1PerOrderValue") == null)                  ? 0 : rec_obj.get("Expense1PerOrderValue")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Expense1PerQuantityValue") == null)               ? 0 : rec_obj.get("Expense1PerQuantityValue")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Expense1QuantityValue") == null)                  ? 0 : rec_obj.get("Expense1QuantityValue")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Expense2PercentOfPriceValue") == null)            ? 0 : rec_obj.get("Expense2PercentOfPriceValue")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Expense2PerEachValue") == null)                   ? 0 : rec_obj.get("Expense2PerEachValue")  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Expense2PerKgValue") == null)                     ? 0 : rec_obj.get("Expense2PerKgValue")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Expense2PerPackageValue") == null)                ? 0 : rec_obj.get("Expense2PerPackageValue")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Expense2PerOrderValue") == null)                  ? 0 : rec_obj.get("Expense2PerOrderValue")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Expense2PerQuantityValue") == null)               ? 0 : rec_obj.get("Expense2PerQuantityValue")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Expense2QuantityValue") == null)                  ? 0 : rec_obj.get("Expense2QuantityValue")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Expense3PercentOfPriceValue") == null)            ? 0 : rec_obj.get("Expense3PercentOfPriceValue")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Expense3PerEachValue") == null)                   ? 0 : rec_obj.get("Expense3PerEachValue")  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Expense3PerKgValue") == null)                     ? 0 : rec_obj.get("Expense3PerKgValue")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Expense3PerPackageValue") == null)                ? 0 : rec_obj.get("Expense3PerPackageValue")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Expense3PerOrderValue") == null)                  ? 0 : rec_obj.get("Expense3PerOrderValue")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Expense3PerQuantityValue") == null)               ? 0 : rec_obj.get("Expense3PerQuantityValue")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Expense3QuantityValue") == null)                  ? 0 : rec_obj.get("Expense3QuantityValue")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Expense4PercentOfPriceValue") == null)            ? 0 : rec_obj.get("Expense4PercentOfPriceValue")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Expense4PerEachValue") == null)                   ? 0 : rec_obj.get("Expense4PerEachValue")  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Expense4PerKgValue") == null)                     ? 0 : rec_obj.get("Expense4PerKgValue")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Expense4PerPackageValue") == null)                ? 0 : rec_obj.get("Expense4PerPackageValue")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Expense4PerOrderValue") == null)                  ? 0 : rec_obj.get("Expense4PerOrderValue")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Expense4PerQuantityValue") == null)               ? 0 : rec_obj.get("Expense4PerQuantityValue")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Expense4QuantityValue") == null)                  ? 0 : rec_obj.get("Expense4QuantityValue")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Expense5PercentOfPriceValue") == null)            ? 0 : rec_obj.get("Expense5PercentOfPriceValue")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Expense5PerEachValue") == null)                   ? 0 : rec_obj.get("Expense5PerEachValue")  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Expense5PerKgValue") == null)                     ? 0 : rec_obj.get("Expense5PerKgValue")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Expense5PerPackageValue") == null)                ? 0 : rec_obj.get("Expense5PerPackageValue")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Expense5PerOrderValue") == null)                  ? 0 : rec_obj.get("Expense5PerOrderValue")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Expense5PerQuantityValue") == null)               ? 0 : rec_obj.get("Expense5PerQuantityValue")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Expense5QuantityValue") == null)                  ? 0 : rec_obj.get("Expense5QuantityValue")  )                      + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );
                       // WriteLog.write(conf.getLogFile(), "executeUpdate: \n" + com_stmt   , false );


                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "PartPurchaseExpenseValues was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getPartPurchaseExpenseValues





    public static String getPartTemplates(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/PartTemplates?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".parttemplate where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".parttemplate (tenant_id , id , " +
                          " Code , " +
                          " DescriptionId , " +
                          " TemplateType , " +
                          " IsDefault , " +
                          " IsActive , " +
                          " PartCodeId , " +
                          " ProductGroupId , " +
                          " PreparerId , " +
                          " CountryOfOriginId , " +
                          " SalesOverheadMarkupId , " +
                          " ProfitMarkupId , " +
                          " AbcCodeId , " +
                          " CategoryString , " +
                          " PartType , " +
                          " TraceabilityMode , " +
                          " AutomaticReportingMode , " +
                          " SerialNumberGeneration , " +
                          " SerialNumberGenerationSource , " +
                          " LotSizingRule , " +
                          " DeductSalesForecast , " +
                          " DeductionMethod , " +
                          " Eoq , " +
                          " ReorderPoint , " +
                          " SafetyStock , " +
                          " AnnualVolume , " +
                          " SafetyTime , " +
                          " ManageStockBalance , " +
                          " PartActivityTemplateId , " +
                          " PartStatus , " +
                          " UseInCalculation , " +
                          " IsPreset , " +
                          " UseRandomLocationStorage , " +
                          " AllowOrderCreationFromCustomerOrder , " +
                          " RoundingBase , " +
                          " LeadTime  , " +
                          " ManufacturingLabelType  , " +
                          " SalesLabelType  , " +
                          " PurchaseLabelType  , " +
                          " PolishGtuCodeId  , " +
                          " Description   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Code") == null)                                 ? 0 : rec_obj.get("Code")  )                                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                        ? 0 : rec_obj.get("DescriptionId")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("TemplateType") == null)                         ? 0 : rec_obj.get("TemplateType")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsDefault") == "false")                         ? 0 : 1  )                                                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsActive") == "false")                          ? 0 : 1  )                                                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PartCodeId") == null)                           ? 0 : rec_obj.get("PartCodeId")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ProductGroupId") == null)                       ? 0 : rec_obj.get("ProductGroupId")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PreparerId") == null)                           ? 0 : rec_obj.get("PreparerId")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CountryOfOriginId") == null)                    ? 0 : rec_obj.get("CountryOfOriginId")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SalesOverheadMarkupId") == null)                ? 0 : rec_obj.get("SalesOverheadMarkupId")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ProfitMarkupId") == null)                       ? 0 : rec_obj.get("ProfitMarkupId")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AbcCodeId") == null)                            ? 0 : rec_obj.get("AbcCodeId")  )                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CategoryString") == null)                       ? 0 : rec_obj.get("CategoryString")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PartType") == null)                             ? 0 : rec_obj.get("PartType")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("TraceabilityMode") == null)                     ? 0 : rec_obj.get("TraceabilityMode")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AutomaticReportingMode") == null)               ? 0 : rec_obj.get("AutomaticReportingMode")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SerialNumberGeneration") == null)               ? 0 : rec_obj.get("SerialNumberGeneration")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SerialNumberGenerationSource") == null)         ? 0 : rec_obj.get("SerialNumberGenerationSource")  )             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("LotSizingRule") == null)                        ? 0 : rec_obj.get("LotSizingRule")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DeductSalesForecast") == null)                  ? 0 : rec_obj.get("DeductSalesForecast")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DeductionMethod") == null)                      ? 0 : rec_obj.get("DeductionMethod")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Eoq") == null)                                  ? 0 : rec_obj.get("Eoq")  )                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReorderPoint") == null)                         ? 0 : rec_obj.get("ReorderPoint")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SafetyStock") == null)                          ? 0 : rec_obj.get("SafetyStock")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AnnualVolume") == null)                         ? 0 : rec_obj.get("AnnualVolume")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SafetyTime") == null)                           ? 0 : rec_obj.get("SafetyTime")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ManageStockBalance") == "false")                ? 0 : 1  )                                                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PartActivityTemplateId") == null)               ? 0 : rec_obj.get("PartActivityTemplateId")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PartStatus") == null)                           ? 0 : rec_obj.get("PartStatus")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("UseInCalculation") == "false")                  ? 0 : 1  )                                                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsPreset") == "false")                          ? 0 : 1  )                                                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("UseRandomLocationStorage") == "false")          ? 0 : 1  )                                                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AllowOrderCreationFromCustomerOrder") == "false")   ? 0 : 1  )                                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RoundingBase") == null)                             ? 0 : rec_obj.get("RoundingBase")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("LeadTime") == null)                                 ? 0 : rec_obj.get("LeadTime")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ManufacturingLabelType") == null)                   ? 0 : rec_obj.get("ManufacturingLabelType")  )               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SalesLabelType") == null)                           ? 0 : rec_obj.get("SalesLabelType")  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PurchaseLabelType") == null)                        ? 0 : rec_obj.get("PurchaseLabelType")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PolishGtuCodeId") == null)                          ? 0 : rec_obj.get("PolishGtuCodeId")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                              ? 0 : rec_obj.get("Description")  )                          + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );
                      //  WriteLog.write(conf.getLogFile(), "executeUpdate: \n" + com_stmt   , false );


                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "PartTemplate was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getPartTemplates





    public static String getPriceChangeLogs(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/PriceChangeLogs" );
             // ?$filter=isnotnull(StartDate)&StartDate%20Gt%20'2021-10-10'$skip=0&$top=50000&$orderby=Id%20desc"


              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/PriceChangeLogs?$filter=isnotnull(Timestamp)&Timestamp%20Gt%20'2021-10-10'&$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".pricechangelog where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".pricechangelog (tenant_id , id , " +
                          " Context, " +
                          " PriceType, " +
                          " PriceListId, " +
                          " Timestamp, " +
                          " UserCode, " +
                          " NewPrice, " +
                          " NewPriceCurrencyId, " +
                          " OldPrice, " +
                          " OldPriceCurrencyId, " +
                          " Balance, " +
                          " PartId, " +
                          " CalculationId, " +
                          " SupplierId, " +
                          " CustomerId, " +
                          " StaggeredQuantity, " +
                          " IsSetupPrice, " +
                          " Discount, " +
                          " IsExportedToManagementAccounting, " +
                          " PurchaseCalculationId  " +

                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Context") == null)                                   ? 0 : rec_obj.get("Context")  )                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PriceType") == null)                                 ? 0 : rec_obj.get("PriceType")  )                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PriceListId") == null)                               ? 0 : rec_obj.get("PriceListId")  )                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Timestamp") == null)                                 ? new Date(2021000000) : rec_obj.get("Timestamp").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                          "\"" + ((rec_obj.get("UserCode") == null)                                  ? 0 : rec_obj.get("UserCode")  )                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("NewPrice") == null)                                  ? 0 : rec_obj.get("NewPrice")  )                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("NewPriceCurrencyId") == null)                        ? 0 : rec_obj.get("NewPriceCurrencyId")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OldPrice") == null)                                  ? 0 : rec_obj.get("OldPrice")  )                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OldPriceCurrencyId") == null)                        ? 0 : rec_obj.get("OldPriceCurrencyId")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Balance") == null)                                   ? 0 : rec_obj.get("Balance")  )                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PartId") == null)                                    ? 0 : rec_obj.get("PartId")  )                                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CalculationId") == null)                             ? 0 : rec_obj.get("CalculationId")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SupplierId") == null)                                ? 0 : rec_obj.get("SupplierId")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CustomerId") == null)                                ? 0 : rec_obj.get("CustomerId")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("StaggeredQuantity") == null)                         ? 0 : rec_obj.get("StaggeredQuantity")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsSetupPrice") == "false")                           ? 0 : 1 )                                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Discount") == null)                                  ? 0 : rec_obj.get("Discount")  )                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsExportedToManagementAccounting") == "false")       ? 0 : 1 )                                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PurchaseCalculationId") == null)                     ? 0 : rec_obj.get("PurchaseCalculationId")  )                      + "\" "    + "  " +

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "PriceChangeLog was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getPriceChangeLogs







    public static String getProductRecordOperationReportings(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/ProductRecordOperationReportings?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".productrecordoperationreporting where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".productrecordoperationreporting (tenant_id , id , " +
                          " LoggingTimeStamp , " +
                          " ReportingType , " +
                          " ProductRecordId , " +
                          " OrderNumber , " +
                          " ReportedTime , " +
                          " ReportedQuantity , " +
                          " QuantityPerCycle , " +
                          " CycleTime , " +
                          " TotalTime , " +
                          " TotalCycles , " +
                          " TotalMeasurementSetting , " +
                          " ReportedMeasurementSetting , " +
                          " OperationReportingId   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("LoggingTimeStamp") == null      || rec_obj.get("LoggingTimeStamp").toString().substring(0,2).equals("00")  )      ? new Date(2021000000) : rec_obj.get("LoggingTimeStamp").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("ReportingType") == null)                        ? 0 : rec_obj.get("ReportingType")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ProductRecordId") == null)                      ? 0 : rec_obj.get("ProductRecordId")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OrderNumber") == null)                          ? 0 : rec_obj.get("OrderNumber")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReportedTime") == null)                         ? 0 : rec_obj.get("ReportedTime")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReportedQuantity") == null)                     ? 0 : rec_obj.get("ReportedQuantity")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("QuantityPerCycle") == null)                     ? 0 : rec_obj.get("QuantityPerCycle")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CycleTime") == null)                            ? 0 : rec_obj.get("CycleTime")  )                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("TotalTime") == null)                            ? 0 : rec_obj.get("TotalTime")  )                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("TotalCycles") == null)                          ? 0 : rec_obj.get("TotalCycles")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("TotalMeasurementSetting") == null)              ? 0 : rec_obj.get("TotalMeasurementSetting")  )                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReportedMeasurementSetting") == null)           ? 0 : rec_obj.get("TReportedMeasurementSetting")  )              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OperationReportingId") == null)                 ? 0 : rec_obj.get("OperationReportingId")  )                     + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );
                       // WriteLog.write(conf.getLogFile(), "executeUpdate: \n" + com_stmt   , false );


                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "ProductRecordOperationReporting was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getProductRecordOperationReportings






    public static String getProductRecords(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/ProductRecords?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".productrecord where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".productrecord (tenant_id , id , " +
                          " ProductRecordType , " +
                          " CertificateId , " +
                          " CustomerOrderPartRevisionId , " +
                          " PurchaseOrderPartRevisionId , " +
                          " PlannedDeliveryDate , " +
                          " AccountsReceivableId , " +
                          " InvoiceDate , " +
                          " CostInCompanyCurrency , " +
                          " CostInCompanyCurrencyCurrencyId , " +
                          " IncomeInCompanyCurrency , " +
                          " IncomeInCompanyCurrencyCurrencyId , " +
                          " HasWarranty , " +
                          " AssembleDate , " +
                          " Reserved , " +
                          " Status , " +
                          " ManufactureDate , " +
                          " Operation , " +
                          " Weight , " +
                          " Volume , " +
                          " CreationContext , " +
                          " CustomerOrderInvoiceId , " +
                          " WarrantyMonths , " +
                          " CommentId , " +
                          " WarrantyCommitmentId , " +
                          " PurchaseOrderId , " +
                          " ActualArrivalDate , " +
                          " MeasurementSetting , " +
                          " NumberOfCycles , " +
                          " InstallationOrderId , " +
                          " InstalledBy , " +
                          " InstalledByName , " +
                          " InstallationDate , " +
                          " InstallationCode , " +
                          " InstallationCommentId , " +
                          " BestBeforeDate , " +
                          " SerialNumberWithPartNumber , " +
                          " ReportedQuantity , " +
                          " DeliveryAddressId , " +
                          " Installer , " +
                          " WipLocationName , " +
                          " ReportNo , " +
                          " RegistrationNo , " +
                          " ManufactuedPartNo , " +
                          " Type , " +
                          " WarrantyStartDate , " +
                          " WarrantyEndDate , " +
                          " ManufacturingOrderNo , " +
                          " ManufacturingOrderId , " +
                          " StockOrderNo , " +
                          " ProductRecordBatchId , " +
                          " ChargeNumber , " +
                          " SerialNo , " +
                          " ActualDeliveryDate , " +
                          " InvoiceNumber , " +
                          " CustomerOrderId , " +
                          " CustomerId , " +
                          " OwnerId , " +
                          " CustomerOrderOurReferenceId , " +
                          " CustomerOrderDeliveryRowId , " +
                          " CustomerOrderOurReferenceName , " +
                          " BusinessContactReferenceId , " +
                          " BusinessContactReferenceName , " +
                          " PartId , " +
                          " PartConfigurationId , " +
                          " ProjectId , " +
                          " MeasurementSettingWarranty , " +
                          " NumberOfCyclesWarranty , " +
                          " FixedAssetId , " +
                          " LifeCycleState , " +
                          " BlockContextType , " +
                          " BlockedFromDate , " +
                          " BlockedToDate , " +
                          " BlockedById , " +
                          " BlockMessageId , " +
                          " EmployeeId , " +
                          " WorkCenterId , " +
                          " DepartmentId , " +
                          " OperationTime , " +
                          " OperationTimeWarranty , " +
                          " WarrantyCode , " +
                          " TypeDescription , " +
                          " Comment , " +
                          " Certificate , " +
                          " WarrantyCommitment , " +
                          " InstallationComment , " +
                          " Part , " +
                          " ManufacturingOrder , " +
                          " CustomerOrder , " +
                          " CustomerOrderDeliveryRow , " +
                          " DeliveryAddress , " +
                          " BlockMessage   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("ProductRecordType") == null)                        ? 0 : rec_obj.get("ProductRecordType")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CertificateId") == null)                            ? 0 : rec_obj.get("CertificateId")  )                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CustomerOrderPartRevisionId") == null)              ? 0 : rec_obj.get("CustomerOrderPartRevisionId")  )                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PurchaseOrderPartRevisionId") == null)              ? 0 : rec_obj.get("PurchaseOrderPartRevisionId")  )                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PlannedDeliveryDate") == null      || rec_obj.get("PlannedDeliveryDate").toString().substring(0,2).equals("00")  )      ? new Date(2021000000) : rec_obj.get("PlannedDeliveryDate").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("AccountsReceivableId") == null)                     ? 0 : rec_obj.get("AccountsReceivableId")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InvoiceDate") == null              || rec_obj.get("InvoiceDate").toString().substring(0,2).equals("00")  )              ? new Date(2021000000) : rec_obj.get("InvoiceDate").toString().substring(0,19).replace('T', ' ')  )              + "\" " + ", " +
                          "\"" + ((rec_obj.get("CostInCompanyCurrency") == null)                    ? 0 : rec_obj.get("CostInCompanyCurrency")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CostInCompanyCurrencyCurrencyId") == null)          ? 0 : rec_obj.get("CostInCompanyCurrencyCurrencyId")  )              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IncomeInCompanyCurrency") == null)                  ? 0 : rec_obj.get("IncomeInCompanyCurrency")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IncomeInCompanyCurrencyCurrencyId") == null)        ? 0 : rec_obj.get("IncomeInCompanyCurrencyCurrencyId")  )            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("HasWarranty") == "false")                           ? 0 : 1  )                                                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AssembleDate") == null             || rec_obj.get("AssembleDate").toString().substring(0,2).equals("00")  )             ? new Date(2021000000) : rec_obj.get("AssembleDate").toString().substring(0,19).replace('T', ' ')  )             + "\" " + ", " +
                          "\"" + ((rec_obj.get("Reserved") == null)                                 ? 0 : rec_obj.get("Reserved")  )                                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Status") == null)                                   ? 0 : rec_obj.get("Status")  )                                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ManufactureDate") == null          || rec_obj.get("ManufactureDate").toString().substring(0,2).equals("00")  )          ? new Date(2021000000) : rec_obj.get("ManufactureDate").toString().substring(0,19).replace('T', ' ')  )          + "\" " + ", " +
                          "\"" + ((rec_obj.get("Operation") == null)                                ? 0 : rec_obj.get("Operation")  )                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Weight") == null)                                   ? 0 : rec_obj.get("Weight")  )                                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Volume") == null)                                   ? 0 : rec_obj.get("Volume")  )                                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CreationContext") == null)                          ? 0 : rec_obj.get("CreationContext")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CustomerOrderInvoiceId") == null)                   ? 0 : rec_obj.get("CustomerOrderInvoiceId")  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("WarrantyMonths") == null)                           ? 0 : rec_obj.get("WarrantyMonths")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CommentId") == null)                                ? 0 : rec_obj.get("CommentId")  )                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("WarrantyCommitmentId") == null)                     ? 0 : rec_obj.get("WarrantyCommitmentId")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PurchaseOrderId") == null)                          ? 0 : rec_obj.get("PurchaseOrderId")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ActualArrivalDate") == null          || rec_obj.get("ActualArrivalDate").toString().substring(0,2).equals("00")  )          ? new Date(2021000000) : rec_obj.get("ActualArrivalDate").toString().substring(0,19).replace('T', ' ')  )          + "\" " + ", " +
                          "\"" + ((rec_obj.get("MeasurementSetting") == null)                       ? 0 : rec_obj.get("MeasurementSetting")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("NumberOfCycles") == null)                           ? 0 : rec_obj.get("NumberOfCycles")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InstallationOrderId") == null)                      ? 0 : rec_obj.get("InstallationOrderId")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InstalledBy") == null)                              ? 0 : rec_obj.get("InstalledBy")  )                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InstalledByName") == null)                          ? 0 : rec_obj.get("InstalledByName")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InstallationDate") == null           || rec_obj.get("InstallationDate").toString().substring(0,2).equals("00")  )       ? new Date(2021000000) : rec_obj.get("InstallationDate").toString().substring(0,19).replace('T', ' ')  )          + "\" " + ", " +
                          "\"" + ((rec_obj.get("InstallationCode") == null)                         ? 0 : rec_obj.get("InstallationCode")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InstallationCommentId") == null)                    ? 0 : rec_obj.get("InstallationCommentId")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BestBeforeDate") == null             || rec_obj.get("BestBeforeDate").toString().substring(0,2).equals("00")  )       ? new Date(2021000000) : rec_obj.get("BestBeforeDate").toString().substring(0,19).replace('T', ' ')  )          + "\" " + ", " +
                          "\"" + ((rec_obj.get("SerialNumberWithPartNumber") == null)               ? 0 : rec_obj.get("SerialNumberWithPartNumber")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReportedQuantity") == null)                         ? 0 : rec_obj.get("ReportedQuantity")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DeliveryAddressId") == null)                        ? 0 : rec_obj.get("DeliveryAddressId")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Installer") == null)                                ? 0 : rec_obj.get("Installer")  )                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("WipLocationName") == null)                          ? 0 : rec_obj.get("WipLocationName")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReportNo") == null)                                 ? 0 : rec_obj.get("ReportNo")  )                                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RegistrationNo") == null)                           ? 0 : rec_obj.get("RegistrationNo")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ManufactuedPartNo") == null)                        ? 0 : rec_obj.get("ManufactuedPartNo")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Type") == null)                                     ? 0 : rec_obj.get("Type")  )                                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("WarrantyStartDate") == null             || rec_obj.get("WarrantyStartDate").toString().substring(0,2).equals("00")  )       ? new Date(2021000000) : rec_obj.get("WarrantyStartDate").toString().substring(0,19).replace('T', ' ')  )          + "\" " + ", " +
                          "\"" + ((rec_obj.get("WarrantyEndDate") == null               || rec_obj.get("WarrantyEndDate").toString().substring(0,2).equals("00")  )         ? new Date(2021000000) : rec_obj.get("WarrantyEndDate").toString().substring(0,19).replace('T', ' ')  )            + "\" " + ", " +
                          "\"" + ((rec_obj.get("ManufacturingOrderNo") == null)                     ? 0 : rec_obj.get("ManufacturingOrderNo")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ManufacturingOrderId") == null)                     ? 0 : rec_obj.get("ManufacturingOrderId")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("StockOrderNo") == null)                             ? 0 : rec_obj.get("StockOrderNo")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ProductRecordBatchId") == null)                     ? 0 : rec_obj.get("ProductRecordBatchId")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ChargeNumber") == null)                             ? 0 : rec_obj.get("ChargeNumber")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SerialNo") == null)                                 ? 0 : rec_obj.get("SerialNo")  )                                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ActualDeliveryDate") == null               || rec_obj.get("ActualDeliveryDate").toString().substring(0,2).equals("00")  )         ? new Date(2021000000) : rec_obj.get("ActualDeliveryDate").toString().substring(0,19).replace('T', ' ')  )            + "\" " + ", " +
                          "\"" + ((rec_obj.get("InvoiceNumber") == null)                            ? 0 : rec_obj.get("InvoiceNumber")  )                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CustomerOrderId") == null)                          ? 0 : rec_obj.get("CustomerOrderId")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CustomerId") == null)                               ? 0 : rec_obj.get("CustomerId")  )                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OwnerId") == null)                                  ? 0 : rec_obj.get("OwnerId")  )                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CustomerOrderOurReferenceId") == null)              ? 0 : rec_obj.get("CustomerOrderOurReferenceId")  )                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CustomerOrderDeliveryRowId") == null)               ? 0 : rec_obj.get("CustomerOrderDeliveryRowId")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CustomerOrderOurReferenceName") == null)            ? 0 : rec_obj.get("CustomerOrderOurReferenceName")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BusinessContactReferenceId") == null)               ? 0 : rec_obj.get("BusinessContactReferenceId")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BusinessContactReferenceName") == null)             ? 0 : rec_obj.get("BusinessContactReferenceName")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PartId") == null)                                   ? 0 : rec_obj.get("PartId")  )                                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PartConfigurationId") == null)                      ? 0 : rec_obj.get("PartConfigurationId")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ProjectId") == null)                                ? 0 : rec_obj.get("ProjectId")  )                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("MeasurementSettingWarranty") == null)               ? 0 : rec_obj.get("MeasurementSettingWarranty")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("NumberOfCyclesWarranty") == null)                   ? 0 : rec_obj.get("NumberOfCyclesWarranty")  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("FixedAssetId") == null)                             ? 0 : rec_obj.get("FixedAssetId")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("LifeCycleState") == null)                           ? 0 : rec_obj.get("LifeCycleState")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BlockContextType") == null)                         ? 0 : rec_obj.get("BlockContextType")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BlockedFromDate") == null               || rec_obj.get("BlockedFromDate").toString().substring(0,2).equals("00")  )         ? new Date(2021000000) : rec_obj.get("BlockedFromDate").toString().substring(0,19).replace('T', ' ')  )            + "\" " + ", " +
                          "\"" + ((rec_obj.get("BlockedToDate") == null                 || rec_obj.get("BlockedToDate").toString().substring(0,2).equals("00")  )           ? new Date(2021000000) : rec_obj.get("BlockedToDate").toString().substring(0,19).replace('T', ' ')  )              + "\" " + ", " +
                          "\"" + ((rec_obj.get("BlockedById") == null)                              ? 0 : rec_obj.get("BlockedById")  )                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BlockMessageId") == null)                           ? 0 : rec_obj.get("BlockMessageId")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("EmployeeId") == null)                               ? 0 : rec_obj.get("EmployeeId")  )                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("WorkCenterId") == null)                             ? 0 : rec_obj.get("WorkCenterId")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DepartmentId") == null)                             ? 0 : rec_obj.get("DepartmentId")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OperationTime") == null)                            ? 0 : rec_obj.get("OperationTime")  )                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OperationTimeWarranty") == null)                    ? 0 : rec_obj.get("OperationTimeWarranty")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("WarrantyCode") == null)                             ? 0 : rec_obj.get("WarrantyCode")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("TypeDescription") == null)                          ? 0 : rec_obj.get("TypeDescription")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Comment") == null)                                  ? 0 : rec_obj.get("Comment")  )                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Certificate") == null)                              ? 0 : rec_obj.get("Certificate")  )                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("WarrantyCommitment") == null)                       ? 0 : rec_obj.get("WarrantyCommitment")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InstallationComment") == null)                      ? 0 : rec_obj.get("InstallationComment")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Part") == null)                                     ? 0 : rec_obj.get("Part")  )                                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ManufacturingOrder") == null)                       ? 0 : rec_obj.get("ManufacturingOrder")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CustomerOrder") == null)                            ? 0 : rec_obj.get("CustomerOrder")  )                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CustomerOrderDeliveryRow") == null)                 ? 0 : rec_obj.get("CustomerOrderDeliveryRow")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DeliveryAddress") == null)                          ? 0 : rec_obj.get("DeliveryAddress")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BlockMessage ") == null)                            ? 0 : rec_obj.get("BlockMessage")  )                                 + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );
                       // WriteLog.write(conf.getLogFile(), "executeUpdate: \n" + com_stmt   , false );


                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "ProductRecord was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getProductRecords







    public static String getProfitMarkups(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/ProfitMarkups?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".profitmarkup where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".profitmarkup (tenant_id , id , " +
                          " DescriptionId , " +
                          " Markup , " +
                          " Number , " +
                          " Description   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                        ? 0 : rec_obj.get("DescriptionId")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Markup") == null)                               ? 0 : rec_obj.get("Markup")  )                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Number") == null)                               ? 0 : rec_obj.get("Number")  )                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                          ? 0 : rec_obj.get("Description")  )                              + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );
                       // WriteLog.write(conf.getLogFile(), "executeUpdate: \n" + com_stmt   , false );


                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "ProfitMarkup was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getProfitMarkups





    public static String getSalesOverheadMarkups(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/SalesOverheadMarkups?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".salesoverheadmarkup where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".salesoverheadmarkup (tenant_id , id , " +
                          " DescriptionId , " +
                          " Markup , " +
                          " Number , " +
                          " Description   " +
                          " ) " +
                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                        ? 0 : rec_obj.get("DescriptionId")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Markup") == null)                               ? 0 : rec_obj.get("Markup")  )                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Number") == null)                               ? 0 : rec_obj.get("Number")  )                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                          ? 0 : rec_obj.get("Description")  )                              + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );
                       // WriteLog.write(conf.getLogFile(), "executeUpdate: \n" + com_stmt   , false );


                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "SalesOverheadMarkup was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getSalesOverheadMarkups




    public static String getStorageOverheadMarkups(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/StorageOverheadMarkups?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".storageoverheadmarkup where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".storageoverheadmarkup (tenant_id , id , " +
                          " DescriptionId , " +
                          " Markup , " +
                          " Type , " +
                          " Number , " +
                          " Description   " +
                          " ) " +
                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                        ? 0 : rec_obj.get("DescriptionId")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Markup") == null)                               ? 0 : rec_obj.get("Markup")  )                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Type") == null)                                 ? 0 : rec_obj.get("Type")  )                                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Number") == null)                               ? 0 : rec_obj.get("Number")  )                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                          ? 0 : rec_obj.get("Description")  )                              + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );
                       // WriteLog.write(conf.getLogFile(), "executeUpdate: \n" + com_stmt   , false );


                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "StorageOverheadMarkup was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getStorageOverheadMarkups





    public static String getUnplannedStockMovementReasonCodes(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/UnplannedStockMovementReasonCodes?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".unplannedstockmovementreasoncode where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".unplannedstockmovementreasoncode (tenant_id , id , " +
                          " Code , " +
                          " DescriptionId , " +
                          " CommentMandatory , " +
                          " Active , " +
                          " Description   " +
                          " ) " +
                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Code") == null)                                 ? 0 : rec_obj.get("Code")  )                                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                        ? 0 : rec_obj.get("DescriptionId")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CommentMandatory") == "false")                  ? 0 : 1  )                                                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Active") == "false")                            ? 0 : 1  )                                                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                          ? 0 : rec_obj.get("Description")  )                              + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );
                       // WriteLog.write(conf.getLogFile(), "executeUpdate: \n" + com_stmt   , false );


                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "UnplannedStockMovementReasonCode was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getUnplannedStockMovementReasonCodes




    public static String getQuantityChanges(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/PriceChangeLogs" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/QuantityChanges" );
             // ?$filter=isnotnull(StartDate)&StartDate%20Gt%20'2021-10-10'$skip=0&$top=50000&$orderby=Id%20desc"


              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/QuantityChanges?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".quantitychange where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".quantitychange (tenant_id , id , " +
                          " BalanceChange, " +
                          " AvailableBalance, " +
                          " ParentClass, " +
                          " ParentId, " +
                          " Status, " +
                          " ClearingTimeStamp, " +
                          " PickingTimeStamp, " +
                          " PickingByUserId, " +
                          " PickingByPersonId, " +
                          " ActualDeliveryDate, " +
                          " DeliveredByUserId, " +
                          " DeliveredByPersonId, " +
                          " DeliveryLoggingTimeStamp, " +
                          " IsOriginalReceivingInspectionQuantity, " +
                          " Price, " +
                          " PartId, " +
                          " WarehouseId, " +
                          " CanceledQuantity, " +
                          " IsExportedToManagementAccounting, " +
                          " CanceledTimestamp, " +
                          " UndoneTimestamp, " +
                          " ReservationId, " +
                          " TotalBalanceChange " +

                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("BalanceChange") == null)                              ? 0 : rec_obj.get("BalanceChange")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AvailableBalance") == null)                           ? 0 : rec_obj.get("AvailableBalance")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ParentClass") == null)                                ? 0 : rec_obj.get("ParentClass")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ParentId") == null)                                   ? 0 : rec_obj.get("ParentId")  )                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Status") == null)                                     ? 0 : rec_obj.get("Status")  )                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ClearingTimeStamp") == null)                          ? new Date(2021000000) : rec_obj.get("ClearingTimeStamp").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                          "\"" + ((rec_obj.get("PickingTimeStamp") == null)                           ? new Date(2021000000) : rec_obj.get("PickingTimeStamp").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                          "\"" + ((rec_obj.get("PickingByUserId") == null)                            ? 0 : rec_obj.get("PickingByUserId")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PickingByPersonId") == null)                          ? 0 : rec_obj.get("PickingByPersonId")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ActualDeliveryDate") == null || rec_obj.get("ActualDeliveryDate").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("ActualDeliveryDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                          "\"" + ((rec_obj.get("DeliveredByUserId") == null)                          ? 0 : rec_obj.get("DeliveredByUserId")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DeliveredByPersonId") == null)                        ? 0 : rec_obj.get("DeliveredByPersonId")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DeliveryLoggingTimeStamp") == null)                   ? new Date(2021000000) : rec_obj.get("DeliveryLoggingTimeStamp").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                          "\"" + ((rec_obj.get("IsOriginalReceivingInspectionQuantity") == "false")   ? 0 : 1 )                                                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Price") == null)                                      ? 0 : rec_obj.get("Price")  )                                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PartId") == null)                                     ? 0 : rec_obj.get("PartId")  )                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("WarehouseId") == null)                                ? 0 : rec_obj.get("WarehouseId")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CanceledQuantity") == null)                           ? 0 : rec_obj.get("CanceledQuantity")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsExportedToManagementAccounting") == "false")        ? 0 : 1 )                                                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CanceledTimestamp") == null)                          ? new Date(2021000000) : rec_obj.get("CanceledTimestamp").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                          "\"" + ((rec_obj.get("UndoneTimestamp") == null)                            ? new Date(2021000000) : rec_obj.get("UndoneTimestamp").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                          "\"" + ((rec_obj.get("ReservationId") == null)                              ? 0 : rec_obj.get("ReservationId")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("TotalBalanceChange") == null)                         ? 0 : rec_obj.get("TotalBalanceChange")  )                          + "\" "    + "  " +

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "QuantityChange was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getQuantityChanges







    public static String getStockBalanceChanges(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/PriceChangeLogs" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/QuantityChanges" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/StockBalanceChanges" );
             // ?$filter=isnotnull(StartDate)&StartDate%20Gt%20'2021-10-10'$skip=0&$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Inventory/StockBalanceChanges?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".stockbalancechange where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".stockbalancechange (tenant_id , id , " +
                          " PartLocationId, " +
                          " NullablePartLocationId, " +
                          " BalanceChange, " +
                          " StockOrderLatestArrivalDate, " +
                          " AvailableBalance, " +
                          " QuantityChangeId, " +
                          " ProductRecordId  " +

                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                           "\"" + ((rec_obj.get("PartLocationId") == null)                            ? 0 : rec_obj.get("PartLocationId")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("NullablePartLocationId") == null)                    ? 0 : rec_obj.get("NullablePartLocationId")  )                       + "\" "    + ", " +
                           "\"" + ((rec_obj.get("BalanceChange") == null)                             ? 0 : rec_obj.get("BalanceChange")  )                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("StockOrderLatestArrivalDate") == null || rec_obj.get("StockOrderLatestArrivalDate").toString().substring(0,2).equals("00")  ) ? new Date(2021000000) : rec_obj.get("StockOrderLatestArrivalDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                           "\"" + ((rec_obj.get("AvailableBalance") == null)                          ? 0 : rec_obj.get("AvailableBalance")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("QuantityChangeId") == null)                          ? 0 : rec_obj.get("QuantityChangeId")  )                             + "\" "    + ", " +
                           "\"" + ((rec_obj.get("ProductRecordId") == null)                           ? 0 : rec_obj.get("ProductRecordId")  )                              + "\" "    + "  " +

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "StockBalanceChange was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getStockBalanceChanges











}  // Queries_INV
