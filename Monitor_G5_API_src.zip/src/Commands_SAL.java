package sy_my ;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Scanner;
import org.json.simple.JSONObject;
import org.json.simple.JSONArray;
import org.json.simple.JSONValue;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

// import java.time.*;

// -------

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import java.sql.* ;

// import java.sql.Connection;
// import java.sql.Date;
// import java.sql.DriverManager;
// import java.sql.PreparedStatement;
// import java.sql.SQLException;

import java.text.SimpleDateFormat;


public class Commands_SAL {



    // TEST START
    public static HttpURLConnection TestQuery(ReadConf conf) throws Exception {
        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals("185.158.177.241");

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end


             // URL url             = new URL( conf.getUrl_sy() );
             URL url                = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", "185.158.177.241"  );
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", "f1bc5219-b382-472e-adc9-ff0926ecbbb0" );



     	     String json = "{\n";
     		 json += "\"Username\": "     +  "\"ADMIN\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"\" "       + ",\n";
		     json += "\"ForceRelogin\": " +  true          + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( response );

   			     return con ;  // response


                 /*
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parse    = new JSONParser();
                 JSONObject data_obj = (JSONObject) parse.parse( json );  // inline
                 //Get the required object from the above created object
                 JSONObject obj = (JSONObject) data_obj.get("Globale");
                 //Get the required data using its key
                 System.out.println(obj.get("TotalRecovered"));
                 JSONArray arr = (JSONArray) data_obj.get("Countries");
                 for (int i = 0; i < arr.size(); i++) {
                      JSONObject new_obj = (JSONObject) arr.get(i);
                      if (new_obj.get("Slug").equals("albania")) {
                         System.out.println("Total Recovered: " + new_obj.get("TotalRecovered"));
                         break;
                      }
                 }
               */

                }


        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() );
        }
        // return con;
    }

    // TEST END





    public static String postSalesCustomerOrderInvoicesCreate(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Sales_CustomerOrderInvoices_Create.json");

        System.out.println("Sales_CustomerOrderInvoices_Create  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/CustomerOrderInvoices/Create"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");


                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "Sales_CustomerOrderInvoices_Create done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postSalesCustomerOrderInvoicesCreate






    public static String postSalesCustomerOrderInvoicesSetProperties(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Sales_CustomerOrderInvoices_SetProperties.json");

        System.out.println("Sales_CustomerOrderInvoices_SetProperties  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/CustomerOrderInvoices/SetProperties"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");


                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "CustomerOrderInvoices_AddRow done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postSalesCustomerOrderInvoicesAddRow






    public static String postSalesCustomerOrderInvoicesAddRow(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Sales_CustomerOrderInvoices_AddRow.json");

        System.out.println("Sales_CustomerOrderInvoices_AddRow  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/CustomerOrderInvoices/SetProperties"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");


                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "CustomerOrderInvoices_SetProperties done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postSalesCustomerOrderInvoicesSetProperties





    public static String postSalesCustomerOrderInvoicesSetRowCoding(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Sales_CustomerOrderInvoices_SetRowCoding.json");

        System.out.println("Sales_CustomerOrderInvoices_SetRowCoding  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/CustomerOrderInvoices/SetRowCoding"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");


                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "CustomerOrderInvoices_SetRowCoding done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postSalesCustomerOrderInvoicesSetRowCoding






    public static String postSalesCustomerOrderInvoicesUpdateRow(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Sales_CustomerOrderInvoices_UpdateRow.json");

        System.out.println("Sales_CustomerOrderInvoices_UpdateRow  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/CustomerOrderInvoices/UpdateRow"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");


                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "CustomerOrderInvoices_UpdateRow done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postSalesCustomerOrderInvoicesUpdateRow







    public static String postSalesCustomerOrdersCreate(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Sales_CustomerOrders_Create.json");

        System.out.println("Sales_CustomerOrders_Create  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/CustomerOrders/Create"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");


                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "CustomerOrders_Create done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postSalesCustomerOrdersCreate







    public static String postSalesCustomerOrdersAddCommunicationAddress(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Sales_CustomerOrders_AddCommunicationAddress.json");

        System.out.println("Sales_CustomerOrders_AddCommunicationAddress  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/CustomerOrders/AddCommunicationAddress"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");


                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "CustomerOrders_AddCommunicationAddress done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postSalesCustomerOrdersAddCommunicationAddress




    public static String postSalesCustomerOrdersAddRow(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Sales_CustomerOrders_AddRow.json");

        System.out.println("Sales_CustomerOrders_AddRow  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/CustomerOrders/AddRow"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");


                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "CustomerOrders_AddRow done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postSalesCustomerOrdersAddRow





    public static String postSalesCustomerOrdersChangeAccountGroup(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Sales_CustomerOrders_ChangeAccountGroup.json");

        System.out.println("Sales_CustomerOrders_ChangeAccountGroup  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/CustomerOrders/ChangeAccountGroup"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");


                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "CustomerOrders_ChangeAccountGroup done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postSalesCustomerOrdersChangeAccountGroup





    public static String postSalesCustomerOrdersChangeCurrency(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Sales_CustomerOrders_ChangeCurrency.json");

        System.out.println("Sales_CustomerOrders_ChangeCurrency  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/CustomerOrders/ChangeCurrency"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");


                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "CustomerOrders_ChangeCurrency done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postSalesCustomerOrdersChangeCurrency





    public static String postSalesCustomerOrdersChangeCustomer(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Sales_CustomerOrders_ChangeCustomer.json");

        System.out.println("Sales_CustomerOrders_ChangeCustomer  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/CustomerOrders/ChangeCustomer"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");


                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "CustomerOrders_ChangeCustomer done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postSalesCustomerOrdersChangeCustomer





    public static String postSalesCustomerOrdersChangeOrderType(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Sales_CustomerOrders_ChangeOrderType.json");

        System.out.println("Sales_CustomerOrders_ChangeOrderType  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/CustomerOrders/ChangeOrderType"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");


                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "CustomerOrders_ChangeOrderType done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postSalesCustomerOrdersChangeOrderType






    public static String postSalesCustomerOrdersChangeVatGroup(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Sales_CustomerOrders_ChangeVatGroup.json");

        System.out.println("Sales_CustomerOrders_ChangeVatGroup  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/CustomerOrders/ChangeVatGroup"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");


                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "CustomerOrders_ChangeVatGroup done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postSalesCustomerOrdersChangeVatGroup





    public static String postSalesCustomerOrdersConfigureRow(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Sales_CustomerOrders_ConfigureRow.json");

        System.out.println("Sales_CustomerOrders_ConfigureRow  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/CustomerOrders/ConfigureRow"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");


                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );


                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */


                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );

                 WriteLog.write(conf.getLogFile(), "CustomerOrders_ConfigureRow done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postSalesCustomerOrdersConfigureRow






    public static String postSalesCustomerOrdersGetPriceInfo(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Sales_CustomerOrders_GetPriceInfo.json");

        System.out.println("Sales_CustomerOrders_GetPriceInfo  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/CustomerOrders/GetPriceInfo"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 /*
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );
                 */

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */

                 /* 
                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );
                 */
                 WriteLog.write(conf.getLogFile(), "CustomerOrders_GetPriceInfo done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postSalesCustomerOrdersGetPriceInfo






    public static String postSalesCustomerOrdersGetQuantityChanges(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Sales_CustomerOrders_GetQuantityChanges.json");

        System.out.println("Sales_CustomerOrders_GetQuantityChanges  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/CustomerOrders/GetQuantityChanges"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 /*
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );
                 */

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */

                 /* 
                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );
                 */
                 WriteLog.write(conf.getLogFile(), "CustomerOrders_GetQuantityChanges done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postSalesCustomerOrdersGetQuantityChanges






    public static String postSalesCustomerOrdersGetRecipientOfType(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Sales_CustomerOrders_GetRecipientOfType.json");

        System.out.println("Sales_CustomerOrders_GetRecipientOfType  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/CustomerOrders/GetRecipientOfType"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 /*
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );
                 */

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */

                 /* 
                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );
                 */
                 WriteLog.write(conf.getLogFile(), "CustomerOrders_GetRecipientOfType done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postSalesCustomerOrdersGetRecipientOfType







    public static String postSalesCustomerOrdersRemoveCommunicationAddress(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Sales_CustomerOrders_RemoveCommunicationAddress.json");

        System.out.println("Sales_CustomerOrders_RemoveCommunicationAddress  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/CustomerOrders/RemoveCommunicationAddress"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );
                 

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */

                  
                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );
                 
                 WriteLog.write(conf.getLogFile(), "CustomerOrders_RemoveCommunicationAddress done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postSalesCustomerOrdersRemoveCommunicationAddress





    public static String postSalesCustomerOrdersRemoveRow(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Sales_CustomerOrders_RemoveRow.json");

        System.out.println("Sales_CustomerOrders_RemoveRow  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/CustomerOrders/RemoveRow"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );
                 

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */

                  
                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );
                 
                 WriteLog.write(conf.getLogFile(), "CustomerOrders_RemoveRow done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postSalesCustomerOrdersRemoveRow






    public static String postSalesCustomerOrdersReportDeliveries(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Sales_CustomerOrders_ReportDeliveries.json");

        System.out.println("Sales_CustomerOrders_ReportDeliveries  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/CustomerOrders/ReportDeliveries"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );
                 

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */

                  
                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );
                 
                 WriteLog.write(conf.getLogFile(), "CustomerOrders_ReportDeliveries done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postSalesCustomerOrdersReportDeliveries






    public static String postSalesCustomerOrdersSetAftermarketProductRecord(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Sales_CustomerOrders_SetAftermarketProductRecord.json");

        System.out.println("Sales_CustomerOrders_SetAftermarketProductRecord  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/CustomerOrders/SetAftermarketProductRecord"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );
                 

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */

                  
                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );
                 
                 WriteLog.write(conf.getLogFile(), "CustomerOrders_SetAftermarketProductRecord done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postSalesCustomerOrdersSetAftermarketProductRecord






    public static String postSalesCustomerOrdersSetProperties(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Sales_CustomerOrders_SetProperties.json");

        System.out.println("Sales_CustomerOrders_SetProperties  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/CustomerOrders/SetProperties"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );
                 

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */

                  
                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );
                 
                 WriteLog.write(conf.getLogFile(), "CustomerOrders_SetProperties done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postSalesCustomerOrdersSetProperties






    public static String postSalesCustomerOrdersSetRowCoding(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Sales_CustomerOrders_SetRowCoding.json");

        System.out.println("Sales_CustomerOrders_SetRowCoding  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/CustomerOrders/SetRowCoding"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );
                 

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */

                  
                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );
                 
                 WriteLog.write(conf.getLogFile(), "CustomerOrders_SetRowCoding done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postSalesCustomerOrdersSetRowCoding







    public static String postSalesCustomerOrdersUpdateCommunicationAddress(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Sales_CustomerOrders_UpdateCommunicationAddress.json");

        System.out.println("Sales_CustomerOrders_UpdateCommunicationAddress  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/CustomerOrders/UpdateCommunicationAddress"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );
                 

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */

                  
                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );
                 
                 WriteLog.write(conf.getLogFile(), "CustomerOrders_UpdateCommunicationAddress done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postSalesCustomerOrdersUpdateCommunicationAddress





    public static String postSalesCustomerOrdersUpdateInvoiceAddress(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Sales_CustomerOrders_UpdateInvoiceAddress.json");

        System.out.println("Sales_CustomerOrders_UpdateInvoiceAddress  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/CustomerOrders/UpdateInvoiceAddress"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );
                 

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */

                  
                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );
                 
                 WriteLog.write(conf.getLogFile(), "CustomerOrders_UpdateInvoiceAddress done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postSalesCustomerOrdersUpdateInvoiceAddress






    public static String postSalesCustomerOrdersUpdateMailingAddress(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Sales_CustomerOrders_UpdateMailingAddress.json");

        System.out.println("Sales_CustomerOrders_UpdateMailingAddress  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/CustomerOrders/UpdateMailingAddress"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );
                 

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */

                  
                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );
                 
                 WriteLog.write(conf.getLogFile(), "CustomerOrders_UpdateMailingAddress done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postSalesCustomerOrdersUpdateMailingAddress







    public static String postSalesCustomerOrdersUpdateRow(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;
        String    jsonPath     = conf.getJsonPath()          ;  // "./JSON/"
        String    jsonFile     = RestAPI.getJsonFile(conf, jsonPath + "Sales_CustomerOrders_UpdateRow.json");

        System.out.println("Sales_CustomerOrders_UpdateRow  \n" + jsonFile  );

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Sales/CustomerOrders/UpdateRow"
                                             );
             // ?$top=" + recordsLimit +"&$orderby=Id%20desc"

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json =  jsonFile ;  //   "{\n";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int    responsecode = con.getResponseCode();
             WriteLog.write(conf.getLogFile(), "ResponseCode: " + responsecode  , true);

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             //Getting the response text

             String response = "";
     	     Scanner scanner = new Scanner(con.getInputStream() );

  			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
    	     }
		     scanner.close();

             System.out.println( "response \n " + response );
             WriteLog.write(conf.getLogFile(), response, false);

             //Getting the response code

             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode == 500) {
                 System.out.println("Check JSON file : " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }

             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );
                 

                 /*
                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("ProductRecordId") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("ProductRecordId") != "111" ) {
                         System.out.println("Id: " + Id );

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Rename done. " + rs_count + " records "   , true);
                 */

                  
                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("EntityId");
                 //JSONValue  sesId = (JSONValue)  data_obj.get("EntityId") ;

                 String sesId = obj.toString() ;
                 Id = sesId ;
                 //String sesId = data_obj.get("EntityId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );
                 
                 WriteLog.write(conf.getLogFile(), "CustomerOrders_UpdateRow done   =  " + Id   , true);


   			     return Id   ;  // con   response


                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Check JSON file  ( Linked  record )  " +
                                "\n" + e.toString() );
        }

    }   // postSalesCustomerOrdersUpdateRow








}  // Commands_SAL
