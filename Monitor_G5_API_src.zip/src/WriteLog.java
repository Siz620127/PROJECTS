package sy_my ;

import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class WriteLog {
    protected static String defaultLogFile = "C:/PROJECTS/KLIPFOLIO/SY_MY/LOG/SY_MY.log" ;

    public static void write(String s) throws IOException {
        write(defaultLogFile, s);
    }

    public static void write(String f, String s) throws IOException {
        write(f, s, true);
    }

    public static void write(String f, String s,
                             boolean printTime) throws IOException {
        // f - logifaili failinimi koos kataloogiga, nt. "C:/PROJECTS/KLIPFOLIO/SY_MY/LOG/SY_MY.log"
        // s - logifaili tr�kitav tekst
        // printTime - kas tr�kkida logifaili rea algusse ka kuup�ev-kell
        String nl          = System.getProperty("line.separator");
        FileWriter aWriter = new FileWriter(f, true);
        if (printTime) {
            Date now = new Date();
            DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss ");
            //TimeZone tz = TimeZone.getTimeZone("EET"); // or PST, MID, etc ...
            //df.setTimeZone(tz);
            String currentTime = df.format(now);
            aWriter.write(currentTime + " " + s + nl);
        } else {
            aWriter.write(s + nl);
        }
        aWriter.flush();
        aWriter.close();
    }
}
