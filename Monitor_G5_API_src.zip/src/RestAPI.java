package sy_my ;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Scanner;
import org.json.simple.JSONObject;
import org.json.simple.JSONArray;
import org.json.simple.JSONValue;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

// -------

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import java.sql.* ;

// import java.sql.Connection;
// import java.sql.Date;
// import java.sql.DriverManager;
// import java.sql.PreparedStatement;
// import java.sql.SQLException;

import java.text.SimpleDateFormat;


public class RestAPI {

    static public String sessionId = "7da39d20-409e-4378-9b82-5ecbb29b1570" ;
    /*
    {"$id":"1","SessionId":"89583257-f3de-489b-bbd9-4543b0a2b181",
    "ActiveSessions":[{
    "$id":"2","SessionIdentifier":"3d77a8b8-368f-4092-8076-ffefcea9bdcf","LastActivity":"2021-10-20T12:54:41.3047738+00:00","Created":"2021-10-20T14:35:24.4038756+03:00","ClientAddress":"91-23-235-80.sta.estpak.ee"},
    {"$id":"3","SessionIdentifier":"1dadfefa-1ef0-40ae-b669-25e21de35ebd","LastActivity":"2021-10-21T08:29:00.4060138+00:00","Created":"2021-10-21T11:29:00.4060138+03:00","ClientAddress":"91-23-235-80.sta.estpak.ee"},
    {"$id":"4","SessionIdentifier":"7da39d20-409e-4378-9b82-5ecbb29b1570","LastActivity":"2021-10-20T10:30:43.7172639+00:00","Created":"2021-10-19T13:40:17.6448071+03:00","ClientAddress":"92-146-20-81.sta.estpak.ee"}],
    "SessionSuspended":false,
    "Language":{"$id":"5","Id":"0","Code":"EN","Description":"English","IsDefault":false,"Index":"0"},"User":{"$id":"6","Username":"ADMIN","Name":"Administrator","Email":null,"PhoneNumber":null},"IsBuiltInUser":true,"SupportsWebSockets":true}
    */


    // TEST START
    public static HttpURLConnection TestQuery(ReadConf conf) throws Exception {
        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals("185.158.177.241");

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end


             // URL url             = new URL( conf.getUrl_sy() );
             URL url                = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", "185.158.177.241"  );
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", "f1bc5219-b382-472e-adc9-ff0926ecbbb0" );



     	     String json = "{\n";
     		 json += "\"Username\": "     +  "\"ADMIN\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"\" "       + ",\n";
		     json += "\"ForceRelogin\": " +  true          + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode != 200) {
                 System.out.println("LOGIN was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("LOGIN was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( response );

   			     return con ;  // response



                 /*
                 Scanner scanner = new Scanner(url.openStream());
                 //Write all the JSON data into a string using a scanner
                 while (scanner.hasNext() ) {
                  inline += scanner.nextLine();
                  }
                 //Close the scanner
                 scanner.close();
                 */


                 /*
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parse    = new JSONParser();
                 JSONObject data_obj = (JSONObject) parse.parse( json );  // inline
                 //Get the required object from the above created object
                 JSONObject obj = (JSONObject) data_obj.get("Globale");
                 //Get the required data using its key
                 System.out.println(obj.get("TotalRecovered"));
                 JSONArray arr = (JSONArray) data_obj.get("Countries");
                 for (int i = 0; i < arr.size(); i++) {
                      JSONObject new_obj = (JSONObject) arr.get(i);
                      if (new_obj.get("Slug").equals("albania")) {
                         System.out.println("Total Recovered: " + new_obj.get("TotalRecovered"));
                         break;
                      }
                 }
               */

                }


        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() );
        }
        // return con;
    }   // TestQuery


        /*
        // baasiconnecti jaoks
        Connection con;
        try {
            System.out.println("getConnection / getDriver_sy " );
            Class.forName(conf.getDriver_sy());
        } catch (ClassNotFoundException e) {
            throw new Exception("Cannot find jdbc driver class " +
                                conf.getDriver_sy() );
        }
        con = DriverManager.getConnection(conf.getUrl_sy() , conf.getUsername_sy(), conf.getPassword_sy()   );
             // + conf.getDbName_sy()
             // + , conf.getUsername_my(), conf.getPassword_my()   );
        return con;
    }
    */


    // TEST END





    public static String getConnection(ReadConf conf) throws Exception {
               // HttpURLConnection
        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy()  );  //  "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "login"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         // con.setRequestProperty ("X-Monitor-SessionId", "f1bc5219-b382-472e-adc9-ff0926ecbbb0" );

     	     String json = "{\n";
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;    // "\"ADMIN\" "
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";     // "\"\" "
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";      // true
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode != 200) {
                 System.out.println("LOGIN was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("LOGIN was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("SessionId");  // Language
                 //JSONValue  sesId = (JSONValue)  data_obj.get("SessionId") ;

                 String sesId = obj.toString() ;
                 sessionId = sesId ;
                 //String sesId = data_obj.get("SessionId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );
                 // java.lang.String cannot be cast to org.json.simple.JSONValue

                 //Get the required data using its key
                 /*
                 System.out.println(obj.get("Code"));
                 JSONArray arr = (JSONArray) data_obj.get("ActiveSessions");
                 for (int i = 0; i < arr.size(); i++) {
                      JSONObject new_obj = (JSONObject) arr.get(i);
                      if (new_obj.get("Slug").equals("albania")) {
                         System.out.println("Total Recovered: " + new_obj.get("TotalRecovered"));
                         break;
                      }
                 }
                 */
   			     return sessionId    ;  // sesId  con   response



                 /*
                 Scanner scanner = new Scanner(url.openStream());
                 //Write all the JSON data into a string using a scanner
                 while (scanner.hasNext() ) {
                  inline += scanner.nextLine();
                  }
                 //Close the scanner
                 scanner.close();
                 */


                 /*
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parse    = new JSONParser();
                 JSONObject data_obj = (JSONObject) parse.parse( json );  // inline
                 //Get the required object from the above created object
                 JSONObject obj = (JSONObject) data_obj.get("Globale");
                 //Get the required data using its key
                 System.out.println(obj.get("TotalRecovered"));
                 JSONArray arr = (JSONArray) data_obj.get("Countries");
                 for (int i = 0; i < arr.size(); i++) {
                      JSONObject new_obj = (JSONObject) arr.get(i);
                      if (new_obj.get("Slug").equals("albania")) {
                         System.out.println("Total Recovered: " + new_obj.get("TotalRecovered"));
                         break;
                      }
                 }
               */

                }


        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() );
        }
        // return con;
    }   // getConnection






        /*
        // baasiconnecti jaoks
        Connection con;
        try {
            System.out.println("getConnection / getDriver_sy " );
            Class.forName(conf.getDriver_sy());
        } catch (ClassNotFoundException e) {
            throw new Exception("Cannot find jdbc driver class " +
                                conf.getDriver_sy() );
        }
        con = DriverManager.getConnection(conf.getUrl_sy() , conf.getUsername_sy(), conf.getPassword_sy()   );
             // + conf.getDbName_sy()
             // + , conf.getUsername_my(), conf.getPassword_my()   );
        return con;
    }
    */



    public static Connection getConnectionTarget(ReadConf conf) throws Exception {
        // baasiconnecti jaoks
        Connection con;
        try {
            System.out.println("getConnection / getDriver_my " );
            Class.forName(conf.getDriver_my());
        } catch (ClassNotFoundException e) {
            throw new Exception("Cannot find jdbc driver class " +
                                conf.getDriver_my() );
        }
        con = DriverManager.getConnection(conf.getUrl_my() , conf.getUsername_my(), conf.getPassword_my()   );
             // + conf.getDbName_sy()
             // + , conf.getUsername_my(), conf.getPassword_my()   );
        return con;
    }  // getConnectionTarget















    public static void Liiguta(ReadConf conf) throws Exception {
        // Meetod liigutab konfiguratsioonifailis conf n�idatud l�htekataloogist FROMDIR k�ik failid sihtkataloogi TODIR
        // ja kirjutab failide sisu baasi tabelisse
        // kui baasi kirjutamine ei �nnestu, siis sihtkataloogi ei liigutata
        // oma t��st teeb tekstifaili logi (konfiguratsioonifailis LOGFILE)
        Connection con         = Loefailid.getConnection(conf);
        PreparedStatement stmt = null;
        String lause           = null;
        boolean edukas         = false;

    //  Statement stmt_1       = null;
        ResultSet rs           = null;

        System.out.println("Liiguta starts " );

        // Source directory
        File kust = new File(conf.getFromDir());
        // Destination directory
        File kuhu = new File(conf.getToDir());
        String[] nimekiri = kust.list();
        String   failinimi;
        SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
        long     lastModified;
        String   kpv;

        // hakkan �kshaaval faile lugema
        for (int i = 0; i < nimekiri.length; i++) {
            failinimi = nimekiri[i];
            System.out.println("Liiguta failinimi "  + failinimi );

            FileInputStream fis = null;
            File algfail  = new File(conf.getFromDir() + "/" + failinimi);
            File loppfail = new File(conf.getToDir()   + "/" + failinimi);
            edukas = false;

            try {
                // loen faili viimase muutmise kuup�eva-kella
                lastModified = algfail.lastModified();
                kpv          = sdf.format(new Date(lastModified));
                byte[] bytes = null;
                fis          = new FileInputStream(algfail);
                bytes        = new byte[fis.available()];
                fis.read(bytes);
                //siin on faili sisu bytes-massiivis
                String sisu  = new String(bytes);

                System.out.println("Liiguta faili sisu "  + sisu );

                // lisan faili baasi
                /*
                lause =
                        "Insert into SULAR.RAHAFAILID (RAHAFAILI_ID,FAILINIMI,SAADUD,PAISEKAART,PLOMM,CREATED,STAATUS,LAADVIGA,KOTI_ID,SISU) " +
                        "values (sular.seq_rahafaili_id.nextval,'" +
                        failinimi + "', sysdate, null, null, to_date('" + kpv +
                        "','DD.MM.YYYY HH24:MI:SS'), 'S', null, null,?)";
                */

                lause =
                        "Select ID,DepartmentId,DepartmentCode,DepartmentName,TSM  from G5_DEPARTMENTS  " +
                        "order by DepartmentCode " ;

                //System.out.println( sisu );
                stmt = con.prepareStatement( sisu );
                // stmt.setObject(1, sisu);
                // stmt.executeUpdate();
                rs = stmt.executeQuery();
                edukas = true;

                // ----------------------------
                // Write to Destination DB
                // ----------------------------
                System.out.println("Liiguta Write to Destination " );

                while (rs.next()) {
                  String str = rs.getString("id") + ":" + rs.getString(2);
                  System.out.println("id:" + str);

                }
                lause =
                        "Insert into G5_DEPARTMENTS  " +
                        "( ID,DepartmentId,DepartmentCode,DepartmentName,TSM   ) " +
                        "values ( 101,101 ,'java_code_1' ,'java_name_1' , now() ) " ;
                System.out.println("executeUpdate: " + lause );

                stmt = con.prepareStatement( lause );  // lause
                stmt.executeUpdate();

                rs.close();
                stmt.close();

            } catch (IOException e) {
                WriteLog.write(conf.getLogFile(),
                               algfail.getName() + " IO Error while opening file ");
                WriteLog.write(conf.getLogFile(), e.toString(), false);
                //return;
            } catch (SQLException e) {
                WriteLog.write(conf.getLogFile(),
                               algfail.getName() + " SQL Error while inserting into database ");
                WriteLog.write(conf.getLogFile(), e.toString() + lause, false);
            } catch (Exception e) {
                WriteLog.write(conf.getLogFile(),
                               algfail.getName() + " Error while processing file ");
                WriteLog.write(conf.getLogFile(), e.toString(), false);
            } finally {
                if (fis != null) {
                    try {
                        fis.close();
                    } catch (IOException e) {
                        WriteLog.write(conf.getLogFile(),
                                       algfail.getName() + " IO Error while closing file ");
                        WriteLog.write(conf.getLogFile(), e.toString(), false);
                    }
                }
            }
            if (edukas) {
                // Move file to new directory
                boolean success = true;
                success = algfail.renameTo(loppfail);
                if (!success) {
                    // File was not successfully moved
                    WriteLog.write(conf.getLogFile(),
                                   algfail.getName() + " Fail baasi kirjutatud, aga ei �nnestunud liigutada seda kataloogi " +
                                   conf.getToDir());
                } else {
                    WriteLog.write(conf.getLogFile(),
                                   algfail.getName() + " OK");
                }
            }

        }
        // sulgen baasi�henduse
        con.close();
    }  // Liiguta




    public static void ChangeConf(ReadConf conf) throws Exception {
        // Meetod liigutab konfiguratsioonifailis conf n�idatud l�htekataloogist FROMDIR k�ik failid sihtkataloogi TODIR
        // ja kirjutab failide sisu baasi tabelisse
        // kui baasi kirjutamine ei �nnestu, siis sihtkataloogi ei liigutata
        // oma t��st teeb tekstifaili logi (konfiguratsioonifailis LOGFILE)
        // Connection con         = Loefailid.getConnection(conf);
        PreparedStatement stmt = null;
        String  lause          = null;
        boolean edukas         = false;

    //  Statement stmt_1       = null;
        ResultSet rs           = null;

        System.out.println("ChangeConf starts " );

        // Source directory
        File kust = new File( "./" );   // conf.getFromDir()
        // Destination directory
        File kuhu = new File( "./"  );  // conf.getToDir()
        String[] nimekiri = kust.list();
        String   failinimi;
        SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
        long     lastModified;
        String   kpv;

        // ----------------------------------
        // SY_MY.conf changing
        // ----------------------------------
        //for (int i = 0; i < nimekiri.length; i++) {
            failinimi = "SY_MY.conf" ;  //  nimekiri[i];
            System.out.println("Change file  "  + failinimi );

            FileInputStream  fis = null;
            FileOutputStream fos = null ;
            File algfail  = new File("./" + failinimi );          // conf.getFromDir() + "/" + failinimi
            File loppfail = new File("./" + failinimi + "_new");  // conf.getToDir()   + "/" + failinimi
            edukas = false;

            try {
                // loen faili viimase muutmise kuup�eva-kella
                lastModified = algfail.lastModified();
                kpv          = sdf.format(new Date(lastModified));
                byte[] bytes = null;
                fis          = new FileInputStream(algfail);
                bytes        = new byte[fis.available()];
                fis.read(bytes);
                //siin on faili sisu bytes-massiivis
                String sisu   = new String( bytes );
                String sess_1 = sisu.substring( 0 , sisu.indexOf("SESSIONID_SY")  );
                String sess_2 = sisu.substring( sisu.indexOf("SESSIONID_SY")  );
                String sess_3 = sess_2.substring( sess_2.indexOf("\n")  );


                sessionId = RestAPI.getConnection(conf) ;


                String sess   = sess_1 +
                               "SESSIONID_SY = "  + sessionId + "\n" +
                               sess_3 ;

                byte[] bytes_out = sess.getBytes();

                fos          = new FileOutputStream( loppfail );
                fos.write( bytes_out , 0, sess.length()  );

                System.out.println("sess "  + sess );
                edukas = true ;





            }
            catch (IOException e) {
                WriteLog.write(conf.getLogFile(),
                               algfail.getName() + " IO Error while opening file ");
                WriteLog.write(conf.getLogFile(), e.toString(), false);
                //return;
            }
            /*
            catch (SQLException e) {
                WriteLog.write(conf.getLogFile(),
                               algfail.getName() + " SQL Error while inserting into database ");
                WriteLog.write(conf.getLogFile(), e.toString() + lause, false);
            }
            */
            catch (Exception e) {
                WriteLog.write(conf.getLogFile(),
                               algfail.getName() + " Error while processing file ");
                WriteLog.write(conf.getLogFile(), e.toString(), false);
            }
            finally {
                if (fis != null) {
                    try {
                        fis.close();
                    }
                    catch (IOException e) {
                        WriteLog.write(conf.getLogFile(),
                                       algfail.getName() + " IO Error while closing file ");
                        WriteLog.write(conf.getLogFile(), e.toString(), false);
                    }
                }
                if (fos != null) {
                    try {
                        fos.close();
                    }
                    catch (IOException e) {
                        WriteLog.write(conf.getLogFile(),
                                       loppfail.getName() + " IO Error while closing file ");
                        WriteLog.write(conf.getLogFile(), e.toString(), false);
                    }
                }
            }


            if (edukas) {
                // Move file to new directory
                boolean success = true;
                WriteLog.write(conf.getLogFile(),
                               algfail.getName() + " copy to " + loppfail.getName()  );
                //success = algfail.renameTo(loppfail);
                success = true ;
                if (!success) {
                    // File was not successfully moved
                    WriteLog.write(conf.getLogFile(),
                                   algfail.getName() + " ei �nnestunud liigutada seda kataloogi " +
                                   conf.getToDir());
                }
                else {
                    WriteLog.write(conf.getLogFile(),
                                   algfail.getName() + " OK");
                }



            }


    }  // ChangeConf





    public static String getJsonFile(ReadConf conf, String jsonFileName  ) throws Exception {
               // HttpURLConnection
        // Read content of "jsonFileName"

        PreparedStatement stmt = null;
        String  lause          = null;
        boolean edukas         = false;

    //  Statement stmt_1       = null;
        ResultSet rs           = null;
        String sisu            = "" ;

        System.out.println("getJsonFile starts " );


        // Source directory
        // File kust = new File( conf.getJsonPath() );  //  "./"
        // Destination directory
        // File kuhu = new File( conf.getJsonPath() );  //  "./"
        // String[] nimekiri = kust.list();
        String   failinimi;
        SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
        long     lastModified;
        String   kpv;

        // ----------------------------------
        // JSON file reading
        // ----------------------------------
            failinimi = jsonFileName ;  // kust +
            System.out.println("Reading file  "  + failinimi );

            FileInputStream  fis = null;
            FileOutputStream fos = null ;
            File algfail  = new File(  failinimi );          // conf.getJsonPath() + + "/" + failinimi
            File loppfail = new File( conf.getJsonPath() + failinimi + "_new");  // conf.getToDir()   + "/" + failinimi

            System.out.println("failinimi " + failinimi );
            System.out.println("algfail " + algfail.getName() );



            edukas = false;

            try {
                lastModified = algfail.lastModified();
                kpv          = sdf.format(new Date(lastModified));
                byte[] bytes = null;
                fis          = new FileInputStream(algfail);
                bytes        = new byte[fis.available()];
                fis.read(bytes);
                //siin on faili sisu bytes-massiivis
                sisu         = new String( bytes );
                System.out.println("JSON file : \n "  + sisu );
                edukas = true ;
 		        // return sisu    ;

            }

            catch (IOException e) {
                WriteLog.write(conf.getLogFile(),
                               algfail.getName() + " IO Error while opening file ");
                WriteLog.write(conf.getLogFile(), e.toString(), true);
                // return sisu    ;
            }

            catch (Exception e) {
                WriteLog.write(conf.getLogFile(),
                               algfail.getName() + " Error while processing file ");
                WriteLog.write(conf.getLogFile(), e.toString(), true );
                // return sisu    ;
            }
            finally {
                if (fis != null) {
                    try {
                        fis.close();
                    }
                    catch (IOException e) {
                        WriteLog.write(conf.getLogFile(),
                                       algfail.getName() + " IO Error while closing file ");
                        WriteLog.write(conf.getLogFile(), e.toString(), true );
                    }
                }
                if (fos != null) {
                    try {
                        fos.close();
                    }
                    catch (IOException e) {
                        WriteLog.write(conf.getLogFile(),
                                       loppfail.getName() + " IO Error while closing file ");
                        WriteLog.write(conf.getLogFile(), e.toString(), true);
                    }
                }
            }


            if (edukas) {
                // File was reading
                boolean success = true;
                WriteLog.write(conf.getLogFile(), algfail.getName() + " content  \n " + sisu   );
                //success = algfail.renameTo(loppfail);
                success = true ;
                if (!success) {
                    // File was not successfully moved
                    WriteLog.write(conf.getLogFile(),
                                   algfail.getName() + " ei ?nnestunud liigutada seda kataloogi " +
                                   conf.getToDir());
                }
                else {
                    // WriteLog.write(conf.getLogFile(), algfail.getName() + " OK");
                    System.out.println( algfail.getName() + " OK" );

                }



            }

           return sisu    ;

    }  // getJsonFile






    public static void main(String[] args) throws Exception {
        // loe �ra argumentidest konfiguratsioonifaili asukoht
        String paramfail ;
        String queryName ;

        queryName = args[0];
        // paramfail = args[0];
        paramfail = "SY_MY.conf";
        //paramfail = "c:/PROJECTS/KLIPFOLIO/src/SY_MY.conf";

        System.out.println("ReadConf: " + paramfail);

        ReadConf conf = new ReadConf(paramfail);
        //RestAPI  rest = new RestAPI( );

        WriteLog.write( conf.getLogFile(), "Conf file was loaded successfully \n ", true);
        /*
        WriteLog.write(conf.getLogFile(), "", false);
        WriteLog.write(conf.getLogFile(),
                       "=============================  Alustasin laadimist ==============================");
        // kirjuta logisse konfifailist loetud kraam
        WriteLog.write(conf.getLogFile(), conf.toString(), false);
        */
        try {
            System.out.println( queryName +  " Query calling " );
            WriteLog.write( conf.getLogFile(), queryName +  " Query calling " , true);

            // HttpURLConnection con  = RestAPI.TestQuery(conf);

            if ( queryName.equals("getConnection") ) {
               String sesId = RestAPI.getConnection(conf);
            }
            if ( queryName.equals("getConnectionTarget") ) {
               Connection con = getConnectionTarget( conf) ;
            }
            if ( queryName.equals("ChangeConf") ) {
               RestAPI.ChangeConf(conf);
            }
            if ( queryName.equals("getPersons") ) {
               String Id    = Queries_COM.getPersons( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getCalendars") ) {
               String Id    = Queries_COM.getCalendars( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getCountries") ) {
               String Id    = Queries_COM.getCountries( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getCurrencies") ) {
               String Id    = Queries_COM.getCurrencies( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getCurrencyExchangeRates") ) {
               String Id    = Queries_COM.getCurrencyExchangeRates( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getDeliveryMethods") ) {
               String Id    = Queries_COM.getDeliveryMethods( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getDeliveryTerms") ) {
               String Id    = Queries_COM.getDeliveryTerms( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getDepartments") ) {
               String Id    = Queries_COM.getDepartments( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getLanguageCodes") ) {
               String Id    = Queries_COM.getLanguageCodes( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getPaymentMethods") ) {
               String Id    = Queries_COM.getPaymentMethods( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getPaymentTerms") ) {
               String Id    = Queries_COM.getPaymentTerms( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getUnits") ) {
               String Id    = Queries_COM.getUnits( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getWarehouses") ) {
               String Id    = Queries_COM.getWarehouses( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getAddresses") ) {
               String Id    = Queries_COM.getAddresses( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getApplicationUsers") ) {
               String Id    = Queries_COM.getApplicationUsers( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getAutoCompleteConfigurations") ) {
               String Id    = Queries_COM.getAutoCompleteConfigurations( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getBusinessContactBankAccounts") ) {
               String Id    = Queries_COM.getBusinessContactBankAccounts( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getBusinessContactNoteHistories") ) {
               String Id    = Queries_COM.getBusinessContactNoteHistories( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getBusinessContactReferences") ) {
               String Id    = Queries_COM.getBusinessContactReferences( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getCentralBankCodes") ) {
               String Id    = Queries_COM.getCentralBankCodes( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getComments") ) {
               String Id    = Queries_COM.getComments( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getCommunicationAddresses") ) {
               String Id    = Queries_COM.getCommunicationAddresses( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getCurrencyExchangeRateChangeLogs") ) {
               String Id    = Queries_COM.getCurrencyExchangeRateChangeLogs( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getCustomReportDefinitions") ) {
               String Id    = Queries_COM.getCustomReportDefinitions( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getCustomReportDisplayDefinitions") ) {
               String Id    = Queries_COM.getCustomReportDisplayDefinitions( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getDelegatedWork") ) {
               String Id    = Queries_COM.getDelegatedWork( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getDeliveryAddresses") ) {
               String Id    = Queries_COM.getDeliveryAddresses( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getDeliveryAddressWarehouseInformations") ) {
               String Id    = Queries_COM.getDeliveryAddressWarehouseInformations( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getDiscountCategories") ) {
               String Id    = Queries_COM.getDiscountCategories( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getEntityChangeLogs") ) {
               String Id    = Queries_COM.getEntityChangeLogs( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getEntityPropertyChanges") ) {
               String Id    = Queries_COM.getEntityPropertyChanges( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getExtraFieldGroups") ) {
               String Id    = Queries_COM.getExtraFieldGroups( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getExtraFieldOptionTemplates") ) {
               String Id    = Queries_COM.getExtraFieldOptionTemplates( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getExtraFields") ) {
               String Id    = Queries_COM.getExtraFields( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getExtraFieldTemplates") ) {
               String Id    = Queries_COM.getExtraFieldTemplates( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getFilePaths") ) {
               String Id    = Queries_COM.getFilePaths( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getFormReportConfigurations") ) {
               String Id    = Queries_COM.getFormReportConfigurations( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getFormReportTranslationGroups") ) {
               String Id    = Queries_COM.getFormReportTranslationGroups( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getFormReportTranslations") ) {
               String Id    = Queries_COM.getFormReportTranslations( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getPartConfigurationPresets") ) {
               String Id    = Queries_COM.getPartConfigurationPresets( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getPartConfigurationResults") ) {
               String Id    = Queries_COM.getPartConfigurationResults( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getPartConfigurations") ) {
               String Id    = Queries_COM.getPartConfigurations( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getPartConfigurationTemplates") ) {
               String Id    = Queries_COM.getPartConfigurationTemplates( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getPartUnitUsages") ) {
               String Id    = Queries_COM.getPartUnitUsages( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getPaymentPlanTemplateRows") ) {
               String Id    = Queries_COM.getPaymentPlanTemplateRows( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getPaymentPlanTemplates") ) {
               String Id    = Queries_COM.getPaymentPlanTemplates( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getPersonManufacturingPrintSettings") ) {
               String Id    = Queries_COM.getPersonManufacturingPrintSettings( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getPriceLists") ) {
               String Id    = Queries_COM.getPriceLists( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getProbabilities") ) {
               String Id    = Queries_COM.getProbabilities( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getProductGroups") ) {
               String Id    = Queries_COM.getProductGroups( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getProjectActivities") ) {
               String Id    = Queries_COM.getProjectActivities( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getProjectActivityRelations") ) {
               String Id    = Queries_COM.getProjectActivityRelations( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getProjectActivityTypes") ) {
               String Id    = Queries_COM.getProjectActivityTypes( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getProjectAggregates") ) {
               String Id    = Queries_COM.getProjectAggregates( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getProjectCostBudgets") ) {
               String Id    = Queries_COM.getProjectCostBudgets( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getProjectCostForecasts") ) {
               String Id    = Queries_COM.getProjectCostForecasts( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getProjectCostReportingEntries") ) {
               String Id    = Queries_COM.getProjectCostReportingEntries( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getProjectCostTypes") ) {
               String Id    = Queries_COM.getProjectCostTypes( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getProjectPhases") ) {
               String Id    = Queries_COM.getProjectPhases( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getProjectPhaseTypes") ) {
               String Id    = Queries_COM.getProjectPhaseTypes( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getProjects") ) {
               String Id    = Queries_COM.getProjects( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getProjectTypes") ) {
               String Id    = Queries_COM.getProjectTypes( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getReasonCodes") ) {
               String Id    = Queries_COM.getReasonCodes( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getRejectionCodeItems") ) {
               String Id    = Queries_COM.getRejectionCodeItems( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getResellers") ) {
               String Id    = Queries_COM.getResellers( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getRevisions") ) {
               String Id    = Queries_COM.getRevisions( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getServerPrinters") ) {
               String Id    = Queries_COM.getServerPrinters( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getStaggeredPrices") ) {
               String Id    = Queries_COM.getStaggeredPrices( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getStatisticalGoodsCodes") ) {
               String Id    = Queries_COM.getStatisticalGoodsCodes( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getTariffAndServiceCodes") ) {
               String Id    = Queries_COM.getTariffAndServiceCodes( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getTransactionTypeIntrastats") ) {
               String Id    = Queries_COM.getTransactionTypeIntrastats( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getTransferProfiles") ) {
               String Id    = Queries_COM.getTransferProfiles( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getVatGroups") ) {
               String Id    = Queries_COM.getVatGroups( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getVatRates") ) {
               String Id    = Queries_COM.getVatRates( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getWorkCenterManufacturingPrintSettings") ) {
               String Id    = Queries_COM.getWorkCenterManufacturingPrintSettings( conf   ) ;  // , rest , con , sessionId
            }






            if ( queryName.equals("getManufacturingOrders") ) {
               String Id    = Queries_MAN.getManufacturingOrders( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getWorkCenters") ) {
               String Id    = Queries_MAN.getWorkCenters( conf   ) ;  // , rest , con , sessionId
            }
                if ( queryName.equals("getManufacturingOrderTypes") ) {
               String Id    = Queries_MAN.getManufacturingOrderTypes( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getManufacturingOrderOperations") ) {
               String Id    = Queries_MAN.getManufacturingOrderOperations( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getManufacturingOrderNodes") ) {
               String Id    = Queries_MAN.getManufacturingOrderNodes( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getDrawingRevisions") ) {
               String Id    = Queries_MAN.getDrawingRevisions( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getDrawings") ) {
               String Id    = Queries_MAN.getDrawings( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getManufacturingOrderMaterials") ) {
               String Id    = Queries_MAN.getManufacturingOrderMaterials( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getManufacturingPickingListMaterials") ) {
               String Id    = Queries_MAN.getManufacturingPickingListMaterials( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getManufacturingPickingLists") ) {
               String Id    = Queries_MAN.getManufacturingPickingLists( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getMaterialRows") ) {
               String Id    = Queries_MAN.getMaterialRows( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getOperationRows") ) {
               String Id    = Queries_MAN.getOperationRows( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getPreparations") ) {
               String Id    = Queries_MAN.getPreparations( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getWorkCenterCostFactorGroups") ) {
               String Id    = Queries_MAN.getWorkCenterCostFactorGroups( conf   ) ;  // , rest , con , sessionId
            }








            if ( queryName.equals("getAccounts") ) {
               String Id    = Queries_ACC.getAccounts( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getBookings") ) {
               String Id    = Queries_ACC.getBookings( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getVouchers") ) {
               String Id    = Queries_ACC.getVouchers( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getAccountingYearPeriods") ) {
               String Id    = Queries_ACC.getAccountingYearPeriods( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getAccountingYears") ) {
               String Id    = Queries_ACC.getAccountingYears( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getAccountsPayables") ) {
               String Id    = Queries_ACC.getAccountsPayables( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getAccountsReceivables") ) {
               String Id    = Queries_ACC.getAccountsReceivables( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getAccountYearSettingCodingDimensionAvailabilities") ) {
               String Id    = Queries_ACC.getAccountYearSettingCodingDimensionAvailabilities( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getAccountYearSettings") ) {
               String Id    = Queries_ACC.getAccountYearSettings( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getAccrualAccountingLedgers") ) {
               String Id    = Queries_ACC.getAccrualAccountingLedgers( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getAccrualAccountingRows") ) {
               String Id    = Queries_ACC.getAccrualAccountingRows( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getAccrualAccountings") ) {
               String Id    = Queries_ACC.getAccrualAccountings( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getBookingRows") ) {
               String Id    = Queries_ACC.getBookingRows( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getCodingDimensions") ) {
               String Id    = Queries_ACC.getCodingDimensions( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getCodingElements") ) {
               String Id    = Queries_ACC.getCodingElements( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getCodingEntries") ) {
               String Id    = Queries_ACC.getCodingEntries( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getCodingEntryElements") ) {
               String Id    = Queries_ACC.getCodingEntryElements( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getCodingRows") ) {
               String Id    = Queries_ACC.getCodingRows( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getCodings") ) {
               String Id    = Queries_ACC.getCodings( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getVoucherNumberSeries") ) {
               String Id    = Queries_ACC.getVoucherNumberSeries( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getVoucherRows") ) {
               String Id    = Queries_ACC.getVoucherRows( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getVoucherSeries") ) {
               String Id    = Queries_ACC.getVoucherSeries( conf   ) ;  // , rest , con , sessionId
            }








            if ( queryName.equals("getParts") ) {
               String Id    = Queries_INV.getParts( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getPriceChangeLogs") ) {
               String Id    = Queries_INV.getPriceChangeLogs( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getQuantityChanges") ) {
               String Id    = Queries_INV.getQuantityChanges( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getStockBalanceChanges") ) {
               String Id    = Queries_INV.getStockBalanceChanges( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getAbcCodes") ) {
               String Id    = Queries_INV.getAbcCodes( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getAlloys") ) {
               String Id    = Queries_INV.getAlloys( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getCaseEntry") ) {
               String Id    = Queries_INV.getCaseEntry( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getCaseEntryActivities") ) {
               String Id    = Queries_INV.getCaseEntryActivities( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getCaseEntryAdditionalCost") ) {
               String Id    = Queries_INV.getCaseEntryAdditionalCost( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getCaseEntryPhases") ) {
               String Id    = Queries_INV.getCaseEntryPhases( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getCaseManagementActivities") ) {
               String Id    = Queries_INV.getCaseManagementActivities( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getCaseManagementCost") ) {
               String Id    = Queries_INV.getCaseManagementCost( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getCaseManagementPhases") ) {
               String Id    = Queries_INV.getCaseManagementPhases( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getCaseManagementType") ) {
               String Id    = Queries_INV.getCaseManagementType( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getGoodsTypes") ) {
               String Id    = Queries_INV.getGoodsTypes( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getHyperLinks") ) {
               String Id    = Queries_INV.getHyperLinks( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getPackageTypes") ) {
               String Id    = Queries_INV.getPackageTypes( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getPartCodes") ) {
               String Id    = Queries_INV.getPartCodes( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getPartIdentityTypes") ) {
               String Id    = Queries_INV.getPartIdentityTypes( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getPartLocationProductRecords") ) {
               String Id    = Queries_INV.getPartLocationProductRecords( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getPartLocations") ) {
               String Id    = Queries_INV.getPartLocations( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getPartOtherIdentities") ) {
               String Id    = Queries_INV.getPartOtherIdentities( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getPartPlanningInformation") ) {
               String Id    = Queries_INV.getPartPlanningInformation( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getPartPurchaseExpenseValues") ) {
               String Id    = Queries_INV.getPartPurchaseExpenseValues( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getPartTemplates") ) {
               String Id    = Queries_INV.getPartTemplates( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getProductRecordOperationReportings") ) {
               String Id    = Queries_INV.getProductRecordOperationReportings( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getProductRecords") ) {
               String Id    = Queries_INV.getProductRecords( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getProfitMarkups") ) {
               String Id    = Queries_INV.getProfitMarkups( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getSalesOverheadMarkups") ) {
               String Id    = Queries_INV.getSalesOverheadMarkups( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getStorageOverheadMarkups") ) {
               String Id    = Queries_INV.getStorageOverheadMarkups( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getUnplannedStockMovementReasonCodes") ) {
               String Id    = Queries_INV.getUnplannedStockMovementReasonCodes( conf   ) ;  // , rest , con , sessionId
            }












            if ( queryName.equals("getInquiries") ) {
               String Id    = Queries_PUR.getInquiries( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getPurchaseOrderDeliveries") ) {
               String Id    = Queries_PUR.getPurchaseOrderDeliveries( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getPurchaseOrderInvoices") ) {
               String Id    = Queries_PUR.getPurchaseOrderInvoices( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getPurchaseOrders") ) {
               String Id    = Queries_PUR.getPurchaseOrders( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getSuppliers") ) {
               String Id    = Queries_PUR.getSuppliers( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getInquiryRows") ) {
               String Id    = Queries_PUR.getInquiryRows( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getInquiryTypes") ) {
               String Id    = Queries_PUR.getInquiryTypes( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getOtherSupplierNumbers") ) {
               String Id    = Queries_PUR.getOtherSupplierNumbers( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getPackingTerms") ) {
               String Id    = Queries_PUR.getPackingTerms( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getPurchaseOrderDeliveryRows") ) {
               String Id    = Queries_PUR.getPurchaseOrderDeliveryRows( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getPurchaseOrderInvoiceRows") ) {
               String Id    = Queries_PUR.getPurchaseOrderInvoiceRows( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getPurchaseOrderRows") ) {
               String Id    = Queries_PUR.getPurchaseOrderRows( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getPurchaseOrderTypes") ) {
               String Id    = Queries_PUR.getPurchaseOrderTypes( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getResponseTimes") ) {
               String Id    = Queries_PUR.getResponseTimes( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getSupplierAccountGroups") ) {
               String Id    = Queries_PUR.getSupplierAccountGroups( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getSupplierDistricts") ) {
               String Id    = Queries_PUR.getSupplierDistricts( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getSupplierPartLinks") ) {
               String Id    = Queries_PUR.getSupplierPartLinks( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getSupplierStatuses") ) {
               String Id    = Queries_PUR.getSupplierStatuses( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getSupplierTypes") ) {
               String Id    = Queries_PUR.getSupplierTypes( conf   ) ;  // , rest , con , sessionId
            }









            if ( queryName.equals("getCustomerOrderInvoices") ) {
               String Id    = Queries_SAL.getCustomerOrderInvoices( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getCustomerOrders") ) {
               String Id    = Queries_SAL.getCustomerOrders( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getCustomers") ) {
               String Id    = Queries_SAL.getCustomers( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getQuotes") ) {
               String Id    = Queries_SAL.getQuotes( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getCustomerAccountGroups") ) {
               String Id    = Queries_SAL.getCustomerAccountGroups( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getCustomerDistricts") ) {
               String Id    = Queries_SAL.getCustomerDistricts( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getCustomerOrderDeliveryRows") ) {
               String Id    = Queries_SAL.getCustomerOrderDeliveryRows( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getCustomerOrderInvoiceRows") ) {
               String Id    = Queries_SAL.getCustomerOrderInvoiceRows( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getCustomerOrderRows") ) {
               String Id    = Queries_SAL.getCustomerOrderRows( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getCustomerOrderShippingInformationRows") ) {
               String Id    = Queries_SAL.getCustomerOrderShippingInformationRows( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getCustomerOrderTypes") ) {
               String Id    = Queries_SAL.getCustomerOrderTypes( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getCustomerPartLinks") ) {
               String Id    = Queries_SAL.getCustomerPartLinks( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getCustomerRelationshipActivityTypes") ) {
               String Id    = Queries_SAL.getCustomerRelationshipActivityTypes( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getCustomerRelationshipManagementActivities") ) {
               String Id    = Queries_SAL.getCustomerRelationshipManagementActivities( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getCustomerStatuses") ) {
               String Id    = Queries_SAL.getCustomerStatuses( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getCustomerTypes") ) {
               String Id    = Queries_SAL.getCustomerTypes( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getInvoiceLogs") ) {
               String Id    = Queries_SAL.getInvoiceLogs( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getOtherCustomerNumbers") ) {
               String Id    = Queries_SAL.getOtherCustomerNumbers( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getQuoteRows") ) {
               String Id    = Queries_SAL.getQuoteRows( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getQuoteTypes") ) {
               String Id    = Queries_SAL.getQuoteTypes( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getReasonCodeLostQuotes") ) {
               String Id    = Queries_SAL.getReasonCodeLostQuotes( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getSalesPickingLists") ) {
               String Id    = Queries_SAL.getSalesPickingLists( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getSalesPrices") ) {
               String Id    = Queries_SAL.getSalesPrices( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getValidityTimes") ) {
               String Id    = Queries_SAL.getValidityTimes( conf   ) ;  // , rest , con , sessionId
            }






            if ( queryName.equals("getAbsenceCodes") ) {
               String Id    = Queries_TIM.getAbsenceCodes( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getIndirectWorkCodes") ) {
               String Id    = Queries_TIM.getIndirectWorkCodes( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getOvertimeTypes") ) {
               String Id    = Queries_TIM.getOvertimeTypes( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getPlannedAbsences") ) {
               String Id    = Queries_TIM.getPlannedAbsences( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getAttendanceChart") ) {
               String Id    = Queries_TIM.getAttendanceChart( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getAttendanceIntervals") ) {
               String Id    = Queries_TIM.getAttendanceIntervals( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getRecordingDays") ) {
               String Id    = Queries_TIM.getRecordingDays( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getSalaryTypes") ) {
               String Id    = Queries_TIM.getSalaryTypes( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getShedules") ) {
               String Id    = Queries_TIM.getShedules( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getStandbyWorks") ) {
               String Id    = Queries_TIM.getStandbyWorks( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getTimeBanks") ) {
               String Id    = Queries_TIM.getTimeBanks( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getWorkIntervals") ) {
               String Id    = Queries_TIM.getWorkIntervals( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("getAttendanceGroupSettings") ) {
               String Id    = Queries_TIM.getAttendanceGroupSettings( conf   ) ;  // , rest , con , sessionId
            }






            if ( queryName.equals("postInventoryPartsCreate") ) {
               String Id    = Commands_INV.postInventoryPartsCreate( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryPartsAddCustomerPartLink") ) {
               String Id    = Commands_INV.postInventoryPartsAddCustomerPartLink( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryPartsAddDrawing") ) {
               String Id    = Commands_INV.postInventoryPartsAddDrawing( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryPartsAddDrawingRevision") ) {
               String Id    = Commands_INV.postInventoryPartsAddDrawingRevision( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryPartsAddPartUnitUsage") ) {
               String Id    = Commands_INV.postInventoryPartsAddPartUnitUsage( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryPartsAddRevision") ) {
               String Id    = Commands_INV.postInventoryPartsAddRevision( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryPartsAddStaggeredSupplierPartLinkPrice") ) {
               String Id    = Commands_INV.postInventoryPartsAddStaggeredSupplierPartLinkPrice( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryPartsAddSupplierPartLink") ) {
               String Id    = Commands_INV.postInventoryPartsAddSupplierPartLink( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryPartsApplyPartTemplate") ) {
               String Id    = Commands_INV.postInventoryPartsApplyPartTemplate( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryPartsChangeDefaultUnit") ) {
               String Id    = Commands_INV.postInventoryPartsChangeDefaultUnit( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryPartsCreateHyperLink") ) {
               String Id    = Commands_INV.postInventoryPartsCreateHyperLink( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryPartsCreateLocation") ) {
               String Id    = Commands_INV.postInventoryPartsCreateLocation( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryPartsCreatePartOtherIdentity") ) {
               String Id    = Commands_INV.postInventoryPartsCreatePartOtherIdentity( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryPartsGetFromPartLocations") ) {
               String Id    = Commands_INV.postInventoryPartsGetFromPartLocations( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryPartsGetPartBalanceInfo") ) {
               String Id    = Commands_INV.postInventoryPartsGetPartBalanceInfo( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryPartsGetToPartLocations") ) {
               String Id    = Commands_INV.postInventoryPartsGetToPartLocations( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryPartsRemoveCustomerPartLink") ) {
               String Id    = Commands_INV.postInventoryPartsRemoveCustomerPartLink( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryPartsRemoveDrawing") ) {
               String Id    = Commands_INV.postInventoryPartsRemoveDrawing( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryPartsRemoveDrawingRevision") ) {
               String Id    = Commands_INV.postInventoryPartsRemoveDrawingRevision( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryPartsRemoveHyperLink") ) {
               String Id    = Commands_INV.postInventoryPartsRemoveHyperLink( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryPartsRemoveLocation") ) {
               String Id    = Commands_INV.postInventoryPartsRemoveLocation( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryPartsRemovePartOtherIdentity") ) {
               String Id    = Commands_INV.postInventoryPartsRemovePartOtherIdentity( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryPartsRemovePartUnitUsage") ) {
               String Id    = Commands_INV.postInventoryPartsRemovePartUnitUsage( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryPartsRemoveRevision") ) {
               String Id    = Commands_INV.postInventoryPartsRemoveRevision( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryPartsRemoveStaggeredSupplierPartLinkPrice") ) {
               String Id    = Commands_INV.postInventoryPartsRemoveStaggeredSupplierPartLinkPrice( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryPartsRemoveSupplierPartLink") ) {
               String Id    = Commands_INV.postInventoryPartsRemoveSupplierPartLink( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryPartsReportStockCount") ) {
               String Id    = Commands_INV.postInventoryPartsReportStockCount( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryPartsSaveAs") ) {
               String Id    = Commands_INV.postInventoryPartsSaveAs( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryPartsSetActiveDrawingRevision") ) {
               String Id    = Commands_INV.postInventoryPartsSetActiveDrawingRevision( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryPartsSetActiveRevision") ) {
               String Id    = Commands_INV.postInventoryPartsSetActiveRevision( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryPartsSetActiveSupplierPartLink") ) {
               String Id    = Commands_INV.postInventoryPartsSetActiveSupplierPartLink( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryPartsSetProperties") ) {
               String Id    = Commands_INV.postInventoryPartsSetProperties( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryPartsUnplannedArrivalStockMovement") ) {
               String Id    = Commands_INV.postInventoryPartsUnplannedArrivalStockMovement( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryPartsUnplannedWithdrawalStockMovement") ) {
               String Id    = Commands_INV.postInventoryPartsUnplannedWithdrawalStockMovement( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryPartsUpdateCustomerPartLink") ) {
               String Id    = Commands_INV.postInventoryPartsUpdateCustomerPartLink( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryPartsUpdateDescription") ) {
               String Id    = Commands_INV.postInventoryPartsUpdateDescription( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryPartsUpdateDrawing") ) {
               String Id    = Commands_INV.postInventoryPartsUpdateDrawing( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryPartsUpdateDrawingRevision") ) {
               String Id    = Commands_INV.postInventoryPartsUpdateDrawingRevision( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryPartsUpdateHyperLink") ) {
               String Id    = Commands_INV.postInventoryPartsUpdateHyperLink( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryPartsUpdateLocation") ) {
               String Id    = Commands_INV.postInventoryPartsUpdateLocation( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryPartsUpdatePartBlockedStatus") ) {
               String Id    = Commands_INV.postInventoryPartsUpdatePartBlockedStatus( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryPartsUpdatePartPlanningInformation") ) {
               String Id    = Commands_INV.postInventoryPartsUpdatePartPlanningInformation( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryPartsUpdatePartPurchaseExpenseValues") ) {
               String Id    = Commands_INV.postInventoryPartsUpdatePartPurchaseExpenseValues( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryPartsUpdatePartUnitUsage") ) {
               String Id    = Commands_INV.postInventoryPartsUpdatePartUnitUsage( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryPartsUpdateRevision") ) {
               String Id    = Commands_INV.postInventoryPartsUpdateRevision( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryPartsUpdateStaggeredSupplierPartLinkPrice") ) {
               String Id    = Commands_INV.postInventoryPartsUpdateStaggeredSupplierPartLinkPrice( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryPartsUpdateSupplierPartLink") ) {
               String Id    = Commands_INV.postInventoryPartsUpdateSupplierPartLink( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryProductRecordsChangeOwner") ) {
               String Id    = Commands_INV.postInventoryProductRecordsChangeOwner( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryProductRecordsCreate") ) {
               String Id    = Commands_INV.postInventoryProductRecordsCreate( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryProductRecordsGetPartLocations") ) {
               String Id    = Commands_INV.postInventoryProductRecordsGetPartLocations( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryProductRecordsGetStructure") ) {
               String Id    = Commands_INV.postInventoryProductRecordsGetStructure( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryProductRecordsRename") ) {
               String Id    = Commands_INV.postInventoryProductRecordsRename( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryProductRecordsReportReading") ) {
               String Id    = Commands_INV.postInventoryProductRecordsReportReading( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryProductRecordsSetLifeCycle") ) {
               String Id    = Commands_INV.postInventoryProductRecordsSetLifeCycle( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryProductRecordsSetManufacturingOrder") ) {
               String Id    = Commands_INV.postInventoryProductRecordsSetManufacturingOrder( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryProductRecordsSetProperties") ) {
               String Id    = Commands_INV.postInventoryProductRecordsSetProperties( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryProductRecordsUpdateDeliveryAddress") ) {
               String Id    = Commands_INV.postInventoryProductRecordsUpdateDeliveryAddress( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryCommandsSetCaseEntryManufacturingOrder") ) {
               String Id    = Commands_INV.postInventoryCommandsSetCaseEntryManufacturingOrder( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryCommandsSetCaseEntryPart") ) {
               String Id    = Commands_INV.postInventoryCommandsSetCaseEntryPart( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryCommandsSetCaseEntryProductRecord") ) {
               String Id    = Commands_INV.postInventoryCommandsSetCaseEntryProductRecord( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryCaseEntryAdditionalCostCreateCaseEntryAdditionalCost") ) {
               String Id    = Commands_INV.postInventoryCaseEntryAdditionalCostCreateCaseEntryAdditionalCost( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryCaseEntryAdditionalCostUpdateCaseEntryAdditionalCost") ) {
               String Id    = Commands_INV.postInventoryCaseEntryAdditionalCostUpdateCaseEntryAdditionalCost( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryCaseEntryAddCommunicationAddress") ) {
               String Id    = Commands_INV.postInventoryCaseEntryAddCommunicationAddress( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryCaseEntryChangeNumber") ) {
               String Id    = Commands_INV.postInventoryCaseEntryChangeNumber( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryCaseEntryCreate") ) {
               String Id    = Commands_INV.postInventoryCaseEntryCreate( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryCaseEntryCreateFormReport") ) {
               String Id    = Commands_INV.postInventoryCaseEntryCreateFormReport( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryCaseEntryRemove") ) {
               String Id    = Commands_INV.postInventoryCaseEntryRemove( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryCaseEntrySetProperties") ) {
               String Id    = Commands_INV.postInventoryCaseEntrySetProperties( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryCaseEntriesCreateActivity") ) {
               String Id    = Commands_INV.postInventoryCaseEntriesCreateActivity( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryCaseEntriesCreatePhase") ) {
               String Id    = Commands_INV.postInventoryCaseEntriesCreatePhase( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryCaseEntriesRemoveActivity") ) {
               String Id    = Commands_INV.postInventoryCaseEntriesRemoveActivity( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryCaseEntriesRemovePhase") ) {
               String Id    = Commands_INV.postInventoryCaseEntriesRemovePhase( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryCaseEntriesSetReplacementDelivery") ) {
               String Id    = Commands_INV.postInventoryCaseEntriesSetReplacementDelivery( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryCaseEntriesUpdateActivity") ) {
               String Id    = Commands_INV.postInventoryCaseEntriesUpdateActivity( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventoryCaseEntriesUpdatePhase") ) {
               String Id    = Commands_INV.postInventoryCaseEntriesUpdatePhase( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventorySalesForecastsAddRow") ) {
               String Id    = Commands_INV.postInventorySalesForecastsAddRow( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventorySalesForecastsCreate") ) {
               String Id    = Commands_INV.postInventorySalesForecastsCreate( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventorySalesForecastsRemove") ) {
               String Id    = Commands_INV.postInventorySalesForecastsRemove( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventorySalesForecastsRemoveRow") ) {
               String Id    = Commands_INV.postInventorySalesForecastsRemoveRow( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventorySalesForecastsSetProperties") ) {
               String Id    = Commands_INV.postInventorySalesForecastsSetProperties( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postInventorySalesForecastsUpdateRow") ) {
               String Id    = Commands_INV.postInventorySalesForecastsUpdateRow( conf   ) ;  // , rest , con , sessionId
            }






            if ( queryName.equals("postAccountingAccountsPayablesAddDeliveryRows") ) {
               String Id    = Commands_ACC.postAccountingAccountsPayablesAddDeliveryRows( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postAccountingAccountsPayablesCancelAccountsPayable") ) {
               String Id    = Commands_ACC.postAccountingAccountsPayablesCancelAccountsPayable( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postAccountingAccountsPayablesChangeInvoiceType") ) {
               String Id    = Commands_ACC.postAccountingAccountsPayablesChangeInvoiceType( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postAccountingAccountsPayablesChangeSupplier") ) {
               String Id    = Commands_ACC.postAccountingAccountsPayablesChangeSupplier( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postAccountingAccountsPayablesCreate") ) {
               String Id    = Commands_ACC.postAccountingAccountsPayablesCreate( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postAccountingAccountsPayablesFinalBook") ) {
               String Id    = Commands_ACC.postAccountingAccountsPayablesFinalBook( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postAccountingAccountsPayablesSetCurrency") ) {
               String Id    = Commands_ACC.postAccountingAccountsPayablesSetCurrency( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postAccountingAccountsPayablesSetDeliveryRowCoding") ) {
               String Id    = Commands_ACC.postAccountingAccountsPayablesSetDeliveryRowCoding( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postAccountingAccountsPayablesSetDueDate") ) {
               String Id    = Commands_ACC.postAccountingAccountsPayablesSetDueDate( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postAccountingAccountsPayablesSetExchangeRate") ) {
               String Id    = Commands_ACC.postAccountingAccountsPayablesSetExchangeRate( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postAccountingAccountsPayablesSetInvoiceAmount") ) {
               String Id    = Commands_ACC.postAccountingAccountsPayablesSetInvoiceAmount( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postAccountingAccountsPayablesSetInvoiceDate") ) {
               String Id    = Commands_ACC.postAccountingAccountsPayablesSetInvoiceDate( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postAccountingAccountsPayablesSetOCRNumber") ) {
               String Id    = Commands_ACC.postAccountingAccountsPayablesSetOCRNumber( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postAccountingAccountsPayablesSetPaymentTerm") ) {
               String Id    = Commands_ACC.postAccountingAccountsPayablesSetPaymentTerm( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postAccountingAccountsPayablesSetPaymentTerm") ) {
               String Id    = Commands_ACC.postAccountingAccountsPayablesSetPaymentTerm( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postAccountingAccountsPayablesSetVatGroup") ) {
               String Id    = Commands_ACC.postAccountingAccountsPayablesSetVatGroup( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postAccountingAccountsPayablesSetVoucherDate") ) {
               String Id    = Commands_ACC.postAccountingAccountsPayablesSetVoucherDate( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postAccountingAccountsPayablesUpdateDeliveryRow") ) {
               String Id    = Commands_ACC.postAccountingAccountsPayablesUpdateDeliveryRow( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postAccountingAccountsPayablesUpdateFinalBookingRows") ) {
               String Id    = Commands_ACC.postAccountingAccountsPayablesUpdateFinalBookingRows( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postAccountingAccountsPayablesUpdateVatAmount") ) {
               String Id    = Commands_ACC.postAccountingAccountsPayablesUpdateVatAmount( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postAccountingAccountsReceivablesSetProperties") ) {
               String Id    = Commands_ACC.postAccountingAccountsReceivablesSetProperties( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postAccountingAccrualAccountingsCreate") ) {
               String Id    = Commands_ACC.postAccountingAccrualAccountingsCreate( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postAccountingVouchersCreate") ) {
               String Id    = Commands_ACC.postAccountingVouchersCreate( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postAccountingVouchersSetProperties") ) {
               String Id    = Commands_ACC.postAccountingVouchersSetProperties( conf   ) ;  // , rest , con , sessionId
            }

            if ( queryName.equals("postCommonApplicationUsersAddPermissionGroup") ) {
               String Id    = Commands_COM.postCommonApplicationUsersAddPermissionGroup( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonApplicationUsersCreate") ) {
               String Id    = Commands_COM.postCommonApplicationUsersCreate( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonApplicationUsersRemove") ) {
               String Id    = Commands_COM.postCommonApplicationUsersRemove( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonApplicationUsersRemovePermissionGroup") ) {
               String Id    = Commands_COM.postCommonApplicationUsersRemovePermissionGroup( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonApplicationUsersSetEmailProperties") ) {
               String Id    = Commands_COM.postCommonApplicationUsersSetEmailProperties( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonApplicationUsersSetLicense") ) {
               String Id    = Commands_COM.postCommonApplicationUsersSetLicense( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonApplicationUsersSetProperties") ) {
               String Id    = Commands_COM.postCommonApplicationUsersSetProperties( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonCommandsAddFileToComment") ) {
               String Id    = Commands_COM.postCommonCommandsAddFileToComment( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonCommandsAddWorkdaysToDate") ) {
               String Id    = Commands_COM.postCommonCommandsAddWorkdaysToDate ( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonCommandsCreateBusinessContactNoteHistory") ) {
               String Id    = Commands_COM.postCommonCommandsCreateBusinessContactNoteHistory( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonCommandsCreateComment") ) {
               String Id    = Commands_COM.postCommonCommandsCreateComment( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonCommandsExecuteAutoCompleteSearch") ) {
               String Id    = Commands_COM.postCommonCommandsExecuteAutoCompleteSearch( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonCommandsGetAvailableLicenses") ) {
               String Id    = Commands_COM.postCommonCommandsGetAvailableLicenses( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonCommandsGetCategoryComponentValues") ) {
               String Id    = Commands_COM.postCommonCommandsGetCategoryComponentValues( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonCommandsGetCustomReport") ) {
               String Id    = Commands_COM.postCommonCommandsGetCustomReport( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonCommandsGetCustomReportByDisplayId") ) {
               String Id    = Commands_COM.postCommonCommandsGetCustomReportByDisplayId( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonCommandsGetEntity") ) {
               String Id    = Commands_COM.postCommonCommandsGetEntity( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonCommandsGetEntityModificationInformation") ) {
               String Id    = Commands_COM.postCommonCommandsGetEntityModificationInformation( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonCommandsGetMonitorConfiguration") ) {
               String Id    = Commands_COM.postCommonCommandsGetMonitorConfiguration( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonCommandsGetSystemId") ) {
               String Id    = Commands_COM.postCommonCommandsGetSystemId( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonCommandsGetSystemParameters") ) {
               String Id    = Commands_COM.postCommonCommandsGetSystemParameters( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonCommandsPrintCustomReportByDisplayId") ) {
               String Id    = Commands_COM.postCommonCommandsPrintCustomReportByDisplayId( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonCommandsSendSystemEmail") ) {
               String Id    = Commands_COM.postCommonCommandsSendSystemEmail( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonCommandsSendUserEmail") ) {
               String Id    = Commands_COM.postCommonCommandsSendUserEmail( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonCommandsSetExtraFieldValues") ) {
               String Id    = Commands_COM.postCommonCommandsSetExtraFieldValues( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonCommandsUpdateAddress") ) {
               String Id    = Commands_COM.postCommonCommandsUpdateAddress( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonCommandsUpdateBusinessContactNoteHistory") ) {
               String Id    = Commands_COM.postCommonCommandsUpdateBusinessContactNoteHistory( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonCommandsUpdateComment") ) {
               String Id    = Commands_COM.postCommonCommandsUpdateComment( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonCommandsUpdateDeliveryAddress") ) {
               String Id    = Commands_COM.postCommonCommandsUpdateDeliveryAddress( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonCommandsUpdateDeliveryAddressWarehouseInformation") ) {
               String Id    = Commands_COM.postCommonCommandsUpdateDeliveryAddressWarehouseInformation( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonFileLinksRemove") ) {
               String Id    = Commands_COM.postCommonFileLinksRemove( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonFileLinksUpdate") ) {
               String Id    = Commands_COM.postCommonFileLinksUpdate( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonFileLinksUpdateData") ) {
               String Id    = Commands_COM.postCommonFileLinksUpdateData( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonFilePathsUploadFile") ) {
               String Id    = Commands_COM.postCommonFilePathsUploadFile( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonPartConfigurationsCreateAndAddFreeSelectionRow") ) {
               String Id    = Commands_COM.postCommonPartConfigurationsCreateAndAddFreeSelectionRow( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonPartConfigurationsDestroy") ) {
               String Id    = Commands_COM.postCommonPartConfigurationsDestroy( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonPartConfigurationsExists") ) {
               String Id    = Commands_COM.postCommonPartConfigurationsExists( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonPartConfigurationsGet") ) {
               String Id    = Commands_COM.postCommonPartConfigurationsGet( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonPartConfigurationsPoke") ) {
               String Id    = Commands_COM.postCommonPartConfigurationsPoke ( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonPartConfigurationsUpdate") ) {
               String Id    = Commands_COM.postCommonPartConfigurationsUpdate( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonPaymentPlanTemplatesCreate") ) {
               String Id    = Commands_COM.postCommonPaymentPlanTemplatesCreate( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonPersonsAddEmploymentPeriod") ) {
               String Id    = Commands_COM.postCommonPersonsAddEmploymentPeriod( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonPersonsAddRelative") ) {
               String Id    = Commands_COM.postCommonPersonsAddRelative( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonPersonsBlock") ) {
               String Id    = Commands_COM.postCommonPersonsBlock( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonPersonsCreate") ) {
               String Id    = Commands_COM.postCommonPersonsCreate( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonPersonsGetIdByPersonalCardNumber") ) {
               String Id    = Commands_COM.postCommonPersonsGetIdByPersonalCardNumber( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonPersonsRemove") ) {
               String Id    = Commands_COM.postCommonPersonsRemove( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonPersonsRemoveEmploymentPeriod") ) {
               String Id    = Commands_COM.postCommonPersonsRemoveEmploymentPeriod( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonPersonsRemoveRelative") ) {
               String Id    = Commands_COM.postCommonPersonsRemoveRelative( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonPersonsSetAvailableAsProperties") ) {
               String Id    = Commands_COM.postCommonPersonsSetAvailableAsProperties( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonPersonsSetContactInformationProperties") ) {
               String Id    = Commands_COM.postCommonPersonsSetContactInformationProperties( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonPersonsSetProperties") ) {
               String Id    = Commands_COM.postCommonPersonsSetProperties( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonPersonsUpdateEmploymentPeriod") ) {
               String Id    = Commands_COM.postCommonPersonsUpdateEmploymentPeriod( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonPersonsUpdateRelative") ) {
               String Id    = Commands_COM.postCommonPersonsUpdateRelative( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonProjectsChangeActivityCostReportingEntry") ) {
               String Id    = Commands_COM.postCommonProjectsChangeActivityCostReportingEntry( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonProjectsCreate") ) {
               String Id    = Commands_COM.postCommonProjectsCreate( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonProjectsCreateActivity") ) {
               String Id    = Commands_COM.postCommonProjectsCreateActivity( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonProjectsCreateActivityDelegatedWork") ) {
               String Id    = Commands_COM.postCommonProjectsCreateActivityDelegatedWork( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonProjectsCreateCostReportingEntry") ) {
               String Id    = Commands_COM.postCommonProjectsCreateCostReportingEntry( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonProjectsCreatePhase") ) {
               String Id    = Commands_COM.postCommonProjectsCreatePhase( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonProjectsCreateRootActivity") ) {
               String Id    = Commands_COM.postCommonProjectsCreateRootActivity( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonProjectsRemove") ) {
               String Id    = Commands_COM.postCommonProjectsRemove( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonProjectsRemoveActivity") ) {
               String Id    = Commands_COM.postCommonProjectsRemoveActivity( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonProjectsRemoveActivityDelegatedWork") ) {
               String Id    = Commands_COM.postCommonProjectsRemoveActivityDelegatedWork( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonProjectsRemovePhase") ) {
               String Id    = Commands_COM.postCommonProjectsRemovePhase( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonProjectsReplan") ) {
               String Id    = Commands_COM.postCommonProjectsReplan( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonProjectsSetPreviousActivities") ) {
               String Id    = Commands_COM.postCommonProjectsSetPreviousActivities( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonProjectsSetPreviousPhases") ) {
               String Id    = Commands_COM.postCommonProjectsSetPreviousPhases( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonProjectsSetProperties") ) {
               String Id    = Commands_COM.postCommonProjectsSetProperties( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonProjectsSetType") ) {
               String Id    = Commands_COM.postCommonProjectsSetType( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonProjectsUpdateActivity") ) {
               String Id    = Commands_COM.postCommonProjectsUpdateActivity( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonProjectsUpdateCostBudget") ) {
               String Id    = Commands_COM.postCommonProjectsUpdateCostBudget( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonProjectsUpdateCostForecast") ) {
               String Id    = Commands_COM.postCommonProjectsUpdateCostForecast( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonProjectsUpdateCostReportingEntry") ) {
               String Id    = Commands_COM.postCommonProjectsUpdateCostReportingEntry( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postCommonProjectsUpdatePhase") ) {
               String Id    = Commands_COM.postCommonProjectsUpdatePhase( conf   ) ;  // , rest , con , sessionId
            }





            if ( queryName.equals("postManufacturingManufacturingOrderMaterialsUpdate") ) {
               String Id    = Commands_MAN.postManufacturingManufacturingOrderMaterialsUpdate( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postManufacturingManufacturingOrderMaterialsUpdateMaterialQuantity") ) {
               String Id    = Commands_MAN.postManufacturingManufacturingOrderMaterialsUpdateMaterialQuantity( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postManufacturingManufacturingOrderNodesStepToStatus") ) {
               String Id    = Commands_MAN.postManufacturingManufacturingOrderNodesStepToStatus( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postManufacturingManufacturingOrderOperationsAddMaterial") ) {
               String Id    = Commands_MAN.postManufacturingManufacturingOrderOperationsAddMaterial( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postManufacturingManufacturingOrderOperationsAddOperation") ) {
               String Id    = Commands_MAN.postManufacturingManufacturingOrderOperationsAddOperation( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postManufacturingManufacturingOrderOperationsBundle") ) {
               String Id    = Commands_MAN.postManufacturingManufacturingOrderOperationsBundle( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postManufacturingManufacturingOrderOperationsPrintDefaultShopPacket") ) {
               String Id    = Commands_MAN.postManufacturingManufacturingOrderOperationsPrintDefaultShopPacket( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postManufacturingManufacturingOrderOperationsPrintShopPacket") ) {
               String Id    = Commands_MAN.postManufacturingManufacturingOrderOperationsPrintShopPacket( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postManufacturingManufacturingOrderOperationsRemove") ) {
               String Id    = Commands_MAN.postManufacturingManufacturingOrderOperationsRemove( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postManufacturingManufacturingOrderOperationsRemoveBundle") ) {
               String Id    = Commands_MAN.postManufacturingManufacturingOrderOperationsRemoveBundle( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postManufacturingManufacturingOrderOperationsSetSupplier") ) {
               String Id    = Commands_MAN.postManufacturingManufacturingOrderOperationsSetSupplier( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postManufacturingManufacturingOrderOperationsSetWorkCenter") ) {
               String Id    = Commands_MAN.postManufacturingManufacturingOrderOperationsSetWorkCenter( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postManufacturingManufacturingOrderOperationsUpdate") ) {
               String Id    = Commands_MAN.postManufacturingManufacturingOrderOperationsUpdate( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postManufacturingManufacturingOrdersCreate") ) {
               String Id    = Commands_MAN.postManufacturingManufacturingOrdersCreate( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postManufacturingManufacturingOrdersCreateFromCustomerOrderRow") ) {
               String Id    = Commands_MAN.postManufacturingManufacturingOrdersCreateFromCustomerOrderRow( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postManufacturingManufacturingOrdersRemove") ) {
               String Id    = Commands_MAN.postManufacturingManufacturingOrdersRemove( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postManufacturingManufacturingOrdersRemoveMaterial") ) {
               String Id    = Commands_MAN.postManufacturingManufacturingOrdersRemoveMaterial( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postManufacturingManufacturingOrdersReplan") ) {
               String Id    = Commands_MAN.postManufacturingManufacturingOrdersReplan( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postManufacturingManufacturingOrdersReplanOperation") ) {
               String Id    = Commands_MAN.postManufacturingManufacturingOrdersReplanOperation( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postManufacturingManufacturingOrdersReplanPinnedOperation") ) {
               String Id    = Commands_MAN.postManufacturingManufacturingOrdersReplanPinnedOperation( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postManufacturingManufacturingOrdersReplanQuantity") ) {
               String Id    = Commands_MAN.postManufacturingManufacturingOrdersReplanQuantity( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postManufacturingManufacturingOrdersSetProperties") ) {
               String Id    = Commands_MAN.postManufacturingManufacturingOrdersSetProperties( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postManufacturingManufacturingPickingListsCreate") ) {
               String Id    = Commands_MAN.postManufacturingManufacturingPickingListsCreate( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postManufacturingManufacturingPickingListsDelete") ) {
               String Id    = Commands_MAN.postManufacturingManufacturingPickingListsDelete( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postManufacturingManufacturingPickingListsReport") ) {
               String Id    = Commands_MAN.postManufacturingManufacturingPickingListsReport( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postManufacturingMaterialRowsRemove") ) {
               String Id    = Commands_MAN.postManufacturingMaterialRowsRemove( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postManufacturingMaterialRowsSetPart") ) {
               String Id    = Commands_MAN.postManufacturingMaterialRowsSetPart( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postManufacturingMaterialRowsUpdate") ) {
               String Id    = Commands_MAN.postManufacturingMaterialRowsUpdate( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postManufacturingMaterialRowsUpdatePreparationTerm") ) {
               String Id    = Commands_MAN.postManufacturingMaterialRowsUpdatePreparationTerm( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postManufacturingOperationRowsRemove") ) {
               String Id    = Commands_MAN.postManufacturingOperationRowsRemove( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postManufacturingOperationRowsSetSupplier") ) {
               String Id    = Commands_MAN.postManufacturingOperationRowsSetSupplier( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postManufacturingOperationRowsSetWorkCenter") ) {
               String Id    = Commands_MAN.postManufacturingOperationRowsSetWorkCenter( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postManufacturingOperationRowsUpdate") ) {
               String Id    = Commands_MAN.postManufacturingOperationRowsUpdate( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postManufacturingOperationRowsUpdatePreparationTerm") ) {
               String Id    = Commands_MAN.postManufacturingOperationRowsUpdatePreparationTerm( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postManufacturingPreparationsAddMaterialRow") ) {
               String Id    = Commands_MAN.postManufacturingPreparationsAddMaterialRow( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postManufacturingPreparationsAddOperationRow") ) {
               String Id    = Commands_MAN.postManufacturingPreparationsAddOperationRow( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postManufacturingPreparationsCreate") ) {
               String Id    = Commands_MAN.postManufacturingPreparationsCreate( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postManufacturingReportingCreateManufacturingTransportLabel") ) {
               String Id    = Commands_MAN.postManufacturingReportingCreateManufacturingTransportLabel( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postManufacturingReportingGetTraceabilityDataForReportManufacturingOrderOperation") ) {
               String Id    = Commands_MAN.postManufacturingReportingGetTraceabilityDataForReportManufacturingOrderOperation( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postManufacturingReportingReportManufacturingOrderMaterial") ) {
               String Id    = Commands_MAN.postManufacturingReportingReportManufacturingOrderMaterial( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postManufacturingReportingReportManufacturingOrderOperation") ) {
               String Id    = Commands_MAN.postManufacturingReportingReportManufacturingOrderOperation( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postManufacturingReportingReportTraceableManufacturingOrderMaterial") ) {
               String Id    = Commands_MAN.postManufacturingReportingReportTraceableManufacturingOrderMaterial( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postManufacturingScheduleCyclesIsWithin") ) {
               String Id    = Commands_MAN.postManufacturingScheduleCyclesIsWithin( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postManufacturingWorkCentersCreateCostFactorGroup") ) {
               String Id    = Commands_MAN.postManufacturingWorkCentersCreateCostFactorGroup( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postManufacturingWorkCentersGetCapacityAndLoading") ) {
               String Id    = Commands_MAN.postManufacturingWorkCentersGetCapacityAndLoading( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postManufacturingWorkCentersSetCostFactorGroupTypes") ) {
               String Id    = Commands_MAN.postManufacturingWorkCentersSetCostFactorGroupTypes( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postManufacturingWorkCentersUpdateCostFactorGroup") ) {
               String Id    = Commands_MAN.postManufacturingWorkCentersUpdateCostFactorGroup( conf   ) ;  // , rest , con , sessionId
            }




            if ( queryName.equals("postMQUsersCreate") ) {
               String Id    = Commands_MQ.postMQUsersCreate( conf   ) ;  // , rest , con , sessionId
            }



            if ( queryName.equals("postPurchaseInquiriesAddCommunicationAddress") ) {
               String Id    = Commands_PUR.postPurchaseInquiriesAddCommunicationAddress( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postPurchaseInquiriesCreate") ) {
               String Id    = Commands_PUR.postPurchaseInquiriesCreate( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postPurchaseInquiriesAddRow") ) {
               String Id    = Commands_PUR.postPurchaseInquiriesAddRow( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postPurchaseInquiriesChangeCurrency") ) {
               String Id    = Commands_PUR.postPurchaseInquiriesChangeCurrency( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postPurchaseInquiriesChangeInquiryType") ) {
               String Id    = Commands_PUR.postPurchaseInquiriesChangeInquiryType( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postPurchaseInquiriesChangeSupplier") ) {
               String Id    = Commands_PUR.postPurchaseInquiriesChangeSupplier( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postPurchaseInquiriesGetRecipientOfType") ) {
               String Id    = Commands_PUR.postPurchaseInquiriesGetRecipientOfType( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postPurchaseInquiriesRemoveCommunicationAddress") ) {
               String Id    = Commands_PUR.postPurchaseInquiriesRemoveCommunicationAddress( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postPurchaseInquiriesSetProperties") ) {
               String Id    = Commands_PUR.postPurchaseInquiriesSetProperties( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postPurchaseInquiriesSetRowCoding") ) {
               String Id    = Commands_PUR.postPurchaseInquiriesSetRowCoding( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postPurchaseInquiriesUpdateCommunicationAddress") ) {
               String Id    = Commands_PUR.postPurchaseInquiriesUpdateCommunicationAddress( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postPurchaseInquiriesUpdateDeliveryAddress") ) {
               String Id    = Commands_PUR.postPurchaseInquiriesUpdateDeliveryAddress( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postPurchaseInquiriesUpdateMailingAddress") ) {
               String Id    = Commands_PUR.postPurchaseInquiriesUpdateMailingAddress( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postPurchaseInquiriesUpdateRow") ) {
               String Id    = Commands_PUR.postPurchaseInquiriesUpdateRow( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postPurchasePurchaseOrderAdvicesCreate") ) {
               String Id    = Commands_PUR.postPurchasePurchaseOrderAdvicesCreate( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postPurchasePurchaseOrderAdvicesAddRow") ) {
               String Id    = Commands_PUR.postPurchasePurchaseOrderAdvicesAddRow( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postPurchasePurchaseOrderAdvicesRemove") ) {
               String Id    = Commands_PUR.postPurchasePurchaseOrderAdvicesRemove( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postPurchasePurchaseOrderAdvicesRemoveRow") ) {
               String Id    = Commands_PUR.postPurchasePurchaseOrderAdvicesRemoveRow( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postPurchasePurchaseOrderAdvicesSetProperties") ) {
               String Id    = Commands_PUR.postPurchasePurchaseOrderAdvicesSetProperties( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postPurchasePurchaseOrderAdvicesUpdateRow") ) {
               String Id    = Commands_PUR.postPurchasePurchaseOrderAdvicesUpdateRow( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postPurchasePurchaseOrdersCreate") ) {
               String Id    = Commands_PUR.postPurchasePurchaseOrdersCreate( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postPurchasePurchaseOrdersAddCommunicationAddress") ) {
               String Id    = Commands_PUR.postPurchasePurchaseOrdersAddCommunicationAddress( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postPurchasePurchaseOrdersAddRow") ) {
               String Id    = Commands_PUR.postPurchasePurchaseOrdersAddRow( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postPurchasePurchaseOrdersChangeCurrency") ) {
               String Id    = Commands_PUR.postPurchasePurchaseOrdersChangeCurrency( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postPurchasePurchaseOrdersChangeOrderType") ) {
               String Id    = Commands_PUR.postPurchasePurchaseOrdersChangeOrderType( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postPurchasePurchaseOrdersChangeSupplier") ) {
               String Id    = Commands_PUR.postPurchasePurchaseOrdersChangeSupplier( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postPurchasePurchaseOrdersGetRecipientOfType") ) {
               String Id    = Commands_PUR.postPurchasePurchaseOrdersGetRecipientOfType( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postPurchasePurchaseOrdersRemoveCommunicationAddress") ) {
               String Id    = Commands_PUR.postPurchasePurchaseOrdersRemoveCommunicationAddress( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postPurchasePurchaseOrdersReportArrivals") ) {
               String Id    = Commands_PUR.postPurchasePurchaseOrdersReportArrivals( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postPurchasePurchaseOrdersSetIsConfirmed") ) {
               String Id    = Commands_PUR.postPurchasePurchaseOrdersSetIsConfirmed( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postPurchasePurchaseOrdersSetProperties") ) {
               String Id    = Commands_PUR.postPurchasePurchaseOrdersSetProperties( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postPurchasePurchaseOrdersSetRowCoding") ) {
               String Id    = Commands_PUR.postPurchasePurchaseOrdersSetRowCoding( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postPurchasePurchaseOrdersSetRowIsConfirmed") ) {
               String Id    = Commands_PUR.postPurchasePurchaseOrdersSetRowIsConfirmed( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postPurchasePurchaseOrdersUpdateCommunicationAddress") ) {
               String Id    = Commands_PUR.postPurchasePurchaseOrdersUpdateCommunicationAddress( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postPurchasePurchaseOrdersUpdateDeliveryAddress") ) {
               String Id    = Commands_PUR.postPurchasePurchaseOrdersUpdateDeliveryAddress( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postPurchasePurchaseOrdersUpdateMailingAddress") ) {
               String Id    = Commands_PUR.postPurchasePurchaseOrdersUpdateMailingAddress( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postPurchasePurchaseOrdersUpdateRow") ) {
               String Id    = Commands_PUR.postPurchasePurchaseOrdersUpdateRow( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postPurchaseSuppliersCreate") ) {
               String Id    = Commands_PUR.postPurchaseSuppliersCreate( conf   ) ;  // , rest , con , sessionId
            }




            if ( queryName.equals("postSalesCustomerOrderInvoicesCreate") ) {
               String Id    = Commands_SAL.postSalesCustomerOrderInvoicesCreate( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postSalesCustomerOrderInvoicesAddRow") ) {
               String Id    = Commands_SAL.postSalesCustomerOrderInvoicesAddRow( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postSalesCustomerOrderInvoicesSetProperties") ) {
               String Id    = Commands_SAL.postSalesCustomerOrderInvoicesSetProperties( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postSalesCustomerOrderInvoicesSetRowCoding") ) {
               String Id    = Commands_SAL.postSalesCustomerOrderInvoicesSetRowCoding( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postSalesCustomerOrderInvoicesUpdateRow") ) {
               String Id    = Commands_SAL.postSalesCustomerOrderInvoicesUpdateRow( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postSalesCustomerOrdersCreate") ) {
               String Id    = Commands_SAL.postSalesCustomerOrdersCreate( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postSalesCustomerOrdersAddCommunicationAddress") ) {
               String Id    = Commands_SAL.postSalesCustomerOrdersAddCommunicationAddress( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postSalesCustomerOrdersAddRow") ) {
               String Id    = Commands_SAL.postSalesCustomerOrdersAddRow( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postSalesCustomerOrdersChangeAccountGroup") ) {
               String Id    = Commands_SAL.postSalesCustomerOrdersChangeAccountGroup( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postSalesCustomerOrdersChangeCurrency") ) {
               String Id    = Commands_SAL.postSalesCustomerOrdersChangeCurrency( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postSalesCustomerOrdersChangeCustomer") ) {
               String Id    = Commands_SAL.postSalesCustomerOrdersChangeCustomer( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postSalesCustomerOrdersChangeOrderType") ) {
               String Id    = Commands_SAL.postSalesCustomerOrdersChangeOrderType( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postSalesCustomerOrdersChangeVatGroup") ) {
               String Id    = Commands_SAL.postSalesCustomerOrdersChangeVatGroup( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postSalesCustomerOrdersConfigureRow") ) {
               String Id    = Commands_SAL.postSalesCustomerOrdersConfigureRow( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postSalesCustomerOrdersGetPriceInfo") ) {
               String Id    = Commands_SAL.postSalesCustomerOrdersGetPriceInfo( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postSalesCustomerOrdersGetQuantityChanges") ) {
               String Id    = Commands_SAL.postSalesCustomerOrdersGetQuantityChanges( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postSalesCustomerOrdersGetRecipientOfType") ) {
               String Id    = Commands_SAL.postSalesCustomerOrdersGetRecipientOfType( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postSalesCustomerOrdersRemoveCommunicationAddress") ) {
               String Id    = Commands_SAL.postSalesCustomerOrdersRemoveCommunicationAddress( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postSalesCustomerOrdersRemoveRow") ) {
               String Id    = Commands_SAL.postSalesCustomerOrdersRemoveRow( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postSalesCustomerOrdersReportDeliveries") ) {
               String Id    = Commands_SAL.postSalesCustomerOrdersReportDeliveries( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postSalesCustomerOrdersSetAftermarketProductRecord") ) {
               String Id    = Commands_SAL.postSalesCustomerOrdersSetAftermarketProductRecord( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postSalesCustomerOrdersSetProperties") ) {
               String Id    = Commands_SAL.postSalesCustomerOrdersSetProperties( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postSalesCustomerOrdersSetProperties") ) {
               String Id    = Commands_SAL.postSalesCustomerOrdersSetProperties( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postSalesCustomerOrdersSetRowCoding") ) {
               String Id    = Commands_SAL.postSalesCustomerOrdersSetRowCoding( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postSalesCustomerOrdersUpdateCommunicationAddress") ) {
               String Id    = Commands_SAL.postSalesCustomerOrdersUpdateCommunicationAddress( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postSalesCustomerOrdersUpdateInvoiceAddress") ) {
               String Id    = Commands_SAL.postSalesCustomerOrdersUpdateInvoiceAddress( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postSalesCustomerOrdersUpdateMailingAddress") ) {
               String Id    = Commands_SAL.postSalesCustomerOrdersUpdateMailingAddress( conf   ) ;  // , rest , con , sessionId
            }
            if ( queryName.equals("postSalesCustomerOrdersUpdateRow") ) {
               String Id    = Commands_SAL.postSalesCustomerOrdersUpdateRow( conf   ) ;  // , rest , con , sessionId
            }
































































        } catch (Exception e) {
            WriteLog.write(conf.getLogFile(), " ERROR ");
            WriteLog.write(conf.getLogFile(), e.toString(), false);
        }

    }  // main


}
