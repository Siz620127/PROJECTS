package sy_my ;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Scanner;
import org.json.simple.JSONObject;
import org.json.simple.JSONArray;
import org.json.simple.JSONValue;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

// -------

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import java.sql.* ;

// import java.sql.Connection;
// import java.sql.Date;
// import java.sql.DriverManager;
// import java.sql.PreparedStatement;
// import java.sql.SQLException;

import java.text.SimpleDateFormat;


public class Queries {



    // TEST START
    public static HttpURLConnection TestQuery(ReadConf conf) throws Exception {
        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals("185.158.177.241");

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end


             // URL url             = new URL( conf.getUrl_sy() );
             URL url                = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", "185.158.177.241"  );
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", "f1bc5219-b382-472e-adc9-ff0926ecbbb0" );



     	     String json = "{\n";
     		 json += "\"Username\": "     +  "\"ADMIN\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"\" "       + ",\n";
		     json += "\"ForceRelogin\": " +  true          + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( response );

   			     return con ;  // response


                 /*
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parse    = new JSONParser();
                 JSONObject data_obj = (JSONObject) parse.parse( json );  // inline
                 //Get the required object from the above created object
                 JSONObject obj = (JSONObject) data_obj.get("Globale");
                 //Get the required data using its key
                 System.out.println(obj.get("TotalRecovered"));
                 JSONArray arr = (JSONArray) data_obj.get("Countries");
                 for (int i = 0; i < arr.size(); i++) {
                      JSONObject new_obj = (JSONObject) arr.get(i);
                      if (new_obj.get("Slug").equals("albania")) {
                         System.out.println("Total Recovered: " + new_obj.get("TotalRecovered"));
                         break;
                      }
                 }
               */

                }


        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() );
        }
        // return con;
    }

    // TEST END





    public static String getPersons(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = "100"  ;
        String    Id           = ""  ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Persons"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  monitordb5.person where tenant_id = 100 " ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into monitordb5.person (tenant_id , id , " +
                          " MachineIntegrationType, " +
                          " MachineIntegrationLinkedToWorkCenterId, " +
                          " ManualWorkLinkedToWorkCenterId, " +
                          " ReportInterval, " +
                          " TimeIntervalForLoadingToOrder, " +
                          " ReportQtyWhenFullPalletIsManufactured, " +
                          " MachineUniqueTimeForShortStops, " +
                          " ReportPiecesAtEndSetup, " +
                          " SuggestRestAsRejects, " +
                          " LockPossibilityToManuallyChangeRejection, " +
                          " StartSetupTimeAutomaticallyWhenLoadingNewOrder, " +
                          " CheckSetupWhenLoadingNewOrder,  " +
                          " DefaultRejectionCodeId,  " +
                          " MachineUniqueIndirectWorkCodeIdForShortStops, " +
                          " MachineUniqueIndirectWorkCodeIdWhenRunningWithoutOrder, " +
                          " UnauthorizedPlannedAbsenceReminderId, " +
                          " EmployeeRecordingType, " +

                           " EmployeeNumber, " +
                           " IsReference,  " +
                           " IsPurchaseManager, " +

                           " IsProjectManager, " +

                           " IsPlanner, " +
                           " IsAccountManager, " +
                           " Contact, " +
                           " ContactPhoneNumber, " +
                           " ContactCellPhoneNumber, " +
                           " ContactEmailAddress, " +
                           " CommentId, " +
                           " IsPersonBlocked, " +
                           " PersonBlockedById, " +
                           " PersonBlockedDate, " +
                           " CanAuthorize, " +
                           " IsSeller, " +
                           " Initials, " +

                           " SignatureId, " +

                           " DepartmentId, " +
                           " DistrictId, " +
                           " LanguageId, " +
                           " WarehouseId, " +
                           " Category, " +
                           " IdentityNumber, " +
                           " GroupSettingsId, " +

                           " WorkMethod, " +
                           " AvailableWorkRecordingMethods, " +
                           " DefaultWorkRecordingMethod, " +
                           " LinkCodesToWorkCenter, " +
                           " LinkCodesToDepartment, " +

                           " UseWorkCenterManufacturingPrintSettings, " +

                           " PrintTransportLabel, " +
                           " AutoPrintShopPacket, " +
                           " SuggestRest, " +
                           " ShowMaterialsTab, " +
                           " ShowOperationsTab, " +
                           " ShowMessageTab, " +
                           " ShowOrderAdditionalTextTab, " +
                           " AllowManualMaterialReporting, " +
                           " AllowAddMaterial, " +
                           " ShowGoodsLocation, " +
                           " ShowPartLocation, " +
                           " ShowMultiplePartLocations, " +
                           " PartialReportingAtOut, " +
                           " ReportOfWhichSetupTime, " +
                           " ReportOfWhichTimeAgainstCode, " +
                           " DefaultFilterInPriorityPlan, " +
                           " LockFilterInPriorityPlan, " +
                           " PasswordType, " +
                           " Password, " +
                           " ScheduleManagementType, " +
                           " LastOperatorId, " +

                           " PhoneNumber, " +
                           " CellPhoneNumber, " +

                           " InternalPhoneNumber, " +
                           " PrivateCellPhoneNumber, " +
                           " PrivatePhoneNumber, " +

                           " EmailAddress, " +
                           " SkypeId, " +
                           " FaxNumber, " +
                           " Position, " +
                           " ApplicationUserId, " +

                           " PhotoId, " +

                           " FirstName, " +
                           " LastName, " +
                           " AddressId, " +
                           " BlockedContextType, " +
                           " BlockedFromDate, " +
                           " BlockedToDate, " +

                           " BlockedById, " +
                           " BlockedStatus, " +
                           " BlockMessageId, " +
                           " MandatoryToReportAllProducedParts " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +

                          1       + ", " +   /* MachineIntegrationType, */
                          null    + ", " +   /* MachineIntegrationLinkedToWorkCenterId, */
                          null    + ", " +   /* ManualWorkLinkedToWorkCenterId, */
                          1       + ", " +   /* ReportInterval, */
                          1       + ", " +   /* TimeIntervalForLoadingToOrder, */
                          1       + ", " +   /* ReportQtyWhenFullPalletIsManufactured, */
                          null    + ", " +   /* MachineUniqueTimeForShortStops, */
                          1       + ", " +   /* ReportPiecesAtEndSetup, */
                          1       + ", " +   /* SuggestRestAsRejects, */
                          1       + ", " +   /* LockPossibilityToManuallyChangeRejection, */
                          1       + ", " +   /* StartSetupTimeAutomaticallyWhenLoadingNewOrder, */
                          1       + ", " +   /* CheckSetupWhenLoadingNewOrder, */
                          null    + ", " +   /* DefaultRejectionCodeId, */
                          null    + ", " +   /* MachineUniqueIndirectWorkCodeIdForShortStops, */
                          null    + ", " +   /* MachineUniqueIndirectWorkCodeIdWhenRunningWithoutOrder, */
                          null    + ", " +   /* UnauthorizedPlannedAbsenceReminderId, */
                          1       + ", " +   /* EmployeeRecordingType, */

                          "\"" + rec_obj.get("EmployeeNumber")         + "\" " + ", " +
                          "\"" + ((rec_obj.get("IsReference")       == "false") ? 0 : 1  )  + "\" " + ", " +
                          "\"" + ((rec_obj.get("IsPurchaseManager") == "false") ? 0 : 1  )  + "\" " + ", " +

                          0    + ", " +   /* IsProjectManager, */

                          "\"" + ((rec_obj.get("IsPlanner")         == "false") ? 0 : 1  )  + "\" " + ", " +
                          "\"" + ((rec_obj.get("IsAccountManager")  == "false") ? 0 : 1  )  + "\" " + ", " +
                          "\"" + rec_obj.get("Contact")                + "\" " + ", " +
                          "\"" + rec_obj.get("ContactPhoneNumber")     + "\" " + ", " +
                          "\"" + rec_obj.get("ContactCellPhoneNumber") + "\" " + ", " +
                          "\"" + rec_obj.get("ContactEmailAddress")    + "\" " + ", " +
                          "\"" + ((rec_obj.get("CommentId") == null) ? 0 : rec_obj.get("CommentId") )  + "\" " + ", " +
                          "\"" + ((rec_obj.get("IsPersonBlocked")   == "false") ? 0 : 1  )             + "\" " + ", " +
                          "\"" + ((rec_obj.get("PersonBlockedById") == null )   ? 0 : 1  )             + "\" " + ", " +
                          "\"" + ((rec_obj.get("PersonBlockedDate") == null )   ? new Date(2021000000) : rec_obj.get("PersonBlockedDate")  )   + "\" " + ", " +
                          "\"" + ((rec_obj.get("CanAuthorize")      == "false") ? 0 : 1  )             + "\" " + ", " +
                          "\"" + ((rec_obj.get("IsSeller")          == "false") ? 0 : 1  )             + "\" " + ", " +
                          "\"" + rec_obj.get("Initials")               + "\" " + ", " +

                          null    + ", " +   /* SignatureId, */

                          "\"" + rec_obj.get("DepartmentId")           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DistrictId")        == null )  ? 0 : rec_obj.get("DistrictId")  )    + "\" "    + ", " +
                          "\"" + rec_obj.get("LanguageId")             + "\" "    + ", " +
                          "\"" + rec_obj.get("WarehouseId")            + "\" "    + ", " +
                          "\"" + rec_obj.get("Category")               + "\" "    + ", " +
                          "\"" + rec_obj.get("IdentityNumber")         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("GroupSettingsId") == null) ? 0 : rec_obj.get("GroupSettingsId")  )    + "\" "    + ", " +

                          1       + ", " +   /* WorkMethod, */
                          1       + ", " +   /* AvailableWorkRecordingMethods, */
                          1       + ", " +   /* DefaultWorkRecordingMethod, */
                          1       + ", " +   /* LinkCodesToWorkCenter, */
                          1       + ", " +   /* LinkCodesToDepartment, */

                          "\"" +  ((rec_obj.get("UseWorkCenterManufacturingPrintSettings") == "false") ? 0 : 1  )     + "\" "  + ", " +

                          1       + ", " +   /* PrintTransportLabel, */
                          1       + ", " +   /* AutoPrintShopPacket, */
                          1       + ", " +   /* SuggestRest, */
                          1       + ", " +   /* ShowMaterialsTab, */
                          1       + ", " +   /* ShowOperationsTab, */
                          1       + ", " +   /* ShowMessageTab, */
                          1       + ", " +   /* ShowOrderAdditionalTextTab, */
                          1       + ", " +   /* AllowManualMaterialReporting, */
                          1       + ", " +   /* AllowAddMaterial, */
                          1       + ", " +   /* ShowGoodsLocation, */
                          1       + ", " +   /* ShowPartLocation, */
                          1       + ", " +   /* ShowMultiplePartLocations, */
                          1       + ", " +   /* PartialReportingAtOut, */
                          1       + ", " +   /* ReportOfWhichSetupTime, */
                          1       + ", " +   /* ReportOfWhichTimeAgainstCode, */
                          1       + ", " +   /* DefaultFilterInPriorityPlan, */
                          1       + ", " +   /* LockFilterInPriorityPlan, */
                          1       + ", " +   /* PasswordType, */
                          null    + ", " +   /* Password,  */
                          1       + ", " +   /* ScheduleManagementType, */
                          null    + ", " +   /* LastOperatorId, */

                          "\"" + rec_obj.get("PhoneNumber")         + "\" "    + ", " +
                          "\"" + rec_obj.get("CellPhoneNumber")     + "\" "    + ", " +
                          "\"" + rec_obj.get("InternalPhoneNumber") + "\" "    + ", " +

                          null    + ", " +   /* PrivateCellPhoneNumber, */
                          null    + ", " +   /* PrivatePhoneNumber, */

                          "\"" + rec_obj.get("EmailAddress")       + "\" "    + ", " +
                          "\"" + rec_obj.get("SkypeId")            + "\" "    + ", " +
                          "\"" + rec_obj.get("FaxNumber")          + "\" "    + ", " +
                          "\"" + rec_obj.get("Position")           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ApplicationUserId")   == null )  ? 0 : rec_obj.get("ApplicationUserId")  )     + "\" "    + ", " +

                          null    + ", " +   /* PhotoId, */

                          "\"" + rec_obj.get("FirstName")          + "\" "    + ", " +
                          "\"" + rec_obj.get("LastName")           + "\" "    + ", " +
                          "\"" + rec_obj.get("AddressId")          + "\" "    + ", " +
                          "\"" + rec_obj.get("BlockedContextType") + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BlockedFromDate") == null )   ? new Date(2021000000) : rec_obj.get("BlockedFromDate")  )    + "\" "    + ", " +
                          "\"" + (( rec_obj.get("BlockedToDate")  == null )   ? new Date(2021000000) :  rec_obj.get("BlockedToDate")   )    + "\" "    + ", " +

                          null    + ", " +   /* BlockedById, */
                          0       + ", " +   /* BlockedStatus, */
                          null    + ", " +   /* BlockMessageId, */
                          0       + "  " +   /* MandatoryToReportAllProducedParts  */

                           /* rec_obj.get("IsRecordingEmployee")    + ", " +  */

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Person was imported from Monitor API to MySql", false);


                 /*
                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("SessionId");  // Language
                 //JSONValue  sesId = (JSONValue)  data_obj.get("SessionId") ;

                 String sesId = obj.toString() ;
                 //String sesId = data_obj.get("SessionId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );
                 // java.lang.String cannot be cast to org.json.simple.JSONValue

                 //Get the required data using its key
                 */

                 /*
                 System.out.println(obj.get("Code"));
                 JSONArray arr = (JSONArray) data_obj.get("ActiveSessions");
                 for (int i = 0; i < arr.size(); i++) {
                      JSONObject new_obj = (JSONObject) arr.get(i);
                      if (new_obj.get("Slug").equals("albania")) {
                         System.out.println("Total Recovered: " + new_obj.get("TotalRecovered"));
                         break;
                      }
                 }
                 */
   			     return Id   ;  // con   response


                 /*
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parse    = new JSONParser();
                 JSONObject data_obj = (JSONObject) parse.parse( json );  // inline
                 //Get the required object from the above created object
                 JSONObject obj = (JSONObject) data_obj.get("Globale");
                 //Get the required data using its key
                 System.out.println(obj.get("TotalRecovered"));
                 JSONArray arr = (JSONArray) data_obj.get("Countries");
                 for (int i = 0; i < arr.size(); i++) {
                      JSONObject new_obj = (JSONObject) arr.get(i);
                      if (new_obj.get("Slug").equals("albania")) {
                         System.out.println("Total Recovered: " + new_obj.get("TotalRecovered"));
                         break;
                      }
                 }
               */

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getPersons





    public static String getManufacturingOrders(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = "100"  ;
        String    Id           = ""  ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrders?$filter=isnotnull(StartDate)&$skip=10&$top=10&$orderby=Id&desc" );

             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/ManufacturingOrders?$filter=isnotnull(StartDate)&StartDate%20Gt%20'2021-10-10'$skip=0&$top=50000&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  monitordb5.manufacturingorder where tenant_id = 100 " ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into monitordb5.manufacturingorder (tenant_id , id , " +
                          " OrderNumber, " +
                          " CategoryString, " +
                          " RegisteredByUserId, " +
                          " FinishDate, " +
                          " StartDate, " +
                          " WarehouseId, " +
                          " AlternativePreparationCode, " +
                          " ActualHistoryDate, " +
                          " ProjectId, " +
                          " CustomerId, " +
                          " MultiNodeType, " +
                          " Status, " +
                          " HistoryDate, " +
                          " RegistrationDate, " +
                          " OriginalEndDate, " +
                          " ZipFactor, " +
                          " Priority, " +
                          " CommentId, " +
                          " IsInlcudedInMeanPriceCalculation , " +
                          " DelayedForSure , " +
                          " ReasonForDelayId , " +
                          " ReasonForDelayCommentId , " +
                          " IsLockedToBatch , " +
                          " MaxQuantity , " +
                          " ExplodeType , " +
                          " OrderTypeId , " +
                          " PartConfigurationId , " +
                          " CreatePurchaseOrder , " +
                          " IsExportedToManagementAccounting , " +
                          " CausingTransType , " +
                          " CausingOrderRowId , " +
                          " RequirementDate , " +
                          " RegistrationType , " +
                          " GoodsLabelSetFromCustomerOrderRow , " +
                          " RowsGoodsLabel  " +
                          " ) " +

                          "values ( " +
                          tenant_id                                             + ", " +
                          Id                                                    + ", " +
                           "\"" + rec_obj.get("OrderNumber")                                                                           + "\" " + ", " +
                           "\"" + rec_obj.get("CategoryString")                                                                        + "\" " + ", " +
                          "\"" + ((null == null)    ? 0 : 0 )                                                                          + "\" " + ", " +   /* rec_obj.get("RegisteredByUserId")  */  
                           "\"" + ((rec_obj.get("FinishDate") == null )           ? new Date(2021000000) : rec_obj.get("FinishDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " + 
                           "\"" + ((rec_obj.get("StartDate")  == null )           ? new Date(2021000000) : rec_obj.get("StartDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                           "\"" + ((rec_obj.get("WarehouseId") == null)           ? 0 : rec_obj.get("WarehouseId") )                   + "\" " + ", " +
                          "\"" + ""                                                                                                    + "\" " + ", " +   /* rec_obj.get("AlternativePreparationCode")  */
                          "\"" + (( null == null )                                ? new Date(2021000000) : new Date(2021000000)  )     + "\" " + ", " +   /* rec_obj.get("ActualHistoryDate") */ 
                           "\"" + ((rec_obj.get("ProjectId") == null)             ? 0 : rec_obj.get("ProjectId") )                     + "\" " + ", " +
                          "\"" + ((null == null)                                  ? 0 : 0  )                                           + "\" " + ", " +   /* rec_obj.get("CustomerId")  */ 
                          "\"" + ((null == null)                                  ? 0 : 0  )                                           + "\" " + ", " +   /* rec_obj.get("MultiNodeType")  */ 
                           "\"" + ((rec_obj.get("Status") == null)                ? 0 : rec_obj.get("Status") )                        + "\" " + ", " +
                          "\"" + ((null == null )                                 ? new Date(2021000000) : new Date(2021000000)  )     + "\" " + ", " +   /* rec_obj.get("HistoryDate") */ 
                          "\"" + ((null == null )                                 ? new Date(2021000000) : new Date(2021000000)  )     + "\" " + ", " +   /* rec_obj.get("RegistrationDate")  */ 
                          "\"" + ((null == null )                                 ? new Date(2021000000) : new Date(2021000000)  )     + "\" " + ", " +   /* rec_obj.get("OriginalEndDate")  */ 
                          "\"" + ((null == null )                                 ? 0 : 0  )                                           + "\" " + ", " +   /* rec_obj.get("ZipFactor") */ 
                           "\"" + ((rec_obj.get("Priority") == null)              ? 0 : rec_obj.get("Priority") )                      + "\" " + ", " +
                           "\"" + ((rec_obj.get("CommentId") == null)             ? 0 : rec_obj.get("CommentId") )                     + "\" " + ", " +
                          "\"" + (("false"  == "false")                           ? 0 : 1  )                                           + "\" " + ", " +   /* rec_obj.get("IsInlcudedInMeanPriceCalculation") */ 
                          "\"" + (("false"  == "false")                           ? 0 : 1  )                                           + "\" " + ", " +   /* rec_obj.get("DelayedForSure")   */ 
                          "\"" + ((null     == null)                              ? 0 : 0  )                                           + "\" " + ", " +   /* rec_obj.get("ReasonForDelayId") */ 
                          "\"" + ((null     == null)                              ? 0 : 0  )                                           + "\" " + ", " +   /* rec_obj.get("ReasonForDelayCommentId")  */ 
                          "\"" + (("false"  == "false")                           ? 0 : 1  )                                           + "\" " + ", " +   /* rec_obj.get("IsLockedToBatch") */ 
                          "\"" + ((null     == null)                              ? 0 : 0  )                                           + "\" " + ", " +   /* rec_obj.get("MaxQuantity") */ 
                          "\"" + ((null     == null)                              ? 0 : 0  )                                           + "\" " + ", " +   /* rec_obj.get("ExplodeType") */ 
                          "\"" + ((null     == null)                              ? 0 : 0  )                                           + "\" " + ", " +   /* rec_obj.get("OrderTypeId") */ 
                          "\"" + ((null     == null)                              ? 0 : 0  )                                           + "\" " + ", " +   /* rec_obj.get("PartConfigurationId") */ 
                          "\"" + (("false" == "false")                            ? 0 : 1  )                                           + "\" " + ", " +   /* rec_obj.get("CreatePurchaseOrder") */ 
                          "\"" + (("false" == "false")                            ? 0 : 1  )                                           + "\" " + ", " +   /* rec_obj.get("IsExportedToManagementAccounting") */ 
                          "\"" + ((null == null)                                  ? 0 : 0  )                                           + "\" " + ", " +   /* rec_obj.get("CausingTransType") */ 
                          "\"" + ((null == null)                                  ? 0 : 0  )                                           + "\" " + ", " +   /* rec_obj.get("CausingOrderRowId") */ 
                          "\"" + ((null == null)                                  ? new Date(2021000000) : new Date(2021000000)  )     + "\" " + ", " +   /* rec_obj.get("RequirementDate") */ 
                          "\"" + ((null == null)                                  ? 0 : 0  )                                           + "\" " + ", " +   /* rec_obj.get("RegistrationType") */ 
                          "\"" + (("false" == "false")                            ? 0 : 1  )                                           + "\" " + ", " +   /* rec_obj.get("GoodsLabelSetFromCustomerOrderRow") */ 
                          "\"" + ""                                                                                                    + "\" " + "  " +   /* rec_obj.get("RowsGoodsLabel") */ 

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "ManufacturingOrder was imported from Monitor API to MySql", false);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getManufacturingOrders






    public static String getWorkCenters(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = "100"  ;
        String    Id           = ""  ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrders?$filter=isnotnull(StartDate)&StartDate%20Gt%20'2021-10-10'$skip=0&$top=50000&$orderby=Id%20desc" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/WorkCenters" );

             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/WorkCenters"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  monitordb5.workcenter where tenant_id = 100 " ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into monitordb5.workcenter (tenant_id , id , " +
                          " UsePickingLocation , " +
                          " DefaultCalendarId , " +
                          " Number , " +
                          " DescriptionId , " +
                          " OperationDescriptionId , " +
                          " Type , " +
                          " DepartmentId , " +
                          " WarehouseId , " +
                          " NumberOfPlanningUnits , " +
                          " IsManualNumberOfPlanningUnits , " +
                          " NumberOfFlows , " +
                          " AvailabilityFactor , " +
                          " QueueTime , " +
                          " SimulationFactor , " +
                          " UnitStaffFactor , " +
                          " SetupStaffFactor , " +
                          " AlwaysReportMaterialsUsingStandardUnit , " +
                          " IgnoreAutomaticMaterialReporting , " +
                          " LetNextOperationInList , " +
                          " PlannerId , " +
                          " CategoryString , " +
                          " DefaultSetupTime , " +
                          " DefaultIneffectiveTime , " +
                          " IncludeInCdtAndFlowAnalysis , " +
                          " BlockedStatus , " +
                          " BlockedContextType , " +
                          " BlockedFromDate , " +
                          " BlockedToDate , " +
                          " BlockedById , " +
                          " BlockMessageId , " +
                          " CommentId , " +
                          " SupplierId , " +
                          " ReferenceId , " +
                          " LeadTimeOrder , " +
                          " LeadTimeOperation , " +
                          " IgnoreCreatingSupplierInvoiceBasisForSubcontractor , " +
                          " DefaultFreightCost , " +
                          " DefaultFreightCostCurrencyId , " +
                          " DefaultSetupCost , " +
                          " DefaultSetupCostCurrencyId , " +
                          " CostFactorCommentId , " +
                          " CopiesOfDeliveryNotesToSubcontractor , " +
                          " CopiesOfPurchaseOrdersToSubcontractor , " +
                          " ProcessingTypeId , " +
                          " AllowMultipleOperatorsToStartSameOperation , " +
                          " BasicTime , " +
                          " CorrectionFactor1 , " +
                          " CorrectionFactor2 , " +
                          " CorrectionFactor3 , " +
                          " AutoPrintShopPacket , " +
                          " PrintTransportLabel , " +
                          " MachinesPerShift , " +
                          " MinDebit , " +
                          " TimeUnitFactor , " +
                          " TimeCalculationType , " +
                          " TimeUnitCode , " +
                          " ShowOnPriorityPlan , " +
                          " UtilizationFactor , " +
                          " ProductGroupId , " +
                          " ReliableNewFinishDateOnPriorityPlan , " +
                          " PriorityplanSortedBy , " +
                          " UseQueueTimeWholeDayRoundOf , " +
                          " TimeHorizonInPriorityPlan , " +
                          " ExcludeManufacturingLabelWhenFinishingLastOperation , " +
                          " ExcludeManufacturingLabelWhenFinishingWipOperation , " +
                          " TimePrecision , " +
                          " AnnualVolumeUnitHours , " +
                          " AnnualVolumeSetupHours , " +
                          " AnnualVolumeManHours , " +
                          " SubcontractorAnnualVolumeCost , " +
                          " PrintTransportLabelType , " +
                          " IgnoreAutomaticEquipmentReporting , " +
                          " IgnoreAutomaticallyReportMaterialAtStart , " +
                          " IgnoreAutomaticallyReportEquipmentAtStart , " +
                          " ColorCode , " +

                          " Description , " +
                          " OperationDescription  " +

                          " ) " +

                          "values ( " +
                          tenant_id                                             + ", " +
                          Id                                                    + ", " +
                          "\"" + (("false" == "false")                                   ? 0 : 1  )                                                              + "\" " + ", " +    /* rec_obj.get("UsePickingLocation") */ 
                          "\"" + ((null == null)                                         ? 0 : 0  )                                                              + "\" " + ", " +    /* rec_obj.get("DefaultCalendarId")  */   
                           "\"" + ((rec_obj.get("Number") == null)                        ? 0 : rec_obj.get("Number") )                                           + "\" " + ", " +
                          "\"" + ((null == null)                                         ? 0 : 0  )                                                              + "\" " + ", " +     /* rec_obj.get("DescriptionId") */ 
                          "\"" + ((null == null)                                         ? 0 : 0  )                                                              + "\" " + ", " +     /* rec_obj.get("OperationDescriptionId")  */ 
                           "\"" + ((rec_obj.get("Type") == null)                          ? 0 : rec_obj.get("Type") )                                             + "\" " + ", " +
                           "\"" + ((rec_obj.get("DepartmentId") == null)                  ? 0 : rec_obj.get("DepartmentId") )                                     + "\" " + ", " +
                           "\"" + ((rec_obj.get("WarehouseId") == null)                   ? 0 : rec_obj.get("WarehouseId") )                                      + "\" " + ", " +
                          "\"" + ((null == null)                                         ? 0 : 0  )                                                              + "\" " + ", " +     /* rec_obj.get("NumberOfPlanningUnits") */ 
                          "\"" + (("false" == "false")                                   ? 0 : 1  )                                                              + "\" " + ", " +     /* rec_obj.get("IsManualNumberOfPlanningUnits"  */ 
                          "\"" + ((null == null)                                         ? 0 : 0  )                                                              + "\" " + ", " +     /* (rec_obj.get("NumberOfFlows") */ 
                          "\"" + ((null == null)                                         ? 0 : 0  )                                                              + "\" " + ", " +     /* rec_obj.get("AvailabilityFactor")  */ 
                          "\"" + ((null == null)                                         ? 0 : 0  )                                                              + "\" " + ", " +     /* rec_obj.get("QueueTime")  */ 
                          "\"" + ((null == null)                                         ? 0 : 0 )                                                               + "\" " + ", " +     /* rec_obj.get("SimulationFactor")  */ 
                          "\"" + ((null == null)                                         ? 0 : 0  )                                                              + "\" " + ", " +     /* rec_obj.get("UnitStaffFactor") */ 
                          "\"" + ((null == null)                                         ? 0 : 0  )                                                              + "\" " + ", " +     /* rec_obj.get("SetupStaffFactor") */ 
                          "\"" + (("false" == "false")                                   ? 0 : 1  )                                                              + "\" " + ", " +     /* rec_obj.get("AlwaysReportMaterialsUsingStandardUnit") */  
                          "\"" + (("false" == "false")                                   ? 0 : 1  )                                                              + "\" " + ", " +     /* rec_obj.get("IgnoreAutomaticMaterialReporting") */ 
                          "\"" + (("false" == "false")                                   ? 0 : 1  )                                                              + "\" " + ", " +     /* rec_obj.get("LetNextOperationInList")  */ 
                          "\"" + ((null == null)                                         ? 0 : 0  )                                                              + "\" " + ", " +     /* rec_obj.get("PlannerId")  */  
                          "\"" + ((null == null)                                         ? 0 : 0  )                                                              + "\" " + ", " +     /* rec_obj.get("CategoryString") */   
                          "\"" + ((null == null)                                         ? 0 : 0  )                                                              + "\" " + ", " +     /* rec_obj.get("DefaultSetupTime") */  
                          "\"" + ((null == null)                                         ? 0 : 0  )                                                              + "\" " + ", " +     /* rec_obj.get("DefaultIneffectiveTime")  */ 
                          "\"" + (("false" == "false")                                   ? 0 : 1  )                                                              + "\" " + ", " +     /* rec_obj.get("IncludeInCdtAndFlowAnalysis") */  
                          "\"" + ((null == null)                                         ? 0 : 0 )                                                               + "\" " + ", " +     /* rec_obj.get("BlockedStatus") */
                          "\"" + ((null == null)                                         ? 0 : 0  )                                                              + "\" " + ", " +     /* rec_obj.get("BlockedContextType") */
                          "\"" + ((null == null )                                        ? new Date(2021000000) : new Date(2021000000)  )                        + "\" " + ", " +     /* rec_obj.get("BlockedFromDate") */ 
                          "\"" + ((null == null )                                        ? new Date(2021000000) : new Date(2021000000)  )                        + "\" " + ", " +     /* rec_obj.get("BlockedToDate") */ 
                          "\"" + ((null == null)                                         ? 0 : 0 )                                                               + "\" " + ", " +     /* rec_obj.get("BlockedById")  */ 
                          "\"" + ((null == null)                                         ? 0 : 0 )                                                               + "\" " + ", " +     /* rec_obj.get("BlockMessageId")  */
                           "\"" + ((rec_obj.get("CommentId") == null)                     ? 0 : rec_obj.get("CommentId") )                                        + "\" " + ", " +
                          "\"" + ((null == null)                                         ? 0 : 0 )                                                               + "\" " + ", " +     /* rec_obj.get("SupplierId") */    
                          "\"" + ((null == null)                                         ? 0 : 0 )                                                               + "\" " + ", " +     /* rec_obj.get("ReferenceId") */  
                          "\"" + ((null == null)                                         ? 0 : 0 )                                                               + "\" " + ", " +     /* rec_obj.get("LeadTimeOrder") */ 
                          "\"" + ((null == null)                                         ? 0 : 0  )                                                              + "\" " + ", " +     /* rec_obj.get("LeadTimeOperation") */  
                          "\"" + (("false" == "false")                                   ? 0 : 1  )                                                              + "\" " + ", " +     /* rec_obj.get("IgnoreCreatingSupplierInvoiceBasisForSubcontractor")  */  
                          "\"" + ((null == null)                                         ? 0 : 0 )                                                               + "\" " + ", " +     /* rec_obj.get("DefaultFreightCost") */   
                          "\"" + ((null == null)                                         ? 0 : 0 )                                                               + "\" " + ", " +     /* rec_obj.get("DefaultFreightCostCurrencyId")  */ 
                          "\"" + ((null == null)                                         ? 0 : 0  )                                                              + "\" " + ", " +     /* rec_obj.get("DefaultSetupCost") */ 
                          "\"" + ((null == null)                                         ? 0 : 0 )                                                               + "\" " + ", " +     /* rec_obj.get("DefaultSetupCostCurrencyId") */ 
                          "\"" + ((null == null)                                         ? 0 : 0 )                                                               + "\" " + ", " +     /* rec_obj.get("CostFactorCommentId")  */ 
                          "\"" + ((null == null)                                         ? 0 : 0 )                                                               + "\" " + ", " +     /* rec_obj.get("CopiesOfDeliveryNotesToSubcontractor")  */  
                          "\"" + ((null == null)                                         ? 0 : 0  )                                                              + "\" " + ", " +     /* rec_obj.get("CopiesOfPurchaseOrdersToSubcontractor")  */ 
                          "\"" + ((null == null)                                         ? 0 : 0  )                                                              + "\" " + ", " +     /* rec_obj.get("ProcessingTypeId") */ 
                          "\"" + (("false" == "false")                                   ? 0 : 1  )                                                              + "\" " + ", " +     /* rec_obj.get("AllowMultipleOperatorsToStartSameOperation") */ 
                          "\"" + ((null == null)                                         ? 0 : 0  )                                                              + "\" " + ", " +     /* rec_obj.get("BasicTime") */  
                          "\"" + ((null == null)                                         ? 0 : 0 )                                                               + "\" " + ", " +     /* rec_obj.get("CorrectionFactor1") */  
                          "\"" + ((null == null)                                         ? 0 : 0 )                                                               + "\" " + ", " +     /* rec_obj.get("CorrectionFactor2")  */
                          "\"" + ((null == null)                                         ? 0 : 0 )                                                               + "\" " + ", " +     /* rec_obj.get("CorrectionFactor3") */          
                          "\"" + (("false" == "false")                                   ? 0 : 1  )                                                              + "\" " + ", " +     /* rec_obj.get("AutoPrintShopPacket") */   
                          "\"" + (("false" == "false")                                   ? 0 : 1  )                                                              + "\" " + ", " +     /* rec_obj.get("PrintTransportLabel") */ 
                          "\"" + ((null == null)                                         ? 0 : 0 )                                                               + "\" " + ", " +     /* rec_obj.get("MachinesPerShift") */ 
                          "\"" + ((null == null)                                         ? 0 : 0 )                                                               + "\" " + ", " +     /* rec_obj.get("MinDebit")  */ 
                          "\"" + ((null == null)                                         ? 0 : 0 )                                                               + "\" " + ", " +     /* rec_obj.get("TimeUnitFactor") */   
                          "\"" + ((null == null)                                         ? 0 : 0 )                                                               + "\" " + ", " +     /* rec_obj.get("TimeCalculationType") */ 
                          "\"" + ((null == null)                                         ? 0 : 0 )                                                               + "\" " + ", " +     /* rec_obj.get("TimeUnitCode")  */   
                          "\"" + (("false" == "false")                                   ? 0 : 1 )                                                               + "\" " + ", " +     /* rec_obj.get("ShowOnPriorityPlan") */  
                          "\"" + ((null == null)                                         ? 0 : 0 )                                                               + "\" " + ", " +     /* rec_obj.get("UtilizationFactor")  */   
                          "\"" + ((null == null)                                         ? 0 : 0 )                                                               + "\" " + ", " +     /* rec_obj.get("ProductGroupId")  */  
                          "\"" + (("false" == "false")                                   ? 0 : 1 )                                                               + "\" " + ", " +     /* rec_obj.get("ReliableNewFinishDateOnPriorityPlan")  */ 
                          "\"" + ((null == null)                                         ? 0 : 0 )                                                               + "\" " + ", " +     /* rec_obj.get("PriorityplanSortedBy") */ 
                          "\"" + (("false" == "false")                                   ? 0 : 1  )                                                              + "\" " + ", " +     /* rec_obj.get("UseQueueTimeWholeDayRoundOf") */  
                          "\"" + ((null == null)                                         ? 0 : 0 )                                                               + "\" " + ", " +     /* rec_obj.get("TimeHorizonInPriorityPlan")  */  
                          "\"" + (("false" == "false")                                   ? 0 : 1  )                                                              + "\" " + ", " +     /* rec_obj.get("ExcludeManufacturingLabelWhenFinishingLastOperation")   */   
                          "\"" + (("false"  == "false")                                  ? 0 : 1  )                                                              + "\" " + ", " +     /* rec_obj.get("ExcludeManufacturingLabelWhenFinishingWipOperation")  */    
                          "\"" + ((null == null)                                         ? 0 : 0 )                                                               + "\" " + ", " +     /* rec_obj.get("TimePrecision") */   
                          "\"" + ((null == null)                                         ? 0 : 0 )                                                               + "\" " + ", " +     /* rec_obj.get("AnnualVolumeUnitHours")  */ 
                          "\"" + ((null == null)                                         ? 0 : 0 )                                                               + "\" " + ", " +     /* rec_obj.get("AnnualVolumeSetupHours")  */    
                          "\"" + ((null == null)                                         ? 0 : 0 )                                                               + "\" " + ", " +     /* rec_obj.get("AnnualVolumeManHours")  */  
                          "\"" + ((null == null)                                         ? 0 : 0 )                                                               + "\" " + ", " +     /* rec_obj.get("SubcontractorAnnualVolumeCost") */  
                          "\"" + ((null == null)                                         ? 0 : 0 )                                                               + "\" " + ", " +     /* rec_obj.get("PrintTransportLabelType") */ 
                          "\"" + (("false" == "false")                                   ? 0 : 1  )                                                              + "\" " + ", " +     /* rec_obj.get("IgnoreAutomaticEquipmentReporting") */  
                          "\"" + (("false" == "false")                                   ? 0 : 1  )                                                              + "\" " + ", " +     /* rec_obj.get("IgnoreAutomaticallyReportMaterialAtStart")   */
                          "\"" + (("false" == "false")                                   ? 0 : 1  )                                                              + "\" " + ", " +     /* rec_obj.get("IgnoreAutomaticallyReportEquipmentAtStart")  */ 
                          "\"" + ((null == null)                                         ? 0 : 0 )                                                               + "\" " + ", " +     /* rec_obj.get("ColorCode")  */  

                           "\"" + ((rec_obj.get("Description") == null)                     ? 0 : rec_obj.get("Description") )                                    + "\" " + ", " +
                           "\"" + ((rec_obj.get("OperationDescription") == null)            ? 0 : rec_obj.get("OperationDescription") )                           + "\" " + "  " +

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "WorkCenters was imported from Monitor API to MySql", false);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getWorkCenters




    public static String getManufacturingOrderTypes(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = "100"  ;
        String    Id           = ""  ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrders?$filter=isnotnull(StartDate)&StartDate%20Gt%20'2021-10-10'$skip=0&$top=50000&$orderby=Id%20desc" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/WorkCenters" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrderTypes" );

             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/ManufacturingOrderTypes"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  monitordb5.manufacturingordertype where tenant_id = 100 " ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into monitordb5.manufacturingordertype (tenant_id , id , " +
                          " BaseType , " +
                          " Number , " +
                          " Prefix , " +
                          " DescriptionId , " +
                          " Priority , " +
                          " Visible , " +
                          " IsPreset , " +

                          " Description  " +

                          " ) " +

                          "values ( " +
                          tenant_id                                             + ", " +
                          Id                                                    + ", " +
                           "\"" + ((rec_obj.get("BaseType") == null)                     ? 0 : rec_obj.get("BaseType") )                                         + "\" " + ", " +
                           "\"" + ((rec_obj.get("Number") == null)                       ? 0 : rec_obj.get("Number") )                                           + "\" " + ", " +
                           "\"" + ((rec_obj.get("Prefix") == null)                       ? 0 : rec_obj.get("Prefix") )                                           + "\" " + ", " +
                          "\"" + ((null == null)                                        ? 0 : 0  )                                                              + "\" " + ", " +      /* rec_obj.get("DescriptionId")  */ 
                          "\"" + ((null == null)                                        ? 0 : 0 )                                                               + "\" " + ", " +      /* rec_obj.get("Priority")  */      
                          "\"" + (("false" == "false")                                  ? 0 : 1 )                                                               + "\" " + ", " +      /* rec_obj.get("Visible")  */ 
                          "\"" + (("false" == "false")                                  ? 0 : 1 )                                                               + "\" " + ", " +      /* rec_obj.get("IsPreset") */   

                          "\"" + ((rec_obj.get("Description") == null)                  ? 0 : rec_obj.get("Description") )                                      + "\" " + "  " +

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "ManufacturingOrderTypes was imported from Monitor API to MySql", false);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getManufacturingOrderTypes





    public static String getManufacturingOrderOperations(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = "100"  ;
        String    Id           = ""  ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrders?$filter=isnotnull(StartDate)&StartDate%20Gt%20'2021-10-10'$skip=0&$top=50000&$orderby=Id%20desc" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/WorkCenters" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrderTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrderOperations?$filter=isnotnull(PlannedStartDate)&PlannedStartDate%20Gt%20'2021-10-10'$skip=0&$top=50$orderby=Id%20desc" );

             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/ManufacturingOrderOperations?$filter=isnotnull(PlannedStartDate)&PlannedStartDate%20Gt%20'2021-10-10'$orderby=Id%20desc&$top=50000"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  monitordb5.manufacturingorderoperation where tenant_id = 100 " ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into monitordb5.manufacturingorderoperation (tenant_id , id , " +
                          " Version , " +
                          " BundleId , " +
                          " OperationRowId , " +
                          " CommentId , " +
                          " CurrencyId , " +
                          " RowNumber , " +
                          " SupplierId , " +
                          " DeliveryAddressId , " +
                          " ReportedQuantity , " +
                          " RejectedQuantity , " +
                          " PlannedQuantity , " +
                          " RestQuantity , " +
                          " AutomaticClockOut , " +
                          " ShippingDate , " +
                          " DescriptionId , " +
                          " ActualFinishDate , " +
                          " PlannedFinishDate , " +
                          " OriginalFinishDate , " +
                          " ActualStartDate , " +
                          " PlannedStartDate , " +
                          " ExtraOperationStatus , " +
                          " PurchaseOrderId , " +
                          " OperationNumber , " +
                          " DaysBeforeFinishDate , " +
                          " UnitCostFactorId , " +
                          " SetupCostFactorId , " +
                          " WipLocation , " +
                          " Priority , " +
                          " ClearedStatus , " +
                          " ReportedSetupTime , " +
                          " ReportedUnitCost , " +
                          " ReportedUnitCostCurrencyId , " +
                          " ReportedSetupCost , " +
                          " ReportedSetupCostCurrencyId , " +
                          " ReportedSetupCostInForeignCurrency , " +
                          " ReportedSetupCostInForeignCurrencyCurrencyId , " +
                          " ReportedUnitCostInForeignCurrency , " +
                          " ReportedUnitCostInForeignCurrencyCurrencyId , " +
                          " PlannedUnitCost , " +
                          " PlannedUnitCostCurrencyId , " +
                          " PlannedUnitCostInForeignCurrency , " +
                          " PlannedUnitCostInForeignCurrencyCurrencyId , " +
                          " TransportCost , " +
                          " TransportCostCurrencyId , " +
                          " PlannedSetupCost , " +
                          " PlannedSetupCostCurrencyId , " +
                          " PlannedSetupCostInForeignCurrency , " +
                          " PlannedSetupCostInForeignCurrencyCurrencyId , " +
                          " Status , " +
                          " WorkshopOperationStatus , " +
                          " ReportNumber , " +
                          " ReportedUnitTime , " +
                          " OfWhichTime , " +
                          " ToolStatus , " +
                          " LockedDelegateWork , " +
                          " ManufacturingOrderNodeId , " +
                          " NewFinishDate , " +
                          " ManufacturingOrderId , " +
                          " SubcontractOrderDate , " +
                          " SubcontractOrderConfirmationDate , " +
                          " SubcontractorPartId , " +
                          " IsSubcontractor , " +
                          " SubcontractComprehensiveNumber , " +
                          " SubcontractRequestedFinishDate , " +
                          " WarehouseId , " +
                          " IsCompressedOrExtended , " +
                          " FixedLeadTime , " +
                          " SupplierPartNumber , " +
                          " ExtraQuantityProcent , " +
                          " Overlap , " +
                          " ShippedQuantity , " +
                          " ReceivedQuantity , " +
                          " PoolWorkCenterId , " +
                          " NumberOfFlows , " +
                          " CapacityFactorSimultaneousOrders , " +
                          " AllowsMultipleOperatorsToStartThisOperationSimultaneously , " +
                          " SetupQuantity , " +
                          " PrintingDate , " +
                          " OnPriorityPlan , " +
                          " TimeCalculationType , " +
                          " DeliverToEndCustomer , " +
                          " EditedStatus , " +
                          " TimeCode , " +
                          " PlannedUnitCostFactor1 , " +
                          " PlannedUnitCostFactor2 , " +
                          " PlannedUnitCostFactor3 , " +
                          " PlannedSetupCostFactor1 , " +
                          " PlannedSetupCostFactor2 , " +
                          " PlannedSetupCostFactor3 , " +
                          " PlannedUnitTime , " +
                          " PlannedSetupTime , " +
                          " PlannedCycleTime , " +
                          " PlannedIneffectiveTime , " +
                          " QueueTime , " +
                          " UseQueueTimeWholeDayRoundOf , " +
                          " SetupStaffingFactor , " +
                          " UnitStaffingFactor , " +
                          " WorkCenterId , " +

                          " PartId  " +
                            
                          " ) " +

                          "values ( " +
                          tenant_id                                             + ", " +
                          Id                                                    + ", " +
                           "\"" + ((null == null)                                       ? 0 : 0  )                                                             + "\" " + ", " +      /* rec_obj.get("Version")  */ 
                           "\"" + ((null == null)                                       ? 0 : 0  )                                                             + "\" " + ", " +      /* rec_obj.get("BundleId") */         
                            "\"" + ((rec_obj.get("OperationRowId") == null)              ? 0 : rec_obj.get("OperationRowId") )                                  + "\" " + ", " +
                            "\"" + ((rec_obj.get("InstructionCommentId") == null)        ? 0 : rec_obj.get("InstructionCommentId") )                            + "\" " + ", " +     /* CommentId */ 
                           "\"" + ((null == null)                                       ? 0 : 0 )                                                              + "\" " + ", " +      /* rec_obj.get("CurrencyId") */        
                           "\"" + ((null == null)                                       ? 0 : 0 )                                                              + "\" " + ", " +      /* rec_obj.get("RowNumber") */ 
                           "\"" + ((null == null)                                       ? 0 : 0 )                                                              + "\" " + ", " +      /* rec_obj.get("SupplierId") */   
                           "\"" + ((null == null)                                       ? 0 : 0 )                                                              + "\" " + ", " +      /* rec_obj.get("DeliveryAddressId") */   
                            "\"" + ((rec_obj.get("ReportedQuantity") == null)            ? 0 : rec_obj.get("ReportedQuantity") )                                + "\" " + ", " +
                            "\"" + ((rec_obj.get("RejectedQuantity") == null)            ? 0 : rec_obj.get("RejectedQuantity") )                                + "\" " + ", " +
                            "\"" + ((rec_obj.get("PlannedQuantity") == null)             ? 0 : rec_obj.get("PlannedQuantity") )                                 + "\" " + ", " +
                            "\"" + ((rec_obj.get("RestQuantity") == null)                ? 0 : rec_obj.get("RestQuantity") )                                    + "\" " + ", " +
                           "\"" + (("false" == "false")                                 ? 0 : 1 )                                                              + "\" " + ", " +         /* rec_obj.get("AutomaticClockOut") */ 
                           "\"" + ((null == null)                                        ? new Date(2021000000) : new Date(2021000000)  )                      + "\" " + ", " +         /* rec_obj.get("ShippingDate") */     
                           "\"" + ((null == null)                                        ? 0 : 0  )                                                            + "\" " + ", " +         /* rec_obj.get("DescriptionId")  */
                            "\"" + ((rec_obj.get("ActualFinishDate")  == null )          ? new Date(2021000000) : rec_obj.get("ActualFinishDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                            "\"" + ((rec_obj.get("PlannedFinishDate")  == null )         ? new Date(2021000000) : rec_obj.get("PlannedFinishDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                           "\"" + ((null  == null )                                      ? new Date(2021000000) : new Date(2021000000)  )                      + "\" " + ", " +       /* rec_obj.get("OriginalFinishDate") */ 
                            "\"" + ((rec_obj.get("ActualStartDate")  == null )           ? new Date(2021000000) : rec_obj.get("ActualStartDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                            "\"" + ((rec_obj.get("PlannedStartDate")  == null )          ? new Date(2021000000) : rec_obj.get("PlannedStartDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                           "\"" + ((null == null)                                        ? 0 : 0 )                                                             + "\" " + ", " +     /* rec_obj.get("ExtraOperationStatus") */ 
                           "\"" + ((null == null)                                        ? 0 : 0 )                                                             + "\" " + ", " +     /* rec_obj.get("PurchaseOrderId") */ 
                            "\"" + ((rec_obj.get("OperationNumber") == null)             ? 0 : rec_obj.get("OperationNumber") )                                 + "\" " + ", " +
                           "\"" + ((null == null)                                       ? 0 : 0 )                                                              + "\" " + ", " +     /* rec_obj.get("DaysBeforeFinishDate") */ 
                           "\"" + ((null == null)                                       ? 0 : 0 )                                                              + "\" " + ", " +     /* rec_obj.get("UnitCostFactorId") */ 
                           "\"" + ((null == null)                                       ? 0 : 0 )                                                              + "\" " + ", " +     /* rec_obj.get("SetupCostFactorId") */ 
                            "\"" + ((rec_obj.get("WipLocation") == null)                 ? 0 : rec_obj.get("WipLocation") )                                     + "\" " + ", " +
                            "\"" + ((rec_obj.get("Priority") == null)                    ? 0 : rec_obj.get("Priority") )                                        + "\" " + ", " +
                           "\"" + (("false" == "false")                                 ? 0 : 1 )                                                              + "\" " + ", " +     /* rec_obj.get("ClearedStatus") */ 
                            "\"" + ((rec_obj.get("ReportedSetupTime") == null)           ? 0 : rec_obj.get("ReportedSetupTime") )                               + "\" " + ", " +
                           "\"" + ((null == null)                                       ? 0 : 0 )                                                              + "\" " + ", " +     /* rec_obj.get("ReportedUnitCost")  */ 
                           "\"" + ((null == null)                                       ? 0 : 0 )                                                              + "\" " + ", " +     /* rec_obj.get("ReportedUnitCostCurrencyId") */ 
                           "\"" + ((null == null)                                       ? 0 : 0 )                                                              + "\" " + ", " +     /* rec_obj.get("ReportedSetupCost") */
                           "\"" + ((null == null)                                       ? 0 : 0 )                                                              + "\" " + ", " +     /* rec_obj.get("ReportedSetupCostCurrencyId") */   
                           "\"" + ((null == null)                                       ? 0 : 0 )                                                              + "\" " + ", " +     /* rec_obj.get("ReportedSetupCostInForeignCurrency") */
                           "\"" + ((null == null)                                       ? 0 : 0 )                                                              + "\" " + ", " +     /* rec_obj.get("ReportedSetupCostInForeignCurrencyCurrencyId") */ 
                           "\"" + ((null == null)                                       ? 0 : 0 )                                                              + "\" " + ", " +     /* rec_obj.get("ReportedUnitCostInForeignCurrency")  */ 
                           "\"" + ((null == null)                                       ? 0 : 0 )                                                              + "\" " + ", " +     /* rec_obj.get("ReportedUnitCostInForeignCurrencyCurrencyId") */ 
                           "\"" + ((null == null)                                       ? 0 : 0 )                                                              + "\" " + ", " +     /* rec_obj.get("PlannedUnitCost")  */  
                           "\"" + ((null == null)                                       ? 0 : 0 )                                                              + "\" " + ", " +     /* rec_obj.get("PlannedUnitCostCurrencyId") */ 
                           "\"" + ((null == null)                                       ? 0 : 0 )                                                              + "\" " + ", " +     /* rec_obj.get("PlannedUnitCostInForeignCurrency") */ 
                           "\"" + ((null == null)                                       ? 0 : 0 )                                                              + "\" " + ", " +     /* rec_obj.get("PlannedUnitCostInForeignCurrencyCurrencyId") */ 
                           "\"" + ((null == null)                                       ? 0 : 0 )                                                              + "\" " + ", " +     /* rec_obj.get("TransportCost") */ 
                           "\"" + ((null == null)                                       ? 0 : 0 )                                                              + "\" " + ", " +     /* rec_obj.get("TransportCostCurrencyId") */ 
                           "\"" + ((null == null)                                       ? 0 : 0 )                                                              + "\" " + ", " +     /* rec_obj.get("PlannedSetupCost") */ 
                           "\"" + ((null == null)                                       ? 0 : 0 )                                                              + "\" " + ", " +     /* rec_obj.get("PlannedSetupCostCurrencyId") */ 
                           "\"" + ((null == null)                                       ? 0 : 0 )                                                              + "\" " + ", " +     /* rec_obj.get("PlannedSetupCostInForeignCurrency") */  
                           "\"" + ((null == null)                                       ? 0 : 0 )                                                              + "\" " + ", " +    /* rec_obj.get("PlannedSetupCostInForeignCurrencyCurrencyId") */  
                            "\"" + ((rec_obj.get("Status") == null)                      ? 0 : rec_obj.get("Status") )                                          + "\" " + ", " +
                            "\"" + ((rec_obj.get("WorkshopOperationStatus") == null)     ? 0 : rec_obj.get("WorkshopOperationStatus") )                         + "\" " + ", " +
                            "\"" + ((rec_obj.get("ReportNumber") == null)                ? 0 : rec_obj.get("ReportNumber") )                                    + "\" " + ", " +
                            "\"" + ((rec_obj.get("ReportedUnitTime") == null)            ? 0 : rec_obj.get("ReportedUnitTime") )                                + "\" " + ", " +
                           "\"" + ((null == null)                                       ? 0 : 0 )                                                              + "\" " + ", " +     /* rec_obj.get("OfWhichTime") */ 
                           "\"" + ((null == null)                                       ? 0 : 0 )                                                              + "\" " + ", " +     /* rec_obj.get("ToolStatus") */ 
                           "\"" + (("false" == "false")                                 ? 0 : 1 )                                                              + "\" " + ", " +     /* rec_obj.get("LockedDelegateWork") */ 
                            "\"" + ((rec_obj.get("ManufacturingOrderNodeId") == null)    ? 0 : rec_obj.get("ManufacturingOrderNodeId") )                        + "\" " + ", " +
                           "\"" + ((null  == null )                                     ? new Date(2021000000) : new Date(2021000000) )                       + "\" " + ", " +     /* rec_obj.get("NewFinishDate") */ 
                            "\"" + ((rec_obj.get("ManufacturingOrderId") == null)        ? 0 : rec_obj.get("ManufacturingOrderId") )                            + "\" " + ", " +
                           "\"" + ((null  == null )                                     ? new Date(2021000000) : new Date(2021000000)  )                      + "\" " + ", " +     /* rec_obj.get("SubcontractOrderDate")  */ 
                           "\"" + ((null  == null )                                     ? new Date(2021000000) : new Date(2021000000)  )                      + "\" " + ", " +     /* rec_obj.get("SubcontractOrderConfirmationDate") */ 
                           "\"" + ((null  == null)                                      ? 0 : 0 )                                                             + "\" " + ", " +     /* rec_obj.get("SubcontractorPartId") */ 
                           "\"" + (("false"  == "false")                                ? 0 : 1 )                                                             + "\" " + ", " +     /* rec_obj.get("IsSubcontractor") */
                           "\"" + ((null == null)                                       ? 0 : 0 )                                                             + "\" " + ", " +     /* rec_obj.get("SubcontractComprehensiveNumber") */   
                           "\"" + ((null == null )                                      ? new Date(2021000000) : new Date(2021000000)  )                      + "\" " + ", " +     /* rec_obj.get("SubcontractRequestedFinishDate") */
                           "\"" + ((null == null)                                       ? 0 : 0 )                                                             + "\" " + ", " +     /* rec_obj.get("WarehouseId") */ 
                           "\"" + (("false" == "false")                                 ? 0 : 1 )                                                             + "\" " + ", " +     /* rec_obj.get("IsCompressedOrExtended") */ 
                           "\"" + ((null == null)                                       ? 0 : 0 )                                                             + "\" " + ", " +     /* rec_obj.get("FixedLeadTime") */   
                           "\"" + ((null == null)                                       ? 0 : 0 )                                                             + "\" " + ", " +     /* rec_obj.get("SupplierPartNumber") */  
                           "\"" + ((null == null)                                       ? 0 : 0 )                                                             + "\" " + ", " +     /* rec_obj.get("ExtraQuantityProcent") */ 
                           "\"" + ((null == null)                                       ? 0 : 0 )                                                             + "\" " + ", " +     /* rec_obj.get("Overlap") */   
                           "\"" + ((null == null)                                       ? 0 : 0 )                                                             + "\" " + ", " +     /* rec_obj.get("ShippedQuantity") */ 
                           "\"" + ((null == null)                                       ? 0 : 0 )                                                             + "\" " + ", " +     /* rec_obj.get("ReceivedQuantity") */  
                           "\"" + ((null == null)                                       ? 0 : 0 )                                                             + "\" " + ", " +     /* rec_obj.get("PoolWorkCenterId") */ 
                           "\"" + ((null == null)                                       ? 0 : 0 )                                                             + "\" " + ", " +     /* rec_obj.get("NumberOfFlows") */
                           "\"" + ((null == null)                                       ? 0 : 0 )                                                             + "\" " + ", " +     /* rec_obj.get("CapacityFactorSimultaneousOrders") */
                           "\"" + (("false" == "false")                                 ? 0 : 1 )                                                             + "\" " + ", " +     /* rec_obj.get("AllowsMultipleOperatorsToStartThisOperationSimultaneously") */  
                           "\"" + ((null == null)                                       ? 0 : 0 )                                                             + "\" " + ", " +     /* rec_obj.get("SetupQuantity") */ 
                           "\"" + ((null == null )                                      ? new Date(2021000000) : new Date(2021000000)  )                      + "\" " + ", " +     /* rec_obj.get("PrintingDate") */ 
                           "\"" + (("false" == "false")                                 ? 0 : 1 )                                                             + "\" " + ", " +     /* rec_obj.get("OnPriorityPlan") */       
                           "\"" + ((null == null)                                       ? 0 : 0 )                                                             + "\" " + ", " +     /* rec_obj.get("TimeCalculationType") */ 
                           "\"" + (("false" == "false")                                 ? 0 : 1 )                                                             + "\" " + ", " +     /* rec_obj.get("DeliverToEndCustomer") */  
                           "\"" + ((null == null)                                       ? 0 : 0 )                                                             + "\" " + ", " +     /* rec_obj.get("EditedStatus") */ 
                           "\"" + ((null == null)                                       ? 0 : 0 )                                                             + "\" " + ", " +     /* rec_obj.get("TimeCode")  */   
                           "\"" + ((null == null)                                       ? 0 : 0 )                                                             + "\" " + ", " +     /* rec_obj.get("PlannedUnitCostFactor1") */ 
                           "\"" + ((null == null)                                       ? 0 : 0 )                                                             + "\" " + ", " +     /* rec_obj.get("PlannedUnitCostFactor2")  */ 
                           "\"" + ((null == null)                                       ? 0 : 0 )                                                             + "\" " + ", " +     /* rec_obj.get("PlannedUnitCostFactor3") */   
                           "\"" + ((null == null)                                       ? 0 : 0 )                                                             + "\" " + ", " +     /* rec_obj.get("PlannedSetupCostFactor1") */ 
                           "\"" + ((null == null)                                       ? 0 : 0 )                                                             + "\" " + ", " +     /* rec_obj.get("PlannedSetupCostFactor2") */ 
                           "\"" + ((null == null)                                       ? 0 : 0 )                                                             + "\" " + ", " +     /* rec_obj.get("PlannedSetupCostFactor3") */ 
                            "\"" + ((rec_obj.get("PlannedUnitTime") == null)                   ? 0 : rec_obj.get("PlannedUnitTime") )                           + "\" " + ", " +
                            "\"" + ((rec_obj.get("PlannedSetupTime") == null)                  ? 0 : rec_obj.get("PlannedSetupTime") )                          + "\" " + ", " +
                           "\"" + ((null == null)                                             ? 0 : 0 )                                                        + "\" " + ", " +    /* rec_obj.get("PlannedCycleTime") */ 
                           "\"" + ((null == null)                                             ? 0 : 0 )                                                        + "\" " + ", " +    /* rec_obj.get("PlannedIneffectiveTime") */ 
                           "\"" + ((null == null)                                             ? 0 : 0 )                                                        + "\" " + ", " +    /* rec_obj.get("QueueTime") */  
                           "\"" + (("false" == "false")                                       ? 0 : 1 )                                                        + "\" " + ", " +    /* rec_obj.get("UseQueueTimeWholeDayRoundOf") */ 
                           "\"" + ((null == null)                                             ? 0 : 0 )                                                        + "\" " + ", " +    /* rec_obj.get("SetupStaffingFactor") */ 
                           "\"" + ((null == null)                                             ? 0 : 0 )                                                        + "\" " + ", " +    /* rec_obj.get("UnitStaffingFactor") */  
                            "\"" + ((rec_obj.get("WorkCenterId") == null)                      ? 0 : rec_obj.get("WorkCenterId") )                              + "\" " + ",  " +

                            "\"" + ((rec_obj.get("PartId") == null)                           ? 0 : rec_obj.get("PartId") )                                     + "\" " + "  " +

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );
                          WriteLog.write(conf.getLogFile(), com_stmt, false);


                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "ManufacturingOrderOperations was imported from Monitor API to MySql", false);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getManufacturingOrderOperations






    public static String getManufacturingOrderNodes(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = "100"  ;
        String    Id           = ""  ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrders?$filter=isnotnull(StartDate)&StartDate%20Gt%20'2021-10-10'$skip=0&$top=50000&$orderby=Id%20desc" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/WorkCenters" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrderTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrderOperations?$filter=isnotnull(PlannedStartDate)&PlannedStartDate%20Gt%20'2021-10-10'$skip=0&$top=50$orderby=Id%20desc" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrderNodes?$filter=isnotnull(StartDate)&StartDate%20Gt%20'2021-10-10'$skip=0&$top=50$orderby=Id%20desc" );

             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Manufacturing/ManufacturingOrderNodes?$filter=isnotnull(StartDate)&StartDate%20Gt%20'2021-10-10'$orderby=Id%20desc&$top=50000"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  monitordb5.manufacturingordernode where tenant_id = 100 " ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into monitordb5.manufacturingordernode (tenant_id , id , " +
                          " Number , " +
                          " MainNode , " +
                          " IsPartOfCoordinatedPartsOrder , " +
                          " FixedQueueTime , " +
                          " Level , " +
                          " SortOrder , " +
                          " WarehouseId , " +
                          " ReportedQuantity , " +
                          " WorkingHours , " +
                          " RealEndDate , " +
                          " RealStartDate , " +
                          " OriginalEndDate , " +
                          " PrintoutDate , " +
                          " PartStatus , " +
                          " PrintedToolRows , " +
                          " NodeSerialNumbersId , " +
                          " Status , " +
                          " NodeTreeStatus , " +
                          " PartId , " +
                          " CommentId , " +
                          " PlannedQuantity , " +
                          " RestQuantity , " +
                          " StartDate , " +
                          " ZipFactor , " +
                          " RevisionId , " +
                          " PartType , " +
                          " ManufacturingOrderNodeId , " +
                          " ManufacturingOrderId , " +
                          " EndDate , " +
                          " NewFinishDate , " +
                          " RowNumber  " +

                          " ) " +

                          "values ( " +
                          tenant_id                                             + ", " +
                          Id                                                    + ", " +
                           "\"" + ((rec_obj.get("Number") == null)                                   ? 0 : rec_obj.get("Number") )                                  + "\" " + ", " +
                           "\"" + ((rec_obj.get("IsMainNode") == "false")                            ? 0 : 1 )                                                      + "\" " + ", " + 
                          "\"" + (("false" == "false")                                              ? 0 : 1 )                                                      + "\" " + ", " +       /* rec_obj.get("IsPartOfCoordinatedPartsOrder") */ 
                          "\"" + ((null == null)                                                    ? 0 : 0 )                                                      + "\" " + ", " +       /* rec_obj.get("FixedQueueTime") */ 
                           "\"" + ((rec_obj.get("Level") == null)                                    ? 0 : rec_obj.get("Level") )                                   + "\" " + ", " +
                          "\"" + ((null == null)                                                    ? 0 : 0 )                                                      + "\" " + ", " +       /* rec_obj.get("SortOrder") */ 
                           "\"" + ((rec_obj.get("WarehouseId") == null)                              ? 0 : rec_obj.get("WarehouseId") )                             + "\" " + ", " +
                           "\"" + ((rec_obj.get("ReportedQuantity") == null)                         ? 0 : rec_obj.get("ReportedQuantity") )                        + "\" " + ", " +
                          "\"" + ((null == null)                                                    ? 0 : 0 )                                                      + "\" " + ", " +       /* rec_obj.get("WorkingHours") */         
                          "\"" + ((null == null )                                                   ? new Date(2021000000) : new Date(2021000000)  )               + "\" " + ", " +       /* rec_obj.get("RealEndDate") */ 
                          "\"" + ((null == null )                                                   ? new Date(2021000000) : new Date(2021000000)  )               + "\" " + ", " +       /* rec_obj.get("RealStartDate") */ 
                          "\"" + ((null == null )                                                   ? new Date(2021000000) : new Date(2021000000)  )               + "\" " + ", " +       /* rec_obj.get("OriginalEndDate") */ 
                          "\"" + ((null == null )                                                   ? new Date(2021000000) : new Date(2021000000)  )               + "\" " + ", " +       /* rec_obj.get("PrintoutDate") */ 
                          "\"" + ((null == null )                                                   ? 0 : 0 )                                                      + "\" " + ", " +       /* rec_obj.get("PartStatus") */ 
                          "\"" + ((null == null )                                                   ? 0 : 0 )                                                      + "\" " + ", " +       /* rec_obj.get("PrintedToolRows") */
                          "\"" + ((null == null )                                                   ? 0 : 0 )                                                      + "\" " + ", " +       /* rec_obj.get("NodeSerialNumbersId") */
                           "\"" + ((rec_obj.get("Status") == null)                                   ? 0 : rec_obj.get("Status") )                                  + "\" " + ", " +
                          "\"" + ((null == null )                                                   ? 0 : 0 )                                                      + "\" " + ", " +       /* rec_obj.get("NodeTreeStatus") */
                           "\"" + ((rec_obj.get("PartId") == null)                                   ? 0 : rec_obj.get("PartId") )                                  + "\" " + ", " +
                          "\"" + ((null == null )                                                   ? 0 : 0 )                                                      + "\" " + ", " +       /* rec_obj.get("CommentId") */   
                           "\"" + ((rec_obj.get("PlannedQuantity") == null)                          ? 0 : rec_obj.get("PlannedQuantity") )                         + "\" " + ", " +
                           "\"" + ((rec_obj.get("RestQuantity") == null)                             ? 0 : rec_obj.get("RestQuantity") )                            + "\" " + ", " +
                           "\"" + ((rec_obj.get("StartDate")  == null )                              ? new Date(2021000000) : rec_obj.get("StartDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                          "\"" + ((null == null )                                                   ? 0 : 0 )                                                      + "\" " + ", " +       /* rec_obj.get("ZipFactor") */          
                          "\"" + ((null == null )                                                   ? 0 : 0 )                                                      + "\" " + ", " +       /* rec_obj.get("RevisionId") */    
                          "\"" + ((null == null )                                                   ? 0 : 0 )                                                      + "\" " + ", " +       /* rec_obj.get("PartType") */     
                           "\"" + ((rec_obj.get("ManufacturingOrderNodeId") == null)                 ? 0 : rec_obj.get("ManufacturingOrderNodeId") )                + "\" " + ", " +
                          "\"" + ((null == null )                                                   ? 0 : 0 )                                                      + "\" " + ", " +       /* rec_obj.get("ManufacturingOrderId") */ 
                           "\"" + ((rec_obj.get("EndDate")  == null )                                ? new Date(2021000000) : rec_obj.get("EndDate").toString().substring(0,19).replace('T', ' ')  ) + "\" " + ", " +
                          "\"" + ((null == null )                                                   ? new Date(2021000000) : new Date(2021000000)  )               + "\" " + ", " +       /* rec_obj.get("NewFinishDate") */
                          "\"" + ((null == null )                                                   ? 0 : 0 )                                                      + "\" " + "  " +       /* rec_obj.get("RowNumber") */ 

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );
                          WriteLog.write(conf.getLogFile(), com_stmt, false);


                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "ManufacturingOrderNodes was imported from Monitor API to MySql", false);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getManufacturingOrderNodes








}  // Queries
