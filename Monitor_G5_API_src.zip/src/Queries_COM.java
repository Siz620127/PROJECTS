package sy_my ;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Scanner;
import org.json.simple.JSONObject;
import org.json.simple.JSONArray;
import org.json.simple.JSONValue;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

// -------

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import java.sql.* ;

// import java.sql.Connection;
// import java.sql.Date;
// import java.sql.DriverManager;
// import java.sql.PreparedStatement;
// import java.sql.SQLException;

import java.text.SimpleDateFormat;


public class Queries_COM {



    // TEST START
    public static HttpURLConnection TestQuery(ReadConf conf) throws Exception {
        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals("185.158.177.241");

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end


             // URL url             = new URL( conf.getUrl_sy() );
             URL url                = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "POST" );  // "POST"   "GET"
             con.setRequestProperty("Host", "185.158.177.241"  );
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", "f1bc5219-b382-472e-adc9-ff0926ecbbb0" );



     	     String json = "{\n";
     		 json += "\"Username\": "     +  "\"ADMIN\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"\" "       + ",\n";
		     json += "\"ForceRelogin\": " +  true          + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( response );

   			     return con ;  // response


                 /*
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parse    = new JSONParser();
                 JSONObject data_obj = (JSONObject) parse.parse( json );  // inline
                 //Get the required object from the above created object
                 JSONObject obj = (JSONObject) data_obj.get("Globale");
                 //Get the required data using its key
                 System.out.println(obj.get("TotalRecovered"));
                 JSONArray arr = (JSONArray) data_obj.get("Countries");
                 for (int i = 0; i < arr.size(); i++) {
                      JSONObject new_obj = (JSONObject) arr.get(i);
                      if (new_obj.get("Slug").equals("albania")) {
                         System.out.println("Total Recovered: " + new_obj.get("TotalRecovered"));
                         break;
                      }
                 }
               */

                }


        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() );
        }
        // return con;
    }

    // TEST END




    public static String getAddresses(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Addresses?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".address where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".address (tenant_id , id , " +
                          " Addressee , " +
                          " Field1 , " +
                          " Field2 , " +
                          " Field3 , " +
                          " Field4 , " +
                          " Field5 , " +
                          " Locality , " +
                          " Region , " +
                          " PostalCode , " +
                          " AddressFormatType , " +
                          " CountryId , " +
                          " LanguageId , " +
                          " FormReportTranslationGroupId , " +
                          " PostalCodeId , " +
                          " ParentClass , " +
                          " ParentId , " +
                          " SyncronizationInfo   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Addressee") == null)                      ? 0 : rec_obj.get("Addressee").toString().replaceAll("\"", " ").replaceAll("\\p{Cc}", " ").replaceAll("\\s{2,}", " ")  )   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Field1") == null)                         ? 0 : rec_obj.get("Field1")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Field2") == null)                         ? 0 : rec_obj.get("Field2")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Field3") == null)                         ? 0 : rec_obj.get("Field3")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Field4") == null)                         ? 0 : rec_obj.get("Field4")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Field5") == null)                         ? 0 : rec_obj.get("Field5")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Locality") == null)                       ? 0 : rec_obj.get("Locality")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Region") == null)                         ? 0 : rec_obj.get("Region")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PostalCode") == null)                     ? 0 : rec_obj.get("PostalCode")  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AddressFormatType") == null)              ? 0 : rec_obj.get("AddressFormatType")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CountryId") == null)                      ? 0 : rec_obj.get("CountryId")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("LanguageId") == null)                     ? 0 : rec_obj.get("LanguageId")  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("FormReportTranslationGroupId") == null)   ? 0 : rec_obj.get("FormReportTranslationGroupId")  )     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PostalCodeId") == null)                   ? 0 : rec_obj.get("PostalCodeId")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ParentClass") == null)                    ? 0 : rec_obj.get("ParentClass")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ParentId") == null)                       ? 0 : rec_obj.get("ParentId")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SyncronizationInfo") == null)             ? 0 : rec_obj.get("SyncronizationInfo")  )               + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Address was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getAddresses





    public static String getApplicationUserPrinters(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/ApplicationUserPrinters?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".applicationuserprinter where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".applicationuserprinter (tenant_id , id , " +
                          " PrinterName , " +
                          " ApplicationUserId , " +
                          " ServerPrinterId , " +
                          " FormDocumentType , " +
                          " FormReportType   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("PrinterName") == null)                            ? 0 : rec_obj.get("PrinterName").toString().replaceAll("\"", " ").replaceAll("\\p{Cc}", " ").replaceAll("\\s{2,}", " ")  )   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ApplicationUserId") == null)                      ? 0 : rec_obj.get("ApplicationUserId").toString().replaceAll("\"", " ").replaceAll("\\p{Cc}", " ").replaceAll("\\s{2,}", " ")  )   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ServerPrinterId") == null)                        ? 0 : rec_obj.get("ServerPrinterId")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("FormDocumentType") == null)                       ? 0 : rec_obj.get("FormDocumentType")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("FormReportType") == null)                         ? 0 : rec_obj.get("FormReportType")  )                            + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "ApplicationUserPrinter was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getApplicationUserPrinters





    public static String getApplicationUsers(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/ApplicationUsers?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".applicationuser where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".applicationuser (tenant_id , id , " +
                          " IsInvisible , " +
                          " DefaultRole , " +
                          " DefaultGroup , " +
                          " StartPageConfigurationHolderId , " +
                          " MonthsInPastToIncludeInOverview , " +
                          " SelectedStatisticsOverview , " +
                          " Password , " +
                          " WarehouseId , " +
                          " DefaultCustomerOrderTypeId , " +
                          " DefaultStockCustomerOrderTypeId , " +
                          " DefaultPurchaseOrderTypeId , " +
                          " DefaultStockPurchaseOrderTypeId , " +
                          " DefaultManufacturingOrderTypeId , " +
                          " DefaultQuoteTypeId , " +
                          " DefaultInquiryTypeId , " +
                          " LanguageId , " +
                          " PasswordExpirationDate , " +
                          " DefaultAccountingYear , " +
                          " DefaultCaseManagementType , " +
                          " DefaultProjectTypeId , " +
                          " MailMethod , " +
                          " MailUserName , " +
                          " MailPassword , " +
                          " MailAddress , " +
                          " DefaultPrinter , " +
                          " External1Printer , " +
                          " External2Printer , " +
                          " External3Printer , " +
                          " AllowWebAccess , " +
                          " CanWriteInstructions , " +
                          " EimViewPermissionMode , " +
                          " EimInvoiceInformationViewPermissionId , " +
                          " DefaultVoucherSeriesId , " +
                          " Username , " +
                          " Description , " +
                          " WindowsUserAccountName , " +
                          " CanBeSetAsResponsibleForActivity , " +
                          " PrintoutFormatForParcel  , " +
                          " UseReminderForSupplierInvoicesToBook  , " +
                          " SynchronizePermissionsFromAllWarehouses  , " +
                          " DefaultBlanketOrderPurchaseTypeId  , " +
                          " SynchronizeActivitiesWithCalendar  , " +
                          " PasswordSalt  , " +
                          " DefaultBlanketOrderSalesTypeId  , " +
                          " MailCopyMethod  , " +
                          " UseReminderForSupplierInvoicesToLink  ,  " +
                          " DefaultWebApp  ,  " +
                          " DashboardId  ,  " +
                          " DefaultDeliveryAddressId    " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("IsInvisible") == "false")                         ? 0 : 1  )                                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DefaultRole") == null)                            ? 0 : rec_obj.get("DefaultRole")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DefaultGroup") == null)                           ? 0 : rec_obj.get("DefaultGroup")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("StartPageConfigurationHolderId") == null)         ? 0 : rec_obj.get("StartPageConfigurationHolderId")  )            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("MonthsInPastToIncludeInOverview") == null)        ? 0 : rec_obj.get("MonthsInPastToIncludeInOverview")  )           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SelectedStatisticsOverview") == null)             ? 0 : rec_obj.get("SelectedStatisticsOverview")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Password") == null)                               ? 0 : rec_obj.get("Password")  )                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("WarehouseId") == null)                            ? 0 : rec_obj.get("WarehouseId")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DefaultCustomerOrderTypeId") == null)             ? 0 : rec_obj.get("DefaultCustomerOrderTypeId")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DefaultStockCustomerOrderTypeId") == null)        ? 0 : rec_obj.get("DefaultStockCustomerOrderTypeId")  )           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DefaultPurchaseOrderTypeId") == null)             ? 0 : rec_obj.get("DefaultPurchaseOrderTypeId")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DefaultStockPurchaseOrderTypeId") == null)        ? 0 : rec_obj.get("DefaultStockPurchaseOrderTypeId")  )           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DefaultManufacturingOrderTypeId") == null)        ? 0 : rec_obj.get("DefaultManufacturingOrderTypeId")  )           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DefaultQuoteTypeId") == null)                     ? 0 : rec_obj.get("DefaultQuoteTypeId")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DefaultInquiryTypeId") == null)                   ? 0 : rec_obj.get("DefaultInquiryTypeId")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("LanguageId") == null)                             ? 0 : rec_obj.get("LanguageId")  )                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PasswordExpirationDate") == null      || rec_obj.get("PasswordExpirationDate").toString().substring(0,2).equals("00")  )      ? new Date(2021000000) : rec_obj.get("PasswordExpirationDate").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("DefaultAccountingYear") == null)                  ? 0 : rec_obj.get("DefaultAccountingYear")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DefaultCaseManagementType") == null)              ? 0 : rec_obj.get("DefaultCaseManagementType")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DefaultProjectTypeId") == null)                   ? 0 : rec_obj.get("DefaultProjectTypeId")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("MailMethod") == null)                             ? 0 : rec_obj.get("MailMethod")  )                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("MailUserName") == null)                           ? 0 : rec_obj.get("MailUserName")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("MailPassword") == null)                           ? 0 : rec_obj.get("MailPassword")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("MailAddress") == null)                            ? 0 : rec_obj.get("MailAddress")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DefaultPrinter") == null)                         ? 0 : rec_obj.get("DefaultPrinter")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("External1Printer") == null)                       ? 0 : rec_obj.get("External1Printer")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("External2Printer") == null)                       ? 0 : rec_obj.get("External2Printer")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("External3Printer") == null)                       ? 0 : rec_obj.get("External3Printer")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AllowWebAccess") == "false")                      ? 0 : 1  )                                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CanWriteInstructions") == "false")                ? 0 : 1  )                                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("EimViewPermissionMode") == null)                  ? 0 : rec_obj.get("EimViewPermissionMode")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("EimInvoiceInformationViewPermissionId") == null)  ? 0 : rec_obj.get("EimInvoiceInformationViewPermissionId")  )     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DefaultVoucherSeriesId") == null)                 ? 0 : rec_obj.get("DefaultVoucherSeriesId")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Username") == null)                               ? 0 : rec_obj.get("Username")  )                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                            ? 0 : rec_obj.get("Description")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("WindowsUserAccountName") == null)                 ? 0 : rec_obj.get("WindowsUserAccountName")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CanBeSetAsResponsibleForActivity") == "false")    ? 0 : 1  )                                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PrintoutFormatForParcel") == null)                ? 0 : rec_obj.get("PrintoutFormatForParcel")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("UseReminderForSupplierInvoicesToBook") == "false")     ? 0 : 1  )                                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SynchronizePermissionsFromAllWarehouses") == "false")  ? 0 : 1  )                                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DefaultBlanketOrderPurchaseTypeId") == null)           ? 0 : rec_obj.get("DefaultBlanketOrderPurchaseTypeId")  )    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SynchronizeActivitiesWithCalendar") == null)           ? 0 : rec_obj.get("SynchronizeActivitiesWithCalendar")  )    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PasswordSalt") == null)                                ? 0 : rec_obj.get("PasswordSalt")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DefaultBlanketOrderSalesTypeId") == null)              ? 0 : rec_obj.get("DefaultBlanketOrderSalesTypeId")  )       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("MailCopyMethod") == null)                              ? 0 : rec_obj.get("MailCopyMethod")  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("UseReminderForSupplierInvoicesToLink") == "false")     ? 0 : 1  )                                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DefaultWebApp") == null)                               ? 0 : rec_obj.get("DefaultWebApp")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DashboardId") == null)                                 ? 0 : rec_obj.get("DashboardId")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DefaultDeliveryAddressId") == null)                    ? 0 : rec_obj.get("DefaultDeliveryAddressId")  )             + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "ApplicationUser was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getApplicationUsers





    public static String getAutoCompleteConfigurations(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/AutoCompleteConfigurations?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".autocompleteconfiguration where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".autocompleteconfiguration (tenant_id , id , " +
                          " DescriptionId , " +
                          " PopupTypeId , " +
                          " IsPreset , " +
                          " Description  " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                          ? 0 : rec_obj.get("DescriptionId")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PopupTypeId") == null)                            ? 0 : rec_obj.get("PopupTypeId")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsPreset") == "false")                            ? 0 : 1  )                                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                            ? 0 : rec_obj.get("Description")  )                               + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "AutoCompleteConfiguration was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getAutoCompleteConfigurations







    public static String getBusinessContactBankAccounts(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/BusinessContactBankAccounts?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".businesscontactbankaccount where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".businesscontactbankaccount (tenant_id , id , " +
                          " ClearingNumber , " +
                          " ClearingSystem , " +
                          " CountryId , " +
                          " CentralBankCodeId , " +
                          " CurrencyId , " +
                          " ParentClass , " +
                          " ParentId , " +
                          " Type , " +
                          " Number , " +
                          " BankIdentifierCode , " +
                          " BankAddressId , " +
                          " MainAccountPLNId   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("ClearingNumber") == null)                          ? 0 : rec_obj.get("ClearingNumber")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ClearingSystem") == null)                          ? 0 : rec_obj.get("ClearingSystem")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CountryId") == null)                               ? 0 : rec_obj.get("CountryId")  )                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CentralBankCodeId") == null)                       ? 0 : rec_obj.get("CentralBankCodeId")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CurrencyId") == null)                              ? 0 : rec_obj.get("CurrencyId")  )                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ParentClass") == null)                             ? 0 : rec_obj.get("ParentClass")  )                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ParentId") == null)                                ? 0 : rec_obj.get("ParentId")  )                                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Type") == null)                                    ? 0 : rec_obj.get("Type")  )                                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Number") == null)                                  ? 0 : rec_obj.get("Number")  )                                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BankIdentifierCode") == null)                      ? 0 : rec_obj.get("BankIdentifierCode")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BankAddressId") == null)                           ? 0 : rec_obj.get("BankAddressId")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("MainAccountPLNId") == null)                        ? 0 : rec_obj.get("MainAccountPLNId")  )                           + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "BusinessContactBankAccount was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getBusinessContactBankAccounts




    public static String getBusinessContactNoteHistories(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/BusinessContactNoteHistories?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".businesscontactnotehistory where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".businesscontactnotehistory (tenant_id , id , " +
                          " BodyId , " +
                          " Subject , " +
                          " CreatedByUserId , " +
                          " CreatedTimestamp , " +
                          " ParentClass , " +
                          " ParentId , " +
                          " Body   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("BodyId") == null)                            ? 0 : rec_obj.get("BodyId")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Subject") == null)                           ? 0 : rec_obj.get("Subject")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CreatedByUserId") == null)                   ? 0 : rec_obj.get("CreatedByUserId")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CreatedTimestamp") == null      || rec_obj.get("CreatedTimestamp").toString().substring(0,2).equals("00")  )      ? new Date(2021000000) : rec_obj.get("CreatedTimestamp").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("ParentClass") == null)                       ? 0 : rec_obj.get("ParentClass")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ParentId") == null)                          ? 0 : rec_obj.get("ParentId")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Body") == null)                              ? 0 : rec_obj.get("Body")  )                                 + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "BusinessContactNoteHistory was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getBusinessContactNoteHistories





    public static String getBusinessContactReferences(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/BusinessContactReferences?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".businesscontactreference where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".businesscontactreference (tenant_id , id , " +
                          " Name , " +
                          " ExtraInformation1 , " +
                          " ExtraInformation2 , " +
                          " ExtraInformation3 , " +
                          " Category , " +
                          " Note , " +
                          " CommentId , " +
                          " ParentClass , " +
                          " ParentId , " +
                          " SyncronizationInfo , " +
                          " Code   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Name") == null)                             ? 0 : rec_obj.get("Name")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ExtraInformation1") == null)                ? 0 : rec_obj.get("ExtraInformation1")  )                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ExtraInformation2") == null)                ? 0 : rec_obj.get("ExtraInformation2")  )                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ExtraInformation3") == null)                ? 0 : rec_obj.get("ExtraInformation3")  )                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Category") == null)                         ? 0 : rec_obj.get("Category")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Note") == null)                             ? 0 : rec_obj.get("Note")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CommentId") == null)                        ? 0 : rec_obj.get("CommentId")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ParentClass") == null)                      ? 0 : rec_obj.get("ParentClass")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ParentId") == null)                         ? 0 : rec_obj.get("ParentId")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SyncronizationInfo") == null)               ? 0 : rec_obj.get("SyncronizationInfo")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Code") == null)                             ? 0 : rec_obj.get("Code")  )                               + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "BusinessContactReference was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getBusinessContactReferences






    public static String getCentralBankCodes(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/CentralBankCodes?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".centralbankcode where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".centralbankcode (tenant_id , id , " +
                          " Code , " +
                          " DescriptionId , " +
                          " IsDefault , " +
                          " Description   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Code") == null)                             ? 0 : rec_obj.get("Code")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                    ? 0 : rec_obj.get("DescriptionId")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsDefault") == "false")                     ? 0 : 1  )                                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                      ? 0 : rec_obj.get("Description")  )                        + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "CentralBankCode was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getCentralBankCodes





    public static String getComments(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Comments?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".commenttext where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".commenttext (tenant_id , id , " +
                          " Text , " +
                          " RawText , " +
                          " FileLinkContainerId , " +
                          " ParentClass , " +
                          " ParentId   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Text") == null)                             ? 0 : rec_obj.get("Text").toString().replaceAll("\"", " ").replaceAll("\\p{Cc}", " ").replaceAll("\\s{2,}", " ")  )   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RawText") == null)                          ? 0 : rec_obj.get("RawText").toString().replaceAll("\"", " ").replaceAll("\\p{Cc}", " ").replaceAll("\\s{2,}", " ")  )   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("FileLinkContainerId") == null)              ? 0 : rec_obj.get("FileLinkContainerId")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ParentClass") == null)                      ? 0 : rec_obj.get("ParentClass")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ParentId") == null)                         ? 0 : rec_obj.get("ParentId")  )                           + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "CommentText was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getComments





    public static String getCommunicationAddresses(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/CommunicationAddresses?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".communicationaddress where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".communicationaddress (tenant_id , id , " +
                          " Type , " +
                          " CommunicationAddressValue , " +
                          " Remarks , " +
                          " RecipientOf , " +
                          " EmailSetting , " +
                          " ParentClass , " +
                          " ParentId , " +
                          " SyncronizationInfo , " +
                          " ContactName   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Type") == null)                             ? 0 : rec_obj.get("Type").toString().replaceAll("\"", " ").replaceAll("\\p{Cc}", " ").replaceAll("\\s{2,}", " ")  )   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CommunicationAddressValue") == null)        ? 0 : rec_obj.get("CommunicationAddressValue")  )              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Remarks") == null)                          ? 0 : rec_obj.get("Remarks")  )                                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RecipientOf") == null)                      ? 0 : rec_obj.get("RecipientOf")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("EmailSetting") == null)                     ? 0 : rec_obj.get("EmailSetting")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ParentClass") == null)                      ? 0 : rec_obj.get("ParentClass")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ParentId") == null)                         ? 0 : rec_obj.get("ParentId")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SyncronizationInfo") == null)               ? 0 : rec_obj.get("SyncronizationInfo")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ContactName") == null)                      ? 0 : rec_obj.get("ContactName")  )                            + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "CommunicationAddress was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getCommunicationAddresses






    public static String getCurrencyExchangeRateChangeLogs(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/CurrencyExchangeRateChangeLogs?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".currencyexchangeratelogentry where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".currencyexchangeratelogentry (tenant_id , id , " +
                          " CurrencyId , " +
                          " ExchangeTypeId , " +
                          " LogDate , " +
                          " Rate   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("CurrencyId") == null)              ? 0 : rec_obj.get("CurrencyId")  )              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CurrencyExchangeTypeId") == null)  ? 0 : rec_obj.get("CurrencyExchangeTypeId")  )  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ValidUntilDate") == null      || rec_obj.get("ValidUntilDate").toString().substring(0,2).equals("00")  )      ? new Date(2021000000) : rec_obj.get("ValidUntilDate").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("Rate") == null)                    ? 0 : rec_obj.get("Rate")  )                    + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "CurrencyExchangeRateLogEntry was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getCurrencyExchangeRateChangeLogs





    public static String getCustomReportDefinitions(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/CustomReportDefinitions?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".customreportdefinition where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".customreportdefinition (tenant_id , id , " +
                          " ReportId , " +
                          " ReportNumber , " +
                          " DescriptionId , " +
                          " SectionId , " +
                          " IsDefault , " +
                          " IsPreset , " +
                          " IsAvailableForAll , " +
                          " Downloaded , " +
                          " GeneratedReportNumber   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("ReportId") == null)              ? Id : rec_obj.get("ReportId")  )              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReportNumber") == null)          ? Id : rec_obj.get("ReportNumber")  )          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)         ? 0 : rec_obj.get("DescriptionId")  )         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SectionId") == null)             ? 0 : rec_obj.get("SectionId")  )             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsDefault") == "false")          ? 0 : 1  )                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsPreset") == "false")           ? 0 : 1  )                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsAvailableForAll") == "false")  ? 0 : 1  )                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Downloaded") == "false")         ? 0 : 1  )                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("GeneratedReportNumber") == null) ? 0 : rec_obj.get("GeneratedReportNumber")  ) + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "CustomReportDefinition was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getCustomReportDefinitions





    public static String getCustomReportDisplayDefinitions(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/CustomReportDisplayDefinitions?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".customreportdisplaydefinition where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".customreportdisplaydefinition (tenant_id , id , " +
                          " ParentId , " +
                          " DisplayId , " +
                          " DescriptionId , " +
                          " ReportType , " +
                          " `Sql` , " +
                          " FormReportConfigurationId , " +
                          " GridConfigurationId   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("ParentId") == null)                      ? 0 : rec_obj.get("ParentId")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DisplayId") == null)                     ? 0 : rec_obj.get("DisplayId")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                 ? 0 : rec_obj.get("DescriptionId")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReportType") == null)                    ? 0 : rec_obj.get("ReportType")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Sql") == null)            ? 0 : rec_obj.get("Sql").toString().replaceAll("\"", " ").replaceAll("\\p{Cc}", " ").replaceAll("\\s{2,}", " ")  )   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("FormReportConfigurationId") == null)     ? 0 : rec_obj.get("FormReportConfigurationId")  )         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("GridConfigurationId") == null)           ? 0 : rec_obj.get("GridConfigurationId")  )               + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );
                       // WriteLog.write(conf.getLogFile(), "executeUpdate: \n" + com_stmt   , false );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "CustomReportDisplayDefinition was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getCustomReportDisplayDefinitions





    public static String getDelegatedWork(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/DelegatedWork?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".delegatedwork where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".delegatedwork (tenant_id , id , " +
                          " WorkRecordingType , " +
                          " DelegatedBy , " +
                          " EmployeeId , " +
                          " ActivityId , " +
                          " OperationId  " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("WorkRecordingType") == null)                  ? 0 : rec_obj.get("WorkRecordingType")  )           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DelegatedBy") == null)                        ? 0 : rec_obj.get("DelegatedBy")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("EmployeeId") == null)                         ? 0 : rec_obj.get("EmployeeId")  )                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ActivityId") == null)                         ? 0 : rec_obj.get("ActivityId")  )                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OperationId") == null)                        ? 0 : rec_obj.get("OperationId")  )                 + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );
                       // WriteLog.write(conf.getLogFile(), "executeUpdate: \n" + com_stmt   , false );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "DelegatedWork was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getDelegatedWork




    public static String getDeliveryAddresses(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/DeliveryAddresses?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".deliveryaddress where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".deliveryaddress (tenant_id , id , " +
                          " ConsigneeReferenceId , " +
                          " ConsigneeReferenceName , " +
                          " Destination , " +
                          " DeliveryInstruction , " +
                          " VatRateId , " +
                          " CustomerAccountGroupId , " +
                          " SupplierAccountGroupId , " +
                          " VatGroupId , " +
                          " AddressId , " +
                          " IsDefault , " +
                          " ParentClass , " +
                          " ParentId , " +
                          " SyncronizationInfo   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("ConsigneeReferenceId") == null)             ? 0 : rec_obj.get("ConsigneeReferenceId")  )           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ConsigneeReferenceName") == null)           ? 0 : rec_obj.get("ConsigneeReferenceName")  )         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Destination") == null)                      ? 0 : rec_obj.get("Destination")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DeliveryInstruction") == null)              ? 0 : rec_obj.get("DeliveryInstruction")  )            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("VatRateId") == null)                        ? 0 : rec_obj.get("VatRateId")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CustomerAccountGroupId") == null)           ? 0 : rec_obj.get("CustomerAccountGroupId")  )         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SupplierAccountGroupId") == null)           ? 0 : rec_obj.get("SupplierAccountGroupId")  )         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("VatGroupId") == null)                       ? 0 : rec_obj.get("VatGroupId")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AddressId") == null)                        ? 0 : rec_obj.get("AddressId")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsDefault") == "false")                     ? 0 : 1  )                                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ParentClass") == null)                      ? 0 : rec_obj.get("ParentClass")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ParentId") == null)                         ? 0 : rec_obj.get("ParentId")  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SyncronizationInfo") == null)               ? 0 : rec_obj.get("SyncronizationInfo")  )             + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );
                       // WriteLog.write(conf.getLogFile(), "executeUpdate: \n" + com_stmt   , false );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "DeliveryAddress was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getDeliveryAddresses





    public static String getDeliveryAddressWarehouseInformations(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/DeliveryAddressWarehouseInformations?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".deliveryaddresswarehouseinformation where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".deliveryaddresswarehouseinformation (tenant_id , id , " +
                          " WarehouseId , " +
                          " DeliveryMethodId , " +
                          " DeliveryTermId , " +
                          " TransportTime , " +
                          " DeliveryWeekdays , " +
                          " DestinationForDeliveryTerm , " +
                          " ParentId   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("WarehouseId") == null)                 ? 0 : rec_obj.get("WarehouseId")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DeliveryMethodId") == null)            ? 0 : rec_obj.get("DeliveryMethodId")  )               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DeliveryTermId") == null)              ? 0 : rec_obj.get("DeliveryTermId")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("TransportTime") == null)               ? 0 : rec_obj.get("TransportTime")  )                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DeliveryWeekdays") == null)            ? 0 : rec_obj.get("DeliveryWeekdays")  )               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DestinationForDeliveryTerm") == null)  ? 0 : rec_obj.get("DestinationForDeliveryTerm")  )     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ParentId") == null)                    ? 0 : rec_obj.get("ParentId")  )                       + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );
                       // WriteLog.write(conf.getLogFile(), "executeUpdate: \n" + com_stmt   , false );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "DeliveryAddressWarehouseInformation was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getDeliveryAddressWarehouseInformations





    public static String getDiscountCategories(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/DiscountCategories?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".discountcategory where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".discountcategory (tenant_id , id , " +
                          " Number , " +
                          " DescriptionId , " +
                          " Description  " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Number") == null)                 ? 0 : rec_obj.get("Number")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)          ? 0 : rec_obj.get("DescriptionId")  )             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)            ? 0 : rec_obj.get("Description")  )               + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );
                       // WriteLog.write(conf.getLogFile(), "executeUpdate: \n" + com_stmt   , false );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "DiscountCategory was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getDiscountCategories





    public static String getEntityChangeLogs(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/EntityChangeLogs?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".entitychangelog where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".entitychangelog (tenant_id , id , " +
                          " ChangeType , " +
                          " EntityTypeId , " +
                          " EntityId , " +
                          " ModifiedBy , " +
                          " ModifiedTimestamp , " +
                          " AssociatedTypeId , " +
                          " AssociatedEntityId , " +
                          " EntityCode   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("ChangeType") == null)               ? 0 : rec_obj.get("ChangeType")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("EntityTypeId") == null)             ? 0 : rec_obj.get("EntityTypeId")  )                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("EntityId") == null)                 ? 0 : rec_obj.get("EntityId")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ModifiedBy") == null)               ? 0 : rec_obj.get("ModifiedBy")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ModifiedTimestamp") == null      || rec_obj.get("ModifiedTimestamp").toString().substring(0,2).equals("00")  )      ? new Date(2021000000) : rec_obj.get("ModifiedTimestamp").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("AssociatedTypeId") == null)         ? 0 : rec_obj.get("AssociatedTypeId")  )              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AssociatedEntityId") == null)       ? 0 : rec_obj.get("AssociatedEntityId")  )            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("EntityCode") == null)               ? 0 : rec_obj.get("EntityCode")  )                    + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );
                       // WriteLog.write(conf.getLogFile(), "executeUpdate: \n" + com_stmt   , false );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "EntityChangeLog was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getEntityChangeLogs




    public static String getEntityPropertyChanges(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/EntityPropertyChanges?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".entitypropertychange where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".entitypropertychange (tenant_id , id , " +
                          " MemberName , " +
                          " OldValue , " +
                          " ChangeType , " +
                          " NewValue , " +
                          " EntityChangeLogId   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("MemberName") == null)               ? 0 : rec_obj.get("MemberName").toString().replaceAll("\"", " ").replaceAll("\\p{Cc}", " ").replaceAll("\\s{2,}", " ")  )   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OldValue") == null)                 ? 0 : rec_obj.get("OldValue").toString().replaceAll("\"", " ").replaceAll("\\p{Cc}", " ").replaceAll("\\s{2,}", " ")  )   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ChangeType") == null)               ? 0 : rec_obj.get("ChangeType")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("NewValue") == null)                 ? 0 : rec_obj.get("NewValue").toString().replaceAll("\"", " ").replaceAll("\\p{Cc}", " ").replaceAll("\\s{2,}", " ")  )   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("EntityChangeLogId") == null)        ? 0 : rec_obj.get("EntityChangeLogId")  )             + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );
                       // WriteLog.write(conf.getLogFile(), "executeUpdate: \n" + com_stmt   , false );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "EntityPropertyChange was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getEntityPropertyChanges





    public static String getExtraFieldGroups(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/ExtraFieldGroups?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".extrafieldgroup where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".extrafieldgroup (tenant_id , id , " +
                          " NameId , " +
                          " EntityId , " +
                          " RowNumber , " +
                          " Name   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("NameId") == null)               ? 0 : rec_obj.get("NameId")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("EntityId") == null)             ? 0 : rec_obj.get("EntityId")  )                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RowNumber") == null)            ? 0 : rec_obj.get("RowNumber")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Name") == null)                 ? 0 : rec_obj.get("Name")  )                      + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );
                       // WriteLog.write(conf.getLogFile(), "executeUpdate: \n" + com_stmt   , false );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "ExtraFieldGroup was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getExtraFieldGroups





    public static String getExtraFieldOptionTemplates(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/ExtraFieldOptionTemplates?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".extrafieldoptiontemplate where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".extrafieldoptiontemplate (tenant_id , id , " +
                          " Code , " +
                          " IsActive , " +
                          " RowNumber , " +
                          " DescriptionId , " +
                          " ExtraFieldTemplateId , " +
                          " Description   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Code") == null)                  ? 0 : rec_obj.get("Code")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsActive") == "false")           ? 0 : 1  )                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RowNumber") == null)             ? 0 : rec_obj.get("RowNumber")  )               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)         ? 0 : rec_obj.get("DescriptionId")  )           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ExtraFieldTemplateId") == null)  ? 0 : rec_obj.get("ExtraFieldTemplateId")  )    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)           ? 0 : rec_obj.get("Description")  )             + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );
                       // WriteLog.write(conf.getLogFile(), "executeUpdate: \n" + com_stmt   , false );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "ExtraFieldOptionTemplate was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getExtraFieldOptionTemplates






    public static String getExtraFields(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/ExtraFields?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".extrafield where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".extrafield (tenant_id , id , " +
                          " ParentClass , " +
                          " ParentId , " +
                          " TemplateId , " +
                          " CommentId , " +
                          " DateOnly , " +
                          " DateTime , " +
                          " `Decimal` , " +
                          " `Integer` , " +
                          " `String` , " +
                          " SelectedOption , " +
                          " Identifier , " +
                          " Type , " +
                          " SelectedOptionId , " +
                          " `Comment`   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("ParentClass") == null)                  ? 0 : rec_obj.get("ParentClass")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ParentId") == null)                     ? 0 : rec_obj.get("ParentId")  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("TemplateId") == null)                   ? 0 : rec_obj.get("TemplateId")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CommentId") == null)                    ? 0 : rec_obj.get("CommentId")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DateOnly") == null      || rec_obj.get("DateOnly").toString().substring(0,2).equals("00")  )      ? new Date(2021000000) : rec_obj.get("DateOnly").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("DateTime") == null      || rec_obj.get("DateTime").toString().substring(0,2).equals("00")  )      ? new Date(2021000000) : rec_obj.get("DateTime").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("DecimalValue") == null)                 ? 0 : rec_obj.get("DecimalValue")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IntegerValue") == null)                 ? 0 : rec_obj.get("IntegerValue")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("StringValue") == null)                  ? 0 : rec_obj.get("StringValue")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SelectedOption") == null)               ? 0 : rec_obj.get("SelectedOption")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Identifier") == null)                   ? 0 : rec_obj.get("Identifier")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Type") == null)                         ? 0 : rec_obj.get("Type")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SelectedOptionId") == null)             ? 0 : rec_obj.get("SelectedOptionId")  )               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Comment") == null)                      ? 0 : rec_obj.get("Comment")  )                        + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );
                       // WriteLog.write(conf.getLogFile(), "executeUpdate: \n" + com_stmt   , false );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "ExtraField was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getExtraFields




    public static String getExtraFieldTemplates(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/ExtraFieldTemplates?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".extrafieldtemplate where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".extrafieldtemplate (tenant_id , id , " +
                          " NameId , " +
                          " DescriptionId , " +
                          " Type , " +
                          " ParentId , " +
                          " RowNumber , " +
                          " Identifier , " +
                          " Name , " +
                          " Description   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("NameId") == null)                  ? 0 : rec_obj.get("NameId")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)           ? 0 : rec_obj.get("DescriptionId")  )             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Type") == null)                    ? 0 : rec_obj.get("Type")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ParentId") == null)                ? 0 : rec_obj.get("ParentId")  )                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RowNumber") == null)               ? 0 : rec_obj.get("RowNumber")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Identifier") == null)              ? 0 : rec_obj.get("Identifier")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Name") == null)                    ? 0 : rec_obj.get("Name")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)             ? 0 : rec_obj.get("Description")  )               + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );
                       // WriteLog.write(conf.getLogFile(), "executeUpdate: \n" + com_stmt   , false );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "ExtraFieldTemplate was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getExtraFieldTemplates




    public static String getFilePaths(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/FilePaths?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".filepath where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".filepath (tenant_id , id , " +
                          " Name , " +
                          " Description , " +
                          " Active   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Path") == null)                    ? 0 : rec_obj.get("Path")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)             ? 0 : rec_obj.get("Description")  )             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Active") == "false")               ? 0 : 1  )                                      + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );
                       // WriteLog.write(conf.getLogFile(), "executeUpdate: \n" + com_stmt   , false );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "FilePath was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getFilePaths





    public static String getFormReportConfigurations(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/FormReportConfigurations?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".formreportconfiguration where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".formreportconfiguration (tenant_id , id , " +
                          " IsDefault , " +
                          " Hint , " +
                          " NameId , " +
                          " IsStandard , " +
                          " Definition , " +
                          " DocumentId , " +
                          " IsAdaptation , " +
                          " Type , " +
                          " Name   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("IsDefault") == "false")               ? 0 : 1  )                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Hint") == null)                       ? 0 : rec_obj.get("Hint")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("NameId") == null)                     ? 0 : rec_obj.get("NameId")  )                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsStandard") == "false")              ? 0 : 1  )                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Definition") == null)                 ? 0 : rec_obj.get("Definition")  )              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DocumentId") == null)                 ? 0 : rec_obj.get("DocumentId")  )              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsAdaptation") == "false")            ? 0 : 1  )                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Type") == null)                       ? 0 : rec_obj.get("Type")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Name") == null)                       ? 0 : rec_obj.get("Name")  )                    + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );
                       // WriteLog.write(conf.getLogFile(), "executeUpdate: \n" + com_stmt   , false );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "FormReportConfiguration was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getFormReportConfigurations




    public static String getFormReportTranslationGroups(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/FormReportTranslationGroups?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".formreporttranslationgroup where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".formreporttranslationgroup (tenant_id , id , " +
                          " DocumentFont , " +
                          " IsPreset , " +
                          " DescriptionId , " +
                          " Code , " +
                          " Description   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("DocumentFont") == null)                   ? 0 : rec_obj.get("DocumentFont")  )            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsPreset") == "false")                    ? 0 : 1  )                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                  ? 0 : rec_obj.get("DescriptionId")  )           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Code") == null)                           ? 0 : rec_obj.get("Code")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                    ? 0 : rec_obj.get("Description")  )             + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );
                       // WriteLog.write(conf.getLogFile(), "executeUpdate: \n" + com_stmt   , false );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "FormReportTranslationGroup was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getFormReportTranslationGroups




    public static String getFormReportTranslations(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/FormReportTranslations?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".formreporttranslation where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".formreporttranslation (tenant_id , id , " +
                          " Phrase , " +
                          " PhraseId , " +
                          " FormReportTranslationGroupId   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Phrase") == null)                       ? 0 : rec_obj.get("Phrase")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PhraseId") == null)                     ? 0 : rec_obj.get("PhraseId")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("FormReportTranslationGroupId") == null) ? 0 : rec_obj.get("FormReportTranslationGroupId")  )  + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );
                       // WriteLog.write(conf.getLogFile(), "executeUpdate: \n" + com_stmt   , false );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "FormReportTranslation was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getFormReportTranslations






    public static String getPartConfigurationPresets(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/PartConfigurationPresets?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".partconfigurationpreset where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".partconfigurationpreset (tenant_id , id , " +
                          " Name , " +
                          " ChangedDate , " +
                          " ChangedBy , " +
                          " CreatedDate , " +
                          " CreatedBy , " +
                          " PartConfigurationId   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Name") == null)                       ? 0 : rec_obj.get("Name")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ChangedDate") == null      || rec_obj.get("ChangedDate").toString().substring(0,2).equals("00")  )      ? new Date(2021000000) : rec_obj.get("ChangedDate").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("ChangedBy") == null)                  ? 0 : rec_obj.get("ChangedBy")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CreatedDate") == null      || rec_obj.get("CreatedDate").toString().substring(0,2).equals("00")  )      ? new Date(2021000000) : rec_obj.get("CreatedDate").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("CreatedBy") == null)                  ? 0 : rec_obj.get("CreatedBy")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PartConfigurationId") == null)        ? 0 : rec_obj.get("PartConfigurationId")  )         + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );
                       // WriteLog.write(conf.getLogFile(), "executeUpdate: \n" + com_stmt   , false );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "PartConfigurationPreset was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getPartConfigurationPresets





    public static String getPartConfigurationResults(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/PartConfigurationResults?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".partconfigurationresult where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".partconfigurationresult (tenant_id , id , " +
                          " TemplateId , " +
                          " MainPartId , " +
                          " Quantity , " +
                          " UnitPrice , " +
                          " UnitPriceCurrencyId , " +
                          " StandardPrice , " +
                          " StandardPriceCurrencyId , " +
                          " UnitPriceInCompanyCurrency , " +
                          " UnitPriceInCompanyCurrencyCurrencyId , " +
                          " DiscountPercentage , " +
                          " LockedUnitPrice , " +
                          " LockedDiscount , " +
                          " AlternativePreparationCode , " +
                          " WeightPerUnit , " +
                          " IsValid , " +
                          " PriceFormulaFactor , " +
                          " SnapshotId , " +
                          " PartConfigurationId , " +
                          " PartCalculationId   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("TemplateId") == null)                     ? 0 : rec_obj.get("TemplateId")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("MainPartId") == null)                     ? 0 : rec_obj.get("MainPartId")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Quantity") == null)                       ? 0 : rec_obj.get("Quantity")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("UnitPrice") == null)                      ? 0 : rec_obj.get("UnitPrice")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("UnitPriceCurrencyId") == null)            ? 0 : rec_obj.get("UnitPriceCurrencyId")  )               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("StandardPrice") == null)                  ? 0 : rec_obj.get("StandardPrice")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("StandardPriceCurrencyId") == null)        ? 0 : rec_obj.get("StandardPriceCurrencyId")  )           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("UnitPriceInCompanyCurrency") == null)     ? 0 : rec_obj.get("UnitPriceInCompanyCurrency")  )        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("UnitPriceInCompanyCurrencyCurrencyId") == null)   ? 0 : rec_obj.get("UnitPriceInCompanyCurrencyCurrencyId")  )   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DiscountPercentage") == null)                     ? 0 : rec_obj.get("DiscountPercentage")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("LockedUnitPrice") == "false")                     ? 0 : 1  )                                                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("LockedDiscount") == "false")                      ? 0 : 1  )                                                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AlternativePreparationCode") == null)             ? 0 : rec_obj.get("AlternativePreparationCode")  )             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("WeightPerUnit") == null)                          ? 0 : rec_obj.get("WeightPerUnit")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsValid") == "false")                             ? 0 : 1  )                                                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PriceFormulaFactor") == null)                     ? 0 : rec_obj.get("PriceFormulaFactor")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SnapshotId") == null)                             ? 0 : rec_obj.get("SnapshotId")  )                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PartConfigurationId") == null)                    ? 0 : rec_obj.get("PartConfigurationId")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PartCalculationId") == null)                      ? 0 : rec_obj.get("PartCalculationId")  )                      + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );
                       // WriteLog.write(conf.getLogFile(), "executeUpdate: \n" + com_stmt   , false );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "PartConfigurationResult was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getPartConfigurationResults






    public static String getPartConfigurations(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/PartConfigurations?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".partconfiguration where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".partconfiguration (tenant_id , id , " +
                          " ResultId , " +
                          " CommentId , " +
                          " Comment   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("ResultId") == null)                       ? 0 : rec_obj.get("ResultId")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CommentId") == null)                      ? 0 : rec_obj.get("CommentId")  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Comment") == null)                        ? 0 : rec_obj.get("Comment")  )                         + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );
                       // WriteLog.write(conf.getLogFile(), "executeUpdate: \n" + com_stmt   , false );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "PartConfiguration was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getPartConfigurations






    public static String getPartConfigurationTemplates(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/PartConfigurationTemplates?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".partconfigurationtemplate where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".partconfigurationtemplate (tenant_id , id , " +
                          " Version , " +
                          " Code , " +
                          " DescriptionId , " +
                          " CommentId , " +
                          " Description , " +
                          " Comment   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Version") == null)                       ? 0 : rec_obj.get("Version")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Code") == null)                          ? 0 : rec_obj.get("Code")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                 ? 0 : rec_obj.get("DescriptionId")  )                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CommentId") == null)                     ? 0 : rec_obj.get("CommentId")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                   ? 0 : rec_obj.get("Description")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Comment") == null)                       ? 0 : rec_obj.get("Comment")  )                        + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );
                       // WriteLog.write(conf.getLogFile(), "executeUpdate: \n" + com_stmt   , false );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "PartConfigurationTemplate was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getPartConfigurationTemplates




    public static String getPartUnitUsages(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Accounting/Accounts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Inventory/Parts" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Purchase/Inquiries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Sales/CustomerOrderInvoices" );
             // api/v1/Inventory/QuantityChanges?$top=50000&$orderby=Id%20desc"

              URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/PartUnitUsages?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".partunitusage where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".partunitusage (tenant_id , id , " +
                          " UnitId , " +
                          " IsRemoved , " +
                          " ConversionFactor , " +
                          " UsageType , " +
                          " PartId   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("UnitId") == null)                       ? 0 : rec_obj.get("UnitId")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsRemoved") == "false")                 ? 0 : 1  )                                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ConversionFactor") == null)             ? 0 : rec_obj.get("ConversionFactor")  )              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("UsageType") == null)                    ? 0 : rec_obj.get("UsageType")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PartId") == null)                       ? 0 : rec_obj.get("PartId")  )                        + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );
                       // WriteLog.write(conf.getLogFile(), "executeUpdate: \n" + com_stmt   , false );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "PartUnitUsage was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getPartUnitUsages















    public static String getPersons(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Persons"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".person where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".person (tenant_id , id , " +
                          " MachineIntegrationType, " +
                          " MachineIntegrationLinkedToWorkCenterId, " +
                          " ManualWorkLinkedToWorkCenterId, " +
                          " ReportInterval, " +
                          " TimeIntervalForLoadingToOrder, " +
                          " ReportQtyWhenFullPalletIsManufactured, " +
                          " MachineUniqueTimeForShortStops, " +
                          " ReportPiecesAtEndSetup, " +
                          " SuggestRestAsRejects, " +
                          " LockPossibilityToManuallyChangeRejection, " +
                          " StartSetupTimeAutomaticallyWhenLoadingNewOrder, " +
                          " CheckSetupWhenLoadingNewOrder,  " +
                          " DefaultRejectionCodeId,  " +
                          " MachineUniqueIndirectWorkCodeIdForShortStops, " +
                          " MachineUniqueIndirectWorkCodeIdWhenRunningWithoutOrder, " +
                          " UnauthorizedPlannedAbsenceReminderId, " +
                          " EmployeeRecordingType, " +

                           " EmployeeNumber, " +
                           " IsReference,  " +
                           " IsPurchaseManager, " +

                           " IsProjectManager, " +

                           " IsPlanner, " +
                           " IsAccountManager, " +
                           " Contact, " +
                           " ContactPhoneNumber, " +
                           " ContactCellPhoneNumber, " +
                           " ContactEmailAddress, " +
                           " CommentId, " +
                           " IsPersonBlocked, " +
                           " PersonBlockedById, " +
                           " PersonBlockedDate, " +
                           " CanAuthorize, " +
                           " IsSeller, " +
                           " Initials, " +

                           " SignatureId, " +

                           " DepartmentId, " +
                           " DistrictId, " +
                           " LanguageId, " +
                           " WarehouseId, " +
                           " Category, " +
                           " IdentityNumber, " +
                           " GroupSettingsId, " +

                           " WorkMethod, " +
                           " AvailableWorkRecordingMethods, " +
                           " DefaultWorkRecordingMethod, " +
                           " LinkCodesToWorkCenter, " +
                           " LinkCodesToDepartment, " +

                           " UseWorkCenterManufacturingPrintSettings, " +

                           " PrintTransportLabel, " +
                           " AutoPrintShopPacket, " +
                           " SuggestRest, " +
                           " ShowMaterialsTab, " +
                           " ShowOperationsTab, " +
                           " ShowMessageTab, " +
                           " ShowOrderAdditionalTextTab, " +
                           " AllowManualMaterialReporting, " +
                           " AllowAddMaterial, " +
                           " ShowGoodsLocation, " +
                           " ShowPartLocation, " +
                           " ShowMultiplePartLocations, " +
                           " PartialReportingAtOut, " +
                           " ReportOfWhichSetupTime, " +
                           " ReportOfWhichTimeAgainstCode, " +
                           " DefaultFilterInPriorityPlan, " +
                           " LockFilterInPriorityPlan, " +
                           " PasswordType, " +
                           " Password, " +
                           " ScheduleManagementType, " +
                           " LastOperatorId, " +

                           " PhoneNumber, " +
                           " CellPhoneNumber, " +

                           " InternalPhoneNumber, " +
                           " PrivateCellPhoneNumber, " +
                           " PrivatePhoneNumber, " +

                           " EmailAddress, " +
                           " SkypeId, " +
                           " FaxNumber, " +
                           " Position, " +
                           " ApplicationUserId, " +

                           " PhotoId, " +

                           " FirstName, " +
                           " LastName, " +
                           " AddressId, " +
                           " BlockedContextType, " +
                           " BlockedFromDate, " +
                           " BlockedToDate, " +

                           " BlockedById, " +
                           " BlockedStatus, " +
                           " BlockMessageId, " +
                           " MandatoryToReportAllProducedParts " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("MachineIntegrationType") == null)                     ? 0 : rec_obj.get("MachineIntegrationType")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("MachineIntegrationLinkedToWorkCenterId") == null)     ? 0 : rec_obj.get("MachineIntegrationLinkedToWorkCenterId")  )         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ManualWorkLinkedToWorkCenterId") == null)             ? 0 : rec_obj.get("ManualWorkLinkedToWorkCenterId")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReportInterval") == "false")                          ? 0 : 1  )                                                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("TimeIntervalForLoadingToOrder") == null)              ? 0 : rec_obj.get("TimeIntervalForLoadingToOrder")  )                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReportQtyWhenFullPalletIsManufactured") == "false")   ? 0 : 1  )                                                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("MachineUniqueTimeForShortStops") == null)             ? 0 : rec_obj.get("MachineUniqueTimeForShortStops")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReportPiecesAtEndSetup") == "false")                  ? 0 : 1  )                                                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SuggestRestAsRejects") == "false")                    ? 0 : 1  )                                                             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("LockPossibilityToManuallyChangeRejection") == "false")  ? 0 : 1  )                                                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("StartSetupTimeAutomaticallyWhenLoadingNewOrder") == "false")  ? 0 : 1  )                                                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CheckSetupWhenLoadingNewOrder") == "false")                   ? 0 : 1  )                                                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DefaultRejectionCodeId") == null)                             ? 0 : rec_obj.get("DefaultRejectionCodeId")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("MachineUniqueIndirectWorkCodeIdForShortStops") == null)       ? 0 : rec_obj.get("MachineUniqueIndirectWorkCodeIdForShortStops")  )      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("MachineUniqueIndirectWorkCodeIdWhenRunningWithoutOrder") == null)    ? 0 : rec_obj.get("MachineUniqueIndirectWorkCodeIdWhenRunningWithoutOrder")  )      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("UnauthorizedPlannedAbsenceReminderId") == null)                      ? 0 : rec_obj.get("UnauthorizedPlannedAbsenceReminderId")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("EmployeeRecordingType") == null)                                     ? 0 : rec_obj.get("EmployeeRecordingType")  )                                       + "\" "    + ", " +

                          "\"" + ((rec_obj.get("EmployeeNumber") == null)                                            ? 0 : rec_obj.get("EmployeeNumber")  )                                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsReference") == "false")                                            ? 0 : 1  )                                                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsPurchaseManager") == "false")                                      ? 0 : 1  )                                                                          + "\" "    + ", " +

                          "\"" + ((rec_obj.get("IsProjectManager") == "false")                                       ? 0 : 1  )                                                                          + "\" "    + ", " +

                          "\"" + ((rec_obj.get("IsPlanner")         == "false")                                      ? 0 : 1  )                                                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsAccountManager")  == "false")                                      ? 0 : 1  )                                                                          + "\" "    + ", " +

                          "\"" + ((rec_obj.get("Contact") == null)                                                   ? 0 : rec_obj.get("Contact")  )                                                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ContactPhoneNumber") == null)                                        ? 0 : rec_obj.get("ContactPhoneNumber")  )                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ContactCellPhoneNumber") == null)                                    ? 0 : rec_obj.get("ContactCellPhoneNumber")  )                                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ContactEmailAddress") == null)                                       ? 0 : rec_obj.get("ContactEmailAddress")  )                                         + "\" "    + ", " +

                          "\"" + ((rec_obj.get("CommentId") == null)                                                 ? 0 : rec_obj.get("CommentId") )                                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsPersonBlocked")   == "false")                                      ? 0 : 1  )                                                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PersonBlockedById") == null)                                         ? 0 : rec_obj.get("PersonBlockedById") )                                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PersonBlockedDate") == null      || rec_obj.get("PersonBlockedDate").toString().substring(0,2).equals("00")  )      ? new Date(2021000000) : rec_obj.get("PersonBlockedDate").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("CanAuthorize")      == "false")                                      ? 0 : 1  )                                                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsSeller")          == "false")                                      ? 0 : 1  )                                                                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Initials") == null)                                                  ? 0 : rec_obj.get("Initials") )                                                     + "\" "    + ", " +


                          "\"" + ((rec_obj.get("SignatureId") == null)                                               ? 0 : rec_obj.get("SignatureId") )                                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DepartmentId") == null)                                              ? 0 : rec_obj.get("DepartmentId") )                                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DistrictId")   == null )                                             ? 0 : rec_obj.get("DistrictId")  )                                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("LanguageId")   == null )                                             ? 0 : rec_obj.get("LanguageId")  )                                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("WarehouseId")  == null )                                             ? 0 : rec_obj.get("WarehouseId")  )                                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Category")     == null )                                             ? 0 : rec_obj.get("Category")  )                                                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IdentityNumber")  == null )                                          ? 0 : rec_obj.get("IdentityNumber")  )                                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("GroupSettingsId") == null)                                           ? 0 : rec_obj.get("GroupSettingsId")  )                                             + "\" "    + ", " +

                          "\"" + ((rec_obj.get("WorkMethod") == null)                                                ? 0 : rec_obj.get("WorkMethod")  )                                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("AvailableWorkRecordingMethods") == null)                             ? 0 : rec_obj.get("AvailableWorkRecordingMethods")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DefaultWorkRecordingMethod") == null)                                ? 0 : rec_obj.get("DefaultWorkRecordingMethod")  )                                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("LinkCodesToWorkCenter") == null)                                     ? 0 : rec_obj.get("LinkCodesToWorkCenter")  )                                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("LinkCodesToDepartment") == null)                                     ? 0 : rec_obj.get("LinkCodesToDepartment")  )                                       + "\" "    + ", " +

                          "\"" +  ((rec_obj.get("UseWorkCenterManufacturingPrintSettings") == "false")               ? 0 : 1  )                                                                          + "\" "  + ", " +

                          "\"" +  ((rec_obj.get("PrintTransportLabel") == "false")                                   ? 0 : 1  )                                                                          + "\" "  + ", " +
                          "\"" +  ((rec_obj.get("AutoPrintShopPacket") == "false")                                   ? 0 : 1  )                                                                          + "\" "  + ", " +
                          "\"" +  ((rec_obj.get("SuggestRest")         == "false")                                   ? 0 : 1  )                                                                          + "\" "  + ", " +
                          "\"" +  ((rec_obj.get("ShowMaterialsTab")    == "false")                                   ? 0 : 1  )                                                                          + "\" "  + ", " +
                          "\"" +  ((rec_obj.get("ShowOperationsTab")   == "false")                                   ? 0 : 1  )                                                                          + "\" "  + ", " +
                          "\"" +  ((rec_obj.get("ShowMessageTab")      == "false")                                   ? 0 : 1  )                                                                          + "\" "  + ", " +
                          "\"" +  ((rec_obj.get("ShowOrderAdditionalTextTab")      == "false")                       ? 0 : 1  )                                                                          + "\" "  + ", " +
                          "\"" +  ((rec_obj.get("AllowManualMaterialReporting")    == "false")                       ? 0 : 1  )                                                                          + "\" "  + ", " +
                          "\"" +  ((rec_obj.get("AllowAddMaterial")                == "false")                       ? 0 : 1  )                                                                          + "\" "  + ", " +
                          "\"" +  ((rec_obj.get("ShowGoodsLocation")               == "false")                       ? 0 : 1  )                                                                          + "\" "  + ", " +
                          "\"" +  ((rec_obj.get("ShowPartLocation")                == "false")                       ? 0 : 1  )                                                                          + "\" "  + ", " +
                          "\"" +  ((rec_obj.get("ShowMultiplePartLocations")       == "false")                       ? 0 : 1  )                                                                          + "\" "  + ", " +
                          "\"" +  ((rec_obj.get("PartialReportingAtOut")           == "false")                       ? 0 : 1  )                                                                          + "\" "  + ", " +
                          "\"" +  ((rec_obj.get("ReportOfWhichSetupTime")          == "false")                       ? 0 : 1  )                                                                          + "\" "  + ", " +
                          "\"" +  ((rec_obj.get("ReportOfWhichTimeAgainstCode")    == "false")                       ? 0 : 1  )                                                                          + "\" "  + ", " +
                          "\"" +  ((rec_obj.get("DefaultFilterInPriorityPlan") == null)                              ? 0 : rec_obj.get("DefaultFilterInPriorityPlan")  )                                 + "\" "  + ", " +
                          "\"" +  ((rec_obj.get("LockFilterInPriorityPlan")        == "false")                       ? 0 : 1  )                                                                          + "\" "  + ", " +
                          "\"" +  ((rec_obj.get("PasswordType") == null)                                             ? 0 : rec_obj.get("PasswordType")  )                                                + "\" "  + ", " +
                          "\"" +  ((rec_obj.get("Password") == null)                                                 ? 0 : rec_obj.get("Password")  )                                                    + "\" "  + ", " +
                          "\"" +  ((rec_obj.get("ScheduleManagementType") == null)                                   ? 0 : rec_obj.get("ScheduleManagementType")  )                                      + "\" "  + ", " +
                          "\"" +  ((rec_obj.get("LastOperatorId") == null)                                           ? 0 : rec_obj.get("LastOperatorId")  )                                              + "\" "  + ", " +

                          "\"" +  ((rec_obj.get("PhoneNumber") == null)                                              ? 0 : rec_obj.get("PhoneNumber")  )                                                 + "\" "  + ", " +
                          "\"" +  ((rec_obj.get("CellPhoneNumber") == null)                                          ? 0 : rec_obj.get("CellPhoneNumber")  )                                             + "\" "  + ", " +
                          "\"" +  ((rec_obj.get("InternalPhoneNumber") == null)                                      ? 0 : rec_obj.get("InternalPhoneNumber")  )                                         + "\" "  + ", " +

                          "\"" +  ((rec_obj.get("PrivateCellPhoneNumber") == null)                                   ? 0 : rec_obj.get("PrivateCellPhoneNumber")  )                                      + "\" "  + ", " +
                          "\"" +  ((rec_obj.get("PrivatePhoneNumber") == null)                                       ? 0 : rec_obj.get("PrivatePhoneNumber")  )                                          + "\" "  + ", " +

                          "\"" +  ((rec_obj.get("EmailAddress") == null)                                             ? 0 : rec_obj.get("EmailAddress")  )                                                + "\" "  + ", " +
                          "\"" +  ((rec_obj.get("SkypeId") == null)                                                  ? 0 : rec_obj.get("SkypeId")  )                                                     + "\" "  + ", " +
                          "\"" +  ((rec_obj.get("FaxNumber") == null)                                                ? 0 : rec_obj.get("FaxNumber")  )                                                   + "\" "  + ", " +
                          "\"" +  ((rec_obj.get("Position") == null)                                                 ? 0 : rec_obj.get("Position")  )                                                    + "\" "  + ", " +

                          "\"" + ((rec_obj.get("ApplicationUserId")   == null )                                      ? 0 : rec_obj.get("ApplicationUserId")  )                                           + "\" "  + ", " +

                          "\"" +  ((rec_obj.get("PhotoId") == null)                                                  ? 0 : rec_obj.get("PhotoId")  )                                                     + "\" "  + ", " +

                          "\"" +  ((rec_obj.get("FirstName") == null)                                                ? 0 : rec_obj.get("FirstName")  )                                                   + "\" "  + ", " +
                          "\"" +  ((rec_obj.get("LastName") == null)                                                 ? 0 : rec_obj.get("LastName")  )                                                    + "\" "  + ", " +
                          "\"" +  ((rec_obj.get("AddressId") == null)                                                ? 0 : rec_obj.get("AddressId")  )                                                   + "\" "  + ", " +
                          "\"" +  ((rec_obj.get("BlockedContextType") == null)                                       ? 0 : rec_obj.get("BlockedContextType")  )                                          + "\" "  + ", " +

                          "\"" + ((rec_obj.get("BlockedFromDate") == null      || rec_obj.get("BlockedFromDate").toString().substring(0,2).equals("00")  )      ? new Date(2021000000) : rec_obj.get("BlockedFromDate").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("BlockedToDate") == null        || rec_obj.get("BlockedToDate").toString().substring(0,2).equals("00")  )        ? new Date(2021000000) : rec_obj.get("BlockedToDate").toString().substring(0,19).replace('T', ' ')  )        + "\" " + ", " +

                          "\"" +  ((rec_obj.get("BlockedById") == null)                                              ? 0 : rec_obj.get("BlockedById")  )                                                 + "\" "  + ", " +
                          "\"" +  ((rec_obj.get("BlockedStatus") == null)                                            ? 0 : rec_obj.get("BlockedStatus")  )                                               + "\" "  + ", " +
                          "\"" +  ((rec_obj.get("BlockMessageId") == null)                                           ? 0 : rec_obj.get("BlockMessageId")  )                                              + "\" "  + ", " +

                          "\"" +  ((rec_obj.get("MandatoryToReportAllProducedParts") == "false")                     ? 0 : 1  )                                                                          + "\" "  + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Person was imported from Monitor API to MySql. " + rs_count + " records "   , true);


                 /*
                 //Get the required object from the above created object
                 Object obj   =  data_obj.get("SessionId");  // Language
                 //JSONValue  sesId = (JSONValue)  data_obj.get("SessionId") ;

                 String sesId = obj.toString() ;
                 //String sesId = data_obj.get("SessionId")  ; // .getAsString()

                 System.out.println("obj  \n " +  sesId );
                 // java.lang.String cannot be cast to org.json.simple.JSONValue

                 //Get the required data using its key
                 */

                 /*
                 System.out.println(obj.get("Code"));
                 JSONArray arr = (JSONArray) data_obj.get("ActiveSessions");
                 for (int i = 0; i < arr.size(); i++) {
                      JSONObject new_obj = (JSONObject) arr.get(i);
                      if (new_obj.get("Slug").equals("albania")) {
                         System.out.println("Total Recovered: " + new_obj.get("TotalRecovered"));
                         break;
                      }
                 }
                 */
   			     return Id   ;  // con   response


                 /*
                 //Using the JSON simple library parse the string into a json object
                 JSONParser parse    = new JSONParser();
                 JSONObject data_obj = (JSONObject) parse.parse( json );  // inline
                 //Get the required object from the above created object
                 JSONObject obj = (JSONObject) data_obj.get("Globale");
                 //Get the required data using its key
                 System.out.println(obj.get("TotalRecovered"));
                 JSONArray arr = (JSONArray) data_obj.get("Countries");
                 for (int i = 0; i < arr.size(); i++) {
                      JSONObject new_obj = (JSONObject) arr.get(i);
                      if (new_obj.get("Slug").equals("albania")) {
                         System.out.println("Total Recovered: " + new_obj.get("TotalRecovered"));
                         break;
                      }
                 }
               */

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getPersons




    public static String getPersonManufacturingPrintSettings(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/PersonManufacturingPrintSettings?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".personmanufacturingprintsettings where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".personmanufacturingprintsettings (tenant_id , id , " +
                          " PersonId , " +
                          " Copies , " +
                          " PrintExternalDocuments , " +
                          " FormReportId     " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("PersonId") == null)                       ? 0 : rec_obj.get("PersonId")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Copies") == null)                         ? 0 : rec_obj.get("Copies")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PrintExternalDocuments") == "false")      ? 0 : 1  )                                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("FormReportId") == null)                   ? 0 : rec_obj.get("FormReportId")  )                  + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "PersonManufacturingPrintSetting was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getPersonManufacturingPrintSettings




    public static String getPriceLists(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/PriceLists?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".pricelist where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".pricelist (tenant_id , id , " +
                          " DescriptionId , " +
                          " ConversionFactor , " +
                          " ParentPriceListId , " +
                          " CurrencyId , " +
                          " Number , " +
                          " PriceListBasis , " +
                          " Description   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                     ? 0 : rec_obj.get("DescriptionId")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ConversionFactor") == null)                  ? 0 : rec_obj.get("ConversionFactor")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ParentPriceListId") == null)                 ? 0 : rec_obj.get("ParentPriceListId")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CurrencyId") == null)                        ? 0 : rec_obj.get("CurrencyId")  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Number") == null)                            ? 0 : rec_obj.get("Number")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PriceListBasis") == null)                    ? 0 : rec_obj.get("PriceListBasis")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                       ? 0 : rec_obj.get("Description")  )                      + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "PriceList was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getPriceLists





    public static String getProbabilities(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Probabilities?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".probability where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".probability (tenant_id , id , " +
                          " Number , " +
                          " DescriptionId , " +
                          " Percentage , " +
                          " IsPreset , " +
                          " Description   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Number") == null)                     ? 0 : rec_obj.get("Number")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)              ? 0 : rec_obj.get("DescriptionId")  )             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Percentage") == null)                 ? 0 : rec_obj.get("Percentage")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsPreset") == "false")                ? 0 : 1  )                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                ? 0 : rec_obj.get("Description")  )               + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Probability was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getProbabilities




    public static String getProductGroups(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/ProductGroups?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".productgroup where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".productgroup (tenant_id , id , " +
                          " Number , " +
                          " DescriptionId , " +
                          " Alias , " +
                          " IsDefault , " +
                          " Description   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Number") == null)                     ? 0 : rec_obj.get("Number")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)              ? 0 : rec_obj.get("DescriptionId")  )             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Alias") == null)                      ? 0 : rec_obj.get("Alias")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsDefault") == "false")               ? 0 : 1  )                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                ? 0 : rec_obj.get("Description")  )               + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "ProductGroup was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getProductGroups






    public static String getProjectActivities(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/ProjectActivities?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".projectactivity where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".projectactivity (tenant_id , id , " +
                          " Number , " +
                          " ReportedTimeInHours , " +
                          " RestTimeInHours , " +
                          " PlannedTimeInHours , " +
                          " ShowInProjectReport , " +
                          " ParentId , " +
                          " LockedDelegateWork , " +
                          " ActivityTypeId , " +
                          " CompletedByUserId , " +
                          " ResponsibleUserId , " +
                          " DescriptionId , " +
                          " CommentId , " +
                          " Status , " +
                          " ReminderId , " +
                          " PlannedCompletionDate , " +
                          " CompletionDate  , " +
                          " PlannedStartDate  , " +
                          " ActualStartDate  , " +
                          " CalendarAppointmentId  , " +
                          " Mandatory  , " +
                          " Description  , " +
                          " Comment   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Number") == null)                     ? 0 : rec_obj.get("Number")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReportedTimeInHours") == null)        ? 0 : rec_obj.get("ReportedTimeInHours")  )       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RestTimeInHours") == null)            ? 0 : rec_obj.get("RestTimeInHours")  )           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PlannedTimeInHours") == null)         ? 0 : rec_obj.get("PlannedTimeInHours")  )        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ShowInProjectReport") == "false")     ? 0 : 1  )                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ParentId") == null)                   ? 0 : rec_obj.get("ParentId")  )                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("LockedDelegateWork") == "false")      ? 0 : 1  )                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ActivityTypeId") == null)             ? 0 : rec_obj.get("ActivityTypeId")  )            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CompletedByUserId") == null)          ? 0 : rec_obj.get("CompletedByUserId")  )         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ResponsibleUserId") == null)          ? 0 : rec_obj.get("ResponsibleUserId")  )         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)              ? 0 : rec_obj.get("DescriptionId")  )             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CommentId") == null)                  ? 0 : rec_obj.get("CommentId")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Status") == null)                     ? 0 : rec_obj.get("Status")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReminderId") == null)                 ? 0 : rec_obj.get("ReminderId")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PlannedCompletionDate") == null      || rec_obj.get("PlannedCompletionDate").toString().substring(0,2).equals("00")  )      ? new Date(2021000000) : rec_obj.get("PlannedCompletionDate").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("CompletionDate") == null             || rec_obj.get("CompletionDate").toString().substring(0,2).equals("00")  )             ? new Date(2021000000) : rec_obj.get("CompletionDate").toString().substring(0,19).replace('T', ' ')  )             + "\" " + ", " +
                          "\"" + ((rec_obj.get("PlannedStartDate") == null           || rec_obj.get("PlannedStartDate").toString().substring(0,2).equals("00")  )           ? new Date(2021000000) : rec_obj.get("PlannedStartDate").toString().substring(0,19).replace('T', ' ')  )           + "\" " + ", " +
                          "\"" + ((rec_obj.get("ActualStartDate") == null            || rec_obj.get("ActualStartDate").toString().substring(0,2).equals("00")  )           ? new Date(2021000000) : rec_obj.get("ActualStartDate").toString().substring(0,19).replace('T', ' ')  )             + "\" " + ", " +
                          "\"" + ((rec_obj.get("CalendarAppointmentId") == null)      ? 0 : rec_obj.get("CalendarAppointmentId")  )     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Mandatory") == "false")               ? 0 : 1  )                                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                ? 0 : rec_obj.get("Description")  )               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Comment") == null)                    ? 0 : rec_obj.get("Comment")  )                   + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "ProjectActivity was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getProjectActivities






    public static String getProjectActivityRelations(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/ProjectActivityRelations?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".projectactivityrelation where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".projectactivityrelation (tenant_id , id , " +
                          " ParentId , " +
                          " DependentOnEntityId , " +
                          " Type , " +
                          " RowIndex   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("ParentId") == null)                   ? 0 : rec_obj.get("ParentId")  )                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DependentOnEntityId") == null)        ? 0 : rec_obj.get("DependentOnEntityId")  )       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Type") == null)                       ? 0 : rec_obj.get("Type")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RowIndex") == null)                   ? 0 : rec_obj.get("RowIndex")  )                  + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "ProjectActivityRelation was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getProjectActivityRelations




    public static String getProjectActivityTypes(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/ProjectActivityTypes?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".projectactivitytype where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".projectactivitytype (tenant_id , id , " +
                          " ResponsibleUserId , " +
                          " PlannedTimeInHours , " +
                          " LeadTimeInDays , " +
                          " QueueTimeInDays , " +
                          " CostTypeId , " +
                          " IsReportedAsDirectTime , " +
                          " IsActive , " +
                          " CommentId , " +
                          " UseReminder , " +
                          " ShowInProjectReport , " +
                          " Code , " +
                          " DescriptionId , " +
                          " Comment , " +
                          " Description   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("ResponsibleUserId") == null)                ? 0 : rec_obj.get("ResponsibleUserId")  )                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PlannedTimeInHours") == null)               ? 0 : rec_obj.get("PlannedTimeInHours")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("LeadTimeInDays") == null)                   ? 0 : rec_obj.get("LeadTimeInDays")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("QueueTimeInDays") == null)                  ? 0 : rec_obj.get("QueueTimeInDays")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CostTypeId") == null)                       ? 0 : rec_obj.get("CostTypeId")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsReportedAsDirectTime") == "false")        ? 0 : 1  )                                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsActive") == "false")                      ? 0 : 1  )                                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CommentId") == null)                        ? 0 : rec_obj.get("CommentId")  )                          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("UseReminder") == "false")                   ? 0 : 1  )                                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ShowInProjectReport") == "false")           ? 0 : 1  )                                                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Code") == null)                             ? 0 : rec_obj.get("Code")  )                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                    ? 0 : rec_obj.get("DescriptionId")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Comment") == null)                          ? 0 : rec_obj.get("Comment")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                      ? 0 : rec_obj.get("Description")  )                        + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "ProjectActivityType was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getProjectActivityTypes






    public static String getProjectAggregates(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/ProjectAggregates?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".projectaggregate where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".projectaggregate (tenant_id , id , " +
                          " ProjectId , " +
                          " CostTypeId , " +
                          " ResultCost , " +
                          " PlannedCost , " +
                          " RestCost , " +
                          " ExpectedResultCost , " +
                          " ResultIncome , " +
                          " PlannedIncome , " +
                          " RestIncome , " +
                          " ExpectedResultIncome , " +
                          " ResultTime , " +
                          " PlannedTime , " +
                          " RestTime , " +
                          " ExpectedResultTime , " +
                          " CalculationTimestamp   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("ProjectId") == null)                    ? 0 : rec_obj.get("ProjectId")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CostTypeId") == null)                   ? 0 : rec_obj.get("CostTypeId")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ResultCost") == null)                   ? 0 : rec_obj.get("ResultCost")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PlannedCost") == null)                  ? 0 : rec_obj.get("PlannedCost")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RestCost") == null)                     ? 0 : rec_obj.get("RestCost")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ExpectedResultCost") == null)           ? 0 : rec_obj.get("ExpectedResultCost")  )            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ResultIncome") == null)                 ? 0 : rec_obj.get("ResultIncome")  )                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PlannedIncome") == null)                ? 0 : rec_obj.get("PlannedIncome")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RestIncome") == null)                   ? 0 : rec_obj.get("RestIncome")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ExpectedResultIncome") == null)         ? 0 : rec_obj.get("ExpectedResultIncome")  )          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ResultTime") == null)                   ? 0 : rec_obj.get("ResultTime")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PlannedTime") == null)                  ? 0 : rec_obj.get("PlannedTime")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RestTime") == null)                     ? 0 : rec_obj.get("RestTime")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ExpectedResultTime") == null)           ? 0 : rec_obj.get("ExpectedResultTime")  )            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CalculationTimestamp") == null      || rec_obj.get("CalculationTimestamp").toString().substring(0,2).equals("00")  )      ? new Date(2021000000) : rec_obj.get("CalculationTimestamp").toString().substring(0,19).replace('T', ' ')  )      + "\" " + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "ProjectAggregate was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getProjectAggregates




    public static String getProjectCostBudgets(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/ProjectCostBudgets?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".projectcostbudget where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".projectcostbudget (tenant_id , id , " +
                          " CostTypeId , " +
                          " Cost , " +
                          " Income , " +
                          " Hours , " +
                          " CommentId , " +
                          " ProjectId , " +
                          " Comment   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("CostTypeId") == null)                  ? 0 : rec_obj.get("CostTypeId")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Cost") == null)                        ? 0 : rec_obj.get("Cost")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Income") == null)                      ? 0 : rec_obj.get("Income")  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Hours") == null)                       ? 0 : rec_obj.get("Hours")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CommentId") == null)                   ? 0 : rec_obj.get("CommentId")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ProjectId") == null)                   ? 0 : rec_obj.get("ProjectId")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Comment") == null)                     ? 0 : rec_obj.get("Comment")  )                      + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "ProjectCostBudget was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getProjectCostBudgets





    public static String getProjectCostForecasts(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/ProjectCostForecasts?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".projectcostforecast where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".projectcostforecast (tenant_id , id , " +
                          " CostTypeId , " +
                          " Cost , " +
                          " Income , " +
                          " Hours , " +
                          " CommentId , " +
                          " ProjectId , " +
                          " Comment   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("CostTypeId") == null)                  ? 0 : rec_obj.get("CostTypeId")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Cost") == null)                        ? 0 : rec_obj.get("Cost")  )                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Income") == null)                      ? 0 : rec_obj.get("Income")  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Hours") == null)                       ? 0 : rec_obj.get("Hours")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CommentId") == null)                   ? 0 : rec_obj.get("CommentId")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ProjectId") == null)                   ? 0 : rec_obj.get("ProjectId")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Comment") == null)                     ? 0 : rec_obj.get("Comment")  )                      + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "ProjectCostForecast was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getProjectCostForecasts




    public static String getProjectCostReportingEntries(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/ProjectCostReportingEntries?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".projectcostreportingentry where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".projectcostreportingentry (tenant_id , id , " +
                          " Number , " +
                          " ProjectId , " +
                          " CostTypeId , " +
                          " Amount , " +
                          " IsIncome , " +
                          " ReportingDate , " +
                          " OurReferenceId , " +
                          " OurReferenceName , " +
                          " WorkCenterId , " +
                          " DepartmentId , " +
                          " CommentId , " +
                          " ActivityId , " +
                          " ReportedTimeInHours , " +
                          " EmployeeId , " +
                          " IsCancelled   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Number") == null)                  ? 0 : rec_obj.get("Number")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ProjectId") == null)               ? 0 : rec_obj.get("ProjectId")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CostTypeId") == null)              ? 0 : rec_obj.get("CostTypeId")  )               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Amount") == null)                  ? 0 : rec_obj.get("Amount")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsIncome") == "false")             ? 0 : 1  )                                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReportingDate") == null      || rec_obj.get("ReportingDate").toString().substring(0,2).equals("00")  )      ? new Date(2021000000) : rec_obj.get("ReportingDate").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("OurReferenceId") == null)          ? 0 : rec_obj.get("OurReferenceId")  )           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OurReferenceName") == null)        ? 0 : rec_obj.get("OurReferenceName")  )         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("WorkCenterId") == null)            ? 0 : rec_obj.get("WorkCenterId")  )             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DepartmentId") == null)            ? 0 : rec_obj.get("DepartmentId")  )             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CommentId") == null)               ? 0 : rec_obj.get("CommentId")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ActivityId") == null)              ? 0 : rec_obj.get("ActivityId")  )               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReportedTimeInHours") == null)     ? 0 : rec_obj.get("ReportedTimeInHours")  )      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("EmployeeId") == null)              ? 0 : rec_obj.get("EmployeeId")  )               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsCancelled") == "false")          ? 0 : 1  )                                       + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "ProjectCostReportingEntry was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getProjectCostReportingEntries




    public static String getProjectCostTypes(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/ProjectCostTypes?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".projectcosttype where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".projectcosttype (tenant_id , id , " +
                          " Number , " +
                          " DescriptionId , " +
                          " Type , " +
                          " Origin , " +
                          " IsActive , " +
                          " HourlyCost , " +
                          " PlannedOrigin , " +
                          " ExpectedResultOrigin , " +
                          " BuiltInType , " +
                          " Description   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Number") == null)                  ? 0 : rec_obj.get("Number")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)           ? 0 : rec_obj.get("DescriptionId")  )            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Type") == null)                    ? 0 : rec_obj.get("Type")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Origin") == null)                  ? 0 : rec_obj.get("Origin")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsActive") == "false")             ? 0 : 1  )                                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("HourlyCost") == null)              ? 0 : rec_obj.get("HourlyCost")  )               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PlannedOrigin") == null)           ? 0 : rec_obj.get("PlannedOrigin")  )            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ExpectedResultOrigin") == null)    ? 0 : rec_obj.get("ExpectedResultOrigin")  )     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BuiltInType") == null)             ? 0 : rec_obj.get("BuiltInType")  )              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)             ? 0 : rec_obj.get("Description")  )              + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "ProjectCostType was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getProjectCostTypes






    public static String getProjectPhases(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/ProjectPhases?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".projectphase where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".projectphase (tenant_id , id , " +
                          " DescriptionId , " +
                          " Number , " +
                          " PhaseTypeId , " +
                          " ResponsibleUserId , " +
                          " ParentId , " +
                          " IsDummy , " +
                          " RowIndex , " +
                          " Description , " +
                          " PhaseType   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)           ? 0 : rec_obj.get("DescriptionId")  )            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Number") == null)                  ? 0 : rec_obj.get("Number")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PhaseTypeId") == null)             ? 0 : rec_obj.get("PhaseTypeId")  )              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ResponsibleUserId") == null)       ? 0 : rec_obj.get("ResponsibleUserId")  )        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ParentId") == null)                ? 0 : rec_obj.get("ParentId")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsDummy") == "false")              ? 0 : 1  )                                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RowIndex") == null)                ? 0 : rec_obj.get("RowIndex")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)             ? 0 : rec_obj.get("Description")  )              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PhaseType") == null)               ? 0 : rec_obj.get("PhaseType")  )                + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "ProjectPhase was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getProjectPhases





    public static String getProjectPhaseTypes(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/ProjectPhaseTypes?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".projectphasetype where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".projectphasetype (tenant_id , id , " +
                          " Number , " +
                          " DescriptionId , " +
                          " ManagerId , " +
                          " Description   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Number") == null)                  ? 0 : rec_obj.get("Number")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)           ? 0 : rec_obj.get("DescriptionId")  )            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ManagerId") == null)               ? 0 : rec_obj.get("ManagerId")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)             ? 0 : rec_obj.get("Description")  )              + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "ProjectPhaseType was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getProjectPhaseTypes





    public static String getProjects(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Projects?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".project where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".project (tenant_id , id , " +
                          " Code , " +
                          " DescriptionId , " +
                          " LongDescription , " +
                          " Status , " +
                          " Priority , " +
                          " InternalCommentId , " +
                          " ExternalCommentId , " +
                          " ProjectTypeId , " +
                          " ProjectManagerId , " +
                          " ActivityTemplateId , " +
                          " StartDate , " +
                          " EndDate , " +
                          " ProjectGroupId , " +
                          " CategoryString , " +
                          " Markup , " +
                          " SellerId , " +
                          " CustomerId , " +
                          " CustomerOrderId , " +
                          " CustomerOrderNumber , " +
                          " CustomerReferenceId , " +
                          " CustomerReferenceName , " +
                          " OurReferenceId , " +
                          " OurReferenceName , " +
                          " ParentProjectId , " +
                          " DimensionGroupId , " +
                          " Description , " +
                          " Seller , " +
                          " CustomerReference , " +
                          " InternalComment , " +
                          " ExternalComment , " +
                          " ProjectType   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Code") == null)                  ? 0 : rec_obj.get("Code")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)         ? 0 : rec_obj.get("DescriptionId")  )          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("LongDescription") == null)       ? 0 : rec_obj.get("LongDescription")  )        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Status") == null)                ? 0 : rec_obj.get("Status")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Priority") == null)              ? 0 : rec_obj.get("Priority")  )               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InternalCommentId") == null)     ? 0 : rec_obj.get("InternalCommentId")  )      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ExternalCommentId") == null)     ? 0 : rec_obj.get("ExternalCommentId")  )      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ProjectTypeId") == null)         ? 0 : rec_obj.get("ProjectTypeId")  )          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ProjectManagerId") == null)      ? 0 : rec_obj.get("ProjectManagerId")  )       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ActivityTemplateId") == null)    ? 0 : rec_obj.get("ActivityTemplateId")  )     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("StartDate") == null      || rec_obj.get("StartDate").toString().substring(0,2).equals("00")  )      ? new Date(2021000000) : rec_obj.get("StartDate").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("EndDate") == null        || rec_obj.get("EndDate").toString().substring(0,2).equals("00")  )        ? new Date(2021000000) : rec_obj.get("EndDate").toString().substring(0,19).replace('T', ' ')  )        + "\" " + ", " +
                          "\"" + ((rec_obj.get("ProjectGroupId") == null)        ? 0 : rec_obj.get("ProjectGroupId")  )         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CategoryString") == null)        ? 0 : rec_obj.get("CategoryString")  )         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Markup") == null)                ? 0 : rec_obj.get("Markup")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SellerId") == null)              ? 0 : rec_obj.get("SellerId")  )               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CustomerId") == null)            ? 0 : rec_obj.get("CustomerId")  )             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CustomerOrderId") == null)       ? 0 : rec_obj.get("CustomerOrderId")  )        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CustomerOrderNumber") == null)   ? 0 : rec_obj.get("CustomerOrderNumber")  )    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CustomerReferenceId") == null)   ? 0 : rec_obj.get("CustomerReferenceId")  )    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CustomerReferenceName") == null) ? 0 : rec_obj.get("CustomerReferenceName")  )  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OurReferenceId") == null)        ? 0 : rec_obj.get("OurReferenceId")  )         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OurReferenceName") == null)      ? 0 : rec_obj.get("OurReferenceName")  )       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ParentProjectId") == null)       ? 0 : rec_obj.get("ParentProjectId")  )        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DimensionGroupId") == null)      ? 0 : rec_obj.get("DimensionGroupId")  )       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)           ? 0 : rec_obj.get("Description")  )            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Seller") == null)                ? 0 : rec_obj.get("Seller")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CustomerReference") == null)     ? 0 : rec_obj.get("CustomerReference")  )      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InternalComment") == null)       ? 0 : rec_obj.get("InternalComment")  )        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ExternalComment") == null)       ? 0 : rec_obj.get("ExternalComment")  )        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ProjectType") == null)           ? 0 : rec_obj.get("ProjectType")  )            + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Project was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getProjects





    public static String getProjectTypes(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/ProjectTypes?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".projecttype where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".projecttype (tenant_id , id , " +
                          " IsActive , " +
                          " BaseType , " +
                          " Markup , " +
                          " OnStandby , " +
                          " RetrieveMaterialCost , " +
                          " RetrieveSubcontractCost   , " +
                          " RetrieveWorkCost , " +
                          " RetrieveMaterialCostFromCustomerOrder , " +
                          " MaterialPriceAlternative , " +
                          " ProjectManagerId , " +
                          " DefaultProjectGroupId , " +
                          " DefaultActivityTemplateId , " +
                          " InternalCommentId , " +
                          " ExternalCommentId , " +
                          " Number , " +
                          " Prefix , " +
                          " DescriptionId , " +
                          " Priority , " +
                          " Visible , " +
                          " IsPreset , " +
                          " Description   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("IsActive") == "false")                              ? 0 : 1  )                                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("BaseType") == null)                                 ? 0 : rec_obj.get("BaseType")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Markup") == null)                                   ? 0 : rec_obj.get("Markup")  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OnStandby") == "false")                             ? 0 : 1  )                                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RetrieveMaterialCost") == "false")                  ? 0 : 1  )                                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RetrieveSubcontractCost") == "false")               ? 0 : 1  )                                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RetrieveWorkCost") == "false")                      ? 0 : 1  )                                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RetrieveMaterialCostFromCustomerOrder") == "false") ? 0 : 1  )                                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("MaterialPriceAlternative") == null)                 ? 0 : rec_obj.get("MaterialPriceAlternative")  )     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ProjectManagerId") == null)                         ? 0 : rec_obj.get("ProjectManagerId")  )             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DefaultProjectGroupId") == null)                    ? 0 : rec_obj.get("DefaultProjectGroupId")  )        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DefaultActivityTemplateId") == null)                ? 0 : rec_obj.get("DefaultActivityTemplateId")  )    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InternalCommentId") == null)                        ? 0 : rec_obj.get("InternalCommentId")  )            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ExternalCommentId") == null)                        ? 0 : rec_obj.get("ExternalCommentId")  )            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Number") == null)                                   ? 0 : rec_obj.get("Number")  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Prefix") == null)                                   ? 0 : rec_obj.get("Prefix")  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                            ? 0 : rec_obj.get("DescriptionId")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Priority") == null)                                 ? 0 : rec_obj.get("Priority")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Visible") == "false")                               ? 0 : 1  )                                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsPreset") == "false")                              ? 0 : 1  )                                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                              ? 0 : rec_obj.get("Description")  )                  + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "ProjectType was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getProjectTypes







    public static String getReasonCodes(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/ReasonCodes?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".reasoncode where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".reasoncode (tenant_id , id , " +
                          " Code , " +
                          " DescriptionId , " +
                          " Type , " +
                          " CommentMandatory , " +
                          " Active , " +
                          " Description   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Code") == null)                                 ? Id : rec_obj.get("Code")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                        ? 0 : rec_obj.get("DescriptionId")  )            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Type") == null)                                 ? 0 : rec_obj.get("Type")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CommentMandatory") == "false")                  ? 0 : 1  )                                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Active") == "false")                            ? 0 : 1  )                                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                          ? 0 : rec_obj.get("Description")  )              + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "ReasonCode was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getReasonCodes



    public static String getRejectionCodeItems(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/RejectionCodeItems?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".rejectioncodeitem where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".rejectioncodeitem (tenant_id , id , " +
                          " Code , " +
                          " DescriptionId , " +
                          " Type , " +
                          " Active , " +
                          " ForcedComment , " +
                          " RejectionOnly , " +
                          " Description   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Code") == null)                                 ? 0 : rec_obj.get("Code")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                        ? 0 : rec_obj.get("DescriptionId")  )            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Type") == null)                                 ? 0 : rec_obj.get("Type")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Active") == "false")                            ? 0 : 1  )                                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ForcedComment") == "false")                     ? 0 : 1  )                                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RejectionOnly") == "false")                     ? 0 : 1  )                                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                          ? 0 : rec_obj.get("Description")  )              + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "RejectionCodeItem was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getRejectionCodeItems




    public static String getResellers(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Resellers?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".reseller where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".reseller (tenant_id , id , " +
                          " Code , " +
                          " Name , " +
                          " Provision   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Code") == null)                                 ? 0 : rec_obj.get("Code")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Name") == null)                                 ? 0 : rec_obj.get("Name")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Provision") == null)                            ? 0 : rec_obj.get("Provision")  )                + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Reseller was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getResellers




    public static String getRevisions(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Revisions?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".revision where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".revision (tenant_id , id , " +
                          " Number , " +
                          " ValidFrom , " +
                          " CommentId , " +
                          " PartId , " +
                          " RowIndex , " +
                          " Comment   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Number") == null)                              ? 0 : rec_obj.get("Number")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ValidFrom") == null      || rec_obj.get("ValidFrom").toString().substring(0,2).equals("00")  )      ? new Date(2021000000) : rec_obj.get("ValidFrom").toString().substring(0,19).replace('T', ' ')  )      + "\" " + ", " +
                          "\"" + ((rec_obj.get("CommentId") == null)                           ? 0 : rec_obj.get("CommentId")  )                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PartId") == null)                              ? 0 : rec_obj.get("PartId")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RowIndex") == null)                            ? 0 : rec_obj.get("RowIndex")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Comment") == null)                             ? 0 : rec_obj.get("Comment")  )                    + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Revision was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getRevisions






    public static String getServerPrinters(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/ServerPrinters?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".serverprinter where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".serverprinter (tenant_id , id , " +
                          " Number , " +
                          " DescriptionId , " +
                          " Name , " +
                          " Orientation , " +
                          " DuplexMode , " +
                          " PaperSize , " +
                          " Width , " +
                          " Height , " +
                          " ColorMode , " +
                          " Description   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Number") == null)                              ? 0 : rec_obj.get("Number")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                       ? 0 : rec_obj.get("DescriptionId")  )              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Name") == null)                                ? 0 : rec_obj.get("Name")  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Orientation") == null)                         ? 0 : rec_obj.get("Orientation")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DuplexMode") == null)                          ? 0 : rec_obj.get("DuplexMode")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PaperSize") == null)                           ? 0 : rec_obj.get("PaperSize")  )                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Width") == null)                               ? 0 : rec_obj.get("Width")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Height") == null)                              ? 0 : rec_obj.get("Height")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ColorMode") == null)                           ? 0 : rec_obj.get("ColorMode")  )                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                         ? 0 : rec_obj.get("Description")  )                + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "ServerPrinter was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getServerPrinters





    public static String getStaggeredPrices(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/StaggeredPrices?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".staggeredprice where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".staggeredprice (tenant_id , id , " +
                          " PartId , " +
                          " Price , " +
                          " LowerBoundaryQuantity , " +
                          " FuturePrice , " +
                          " ShippingPrice , " +
                          " ParentClass , " +
                          " ParentId   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("PartId") == null)                              ? 0 : rec_obj.get("PartId")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Price") == null)                               ? 0 : rec_obj.get("Price")  )                      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("LowerBoundaryQuantity") == null)               ? 0 : rec_obj.get("LowerBoundaryQuantity")  )      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("FuturePrice") == null)                         ? 0 : rec_obj.get("FuturePrice")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ShippingPrice") == null)                       ? 0 : rec_obj.get("ShippingPrice")  )              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ParentClass") == null)                         ? 0 : rec_obj.get("ParentClass")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ParentId") == null)                            ? 0 : rec_obj.get("ParentId")  )                   + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "StaggeredPrice was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getStaggeredPrices




    public static String getStatisticalGoodsCodes(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/StatisticalGoodsCodes?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".statisticalgoodscode where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".statisticalgoodscode (tenant_id , id , " +
                          " Code , " +
                          " DescriptionId , " +
                          " DeclarationType , " +
                          " UnitId , " +
                          " Description   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Code") == null)                              ? 0 : rec_obj.get("Code")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                     ? 0 : rec_obj.get("DescriptionId")  )            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DeclarationType") == null)                   ? 0 : rec_obj.get("DeclarationType")  )          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("UnitId") == null)                            ? 0 : rec_obj.get("UnitId")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                       ? 0 : rec_obj.get("Description")  )              + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "StatisticalGoodsCode was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getStatisticalGoodsCodes




    public static String getTariffAndServiceCodes(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/TariffAndServiceCodes?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".tariffandservicecode where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".tariffandservicecode (tenant_id , id , " +
                          " Code , " +
                          " NameId , " +
                          " Type , " +
                          " IsActive , " +
                          " Name   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Code") == null)                              ? 0 : rec_obj.get("Code")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("NameId") == null)                            ? 0 : rec_obj.get("NameId")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Type") == null)                              ? 0 : rec_obj.get("Type")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsActive") == "false")                       ? 0 : 1  )                                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Name") == null)                              ? 0 : rec_obj.get("Name")  )                     + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "TariffAndServiceCode was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getTariffAndServiceCodes





    public static String getTransactionTypeIntrastats(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/TransactionTypeIntrastats?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".transactiontypeintrastat where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".transactiontypeintrastat (tenant_id , id , " +
                          " Number , " +
                          " IsDefault , " +
                          " DescriptionId , " +
                          " Description  " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Number") == null)                              ? 0 : rec_obj.get("Number")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsDefault") == "false")                        ? 0 : 1  )                                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                       ? 0 : rec_obj.get("DescriptionId")  )              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                         ? 0 : rec_obj.get("Description")  )                + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "TransactionTypeIntrastat was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getTransactionTypeIntrastats





    public static String getTransferProfiles(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/TransferProfiles?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".transferprofile where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".transferprofile (tenant_id , id , " +
                          " CompanyId , " +
                          " TargetRole , " +
                          " IsVerified , " +
                          " IsActive , " +
                          " Number , " +
                          " DescriptionId , " +
                          " ConnectionProfileId , " +
                          " RemoteWarehouseId , " +
                          " OrderTransferSettingsId , " +
                          " SupplierId , " +
                          " CustomerCode , " +
                          " Description , " +
                          " Usages   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("CompanyId") == null)                         ? 0 : rec_obj.get("CompanyId")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("TargetRole") == null)                        ? 0 : rec_obj.get("TargetRole")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsVerified") == "false")                     ? 0 : 1  )                                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsActive") == "false")                       ? 0 : 1  )                                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Number") == null)                            ? 0 : rec_obj.get("Number")  )                        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                     ? 0 : rec_obj.get("DescriptionId")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ConnectionProfileId") == null)               ? 0 : rec_obj.get("ConnectionProfileId")  )           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("RemoteWarehouseId") == null)                 ? 0 : rec_obj.get("RemoteWarehouseId")  )             + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OrderTransferSettingsId") == null)           ? 0 : rec_obj.get("OrderTransferSettingsId")  )       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SupplierId") == null)                        ? 0 : rec_obj.get("SupplierId")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CustomerCode") == null)                      ? 0 : rec_obj.get("CustomerCode")  )                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                       ? 0 : rec_obj.get("Description")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Usages") == null)                            ? 0 : rec_obj.get("Usages")  )                        + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "TransferProfile was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getTransferProfiles




    public static String getCalendars(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrders?$filter=isnotnull(StartDate)&StartDate%20Gt%20'2021-10-10'$skip=0&$top=50000&$orderby=Id%20desc" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/WorkCenters" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrderTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrderOperations?$filter=isnotnull(PlannedStartDate)&PlannedStartDate%20Gt%20'2021-10-10'$skip=0&$top=50$orderby=Id%20desc" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrderNodes?$filter=isnotnull(StartDate)&StartDate%20Gt%20'2021-10-10'$skip=0&$top=50$orderby=Id%20desc" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Calendars" );

             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Calendars"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".calendar where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".calendar (tenant_id , id , " +
                          " CalendarType , " +
                          " HolidayType , " +
                          " DescriptionId , " +
                          " Code , " +

                          " Description  " +

                          " ) " +

                          "values ( " +
                          tenant_id                                             + ", " +
                          Id                                                    + ", " +
                           "\"" + ((rec_obj.get("CalendarType") == null)                           ? 0 : rec_obj.get("CalendarType") )                             + "\" " + ", " +
                           "\"" + ((rec_obj.get("HolidayType") == null)                            ? 0 : rec_obj.get("HolidayType") )                              + "\" " + ", " +
                          "\"" + ((null == null)                                                  ? 0 : 0 )                                                        + "\" " + ", " +    /* rec_obj.get("DescriptionId") */
                           "\"" + ((rec_obj.get("Code") == null)                                   ? 0 : rec_obj.get("Code") )                                     + "\" " + ", " +

                          "\"" + ((rec_obj.get("Description") == null)                          ? 0 : rec_obj.get("DescriptionId") )                            + "\" " + "  " +

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );
                       // WriteLog.write(conf.getLogFile(), com_stmt, false);


                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Calendar was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getCalendars






    public static String getCountries(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrders?$filter=isnotnull(StartDate)&StartDate%20Gt%20'2021-10-10'$skip=0&$top=50000&$orderby=Id%20desc" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/WorkCenters" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrderTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrderOperations?$filter=isnotnull(PlannedStartDate)&PlannedStartDate%20Gt%20'2021-10-10'$skip=0&$top=50$orderby=Id%20desc" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrderNodes?$filter=isnotnull(StartDate)&StartDate%20Gt%20'2021-10-10'$skip=0&$top=50$orderby=Id%20desc" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Calendars" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Countries" );

             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Countries"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".country where tenant_id  = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".country (tenant_id , id , " +
                          " Code , " +
                          " IsEuMember , " +
                          " LanguageId , " +
                          " CurrencyId , " +
                          " AddressFormatType , " +
                          " DescriptionId , " +
                          " CustomerAccountGroupId , " +
                          " IsActive , " +
                          " SupplierAccountGroupId , " +
                          " VatRegistrationNumberPrefixException , " +
                          " SupplierVatGroupId , " +
                          " CustomerVatGroupId , " +

                          " CountryRegion , " +
                          " CountrySubRegion , " +
                          " CountryIntermediateRegion , " +

                          " Description , " +
                          " VatGroupId  " +

                          " ) " +

                          "values ( " +
                          tenant_id                                             + ", " +
                          Id                                                    + ", " +
                           "\"" + ((rec_obj.get("Code") == null)                           ? 0 : rec_obj.get("Code") )                                  + "\" " + ", " +
                           "\"" + ((rec_obj.get("IsEuMember") == "false")                  ? 0 : 1 )                                                    + "\" " + ", " +
                           "\"" + ((rec_obj.get("LanguageId") == null)                     ? 0 : rec_obj.get("LanguageId") )                            + "\" " + ", " +
                           "\"" + ((rec_obj.get("CurrencyId") == null)                     ? 0 : rec_obj.get("CurrencyId") )                            + "\" " + ", " +
                           "\"" + ((rec_obj.get("AddressFormatType") == null)              ? 0 : rec_obj.get("AddressFormatType") )                     + "\" " + ", " +
                          "\"" + ((null == null)                                          ? 0 : 0 )                                                    + "\" " + ", " +        /* rec_obj.get("DescriptionId") */
                           "\"" + ((rec_obj.get("CustomerAccountGroupId") == null)         ? 0 : rec_obj.get("CustomerAccountGroupId") )                + "\" " + ", " +
                           "\"" + ((rec_obj.get("IsActive") == "false")                    ? 0 : 1 )                                                    + "\" " + ", " +
                           "\"" + ((rec_obj.get("SupplierAccountGroupId") == null)         ? 0 : rec_obj.get("SupplierAccountGroupId") )                + "\" " + ", " +
                           "\"" + ((rec_obj.get("VatRegistrationNumberPrefixException") == null)   ? 0 : rec_obj.get("VatRegistrationNumberPrefixException") )  + "\" " + ", " +
                           "\"" + ((rec_obj.get("SupplierVatGroupId") == null)             ? 0 : rec_obj.get("SupplierVatGroupId") )                    + "\" " + ", " +
                           "\"" + ((rec_obj.get("CustomerVatGroupId") == null)             ? 0 : rec_obj.get("CustomerVatGroupId") )                    + "\" " + ", " +

                           "\"" + ((rec_obj.get("CountryRegion") == null)                  ? 0 : rec_obj.get("CountryRegion") )                         + "\" " + ", " +
                           "\"" + ((rec_obj.get("CountrySubRegion") == null)               ? 0 : rec_obj.get("CountrySubRegion") )                      + "\" " + ", " +
                           "\"" + ((rec_obj.get("CountryIntermediateRegion") == null)      ? 0 : rec_obj.get("CountryIntermediateRegion") )             + "\" " + ", " +

                           "\"" + ((rec_obj.get("Description") == null)                    ? 0 : rec_obj.get("Description") )                           + "\" " + ", " +
                           "\"" + ((rec_obj.get("VatGroupId") == null)                     ? 0 : rec_obj.get("VatGroupId") )                            + "\" " + "  " +

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );
                       // WriteLog.write(conf.getLogFile(), com_stmt, false);


                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Country was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getCountries







    public static String getCurrencies(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrders?$filter=isnotnull(StartDate)&StartDate%20Gt%20'2021-10-10'$skip=0&$top=50000&$orderby=Id%20desc" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/WorkCenters" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrderTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrderOperations?$filter=isnotnull(PlannedStartDate)&PlannedStartDate%20Gt%20'2021-10-10'$skip=0&$top=50$orderby=Id%20desc" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrderNodes?$filter=isnotnull(StartDate)&StartDate%20Gt%20'2021-10-10'$skip=0&$top=50$orderby=Id%20desc" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Calendars" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Countries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Currencies" );

             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Currencies"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".currency where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".currency (tenant_id , id , " +
                          " DescriptionId , " +
                          " RateFactor , " +
                          " Code , " +
                          " UpdateSettingsId , " +

                          " Description , " +
                          " DefaultSalesExchangeRate , " +
                          " DefaultPurchaseExchangeRate   " +

                          " ) " +

                          "values ( " +
                          tenant_id                                             + ", " +
                          Id                                                    + ", " +
                          "\"" + ((null == null)                                            ? 0 : rec_obj.get("DescriptionId") )                         + "\" " + ", " +    /* rec_obj.get("DescriptionId") */
                           "\"" + ((rec_obj.get("RateFactor") == null)                       ? 0 : rec_obj.get("RateFactor") )                            + "\" " + ", " +
                           "\"" + ((rec_obj.get("Code") == null)                             ? 0 : rec_obj.get("Code") )                                  + "\" " + ", " +
                          "\"" + ((Id   == null)                                            ? 0 : Id )                                                   + "\" " + ",  " +   /* rec_obj.get("UpdateSettingsId") */

                           "\"" + ((rec_obj.get("Description") == null)                      ? 0 : rec_obj.get("Description") )                           + "\" " + ", " +
                           "\"" + ((rec_obj.get("DefaultSalesExchangeRate") == null)         ? 0 : rec_obj.get("DefaultSalesExchangeRate") )              + "\" " + ", " +
                           "\"" + ((rec_obj.get("DefaultPurchaseExchangeRate") == null)      ? 0 : rec_obj.get("DefaultPurchaseExchangeRate") )           + "\" " + "  " +

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );
                       // WriteLog.write(conf.getLogFile(), com_stmt, false);


                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Currency was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getCurrencies






    public static String getCurrencyExchangeRates(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrders?$filter=isnotnull(StartDate)&StartDate%20Gt%20'2021-10-10'$skip=0&$top=50000&$orderby=Id%20desc" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/WorkCenters" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrderTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrderOperations?$filter=isnotnull(PlannedStartDate)&PlannedStartDate%20Gt%20'2021-10-10'$skip=0&$top=50$orderby=Id%20desc" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrderNodes?$filter=isnotnull(StartDate)&StartDate%20Gt%20'2021-10-10'$skip=0&$top=50$orderby=Id%20desc" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Calendars" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Countries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Currencies" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/CurrencyExchangeRates" );

             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/CurrencyExchangeRates?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".currencyexchangerate where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".currencyexchangerate (tenant_id , id , " +
                          " CurrencyExchangeTypeId , " +
                          " Rate , " +
                          " CurrencyId  " +

                          " ) " +

                          "values ( " +
                          tenant_id                                             + ", " +
                          Id                                                    + ", " +
                           "\"" + ((rec_obj.get("CurrencyExchangeTypeId") == null)                   ? 0 : rec_obj.get("CurrencyExchangeTypeId") )                 + "\" " + ", " +
                           "\"" + ((rec_obj.get("Rate") == null)                                     ? 0 : rec_obj.get("Rate") )                                   + "\" " + ", " +
                          "\"" + ((null == null)                                                    ? 0 : 0 )                                                     + "\" " + "  " +     /* rec_obj.get("CurrencyId") */

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );
                      //  WriteLog.write(conf.getLogFile(), com_stmt, false);


                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "CurrencyExchangeRate was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getCurrencyExchangeRates






    public static String getDeliveryMethods(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrders?$filter=isnotnull(StartDate)&StartDate%20Gt%20'2021-10-10'$skip=0&$top=50000&$orderby=Id%20desc" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/WorkCenters" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrderTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrderOperations?$filter=isnotnull(PlannedStartDate)&PlannedStartDate%20Gt%20'2021-10-10'$skip=0&$top=50$orderby=Id%20desc" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrderNodes?$filter=isnotnull(StartDate)&StartDate%20Gt%20'2021-10-10'$skip=0&$top=50$orderby=Id%20desc" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Calendars" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Countries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Currencies" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/CurrencyExchangeRates" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/DeliveryMethods" );

             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/DeliveryMethods?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".deliverymethod where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".deliverymethod (tenant_id , id , " +
                          " MeansOfTransport , " +
                          " DescriptionId , " +
                          " SupplierId , " +
                          " Number , " +
                          " IsDefault , " +
                          " ShippingServiceId , " +
                          " ShippingTemplateId , " +
                          " Code , " +

                          " Description  " +

                          " ) " +

                          "values ( " +
                          tenant_id                                             + ", " +
                          Id                                                    + ", " +
                          "\"" + ((null == null)                                                    ? 0 : 0 )                                               + "\" " + ", " +       /* rec_obj.get("MeansOfTransport") */
                          "\"" + ((null == null)                                                    ? 0 : 0 )                                               + "\" " + ", " +       /* rec_obj.get("DescriptionId") */
                           "\"" + ((rec_obj.get("SupplierId") == null)                               ? 0 : rec_obj.get("SupplierId") )                       + "\" " + ", " +
                           "\"" + ((rec_obj.get("Number") == null)                                   ? 0 : rec_obj.get("Number") )                           + "\" " + ", " +
                           "\"" + ((rec_obj.get("IsDefault") == "false")                             ? 0 : 1 )                                               + "\" " + ", " +
                           "\"" + ((rec_obj.get("ShippingServiceId") == null)                        ? 0 : rec_obj.get("ShippingServiceId") )                + "\" " + ", " +
                           "\"" + ((rec_obj.get("ShippingTemplateId") == null)                       ? 0 : rec_obj.get("ShippingTemplateId") )               + "\" " + ", " +
                          "\"" + ((null == null)                                                    ? 0 : 0 )                                               + "\" " + ", " +       /* rec_obj.get("Code") */

                           "\"" + ((rec_obj.get("Description") == null)                            ? 0 : rec_obj.get("Description") )                        + "\" " + "  " +

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );
                       // WriteLog.write(conf.getLogFile(), com_stmt, false);


                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "DeliveryMethod was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getDeliveryMethods





    public static String getDeliveryTerms(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrders?$filter=isnotnull(StartDate)&StartDate%20Gt%20'2021-10-10'$skip=0&$top=50000&$orderby=Id%20desc" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/WorkCenters" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrderTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrderOperations?$filter=isnotnull(PlannedStartDate)&PlannedStartDate%20Gt%20'2021-10-10'$skip=0&$top=50$orderby=Id%20desc" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrderNodes?$filter=isnotnull(StartDate)&StartDate%20Gt%20'2021-10-10'$skip=0&$top=50$orderby=Id%20desc" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Calendars" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Countries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Currencies" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/CurrencyExchangeRates" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/DeliveryMethods" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/DeliveryTerms" );

             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/DeliveryTerms?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".deliveryterm where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".deliveryterm (tenant_id , id , " +
                          " Destination , " +
                          " TermLocation , " +
                          " TermCode , " +
                          " DescriptionId , " +
                          " Payer , " +
                          " Number , " +
                          " IsDefault , " +
                          " EuIntrastatCode , " +
                          " Code , " +

                          " Description  " +

                          " ) " +

                          "values ( " +
                          tenant_id                                             + ", " +
                          Id                                                    + ", " +
                           "\"" + ((rec_obj.get("Destination") == null)                               ? 0 : rec_obj.get("Destination") )                       + "\" " + ", " +
                           "\"" + ((rec_obj.get("TermLocation") == null)                              ? 0 : rec_obj.get("TermLocation") )                      + "\" " + ", " +
                           "\"" + ((rec_obj.get("TermCode") == null)                                  ? 0 : rec_obj.get("TermCode") )                          + "\" " + ", " +
                          "\"" + ((null == null)                                                     ? 0 : 0 )                                                + "\" " + ", " +    /* rec_obj.get("DescriptionId") */
                           "\"" + ((rec_obj.get("Payer") == null)                                     ? 0 : rec_obj.get("Payer") )                             + "\" " + ", " +
                           "\"" + ((rec_obj.get("Number") == null)                                    ? 0 : rec_obj.get("Number") )                            + "\" " + ", " +
                           "\"" + ((rec_obj.get("IsDefault") == "false")                              ? 0 : 1 )                                                + "\" " + ", " +
                          "\"" + ((null == null)                                                     ? 0 : 0 )                                                + "\" " + ", " +    /* rec_obj.get("EuIntrastatCode")  */
                          "\"" + ((null == null)                                                     ? 0 : 0 )                                                + "\" " + ", " +    /* rec_obj.get("Code") */

                           "\"" + ((rec_obj.get("Description") == null)                             ? 0 : rec_obj.get("Description") )                         + "\" " + "  " +

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );
                       // WriteLog.write(conf.getLogFile(), com_stmt, false);


                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "DeliveryTerm was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getDeliveryTerms





    public static String getDepartments(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrders?$filter=isnotnull(StartDate)&StartDate%20Gt%20'2021-10-10'$skip=0&$top=50000&$orderby=Id%20desc" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/WorkCenters" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrderTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrderOperations?$filter=isnotnull(PlannedStartDate)&PlannedStartDate%20Gt%20'2021-10-10'$skip=0&$top=50$orderby=Id%20desc" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrderNodes?$filter=isnotnull(StartDate)&StartDate%20Gt%20'2021-10-10'$skip=0&$top=50$orderby=Id%20desc" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Calendars" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Countries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Currencies" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/CurrencyExchangeRates" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/DeliveryMethods" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/DeliveryTerms" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Departments" );


             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Departments?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".department where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".department (tenant_id , id , " +
                          " Code , " +
                          " DescriptionId , " +

                          " Description  " +

                          " ) " +

                          "values ( " +
                          tenant_id                                             + ", " +
                          Id                                                    + ", " +
                           "\"" + ((rec_obj.get("Code") == null)                 ? 0 : rec_obj.get("Code") )                       + "\" " + ", " +
                          "\"" + ((null == null)                                ? 0 : 0 )                                         + "\" " + ", " +   /* rec_obj.get("DescriptionId") */

                           "\"" + ((rec_obj.get("Description") == null)          ? 0 : rec_obj.get("Description") )                + "\" " + "  " +

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );
                      //  WriteLog.write(conf.getLogFile(), com_stmt, false);


                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Department was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getDepartments





    public static String getLanguageCodes(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrders?$filter=isnotnull(StartDate)&StartDate%20Gt%20'2021-10-10'$skip=0&$top=50000&$orderby=Id%20desc" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/WorkCenters" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrderTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrderOperations?$filter=isnotnull(PlannedStartDate)&PlannedStartDate%20Gt%20'2021-10-10'$skip=0&$top=50$orderby=Id%20desc" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrderNodes?$filter=isnotnull(StartDate)&StartDate%20Gt%20'2021-10-10'$skip=0&$top=50$orderby=Id%20desc" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Calendars" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Countries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Currencies" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/CurrencyExchangeRates" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/DeliveryMethods" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/DeliveryTerms" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Departments" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/LanguageCodes" );

             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/LanguageCodes?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".languagecode where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".languagecode (tenant_id , id , " +
                          " Code , " +
                          " PhraseId , " +

                          " Phrase  "  +

                          " ) " +

                          "values ( " +
                          tenant_id                                             + ", " +
                          Id                                                    + ", " +
                           "\"" + ((rec_obj.get("Code") == null)                 ? 0 : rec_obj.get("Code") )                       + "\" " + ", " +
                          "\"" + ((rec_obj.get("PhraseId") == null)             ? 0 : rec_obj.get("PhraseId") )                   + "\" " + ", " +

                           "\"" + ((rec_obj.get("Phrase") == null)               ? 0 : rec_obj.get("Phrase") )                     + "\" " + "  " +

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );
                       // WriteLog.write(conf.getLogFile(), com_stmt, false);


                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "LanguageCode was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getLanguageCodes




    public static String getPaymentMethods(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrders?$filter=isnotnull(StartDate)&StartDate%20Gt%20'2021-10-10'$skip=0&$top=50000&$orderby=Id%20desc" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/WorkCenters" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrderTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrderOperations?$filter=isnotnull(PlannedStartDate)&PlannedStartDate%20Gt%20'2021-10-10'$skip=0&$top=50$orderby=Id%20desc" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrderNodes?$filter=isnotnull(StartDate)&StartDate%20Gt%20'2021-10-10'$skip=0&$top=50$orderby=Id%20desc" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Calendars" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Countries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Currencies" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/CurrencyExchangeRates" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/DeliveryMethods" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/DeliveryTerms" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Departments" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/LanguageCodes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/PaymentMethods" );

             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/PaymentMethods?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".paymentmethod where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".paymentmethod (tenant_id , id , " +
                          " Code , " +
                          " DescriptionId , " +
                          " PaymentType , " +
                          " ExporterId , " +
                          " BankWebpage , " +
                          " CustomerIdAtBank , " +
                          " SendPaymentFilePath , " +
                          " SendPaymentDirectoryPath , " +
                          " IsAccountingSeperate , " +
                          " IsActive , " +
                          " TransactionListFormReportConfigurationId , " +
                          " DirectDebit , " +
                          " ReceivingBankAccountValidation , " +
                          " ReceivingGiroAccountValidation , " +
                          " ImporterId , " +
                          " IsChequePayment , " +
                          " CodingAccountCodingEntryId , " +
                          " BankingFeeCodingEntryId , " +
                          " CodingAccountVatCodingEntryId , " +

                          " BankingFeeAccountId , " +
                          " CodingAccountId , " +
                          " Description  " +

                          " ) " +

                          "values ( " +
                          tenant_id                                             + ", " +
                          Id                                                    + ", " +
                           "\"" + ((rec_obj.get("Code") == null)                                        ? 0 : rec_obj.get("Code") )                                         + "\" " + ", " +
                          "\"" + ((null == null)                                                       ? 0 : 0 )                                                           + "\" " + ", " +       /* rec_obj.get("DescriptionId") */
                           "\"" + ((rec_obj.get("PaymentType") == null)                                 ? 0 : rec_obj.get("PaymentType") )                                  + "\" " + ", " +
                          "\"" + ((null == null)                                                       ? 0 : 0 )                                                           + "\" " + ", " +       /* rec_obj.get("ExporterId") */
                           "\"" + ((rec_obj.get("BankWebpage") == null)                                 ? 0 : rec_obj.get("BankWebpage") )                                  + "\" " + ", " +
                           "\"" + ((rec_obj.get("CustomerIdAtBank") == null)                            ? 0 : rec_obj.get("CustomerIdAtBank") )                             + "\" " + ", " +
                           "\"" + ((rec_obj.get("SendPaymentFilePath") == null)                         ? 0 : rec_obj.get("SendPaymentFilePath") )                          + "\" " + ", " +
                           "\"" + ((rec_obj.get("SendPaymentDirectoryPath") == null)                    ? 0 : rec_obj.get("SendPaymentDirectoryPath") )                     + "\" " + ", " +
                          "\"" + (("false" == "false")                                                 ? 0 : 1 )                                                           + "\" " + ", " +       /* rec_obj.get("IsAccountingSeperate") */
                           "\"" + ((rec_obj.get("IsActive") == "false")                                 ? 0 : 1 )                                                           + "\" " + ", " +
                           "\"" + ((rec_obj.get("TransactionListFormReportConfigurationId") == null)    ? 0 : rec_obj.get("TransactionListFormReportConfigurationId") )     + "\" " + ", " +
                          "\"" + (("false" == "false")                                                 ? 0 : 1 )                                                           + "\" " + ", " +       /* rec_obj.get("DirectDebit") */
                           "\"" + ((rec_obj.get("ReceivingBankAccountValidation") == null)              ? 0 : rec_obj.get("ReceivingBankAccountValidation") )               + "\" " + ", " +
                           "\"" + ((rec_obj.get("ReceivingGiroAccountValidation") == null)              ? 0 : rec_obj.get("ReceivingGiroAccountValidation") )               + "\" " + ", " +
                          "\"" + ((null == null)                                                       ? 0 : 0 )                                                           + "\" " + ", " +       /* rec_obj.get("ImporterId") */
                          "\"" + (("false" == "false")                                                 ? 0 : 1 )                                                           + "\" " + ", " +       /* rec_obj.get("IsChequePayment") */
                           "\"" + ((rec_obj.get("CodingAccountCodingEntryId") == null)                  ? 0 : rec_obj.get("CodingAccountCodingEntryId") )                   + "\" " + ", " +
                           "\"" + ((rec_obj.get("BankingFeeCodingEntryId") == null)                     ? 0 : rec_obj.get("BankingFeeCodingEntryId") )                      + "\" " + ", " +
                          "\"" + ((null == null)                                                       ? 0 : 0 )                                                           + "\" " + ", " +       /* rec_obj.get("CodingAccountVatCodingEntryId") */

                           "\"" + ((rec_obj.get("BankingFeeAccountId") == null)                         ? 0 : rec_obj.get("BankingFeeAccountId") )                          + "\" " + ", " +
                           "\"" + ((rec_obj.get("CodingAccountId") == null)                             ? 0 : rec_obj.get("CodingAccountId") )                              + "\" " + ", " +
                           "\"" + ((rec_obj.get("Description") == null)                                 ? 0 : rec_obj.get("Description") )                                  + "\" " + "  " +

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );
                       // WriteLog.write(conf.getLogFile(), com_stmt, false);


                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "PaymentMethod was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getPaymentMethods




    public static String getPaymentTerms(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrders?$filter=isnotnull(StartDate)&StartDate%20Gt%20'2021-10-10'$skip=0&$top=50000&$orderby=Id%20desc" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/WorkCenters" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrderTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrderOperations?$filter=isnotnull(PlannedStartDate)&PlannedStartDate%20Gt%20'2021-10-10'$skip=0&$top=50$orderby=Id%20desc" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrderNodes?$filter=isnotnull(StartDate)&StartDate%20Gt%20'2021-10-10'$skip=0&$top=50$orderby=Id%20desc" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Calendars" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Countries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Currencies" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/CurrencyExchangeRates" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/DeliveryMethods" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/DeliveryTerms" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Departments" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/LanguageCodes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/PaymentMethods" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/PaymentTerms" );

             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/PaymentTerms?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".paymentterm where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".paymentterm (tenant_id , id , " +
                          " GracePeriodInDays , " +
                          " IsFreeDeliveryMonth , " +
                          " DescriptionId , " +
                          " Number , " +
                          " Code , " +
                          " LastDayInMonth , " +
                          " LatePaymentFee , " +
                          " IsDefault , " +
                          " InvoiceType , " +
                          " PaymentMethodId , " +

                          " Description  "  +

                          " ) " +

                          "values ( " +
                          tenant_id                                             + ", " +
                          Id                                                    + ", " +
                           "\"" + ((rec_obj.get("GracePeriodInDays") == null)                                 ? 0 : rec_obj.get("GracePeriodInDays") )                                 + "\" " + ", " +
                           "\"" + ((rec_obj.get("IsFreeDeliveryMonth") == "false")                            ? 0 : 1 )                                                                + "\" " + ", " +
                          "\"" + ((null == null)                                                             ? 0 : 0  )                                                               + "\" " + ", " +     /* DescriptionId */
                           "\"" + ((rec_obj.get("Number") == null)                                            ? 0 : rec_obj.get("Number") )                                            + "\" " + ", " +
                          "\"" + ((null == null)                                                             ? 0 : 0  )                                                               + "\" " + ", " +     /* rec_obj.get("Code") */
                          "\"" + (("false" == "false")                                                       ? 0 : 1  )                                                               + "\" " + ", " +     /* rec_obj.get("LastDayInMonth") */
                          "\"" + (("false" == "false")                                                       ? 0 : 1  )                                                               + "\" " + ", " +     /* rec_obj.get("LatePaymentFee") */
                           "\"" + ((rec_obj.get("IsDefault") == "false")                                      ? 0 : 1  )                                                               + "\" " + ", " +
                           "\"" + ((rec_obj.get("InvoiceType") == null)                                       ? 0 : rec_obj.get("InvoiceType") )                                       + "\" " + ", " +
                           "\"" + ((rec_obj.get("PaymentMethodId") == null)                                   ? 0 : rec_obj.get("PaymentMethodId") )                                   + "\" " + ", " +

                           "\"" + ((rec_obj.get("Description") == null)                                       ? 0 : rec_obj.get("Description") )                                       + "\" " + "  " +

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );
                      //  WriteLog.write(conf.getLogFile(), com_stmt, false);


                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "PaymentTerm was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getPaymentTerms





    public static String getPaymentPlanTemplateRows(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrders?$filter=isnotnull(StartDate)&StartDate%20Gt%20'2021-10-10'$skip=0&$top=50000&$orderby=Id%20desc" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Calendars" );

             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/PaymentPlanTemplateRows?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".paymentplantemplaterow where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".paymentplantemplaterow (tenant_id , id , " +
                          " UnpaidAdvanceWarningType , " +
                          " PaymentPlanTemplateId , " +
                          " PartialInvoiceType , " +
                          " PartId , " +
                          " OverrideDescription , " +
                          " FractionOfTotal , " +
                          " PaymentTermId , " +
                          " RowIndex , " +
                          " Part , " +
                          " PaymentTerm   " +
                          " ) " +

                          "values ( " +
                          tenant_id                                             + ", " +
                          Id                                                    + ", " +
                          "\"" + ((rec_obj.get("UnpaidAdvanceWarningType") == null)                ? 0 : rec_obj.get("UnpaidAdvanceWarningType") )                + "\" " + ", " +
                          "\"" + ((rec_obj.get("PaymentPlanTemplateId") == null)                   ? 0 : rec_obj.get("PaymentPlanTemplateId") )                   + "\" " + ", " +
                          "\"" + ((rec_obj.get("PartialInvoiceType") == null)                      ? 0 : rec_obj.get("PartialInvoiceType") )                      + "\" " + ", " +
                          "\"" + ((rec_obj.get("PartId") == null)                                  ? 0 : rec_obj.get("PartialInvoiceType") )                      + "\" " + ", " +
                          "\"" + ((rec_obj.get("OverrideDescription") == null)                     ? 0 : rec_obj.get("OverrideDescription") )                     + "\" " + ", " +
                          "\"" + ((rec_obj.get("FractionOfTotal") == null)                         ? 0 : rec_obj.get("FractionOfTotal") )                         + "\" " + ", " +
                          "\"" + ((rec_obj.get("PaymentTermId") == null)                           ? 0 : rec_obj.get("PaymentTermId") )                           + "\" " + ", " +
                          "\"" + ((rec_obj.get("RowIndex") == null)                                ? 0 : rec_obj.get("RowIndex") )                                + "\" " + ", " +
                          "\"" + ((rec_obj.get("Part") == null)                                    ? 0 : rec_obj.get("Part") )                                    + "\" " + ", " +
                          "\"" + ((rec_obj.get("PaymentTerm") == null)                             ? 0 : rec_obj.get("PaymentTerm") )                             + "\" " + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );
                      //  WriteLog.write(conf.getLogFile(), com_stmt, false);


                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "PaymentPlanTemplateRow was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getPaymentPlanTemplateRows






    public static String getPaymentPlanTemplates(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrders?$filter=isnotnull(StartDate)&StartDate%20Gt%20'2021-10-10'$skip=0&$top=50000&$orderby=Id%20desc" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Calendars" );

             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/PaymentPlanTemplates?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".paymentplantemplate where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".paymentplantemplate (tenant_id , id , " +
                          " PaymentPlanTemplateType , " +
                          " Number , " +
                          " DescriptionId , " +
                          " IsActive , " +
                          " InvoiceTextTypes , " +
                          " Description   " +
                          " ) " +

                          "values ( " +
                          tenant_id                                             + ", " +
                          Id                                                    + ", " +
                          "\"" + ((rec_obj.get("PaymentPlanTemplateType") == null)                ? 0 : rec_obj.get("PaymentPlanTemplateType") )                + "\" " + ", " +
                          "\"" + ((rec_obj.get("Number") == null)                                 ? 0 : rec_obj.get("Number") )                                 + "\" " + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                          ? 0 : rec_obj.get("DescriptionId") )                          + "\" " + ", " +
                          "\"" + ((rec_obj.get("IsActive") == "false")                            ? 0 : 1  )                                                    + "\" " + ", " +
                          "\"" + ((rec_obj.get("InvoiceTextTypes") == null)                       ? 0 : rec_obj.get("InvoiceTextTypes") )                       + "\" " + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                            ? 0 : rec_obj.get("Description") )                            + "\" " + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );
                      //  WriteLog.write(conf.getLogFile(), com_stmt, false);


                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "PaymentPlanTemplate was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getPaymentPlanTemplates












    public static String getUnits(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrders?$filter=isnotnull(StartDate)&StartDate%20Gt%20'2021-10-10'$skip=0&$top=50000&$orderby=Id%20desc" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/WorkCenters" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrderTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrderOperations?$filter=isnotnull(PlannedStartDate)&PlannedStartDate%20Gt%20'2021-10-10'$skip=0&$top=50$orderby=Id%20desc" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrderNodes?$filter=isnotnull(StartDate)&StartDate%20Gt%20'2021-10-10'$skip=0&$top=50$orderby=Id%20desc" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Calendars" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Countries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Currencies" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/CurrencyExchangeRates" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/DeliveryMethods" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/DeliveryTerms" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Departments" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/LanguageCodes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/PaymentMethods" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/PaymentTerms" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Units" );

             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Units?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".unit where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".unit (tenant_id , id , " +
                          " CodeId , " +
                          " DescriptionId , " +
                          " Number , " +
                          " IsoUnitCodeId , " +

                          " IsDefault , " +
                          " Code , " +
                          " Description  " +

                          " ) " +

                          "values ( " +
                          tenant_id                                             + ", " +
                          Id                                                    + ", " +
                          "\"" + ((null == null)                                                     ? 0 : 0 )                                                         + "\" " + ", " +    /* rec_obj.get("CodeId") */
                          "\"" + ((null == null)                                                     ? 0 : 0 )                                                         + "\" " + ", " +    /* rec_obj.get("DescriptionId") */
                           "\"" + ((rec_obj.get("Number") == null)                                    ? 0 : rec_obj.get("Number") )                                     + "\" " + ", " +
                          "\"" + ((null == null)                                                     ? 0 : 0 )                                                         + "\" " + ", " +    /* rec_obj.get("IsoUnitCodeId") */

                          "\"" + (("false" == "false")                                               ? 0 : 1 )                                                        + "\" " + ", " +     /* rec_obj.get("IsDefault") */
                           "\"" + ((rec_obj.get("Code") == null )                                     ? 0 : rec_obj.get("Code") )                                      + "\" " + ", " +
                           "\"" + ((rec_obj.get("Description") == null)                               ? 0 : rec_obj.get("Description") )                               + "\" " + "  " +

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );
                       // WriteLog.write(conf.getLogFile(), com_stmt, false);


                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Unit was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getUnits



      public static String getWarehouses(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrders?$filter=isnotnull(StartDate)&StartDate%20Gt%20'2021-10-10'$skip=0&$top=50000&$orderby=Id%20desc" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/WorkCenters" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrderTypes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrderOperations?$filter=isnotnull(PlannedStartDate)&PlannedStartDate%20Gt%20'2021-10-10'$skip=0&$top=50$orderby=Id%20desc" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Manufacturing/ManufacturingOrderNodes?$filter=isnotnull(StartDate)&StartDate%20Gt%20'2021-10-10'$skip=0&$top=50$orderby=Id%20desc" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Calendars" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Countries" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Currencies" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/CurrencyExchangeRates" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/DeliveryMethods" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/DeliveryTerms" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Departments" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/LanguageCodes" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/PaymentMethods" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/PaymentTerms" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Units" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Warehouses" );

             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/Warehouses?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";
             /*
     		 json += "\"Username\": "     +  "\"" +   conf.getUsername_sy()     +  "\" "  + ",\n" ;
		     json += "\"Password\": "     +  "\"" +   conf.getPassword_sy()     +  "\" "  + ",\n";
             json += "\"ForceRelogin\": " +           conf.getForceRelogin_sy()           + "\n";
		     json += "}";

    	     con.setDoOutput(true);
	         OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
	         wr.write( json );
	         wr.flush();
             */
             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );
     			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".warehouse where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();

                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".warehouse (tenant_id , id , " +
                          " CalendarId , " +
                          " MailingAddressId , " +
                          " VisitingAddressId , " +
                          " Name , " +
                          " Code , " +
                          " PlaceOfDispatch , " +
                          " VatNumber , " +
                          " ServiceTaxNumber , " +
                          " PalletRegistrationNumber , " +
                          " LanguageId , " +
                          " Url , " +
                          " PartnerCode , " +
                          " CountryId , " +
                          " TimeZone , " +
                          " CustomerId , " +
                          " SupplierId , " +
                          " GermanRegionCode , " +

                          " TimeZoneId  " +

                          " ) " +

                          "values ( " +
                          tenant_id                                             + ", " +
                          Id                                                    + ", " +
                           "\"" + ((rec_obj.get("CalendarId") == null)                                 ? 0 : rec_obj.get("CalendarId") )                                + "\" " + ", " +
                          "\"" + ((null == null)                                                      ? 0 : 0 )                                                        + "\" " + ", " +     /* rec_obj.get("MailingAddressId") */
                          "\"" + ((null == null)                                                      ? 0 : 0 )                                                        + "\" " + ", " +     /* rec_obj.get("VisitingAddressId") */
                           "\"" + ((rec_obj.get("Name") == null)                                       ? 0 : rec_obj.get("Name") )                                      + "\" " + ", " +
                           "\"" + ((rec_obj.get("Code") == null)                                       ? 0 : rec_obj.get("Code") )                                      + "\" " + ", " +
                           "\"" + ((rec_obj.get("PlaceOfDispatch") == null)                            ? 0 : rec_obj.get("PlaceOfDispatch") )                           + "\" " + ", " +
                           "\"" + ((rec_obj.get("VatNumber") == null)                                  ? 0 : rec_obj.get("VatNumber") )                                 + "\" " + ", " +
                          "\"" + ((null == null)                                                      ? 0 : 0 )                                                        + "\" " + ", " +     /* rec_obj.get("ServiceTaxNumber") */
                           "\"" + ((rec_obj.get("PalletRegistrationNumber") == null)                   ? 0 : rec_obj.get("PalletRegistrationNumber") )                  + "\" " + ", " +
                           "\"" + ((rec_obj.get("LanguageId") == null)                                 ? 0 : rec_obj.get("LanguageId") )                                + "\" " + ", " +
                           "\"" + ((rec_obj.get("Url") == null)                                        ? 0 : rec_obj.get("Url") )                                       + "\" " + ", " +
                          "\"" + ((null == null)                                                      ? 0 : 0 )                                                        + "\" " + ", " +     /* rec_obj.get("PartnerCode") */
                           "\"" + ((rec_obj.get("CountryId") == null)                                  ? 0 : rec_obj.get("CountryId") )                                 + "\" " + ", " +
                           "\"" + ((rec_obj.get("TimeZone") == null)                                   ? 0 : rec_obj.get("TimeZone") )                                  + "\" " + ", " +
                          "\"" + ((null == null)                                                      ? 0 : 0 )                                                        + "\" " + ", " +     /* rec_obj.get("CustomerId") */
                          "\"" + ((null == null)                                                      ? 0 : 0 )                                                        + "\" " + ", " +     /* rec_obj.get("SupplierId") */
                          "\"" + ((null == null)                                                      ? 0 : 0 )                                                        + "\" " + ", " +     /* rec_obj.get("GermanRegionCode") */

                           "\"" + ((rec_obj.get("TimeZoneId") == null)                                 ? 0 : rec_obj.get("TimeZoneId") )                                + "\" " + "  " +

                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );
                      //  WriteLog.write(conf.getLogFile(), com_stmt, false);


                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                           rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "Warehouse was imported from Monitor API to MySql. " + rs_count + " records "   , true);

   			     return Id   ;  // con   response

                }

        /*
        } catch (SQLException e) {
          WriteLog.write(conf.getLogFile(),
                         " SQL Error while inserting into database ");
          WriteLog.write(conf.getLogFile(), e.toString() + com_stmt, false);
        }
        */

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getWarehouses




    public static String getVatGroups(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/VatGroups?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".vatgroup where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".vatgroup (tenant_id , id , " +
                          " DescriptionId , " +
                          " Number , " +
                          " Code , " +
                          " DefaultVatRateForSalesId , " +
                          " DefaultVatRateForPurchaseId , " +
                          " Description   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                       ? 0 : rec_obj.get("DescriptionId")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Number") == null)                              ? 0 : rec_obj.get("Number")  )                            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Code") == null)                                ? 0 : rec_obj.get("Code")  )                              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DefaultVatRateForSalesId") == null)            ? 0 : rec_obj.get("DefaultVatRateForSalesId")  )          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DefaultVatRateForPurchaseId") == null)         ? 0 : rec_obj.get("DefaultVatRateForPurchaseId")  )       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                         ? 0 : rec_obj.get("Description")  )                       + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "VatGroup was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getVatGroups





    public static String getVatRates(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/VatRates?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".vatrate where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".vatrate (tenant_id , id , " +
                          " Number , " +
                          " TaxCode , " +
                          " IsoVatCodeId , " +
                          " Percentage , " +
                          " DescriptionId , " +
                          " ReversedTax , " +
                          " OutputVatAccountId , " +
                          " InputVatAccountId , " +
                          " Active , " +
                          " ReversedTaxPercentage , " +
                          " EstonianSpecialCodeA , " +
                          " EstonianSpecialCodeB , " +
                          " IncludeInEstonianAppendix , " +
                          " MalaysianDetailedVatColumn , " +
                          " ReferenceTextId , " +
                          " EcSalesType , " +
                          " Type , " +
                          " CodeType , " +
                          " SAFTStandardVatCodeId , " +
                          " LatvianVatSalesAppendix , " +
                          " LatvianVatSalesTransactionType , " +
                          " LatvianVatPurchaseAppendix , " +
                          " LatvianVatPurchaseTransactionType , " +
                          " LatvianVatDocumentType , " +
                          " DeductiblePercentage , " +
                          " InputVATNonDeductibleAccountId , " +
                          " Description , " +
                          " ReferenceText   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("Number") == null)                       ? 0 : rec_obj.get("Number")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("TaxCode") == null)                      ? 0 : rec_obj.get("TaxCode")  )                    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IsoVatCodeId") == null)                 ? 0 : rec_obj.get("IsoVatCodeId")  )               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Percentage") == null)                   ? 0 : rec_obj.get("Percentage")  )                 + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DescriptionId") == null)                ? 0 : rec_obj.get("DescriptionId")  )              + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReversedTax") == "false")               ? 0 : 1  )                                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("OutputVatAccountId") == null)           ? 0 : rec_obj.get("OutputVatAccountId")  )         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InputVatAccountId") == null)            ? 0 : rec_obj.get("InputVatAccountId")  )          + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Active") == "false")                    ? 0 : 1  )                                         + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReversedTaxPercentage") == null)        ? 0 : rec_obj.get("ReversedTaxPercentage")  )      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("EstonianSpecialCodeA") == null)         ? 0 : rec_obj.get("EstonianSpecialCodeA")  )       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("EstonianSpecialCodeB") == null)         ? 0 : rec_obj.get("EstonianSpecialCodeB")  )       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("IncludeInEstonianAppendix") == null)    ? 0 : rec_obj.get("IncludeInEstonianAppendix")  )  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("MalaysianDetailedVatColumn") == null)   ? 0 : rec_obj.get("MalaysianDetailedVatColumn")  ) + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReferenceTextId") == null)              ? 0 : rec_obj.get("ReferenceTextId")  )            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("EcSalesType") == null)                  ? 0 : rec_obj.get("EcSalesType")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Type") == null)                         ? 0 : rec_obj.get("Type")  )                       + "\" "    + ", " +
                          "\"" + ((rec_obj.get("CodeType") == null)                     ? 0 : rec_obj.get("CodeType")  )                   + "\" "    + ", " +
                          "\"" + ((rec_obj.get("SAFTStandardVatCodeId") == null)        ? 0 : rec_obj.get("SAFTStandardVatCodeId")  )      + "\" "    + ", " +
                          "\"" + ((rec_obj.get("LatvianVatSalesAppendix") == null)      ? 0 : rec_obj.get("LatvianVatSalesAppendix")  )    + "\" "    + ", " +
                          "\"" + ((rec_obj.get("LatvianVatSalesTransactionType") == null)         ? 0 : rec_obj.get("LatvianVatSalesTransactionType")  )        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("LatvianVatPurchaseAppendix") == null)             ? 0 : rec_obj.get("LatvianVatPurchaseAppendix")  )            + "\" "    + ", " +
                          "\"" + ((rec_obj.get("LatvianVatPurchaseTransactionType") == null)      ? 0 : rec_obj.get("LatvianVatPurchaseTransactionType")  )     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("LatvianVatDocumentType") == null)                 ? 0 : rec_obj.get("LatvianVatDocumentType")  )                + "\" "    + ", " +
                          "\"" + ((rec_obj.get("DeductiblePercentage") == null)                   ? 0 : rec_obj.get("DeductiblePercentage")  )                  + "\" "    + ", " +
                          "\"" + ((rec_obj.get("InputVATNonDeductibleAccountId") == null)         ? 0 : rec_obj.get("InputVATNonDeductibleAccountId")  )        + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Description") == null)                            ? 0 : rec_obj.get("Description")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("ReferenceText") == null)                          ? 0 : rec_obj.get("ReferenceText")  )                         + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "VatRate was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getVatRates




    public static String getWorkCenterManufacturingPrintSettings(ReadConf conf   ) throws Exception {
               // HttpURLConnection  , RestAPI rest
        Connection con_target  = RestAPI.getConnectionTarget( conf) ;
        String sessionId       = conf.getSessionId_sy() ;
        PreparedStatement stmt = null;
        String    com_stmt     = null;
        boolean   success      = false;
        ResultSet rs           = null;

        String    tenant_id    = conf.getTenant_id_my()      ;  // "100"
        String    DbName       = conf.getDbName_my()         ;  // "monitordb5"
        String    recordsLimit = conf.getRecordsLimit_sy()   ;  // "30000"
        String    Id           = ""  ;
        Integer   rs_count     = 0 ;

        try {
          // Selfsigned certificate start
          // java.security.cert.CertificateException: No subject alternative names present
          // Certificate name : WIN-20191002-1 get from FireFox Certifiates and import to Java/lib/Security/cacerts
          // java.io.IOException: HTTPS hostname wrong : should be <185.158.177.241>
          // java.lang.RuntimeException: HttpResponseCDode : 401


          javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
          new javax.net.ssl.HostnameVerifier(){

             public boolean verify(String hostname,
              javax.net.ssl.SSLSession sslSession) {
                 //return hostname.equals("localhost");
                 return hostname.equals( conf.getHost_sy() );  // "185.158.177.241"

               }
          });


          /*
          sslSocketFactory.setHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
              return true;
           }
          };
          */


            // Selfsigned certificate end

             // URL url             = new URL( conf.getUrl_sy() );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/api/v1/Common/Persons" );
             // URL url             = new URL( "https://185.158.177.241:8001/en/002_1.1/login" );
             URL url                = new URL( "https://" + conf.getHost_sy() + ":" + conf.getPort_sy() +
                                               "/" + conf.getLanguageCode_sy() + "/" + conf.getCompanyNumber_sy() +
                                               "/" + "api/v1/Common/WorkCenterManufacturingPrintSettings?$top=" + recordsLimit +"&$orderby=Id%20desc"
                                             );

             HttpURLConnection con  = (HttpURLConnection) url.openConnection();
             //HttpURLConnection con = (HttpURLConnection) new URL( conf.getUrl_sy() ).openConnection();

             System.setProperty("sun.net.http.allowRestrictedHeaders", "true") ;
             con.setRequestMethod( "GET" );  // "POST"   "GET"
             con.setRequestProperty("Host", conf.getHost_sy() );    // "185.158.177.241"
   	         con.setRequestProperty ("Content-Type", "application/json" );
   	         con.setRequestProperty ("Cache-Control", "no-cache" );
   	         con.setRequestProperty ("Accept", "application/json" );
   	         con.setRequestProperty ("X-Monitor-SessionId", sessionId );    // "f1bc5219-b382-472e-adc9-ff0926ecbbb0"

             System.out.println("Queries SessionId: " + sessionId  );

     	     String json = "{\n";

             con.connect();  // ???

             //Getting the response code
             int responsecode = con.getResponseCode();
             if (responsecode == 401) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 RestAPI.ChangeConf(conf);     // rest
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }


             if (responsecode != 200) {
                 System.out.println("Connection was wrong: " + responsecode  );
                 throw new RuntimeException("HttpResponseCode: " + responsecode );
                }
              else
                {String inline = "";
                 System.out.println("Connection was successful.");

                 String response = "";
         	     Scanner scanner = new Scanner(con.getInputStream() );


      			 while(scanner.hasNextLine()){
				  response += scanner.nextLine();
				  response += "\n";
			     }
			     scanner.close();

                 System.out.println( "response \n " + response );
                 WriteLog.write(conf.getLogFile(), response, false);

                 //Using the JSON simple library parse the string into a json object
                 JSONParser parser   = new JSONParser();
                 //JSONObject data_obj = (JSONObject) parser.parse( response ) ;
                 JSONArray data_obj = (JSONArray) parser.parse( response ) ;

                 //JSONObject data_obj = new JSONObject((String) parser.parse( response ) );
                 System.out.println("data_obj  \n " + data_obj );

                 // Delete old data
                 com_stmt = "Delete from  " + DbName + ".workcentermanufacturingprintsettings where tenant_id = " + tenant_id ;
                 System.out.println("executeUpdate: \n" + com_stmt );
                 stmt = con_target.prepareStatement( com_stmt );
                 stmt.executeUpdate();
                 stmt.close();


                 for (int i = 0; i < data_obj.size(); i++) {
                      JSONObject rec_obj = (JSONObject) data_obj.get(i);
                      Object obj   =  rec_obj.get("Id") ;
                      Id    = obj.toString() ;
                      // if (rec_obj.get("Id").equals("111") ) {
                      if (rec_obj.get("Id") != "111" ) {
                         System.out.println("Id: " + Id );

                         com_stmt =
                          "Insert into " + DbName + ".workcentermanufacturingprintsettings (tenant_id , id , " +
                          " WorkCenterId , " +
                          " Copies , " +
                          " PrintExternalDocuments , " +
                          " FormReportId   " +
                          " ) " +

                          "values ( " +
                          tenant_id                              + ", " +
                          Id                                     + ", " +
                          "\"" + ((rec_obj.get("WorkCenterId") == null)                       ? 0 : rec_obj.get("WorkCenterId")  )                     + "\" "    + ", " +
                          "\"" + ((rec_obj.get("Copies") == null)                             ? 0 : rec_obj.get("Copies")  )                           + "\" "    + ", " +
                          "\"" + ((rec_obj.get("PrintExternalDocuments") == "false")          ? 0 : 1  )                                               + "\" "    + ", " +
                          "\"" + ((rec_obj.get("FormReportId") == null)                       ? 0 : rec_obj.get("FormReportId")  )                     + "\" "    + "  " +
                          " )";

                          System.out.println("executeUpdate: \n" + com_stmt );

                          stmt = con_target.prepareStatement( com_stmt );  // lause
                          stmt.executeUpdate();

                          stmt.close();

                          rs_count = rs_count + 1 ;
                         // break;
                      }
                 }

                 WriteLog.write(conf.getLogFile(), "WorkCenterManufacturingPrintSettings was imported from Monitor API to MySql. " + rs_count + " records "   , true);


   			     return Id   ;  // con   response



                }

        } catch ( Exception e ) {
            e.printStackTrace();
            throw new Exception("Cannot find URL " +
                                 conf.getUrl_sy() + "\n" + e.toString() );
        }

    }   // getWorkCenterManufacturingPrintSettings










}  // Queries_COM
